import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Remotely configurable app settings.
 *
 * Values live ONLY in the `app_settings` table so they can be changed or
 * cleared from the Control Panel without an app release. There are no
 * hardcoded fallbacks: a missing/empty value resolves to "" and every UI that
 * consumes it must hide the corresponding element instead of rendering a
 * placeholder.
 */
export const APP_SETTING_KEYS = [
  "referral_signup_link",
  "referral_bonus_days",
  "support_email",
  "support_phone",
] as const;

export type AppSettingKey = (typeof APP_SETTING_KEYS)[number];
export type AppSettings = Record<AppSettingKey, string>;

export const EMPTY_APP_SETTINGS: AppSettings = APP_SETTING_KEYS.reduce((acc, k) => {
  acc[k] = "";
  return acc;
}, {} as AppSettings);

export type SocialLink = {
  id: string;
  platform: string;
  label: string | null;
  url: string;
};

let cache: AppSettings | null = null;
let inflight: Promise<AppSettings> | null = null;

let socialCache: SocialLink[] | null = null;
let socialInflight: Promise<SocialLink[]> | null = null;

export async function loadAppSettings(): Promise<AppSettings> {
  if (cache) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    const merged: AppSettings = { ...EMPTY_APP_SETTINGS };
    const { data } = await supabase.from("app_settings").select("key, value");
    for (const row of data ?? []) {
      if ((APP_SETTING_KEYS as readonly string[]).includes(row.key)) {
        merged[row.key as AppSettingKey] = (row.value ?? "").trim();
      }
    }
    cache = merged;
    inflight = null;
    return merged;
  })();
  return inflight;
}

export async function loadSocialLinks(): Promise<SocialLink[]> {
  if (socialCache) return socialCache;
  if (socialInflight) return socialInflight;
  socialInflight = (async () => {
    const { data } = await supabase
      .from("social_links")
      .select("id, platform, label, url, is_active, display_order")
      .eq("is_active", true)
      .order("display_order", { ascending: true });
    const rows = (data ?? [])
      .filter((r) => (r.url ?? "").trim().length > 0)
      .map((r) => ({
        id: r.id,
        platform: (r.platform ?? "").toLowerCase().trim(),
        label: r.label,
        url: (r.url ?? "").trim(),
      }));
    socialCache = rows;
    socialInflight = null;
    return rows;
  })();
  return socialInflight;
}

/** Clears the in-memory caches (used after Control Panel edits). */
export function resetAppSettingsCache() {
  cache = null;
  socialCache = null;
}

/** Reactive access to the central app settings. Empty string = not configured. */
export function useAppSettings(): AppSettings {
  const [settings, setSettings] = useState<AppSettings>(cache ?? EMPTY_APP_SETTINGS);
  useEffect(() => {
    let cancelled = false;
    void loadAppSettings().then((s) => {
      if (!cancelled) setSettings(s);
    });
    return () => {
      cancelled = true;
    };
  }, []);
  return settings;
}

/** Reactive access to the configured social links. Empty array = render nothing. */
export function useSocialLinks(): SocialLink[] {
  const [links, setLinks] = useState<SocialLink[]>(socialCache ?? []);
  useEffect(() => {
    let cancelled = false;
    void loadSocialLinks().then((l) => {
      if (!cancelled) setLinks(l);
    });
    return () => {
      cancelled = true;
    };
  }, []);
  return links;
}
