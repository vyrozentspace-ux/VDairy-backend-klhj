import { supabase } from "@/integrations/supabase/client";

export type MilkType = "cow" | "buffalo" | "mixed";
export type CalculationMode = "fat_snf" | "fat_only" | "total_solid";

export type RateChart = {
  id: string;
  center_id: string;
  milk_type: MilkType;
  chart_name: string;
  is_active: boolean;
  base_rate: number | null;
  fat_min: number;
  fat_max: number;
  fat_step: number;
  snf_min: number;
  snf_max: number;
  snf_step: number;
  created_at: string;
  updated_at: string;
};

export type RateChartRow = {
  id?: string;
  rate_chart_id?: string;
  fat_value: number;
  snf_value: number;
  rate: number;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export function stepsBetween(min: number, max: number, step: number): number[] {
  const out: number[] = [];
  if (step <= 0 || max < min) return out;
  const dec = Math.max(0, (step.toString().split(".")[1] ?? "").length);
  for (let v = min; v <= max + 1e-9; v += step) {
    out.push(Number(v.toFixed(dec)));
  }
  return out;
}

export function roundToStep(value: number, step: number, min: number, max: number): number {
  const clamped = Math.min(max, Math.max(min, value));
  const dec = Math.max(0, (step.toString().split(".")[1] ?? "").length);
  const snapped = Math.round((clamped - min) / step) * step + min;
  return Number(snapped.toFixed(dec));
}

export function generateMatrixRates(
  chart: {
    base_rate: number;
    fat_min: number;
    fat_max: number;
    fat_step: number;
    snf_min: number;
    snf_max: number;
    snf_step: number;
  },
  fatMultiplier = 1.5,
  snfMultiplier = 1.0,
): RateChartRow[] {
  const fats = stepsBetween(chart.fat_min, chart.fat_max, chart.fat_step);
  const snfs = stepsBetween(chart.snf_min, chart.snf_max, chart.snf_step);
  const rows: RateChartRow[] = [];
  for (const f of fats) {
    for (const s of snfs) {
      const rate =
        chart.base_rate + (f - chart.fat_min) * fatMultiplier + (s - chart.snf_min) * snfMultiplier;
      rows.push({ fat_value: f, snf_value: s, rate: Number(rate.toFixed(2)) });
    }
  }
  return rows;
}

export type RateSample = { fat: number; snf: number; rate: number };

/**
 * Build a full fat/SNF matrix from a handful of known sample rate points.
 * Least-squares plane fit (rate = a + b*fat + c*snf) plus inverse-distance
 * weighted residual correction, so cells near a sample match it closely while
 * everything in between varies smoothly.
 */
export function generateRatesFromSamples(
  chart: {
    fat_min: number;
    fat_max: number;
    fat_step: number;
    snf_min: number;
    snf_max: number;
    snf_step: number;
  },
  samples: RateSample[],
): RateChartRow[] {
  const pts = samples.filter(
    (s) => Number.isFinite(s.fat) && Number.isFinite(s.snf) && Number.isFinite(s.rate),
  );
  if (pts.length < 3) return [];

  const n = pts.length;
  const mean = (f: (s: RateSample) => number) => pts.reduce((a, s) => a + f(s), 0) / n;
  const mf = mean((s) => s.fat);
  const ms = mean((s) => s.snf);
  const mr = mean((s) => s.rate);

  let sff = 0,
    sss = 0,
    sfs = 0,
    sfr = 0,
    ssr = 0;
  for (const p of pts) {
    const df = p.fat - mf;
    const ds = p.snf - ms;
    const dr = p.rate - mr;
    sff += df * df;
    sss += ds * ds;
    sfs += df * ds;
    sfr += df * dr;
    ssr += ds * dr;
  }

  const det = sff * sss - sfs * sfs;
  let b = 0;
  let c = 0;
  if (Math.abs(det) > 1e-9) {
    b = (sss * sfr - sfs * ssr) / det;
    c = (sff * ssr - sfs * sfr) / det;
  } else {
    b = sff > 1e-9 ? sfr / sff : 0;
    c = sss > 1e-9 ? ssr / sss : 0;
  }
  const a = mr - b * mf - c * ms;

  const plane = (fat: number, snf: number) => a + b * fat + c * snf;
  const residuals = pts.map((p) => p.rate - plane(p.fat, p.snf));

  const fats = stepsBetween(chart.fat_min, chart.fat_max, chart.fat_step);
  const snfs = stepsBetween(chart.snf_min, chart.snf_max, chart.snf_step);
  const rows: RateChartRow[] = [];

  for (const f of fats) {
    for (const s of snfs) {
      let wsum = 0;
      let rsum = 0;
      let exact: number | null = null;
      for (let i = 0; i < pts.length; i++) {
        const d2 = (pts[i].fat - f) ** 2 + (pts[i].snf - s) ** 2;
        if (d2 < 1e-9) {
          exact = pts[i].rate;
          break;
        }
        const w = 1 / d2;
        wsum += w;
        rsum += w * residuals[i];
      }
      const value = exact !== null ? exact : plane(f, s) + (wsum > 0 ? rsum / wsum : 0);
      rows.push({ fat_value: f, snf_value: s, rate: Number(Math.max(0, value).toFixed(2)) });
    }
  }
  return rows;
}

export async function listRateCharts(centerId: string, milkType?: MilkType): Promise<RateChart[]> {
  let q = db
    .from("rate_charts")
    .select("*")
    .eq("center_id", centerId)
    .order("created_at", { ascending: false });
  if (milkType) q = q.eq("milk_type", milkType);
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return (data ?? []) as RateChart[];
}

export async function getRateChart(
  id: string,
): Promise<{ chart: RateChart; rows: RateChartRow[] }> {
  const { data: chart, error: e1 } = await db.from("rate_charts").select("*").eq("id", id).single();
  if (e1) throw new Error(e1.message);
  const { data: rows, error: e2 } = await db
    .from("rate_chart_rows")
    .select("*")
    .eq("rate_chart_id", id);
  if (e2) throw new Error(e2.message);
  return { chart: chart as RateChart, rows: (rows ?? []) as RateChartRow[] };
}

export async function activateChart(chart: RateChart) {
  const { error } = await db.from("rate_charts").update({ is_active: true }).eq("id", chart.id);
  if (error) throw new Error(error.message);
  await logActivity(chart.center_id, "rate_chart_activated", {
    id: chart.id,
    milk_type: chart.milk_type,
  });
}

export async function deactivateChart(chart: RateChart) {
  const { error } = await db.from("rate_charts").update({ is_active: false }).eq("id", chart.id);
  if (error) throw new Error(error.message);
}

export async function deleteChart(chart: RateChart) {
  const { error } = await db.from("rate_charts").delete().eq("id", chart.id);
  if (error) throw new Error(error.message);
  await logActivity(chart.center_id, "rate_chart_deleted", {
    id: chart.id,
    milk_type: chart.milk_type,
  });
}

export async function duplicateChart(chart: RateChart): Promise<string> {
  const { chart: full, rows } = await getRateChart(chart.id);
  const { data: created, error } = await db
    .from("rate_charts")
    .insert({
      center_id: full.center_id,
      milk_type: full.milk_type,
      chart_name: `${full.chart_name} (copy)`,
      is_active: false,
      base_rate: full.base_rate,
      fat_min: full.fat_min,
      fat_max: full.fat_max,
      fat_step: full.fat_step,
      snf_min: full.snf_min,
      snf_max: full.snf_max,
      snf_step: full.snf_step,
    })
    .select("id")
    .single();
  if (error) throw new Error(error.message);
  if (rows.length) {
    const payload = rows.map((r) => ({
      rate_chart_id: created.id,
      fat_value: r.fat_value,
      snf_value: r.snf_value,
      rate: r.rate,
    }));
    const { error: e2 } = await db.from("rate_chart_rows").insert(payload);
    if (e2) throw new Error(e2.message);
  }
  return created.id as string;
}

export async function saveChartWithRows(input: {
  id?: string;
  center_id: string;
  milk_type: MilkType;
  chart_name: string;
  is_active?: boolean;
  base_rate: number;
  fat_min: number;
  fat_max: number;
  fat_step: number;
  snf_min: number;
  snf_max: number;
  snf_step: number;
  rows: RateChartRow[];
}): Promise<string> {
  let chartId = input.id;
  if (chartId) {
    const { error } = await db
      .from("rate_charts")
      .update({
        chart_name: input.chart_name,
        base_rate: input.base_rate,
        fat_min: input.fat_min,
        fat_max: input.fat_max,
        fat_step: input.fat_step,
        snf_min: input.snf_min,
        snf_max: input.snf_max,
        snf_step: input.snf_step,
      })
      .eq("id", chartId);
    if (error) throw new Error(error.message);
    const { error: eDel } = await db.from("rate_chart_rows").delete().eq("rate_chart_id", chartId);
    if (eDel) throw new Error(eDel.message);
    await logActivity(input.center_id, "rate_chart_updated", { id: chartId });
  } else {
    const { data: created, error } = await db
      .from("rate_charts")
      .insert({
        center_id: input.center_id,
        milk_type: input.milk_type,
        chart_name: input.chart_name,
        is_active: input.is_active ?? false,
        base_rate: input.base_rate,
        fat_min: input.fat_min,
        fat_max: input.fat_max,
        fat_step: input.fat_step,
        snf_min: input.snf_min,
        snf_max: input.snf_max,
        snf_step: input.snf_step,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    chartId = created.id as string;
    await logActivity(input.center_id, "rate_chart_created", {
      id: chartId,
      milk_type: input.milk_type,
    });
  }

  if (input.rows.length) {
    const payload = input.rows.map((r) => ({
      rate_chart_id: chartId,
      fat_value: r.fat_value,
      snf_value: r.snf_value,
      rate: r.rate,
    }));
    // chunk large inserts to keep request size reasonable
    const CHUNK = 500;
    for (let i = 0; i < payload.length; i += CHUNK) {
      const { error } = await db.from("rate_chart_rows").insert(payload.slice(i, i + CHUNK));
      if (error) throw new Error(error.message);
    }
  }
  return chartId!;
}

async function logActivity(centerId: string, action: string, details: Record<string, unknown>) {
  try {
    const { data: userData } = await supabase.auth.getUser();
    await db.from("activity_logs").insert({
      center_id: centerId,
      user_id: userData.user?.id ?? null,
      action,
      details,
    });
  } catch {
    /* non-fatal */
  }
}

/** Look up rate for a given fat/snf reading against the active chart. */
export async function getRateForFatSnf(
  centerId: string,
  milkType: MilkType,
  fat: number,
  snf: number,
): Promise<{ rate: number | null; chart: RateChart | null; mode: CalculationMode }> {
  const { data: settings } = await db
    .from("center_collection_settings")
    .select("calculation_mode")
    .eq("center_id", centerId)
    .maybeSingle();
  const mode: CalculationMode = (settings?.calculation_mode as CalculationMode) ?? "fat_snf";

  const { data: chart } = await db
    .from("rate_charts")
    .select("*")
    .eq("center_id", centerId)
    .eq("milk_type", milkType)
    .eq("is_active", true)
    .maybeSingle();
  if (!chart) return { rate: null, chart: null, mode };

  const c = chart as RateChart;
  const fatKey = roundToStep(fat, c.fat_step, c.fat_min, c.fat_max);

  if (mode === "fat_only") {
    const { data } = await db
      .from("rate_chart_rows")
      .select("rate")
      .eq("rate_chart_id", c.id)
      .eq("fat_value", fatKey);
    const rates = (data ?? []).map((r: { rate: number }) => Number(r.rate));
    if (!rates.length) return { rate: c.base_rate, chart: c, mode };
    const avg = rates.reduce((a: number, b: number) => a + b, 0) / rates.length;
    return { rate: Number(avg.toFixed(2)), chart: c, mode };
  }

  if (mode === "total_solid") {
    const total = fat + snf;
    const { data } = await db.from("rate_chart_rows").select("*").eq("rate_chart_id", c.id);
    if (!data?.length) return { rate: c.base_rate, chart: c, mode };
    let best: RateChartRow | null = null;
    let bestDiff = Infinity;
    for (const r of data as RateChartRow[]) {
      const d = Math.abs(r.fat_value + r.snf_value - total);
      if (d < bestDiff) {
        bestDiff = d;
        best = r;
      }
    }
    return { rate: best ? Number(best.rate) : c.base_rate, chart: c, mode };
  }

  // fat_snf default
  const snfKey = roundToStep(snf, c.snf_step, c.snf_min, c.snf_max);
  const { data: row } = await db
    .from("rate_chart_rows")
    .select("rate")
    .eq("rate_chart_id", c.id)
    .eq("fat_value", fatKey)
    .eq("snf_value", snfKey)
    .maybeSingle();
  return { rate: row ? Number(row.rate) : c.base_rate, chart: c, mode };
}
