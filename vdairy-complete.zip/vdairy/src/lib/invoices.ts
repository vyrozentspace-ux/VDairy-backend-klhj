import { supabase } from "@/integrations/supabase/client";
import { formatDayMonthYear, formatNumericDate } from "@/lib/date-locale";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export type InvoiceStatus = "Unpaid" | "Paid";

export type Invoice = {
  id: string;
  center_id: string;
  farmer_id: string;
  invoice_number: number;
  period_start: string;
  period_end: string;
  total_liter: number;
  total_milk_amount: number;
  total_feed_amount: number;
  total_advance_given: number;
  total_deduction: number;
  previous_balance: number;
  amount_due: number;
  new_balance: number;
  status: InvoiceStatus;
  paid_at: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

export type InvoiceDeductionRow = {
  id: string;
  invoice_id: string;
  deduction_type: string;
  deduction_amount: number;
  balance_after: number;
  deposit: number;
  created_at: string;
};

export type InvoicePayment = {
  id: string;
  invoice_id: string;
  farmer_id: string;
  amount: number;
  payment_number_used: string | null;
  upi_uri: string | null;
  status: "Initiated" | "Confirmed" | "Failed";
  initiated_by: string | null;
  created_at: string;
};

/** Compute default tercile period for a date: 1-10, 11-20, 21-end. */
export function defaultTercilePeriod(d = new Date()): { start: string; end: string } {
  const y = d.getFullYear();
  const m = d.getMonth();
  const day = d.getDate();
  const pad = (n: number) => String(n).padStart(2, "0");
  const iso = (yr: number, mo: number, dy: number) => `${yr}-${pad(mo + 1)}-${pad(dy)}`;
  const lastDay = new Date(y, m + 1, 0).getDate();
  if (day <= 10) return { start: iso(y, m, 1), end: iso(y, m, 10) };
  if (day <= 20) return { start: iso(y, m, 11), end: iso(y, m, 20) };
  return { start: iso(y, m, 21), end: iso(y, m, lastDay) };
}

export function monthTerciles(d = new Date()): { start: string; end: string; label: string }[] {
  const y = d.getFullYear();
  const m = d.getMonth();
  const pad = (n: number) => String(n).padStart(2, "0");
  const iso = (dy: number) => `${y}-${pad(m + 1)}-${pad(dy)}`;
  const lastDay = new Date(y, m + 1, 0).getDate();
  return [
    { start: iso(1), end: iso(10), label: "1–10" },
    { start: iso(11), end: iso(20), label: "11–20" },
    { start: iso(21), end: iso(lastDay), label: `21–${lastDay}` },
  ];
}

export function fmtDMY(iso: string): string {
  return formatNumericDate(iso);
}

export function fmtDMYShort(iso: string): string {
  return formatDayMonthYear(iso);
}

export async function generateInvoice(input: {
  centerId: string;
  farmerId: string;
  periodStart: string;
  periodEnd: string;
  createdBy: string | null;
}): Promise<string> {
  const { data, error } = await db.rpc("generate_invoice", {
    p_center_id: input.centerId,
    p_farmer_id: input.farmerId,
    p_period_start: input.periodStart,
    p_period_end: input.periodEnd,
    p_created_by: input.createdBy,
  });
  if (error) throw new Error(error.message);
  return data as string;
}

export async function confirmInvoicePayment(paymentId: string): Promise<void> {
  const { error } = await db.rpc("confirm_invoice_payment", { p_invoice_payment_id: paymentId });
  if (error) throw new Error(error.message);
}

export async function listInvoices(
  centerId: string,
  opts: { farmerId?: string; from?: string; to?: string } = {},
): Promise<Invoice[]> {
  let q = db
    .from("invoices")
    .select("*")
    .eq("center_id", centerId)
    .order("period_end", { ascending: false });
  if (opts.farmerId) q = q.eq("farmer_id", opts.farmerId);
  if (opts.from) q = q.gte("period_start", opts.from);
  if (opts.to) q = q.lte("period_end", opts.to);
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return (data ?? []) as Invoice[];
}

export async function getInvoice(id: string): Promise<Invoice | null> {
  const { data, error } = await db.from("invoices").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? null) as Invoice | null;
}

export async function listInvoiceDeductions(invoiceId: string): Promise<InvoiceDeductionRow[]> {
  const { data, error } = await db
    .from("invoice_deductions")
    .select("*")
    .eq("invoice_id", invoiceId)
    .order("created_at");
  if (error) throw new Error(error.message);
  return (data ?? []) as InvoiceDeductionRow[];
}

export async function markInvoicePaid(id: string): Promise<void> {
  const { error } = await db.rpc("mark_invoice_paid", { p_invoice_id: id });
  if (error) throw new Error(error.message);
}

export async function markInvoiceUnpaid(id: string): Promise<void> {
  const { error } = await db.rpc("mark_invoice_unpaid", { p_invoice_id: id });
  if (error) throw new Error(error.message);
}

export async function deleteInvoice(id: string): Promise<void> {
  const { error } = await db.from("invoices").delete().eq("id", id);
  if (error) throw new Error(error.message);
}

export async function createInvoicePayment(input: {
  invoiceId: string;
  farmerId: string;
  amount: number;
  paymentNumberUsed: string | null;
  upiUri: string | null;
  initiatedBy: string | null;
}): Promise<string> {
  const { data, error } = await db
    .from("invoice_payments")
    .insert({
      invoice_id: input.invoiceId,
      farmer_id: input.farmerId,
      amount: input.amount,
      payment_number_used: input.paymentNumberUsed,
      upi_uri: input.upiUri,
      initiated_by: input.initiatedBy,
    })
    .select("id")
    .single();
  if (error) throw new Error(error.message);
  return data.id as string;
}

export async function logInvoice(
  centerId: string,
  userId: string | null,
  action: string,
  details: Record<string, unknown>,
) {
  try {
    await db
      .from("activity_logs")
      .insert({ center_id: centerId, user_id: userId, action, details });
  } catch {
    /* non-fatal */
  }
}

/** Compute a live preview of totals for a farmer + period without inserting a row. */
export async function computePreview(input: {
  centerId: string;
  farmerId: string;
  periodStart: string;
  periodEnd: string;
}): Promise<{
  total_liter: number;
  total_milk_amount: number;
  total_feed_amount: number;
  manual_deductions: number;
  total_deduction: number;
  total_advance_given: number;
  previous_balance: number;
  amount_due: number;
  new_balance: number;
}> {
  const [cols, feeds, deds, advs, prevRes, pendingRes] = await Promise.all([
    db
      .from("collections")
      .select("quantity_liters,total_amount")
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .gte("collection_date", input.periodStart)
      .lte("collection_date", input.periodEnd),
    db
      .from("farmer_feed_sales")
      .select("amount,cash_payment")
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .eq("is_settled", false)
      .gte("sale_date", input.periodStart)
      .lte("sale_date", input.periodEnd),
    db
      .from("advance_deductions")
      .select("amount")
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .gte("deduction_date", input.periodStart)
      .lte("deduction_date", input.periodEnd),
    db
      .from("advances")
      .select("amount")
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .gte("advance_date", input.periodStart)
      .lte("advance_date", input.periodEnd),
    db.rpc("farmer_last_invoice_balance", { p_farmer_id: input.farmerId }),
    // EMI instalment that generate_invoice will book for this period (not yet stored).
    db.rpc("pending_installment_for_period", {
      p_center_id: input.centerId,
      p_farmer_id: input.farmerId,
      p_period_start: input.periodStart,
      p_period_end: input.periodEnd,
    }),
  ]);
  const total_liter = (cols.data ?? []).reduce(
    (s: number, r: { quantity_liters: number }) => s + Number(r.quantity_liters),
    0,
  );
  const total_milk_amount = (cols.data ?? []).reduce(
    (s: number, r: { total_amount: number }) => s + Number(r.total_amount),
    0,
  );
  const total_feed_amount = (feeds.data ?? [])
    .filter((r: { cash_payment: boolean }) => !r.cash_payment)
    .reduce((s: number, r: { amount: number }) => s + Number(r.amount), 0);
  const booked_deductions = (deds.data ?? []).reduce(
    (s: number, r: { amount: number }) => s + Number(r.amount),
    0,
  );
  const manual_deductions = booked_deductions + Number(pendingRes.data ?? 0);
  const total_advance_given = (advs.data ?? []).reduce(
    (s: number, r: { amount: number }) => s + Number(r.amount),
    0,
  );
  const previous_balance = Number(prevRes.data ?? 0);
  const total_deduction = total_feed_amount + manual_deductions;
  const amount_due = Math.max(total_milk_amount - total_deduction, 0);
  const new_balance = previous_balance + total_milk_amount - total_deduction - total_advance_given;
  return {
    total_liter,
    total_milk_amount,
    total_feed_amount,
    manual_deductions,
    total_deduction,
    total_advance_given,
    previous_balance,
    amount_due,
    new_balance,
  };
}

/** Full itemized detail behind an invoice/receipt for a farmer + period. */
export type ReceiptDetail = {
  collections: {
    id: string;
    collection_date: string;
    shift: string;
    milk_type: string;
    fat: number;
    snf: number | null;
    quantity_liters: number;
    rate_per_liter: number;
    total_amount: number;
  }[];
  feedSales: {
    id: string;
    sale_date: string;
    product_name: string;
    quantity: number;
    rate: number;
    amount: number;
  }[];
  advanceDeductions: {
    id: string;
    deduction_date: string;
    amount: number;
    comments: string | null;
  }[];
  advancesGiven: { id: string; advance_date: string; amount: number; comments: string | null }[];
};

export async function fetchReceiptDetail(input: {
  centerId: string;
  farmerId: string;
  periodStart: string;
  periodEnd: string;
}): Promise<ReceiptDetail> {
  const [cols, feeds, deds, advs, prods] = await Promise.all([
    db
      .from("collections")
      .select(
        "id,collection_date,shift,milk_type,fat,snf,quantity_liters,rate_per_liter,total_amount",
      )
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .gte("collection_date", input.periodStart)
      .lte("collection_date", input.periodEnd)
      .order("collection_date")
      .order("shift"),
    db
      .from("farmer_feed_sales")
      .select("id,sale_date,feed_product_id,quantity,rate,amount")
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .eq("cash_payment", false)
      .gte("sale_date", input.periodStart)
      .lte("sale_date", input.periodEnd)
      .order("sale_date"),
    db
      .from("advance_deductions")
      .select("id,deduction_date,amount,comments")
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .gte("deduction_date", input.periodStart)
      .lte("deduction_date", input.periodEnd)
      .order("deduction_date"),
    db
      .from("advances")
      .select("id,advance_date,amount,comments")
      .eq("center_id", input.centerId)
      .eq("farmer_id", input.farmerId)
      .gte("advance_date", input.periodStart)
      .lte("advance_date", input.periodEnd)
      .order("advance_date"),
    db.from("feed_products").select("id,product_name").eq("center_id", input.centerId),
  ]);
  const pmap: Record<string, string> = {};
  for (const p of (prods.data ?? []) as { id: string; product_name: string }[])
    pmap[p.id] = p.product_name;
  return {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    collections: (cols.data ?? []) as any,
    feedSales: (
      (feeds.data ?? []) as {
        id: string;
        sale_date: string;
        feed_product_id: string;
        quantity: number;
        rate: number;
        amount: number;
      }[]
    ).map((s) => ({
      id: s.id,
      sale_date: s.sale_date,
      product_name: pmap[s.feed_product_id] ?? "Feed",
      quantity: Number(s.quantity),
      rate: Number(s.rate),
      amount: Number(s.amount),
    })),
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    advanceDeductions: (deds.data ?? []) as any,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    advancesGiven: (advs.data ?? []) as any,
  };
}

/** Find farmers with ANY activity in a period. */
export async function farmersWithActivity(
  centerId: string,
  periodStart: string,
  periodEnd: string,
): Promise<Set<string>> {
  const [cols, feeds, advs, deds] = await Promise.all([
    db
      .from("collections")
      .select("farmer_id")
      .eq("center_id", centerId)
      .gte("collection_date", periodStart)
      .lte("collection_date", periodEnd),
    db
      .from("farmer_feed_sales")
      .select("farmer_id")
      .eq("center_id", centerId)
      .gte("sale_date", periodStart)
      .lte("sale_date", periodEnd),
    db
      .from("advances")
      .select("farmer_id")
      .eq("center_id", centerId)
      .gte("advance_date", periodStart)
      .lte("advance_date", periodEnd),
    db
      .from("advance_deductions")
      .select("farmer_id")
      .eq("center_id", centerId)
      .gte("deduction_date", periodStart)
      .lte("deduction_date", periodEnd),
  ]);
  const out = new Set<string>();
  for (const src of [cols.data, feeds.data, advs.data, deds.data]) {
    for (const r of (src ?? []) as { farmer_id: string }[]) out.add(r.farmer_id);
  }
  return out;
}
