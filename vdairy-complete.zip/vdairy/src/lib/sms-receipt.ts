// Auto-SMS receipt helpers.
// Builds a plain-text receipt in the user's chosen "Receipt Language" and
// opens the phone's native SMS app pre-filled and addressed to the farmer.

import { APP_LANG_KEY } from "@/lib/i18n";

export const RECEIPT_LANG_KEY = "vdairy.receiptLanguage";

export type ReceiptLang = "en" | "hi" | "mr" | "ta" | "te";

const SUPPORTED: ReceiptLang[] = ["en", "hi", "mr", "ta", "te"];

const isSupported = (v: string | null): v is ReceiptLang =>
  !!v && (SUPPORTED as string[]).includes(v);

/** True when the user explicitly picked a Receipt Language. */
export function hasExplicitReceiptLang(): boolean {
  if (typeof window === "undefined") return false;
  return isSupported(window.localStorage.getItem(RECEIPT_LANG_KEY));
}

/**
 * Receipt Language.
 * - If the user explicitly picked one, that always wins.
 * - Otherwise it mirrors the current App Language.
 */
export function getReceiptLang(): ReceiptLang {
  if (typeof window === "undefined") return "en";
  const explicit = window.localStorage.getItem(RECEIPT_LANG_KEY);
  if (isSupported(explicit)) return explicit;
  const app = window.localStorage.getItem(APP_LANG_KEY);
  return isSupported(app) ? app : "en";
}

/** Clear the explicit choice so receipts follow the App Language again. */
export function clearReceiptLang() {
  if (typeof window !== "undefined") window.localStorage.removeItem(RECEIPT_LANG_KEY);
}

type Dict = {
  collectionTitle: string;
  invoiceTitle: string;
  date: string;
  session: string;
  morning: string;
  evening: string;
  fat: string;
  snf: string;
  liters: string;
  rate: string;
  amount: string;
  period: string;
  totalLiters: string;
  milkAmount: string;
  deductions: string;
  feed: string;
  advance: string;
  amountPaid: string;
  balanceRemaining: string;
  cattleFeeds: string;
  qty: string;
  total: string;
  previousBalance: string;
  advanceGiven: string;
  summary: string;
  closing: string;
  promo: string;
};

const DICT: Record<ReceiptLang, Dict> = {
  en: {
    collectionTitle: "Milk Collection Receipt",
    invoiceTitle: "Invoice Payment Receipt",
    date: "Date",
    session: "Session",
    morning: "Morning",
    evening: "Evening",
    fat: "Fat",
    snf: "SNF",
    liters: "Litres",
    rate: "Rate",
    amount: "Amount",
    period: "Period",
    totalLiters: "Total Litres",
    milkAmount: "Milk Amount",
    deductions: "Deductions",
    feed: "Feed",
    advance: "Advance",
    amountPaid: "Amount Paid",
    balanceRemaining: "Balance Remaining",
    cattleFeeds: "Cattle Feeds",
    qty: "Qty",
    total: "Total",
    previousBalance: "Previous Balance",
    advanceGiven: "Advance Given",
    summary: "Summary",
    closing: "Thank you for your milk supply!",
    promo: "VDairy — smart dairy management. Powered by VDairy.",
  },
  hi: {
    collectionTitle: "दूध संग्रह रसीद",
    invoiceTitle: "बिल भुगतान रसीद",
    date: "दिनांक",
    session: "सत्र",
    morning: "सुबह",
    evening: "शाम",
    fat: "फैट",
    snf: "एसएनएफ",
    liters: "लीटर",
    rate: "दर",
    amount: "राशि",
    period: "अवधि",
    totalLiters: "कुल लीटर",
    milkAmount: "दूध राशि",
    deductions: "कटौती",
    feed: "पशु आहार",
    advance: "अग्रिम",
    amountPaid: "भुगतान राशि",
    balanceRemaining: "शेष राशि",
    cattleFeeds: "पशु आहार",
    qty: "मात्रा",
    total: "कुल",
    previousBalance: "पिछला शेष",
    advanceGiven: "दिया गया अग्रिम",
    summary: "सारांश",
    closing: "दूध आपूर्ति के लिए धन्यवाद!",
    promo: "VDairy — स्मार्ट डेयरी प्रबंधन। VDairy द्वारा संचालित।",
  },
  mr: {
    collectionTitle: "दूध संकलन पावती",
    invoiceTitle: "बिल भरणा पावती",
    date: "दिनांक",
    session: "सत्र",
    morning: "सकाळ",
    evening: "संध्याकाळ",
    fat: "फॅट",
    snf: "एसएनएफ",
    liters: "लिटर",
    rate: "दर",
    amount: "रक्कम",
    period: "कालावधी",
    totalLiters: "एकूण लिटर",
    milkAmount: "दूध रक्कम",
    deductions: "वजावट",
    feed: "पशुखाद्य",
    advance: "उचल",
    amountPaid: "दिलेली रक्कम",
    balanceRemaining: "शिल्लक रक्कम",
    cattleFeeds: "पशुखाद्य",
    qty: "प्रमाण",
    total: "एकूण",
    previousBalance: "मागील शिल्लक",
    advanceGiven: "दिलेली उचल",
    summary: "सारांश",
    closing: "दूध पुरवठ्याबद्दल धन्यवाद!",
    promo: "VDairy — स्मार्ट डेअरी व्यवस्थापन. VDairy द्वारा संचालित.",
  },
  ta: {
    collectionTitle: "பால் சேகரிப்பு ரசீது",
    invoiceTitle: "பில் செலுத்துகை ரசீது",
    date: "தேதி",
    session: "அமர்வு",
    morning: "காலை",
    evening: "மாலை",
    fat: "கொழுப்பு",
    snf: "எஸ்என்எஃப்",
    liters: "லிட்டர்",
    rate: "விலை",
    amount: "தொகை",
    period: "காலம்",
    totalLiters: "மொத்த லிட்டர்",
    milkAmount: "பால் தொகை",
    deductions: "கழிப்புகள்",
    feed: "தீவனம்",
    advance: "முன்பணம்",
    amountPaid: "செலுத்திய தொகை",
    balanceRemaining: "மீதமுள்ள இருப்பு",
    cattleFeeds: "கால்நடை தீவனம்",
    qty: "அளவு",
    total: "மொத்தம்",
    previousBalance: "முந்தைய இருப்பு",
    advanceGiven: "வழங்கிய முன்பணம்",
    summary: "சுருக்கம்",
    closing: "பால் வழங்கியதற்கு நன்றி!",
    promo: "VDairy — ஸ்மார்ட் பால் மேலாண்மை. VDairy மூலம் இயக்கப்படுகிறது.",
  },
  te: {
    collectionTitle: "పాల సేకరణ రసీదు",
    invoiceTitle: "బిల్లు చెల్లింపు రసీదు",
    date: "తేదీ",
    session: "సెషన్",
    morning: "ఉదయం",
    evening: "సాయంత్రం",
    fat: "ఫ్యాట్",
    snf: "ఎస్ఎన్ఎఫ్",
    liters: "లీటర్లు",
    rate: "ధర",
    amount: "మొత్తం",
    period: "కాలం",
    totalLiters: "మొత్తం లీటర్లు",
    milkAmount: "పాల మొత్తం",
    deductions: "మినహాయింపులు",
    feed: "దాణా",
    advance: "అడ్వాన్స్",
    amountPaid: "చెల్లించిన మొత్తం",
    balanceRemaining: "మిగిలిన బ్యాలెన్స్",
    cattleFeeds: "పశు దాణా",
    qty: "పరిమాణం",
    total: "మొత్తం",
    previousBalance: "మునుపటి బ్యాలెన్స్",
    advanceGiven: "ఇచ్చిన అడ్వాన్స్",
    summary: "సారాంశం",
    closing: "పాల సరఫరాకు ధన్యవాదాలు!",
    promo: "VDairy — స్మార్ట్ డెయిరీ నిర్వహణ. VDairy ద్వారా అందించబడింది.",
  },
};

/** Public accessor so callers can label a receipt in the Receipt Language. */
export function receiptDict(lang?: ReceiptLang): Dict {
  return DICT[lang ?? getReceiptLang()];
}

const money = (n: number) => `₹${Number(n).toFixed(2)}`;

export function collectionSmsText(input: {
  lang?: ReceiptLang;
  centerName: string;
  farmerName: string;
  farmerCode?: string | null;
  date: string;
  shift: string;
  fat: string | number;
  snf?: string | number | null;
  liters: number;
  rate: number;
  amount: number;
}): string {
  const t = DICT[input.lang ?? getReceiptLang()];
  const shiftLabel = /^m/i.test(input.shift) ? t.morning : t.evening;
  const lines = [
    `${input.centerName} — ${t.collectionTitle}`,
    `${input.farmerName}${input.farmerCode ? ` (${input.farmerCode})` : ""}`,
    `${t.date}: ${input.date}`,
    `${t.session}: ${shiftLabel}`,
    `${t.fat}: ${input.fat}`,
    ...(input.snf !== null && input.snf !== undefined && input.snf !== ""
      ? [`${t.snf}: ${input.snf}`]
      : []),
    `${t.liters}: ${Number(input.liters).toFixed(2)}`,
    `${t.rate}: ${money(input.rate)}`,
    `${t.amount}: ${money(input.amount)}`,
    "",
    t.promo,
  ];
  return lines.join("\n");
}

export type SmsCollectionLine = {
  date: string;
  shift: string;
  fat: string | number;
  snf?: string | number | null;
  liters: number;
  rate: number;
  amount: number;
};

export type SmsDeductionLine = { label: string; amount: number };
export type SmsFeedLine = {
  date: string;
  product: string;
  qty: number;
  rate: number;
  amount: number;
};
export type SmsAdvanceLine = { date: string; comments?: string | null; amount: number };

export function invoiceSmsText(input: {
  lang?: ReceiptLang;
  centerName: string;
  farmerName: string;
  farmerCode?: string | null;
  periodStart: string;
  periodEnd: string;
  totalLiters: number;
  milkAmount: number;
  feedDeduction: number;
  advanceDeduction: number;
  totalDeduction: number;
  amountPaid: number;
  newBalance: number;
  previousBalance?: number;
  advanceGiven?: number;
  /** Every collection in the period — rendered line by line when provided. */
  collections?: SmsCollectionLine[];
  /** Itemized feed sales taken as deductions in the period. */
  feedItems?: SmsFeedLine[];
  /** Itemized feed / advance deductions taken in the period. */
  deductionItems?: SmsDeductionLine[];
  /** Advances handed to the farmer during the period. */
  advanceItems?: SmsAdvanceLine[];
}): string {
  const t = DICT[input.lang ?? getReceiptLang()];

  // Compact receipts drop the year from itemized rows (it is already in the
  // period header) so each collection stays on a single SMS line.
  const short = (d: string) => d.replace(/^(\d{1,2}\/\d{1,2})\/\d{2,4}$/, "$1");
  const num = (n: number, dp = 2) => Number(n).toFixed(dp);

  // e.g. "22/07 E 8.00L F4.0 S8.4 @34.00 = ₹272.00"
  const collectionLines = (input.collections ?? []).map((c) => {
    const shiftLabel = (/^m/i.test(c.shift) ? t.morning : t.evening).slice(0, 1).toUpperCase();
    const snf = c.snf !== null && c.snf !== undefined && c.snf !== "" ? ` S${c.snf}` : "";
    return `${short(c.date)} ${shiftLabel} ${num(c.liters)}L F${c.fat}${snf} @${num(c.rate)} = ${money(c.amount)}`;
  });

  const feedLines = (input.feedItems ?? []).map(
    (f) => `${short(f.date)} ${f.product} ${num(f.qty, 1)} @${num(f.rate)} = ${money(f.amount)}`,
  );

  const items: string[] =
    input.deductionItems && input.deductionItems.length
      ? input.deductionItems.map(
          (d) => `- ${d.label.replace(/(\d{1,2}\/\d{1,2})\/\d{2,4}/g, "$1")} ${money(d.amount)}`,
        )
      : [
          ...(input.feedDeduction > 0 ? [`- ${t.feed} ${money(input.feedDeduction)}`] : []),
          ...(input.advanceDeduction > 0
            ? [`- ${t.advance} ${money(input.advanceDeduction)}`]
            : []),
        ];

  const advanceLines = (input.advanceItems ?? []).map(
    (a) => `${short(a.date)}${a.comments ? ` ${a.comments}` : ""} ${money(a.amount)}`,
  );

  const prev = Number(input.previousBalance ?? 0);
  const advGiven = Number(input.advanceGiven ?? 0);

  const lines = [
    `${input.centerName} — ${t.invoiceTitle}`,
    `${input.farmerName}${input.farmerCode ? ` (${input.farmerCode})` : ""}`,
    `${short(input.periodStart)} - ${input.periodEnd}`,
    "",
    ...(collectionLines.length
      ? [
          `${t.collectionTitle} (${collectionLines.length}):`,
          ...collectionLines,
          `${t.total}: ${num(input.totalLiters)}L = ${money(input.milkAmount)}`,
          "",
        ]
      : [`${t.milkAmount}: ${num(input.totalLiters)}L = ${money(input.milkAmount)}`, ""]),
    ...(feedLines.length
      ? [`${t.cattleFeeds}:`, ...feedLines, `${t.total}: ${money(input.feedDeduction)}`, ""]
      : []),
    ...(advanceLines.length
      ? [`${t.advanceGiven}:`, ...advanceLines, `${t.total}: ${money(advGiven)}`, ""]
      : []),
    ...(input.totalDeduction > 0.001
      ? [`${t.deductions}: ${money(input.totalDeduction)}`, ...items]
      : []),
    ...(Math.abs(prev) > 0.001 ? [`${t.previousBalance}: ${money(prev)}`] : []),
    `${t.balanceRemaining}: ${input.newBalance < 0 ? "-" : ""}${money(Math.abs(input.newBalance))}`,
    "",
    t.closing,
    t.promo,
  ];
  return lines.join("\n");
}

/**
 * Open the native SMS composer pre-filled with `text`, addressed to `mobile`.
 * Uses an anchor click so it works reliably on iOS/Android browsers.
 */
export function openSmsApp(mobile: string | null | undefined, text: string): boolean {
  if (typeof window === "undefined") return false;
  const digits = (mobile ?? "").replace(/[^\d+]/g, "");
  if (!digits) return false;
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const sep = isIOS ? "&" : "?";
  const href = `sms:${digits}${sep}body=${encodeURIComponent(text)}`;
  try {
    const a = document.createElement("a");
    a.href = href;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => a.remove(), 0);
    return true;
  } catch {
    try {
      window.location.href = href;
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Build the full itemized invoice SMS from the raw receipt detail rows.
 * Used by both the invoice list (quick "Paid") and the full receipt view so
 * the auto-sent text is identical everywhere.
 */
export function buildInvoiceSmsFromDetail(input: {
  lang?: ReceiptLang;
  centerName: string;
  farmerName: string;
  farmerCode?: string | null;
  periodStart: string;
  periodEnd: string;
  fmtDate: (iso: string) => string;
  detail: {
    collections: {
      collection_date: string;
      shift: string;
      milk_type?: string;
      fat: number;
      snf: number | null;
      quantity_liters: number;
      rate_per_liter: number;
      total_amount: number;
    }[];
    feedSales: {
      sale_date: string;
      product_name: string;
      quantity?: number;
      rate?: number;
      amount: number;
    }[];
    advanceDeductions: { deduction_date: string; amount: number; comments?: string | null }[];
    advancesGiven?: { advance_date: string; amount: number; comments?: string | null }[];
  };
  totals: {
    total_liter: number;
    total_milk_amount: number;
    total_feed_amount: number;
    manual_deductions: number;
    total_deduction: number;
    total_advance_given?: number;
    previous_balance?: number;
    amount_due: number;
    new_balance: number;
  };
}): string {
  const lang = input.lang ?? getReceiptLang();
  const d = DICT[lang];
  const bookedAdvance = input.detail.advanceDeductions.reduce((s, a) => s + Number(a.amount), 0);
  const residualAdvance = Number(input.totals.manual_deductions) - bookedAdvance;
  return invoiceSmsText({
    lang,
    centerName: input.centerName,
    farmerName: input.farmerName,
    farmerCode: input.farmerCode,
    periodStart: input.periodStart,
    periodEnd: input.periodEnd,
    totalLiters: input.totals.total_liter,
    milkAmount: input.totals.total_milk_amount,
    feedDeduction: input.totals.total_feed_amount,
    advanceDeduction: input.totals.manual_deductions,
    totalDeduction: input.totals.total_deduction,
    amountPaid: input.totals.amount_due,
    newBalance: input.totals.new_balance,
    previousBalance: input.totals.previous_balance,
    advanceGiven: input.totals.total_advance_given,
    collections: input.detail.collections.map((c) => ({
      date: input.fmtDate(c.collection_date),
      shift: c.shift,
      fat: Number(c.fat).toFixed(1),
      snf: c.snf != null ? Number(c.snf).toFixed(1) : null,
      liters: Number(c.quantity_liters),
      rate: Number(c.rate_per_liter),
      amount: Number(c.total_amount),
    })),
    feedItems: input.detail.feedSales.map((s) => ({
      date: input.fmtDate(s.sale_date),
      product: s.product_name,
      qty: Number(s.quantity ?? 0),
      rate: Number(s.rate ?? 0),
      amount: Number(s.amount),
    })),
    advanceItems: (input.detail.advancesGiven ?? []).map((a) => ({
      date: input.fmtDate(a.advance_date),
      comments: a.comments ?? null,
      amount: Number(a.amount),
    })),
    deductionItems: [
      ...input.detail.feedSales.map((s) => ({
        label: `${d.feed} ${input.fmtDate(s.sale_date)} (${s.product_name})`,
        amount: Number(s.amount),
      })),
      ...input.detail.advanceDeductions.map((a) => ({
        label: `${d.advance} ${input.fmtDate(a.deduction_date)}`,
        amount: Number(a.amount),
      })),
      ...(residualAdvance > 0.001 ? [{ label: d.advance, amount: residualAdvance }] : []),
    ],
  });
}
