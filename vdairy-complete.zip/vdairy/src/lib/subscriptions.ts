import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Subscription plans, trial lifecycle and member-limit rules.
 *
 * Pricing/limits live in the `subscription_plans` table so they can be edited
 * from the Control Panel without an app release. No payment gateway is wired
 * yet — the Pay button is a placeholder that records the intent only.
 */

export type BillingCycle = "monthly" | "yearly";

export type Plan = {
  code: string;
  name: string;
  price: number;
  cycle: BillingCycle;
  maxFarmers: number | null;
  features: string[];
};

export type SubscriptionStatus = "trial" | "active" | "expired" | "deactivated";

export type SubscriptionState = {
  status: SubscriptionStatus;
  plan: string | null;
  planName: string | null;
  maxFarmers: number | null;
  trialEndsAt: Date | null;
  /** Registration + 10 days: when an un-upgraded account auto-deactivates. */
  deactivateAt: Date | null;
  currentPeriodEnd: Date | null;
  /** Whole days left in the trial (0 once expired). */
  trialDaysLeft: number | null;
  /** Whole days until auto-deactivation. */
  daysUntilDeactivation: number | null;
};

/** Free trial length for a newly registered centre. */
export const TRIAL_DAYS = 3;
/** Days from registration after which an un-upgraded account auto-deactivates. */
export const DEACTIVATE_AFTER_DAYS = 10;

export function daysBetween(from: Date, to: Date): number {
  return Math.ceil((to.getTime() - from.getTime()) / 86_400_000);
}

export async function fetchPlans(): Promise<Plan[]> {
  const { data, error } = await supabase
    .from("subscription_plans")
    .select("code, name, price_monthly, price_yearly, max_farmers, features, is_active, sort_order")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []).map((r) => {
    const yearly = r.code.endsWith("_yearly");
    return {
      code: r.code,
      name: r.name,
      price: yearly ? Number(r.price_yearly) : Number(r.price_monthly),
      cycle: (yearly ? "yearly" : "monthly") as BillingCycle,
      maxFarmers: r.max_farmers,
      features: Array.isArray(r.features) ? (r.features as string[]) : [],
    };
  });
}

/**
 * Reads the centre's subscription, letting the backend re-evaluate the trial /
 * auto-deactivation flags first (status flag only — nothing is ever deleted).
 */
export async function fetchSubscriptionState(centerId: string): Promise<SubscriptionState | null> {
  const { data, error } = await supabase.rpc("refresh_center_subscription_status", {
    p_center_id: centerId,
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : null;
  if (!row) return null;

  let planName: string | null = null;
  let maxFarmers: number | null = null;
  if (row.plan_code) {
    const { data: p } = await supabase
      .from("subscription_plans")
      .select("name, max_farmers")
      .eq("code", row.plan_code)
      .maybeSingle();
    planName = p?.name ?? null;
    maxFarmers = p?.max_farmers ?? null;
  }

  const now = new Date();
  const trialEndsAt = row.trial_ends ? new Date(row.trial_ends) : null;
  const deactivateAt = row.deactivate_at ? new Date(row.deactivate_at) : null;
  return {
    status: (row.sub_status as SubscriptionStatus) ?? "trial",
    plan: row.plan_code ?? null,
    planName,
    maxFarmers,
    trialEndsAt,
    deactivateAt,
    currentPeriodEnd: row.period_end ? new Date(row.period_end) : null,
    trialDaysLeft: trialEndsAt ? Math.max(daysBetween(now, trialEndsAt), 0) : null,
    daysUntilDeactivation: deactivateAt ? Math.max(daysBetween(now, deactivateAt), 0) : null,
  };
}

/** Reactive subscription state for the selected centre. */
export function useSubscription(centerId: string | null) {
  const [state, setState] = useState<SubscriptionState | null>(null);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    if (!centerId) {
      setState(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      setState(await fetchSubscriptionState(centerId));
    } catch {
      setState(null);
    } finally {
      setLoading(false);
    }
  }, [centerId]);

  useEffect(() => {
    void reload();
  }, [reload]);

  return { subscription: state, loading, reload };
}

/** Active farmer count for a centre (the number the member limit applies to). */
export async function countActiveFarmers(centerId: string): Promise<number> {
  const { count } = await supabase
    .from("farmers")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId)
    .eq("is_active", true);
  return count ?? 0;
}

export const STANDARD_LIMIT = 150;
export const PREMIUM_LIMIT = 300;

/**
 * Exact user-facing message when a centre has reached its member limit.
 * Returns null when there is still room.
 */
export function memberLimitMessage(args: {
  activeFarmers: number;
  maxFarmers: number | null;
  planCode: string | null;
}): string | null {
  const { activeFarmers, maxFarmers, planCode } = args;
  if (maxFarmers == null) return null;
  if (activeFarmers < maxFarmers) return null;
  const isPremium = (planCode ?? "").startsWith("premium") || maxFarmers >= PREMIUM_LIMIT;
  if (isPremium) {
    return `You've reached the maximum member limit (${maxFarmers}) for your current plan.`;
  }
  return `You've reached the ${maxFarmers}-member limit of your Standard plan. Upgrade to Premium to add up to ${PREMIUM_LIMIT} members.`;
}

/** Records a plan selection. Placeholder until a payment gateway is connected. */
export async function startPlanCheckout(args: {
  centerId: string;
  plan: Plan;
  userId: string | null;
}): Promise<void> {
  const { centerId, plan, userId } = args;
  const { error } = await supabase.from("subscription_payments").insert({
    center_id: centerId,
    plan_code: plan.code,
    amount: plan.price,
    billing_cycle: plan.cycle,
    status: "Pending",
    reference: "placeholder-no-gateway",
    created_by: userId,
  });
  if (error) throw error;
}
