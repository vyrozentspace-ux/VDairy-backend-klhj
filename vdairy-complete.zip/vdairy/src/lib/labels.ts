/**
 * Shared display labels that must always go through i18n.
 * These wrap translation keys that already exist in every locale file, so no
 * screen should ever render the raw English literal for a shift or milk type.
 */

export type TFunc = (key: string, opts?: Record<string, unknown>) => string;

const MILK_TYPE_KEYS: Record<string, string> = {
  cow: "settings.cow",
  buffalo: "settings.buffalo",
  mixed: "farmers.mixed",
};

const SHIFT_KEYS: Record<string, string> = {
  morning: "collection.morning",
  evening: "collection.evening",
};

/** Translated label for a milk type ("cow" | "buffalo" | "mixed"). */
export function milkTypeLabel(t: TFunc, milkType: string | null | undefined): string {
  if (!milkType) return "";
  const key = MILK_TYPE_KEYS[milkType.toLowerCase()];
  if (!key) return milkType;
  const out = t(key);
  return out === key ? milkType : out;
}

/** Translated label for a collection shift ("morning" | "evening"). */
export function shiftLabel(t: TFunc, shift: string | null | undefined): string {
  if (!shift) return "";
  const key = SHIFT_KEYS[shift.toLowerCase()];
  if (!key) return shift;
  const out = t(key);
  return out === key ? shift : out;
}

/** Translated label for an invoice deduction row type ("Feed" | "Advance"). */
export function deductionTypeLabel(t: TFunc, type: string | null | undefined): string {
  if (!type) return "";
  const norm = type.trim().toLowerCase();
  if (norm === "feed") return t("invoice.deductionFeed");
  if (norm === "advance" || norm === "advance repayment")
    return t("invoice.deductionAdvanceRepayment");
  return type;
}
