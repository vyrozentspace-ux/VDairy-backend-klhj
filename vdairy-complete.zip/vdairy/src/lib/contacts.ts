// Contact picker helpers. Works only where the Web Contact Picker API is
// available (Android Chrome, real apps). Everywhere else callers should
// gracefully fall back to a "not available" dialog.

export type PickedContact = {
  name: string;
  phones: string[]; // 10-digit local phone numbers
};

type ContactsManager = {
  select: (
    props: string[],
    opts?: { multiple?: boolean },
  ) => Promise<Array<{ name?: string[]; tel?: string[] }>>;
  getProperties?: () => Promise<string[]>;
};

function getManager(): ContactsManager | null {
  if (typeof navigator === "undefined") return null;
  const nav = navigator as unknown as { contacts?: ContactsManager };
  return nav.contacts ?? null;
}

export function hasContactPicker(): boolean {
  return !!getManager();
}

function normalizePhone(raw: string): string {
  return raw.replace(/\D/g, "").slice(-10);
}

function normalize(entries: Array<{ name?: string[]; tel?: string[] }>): PickedContact[] {
  return entries
    .map((c) => {
      const name = (c.name?.[0] ?? "").trim() || "Unknown";
      const phones = Array.from(
        new Set((c.tel ?? []).map(normalizePhone).filter((p) => p.length === 10)),
      );
      return { name, phones };
    })
    .filter((c) => c.phones.length > 0);
}

export async function pickSingleContact(): Promise<PickedContact | null> {
  const mgr = getManager();
  if (!mgr) throw new Error("Contact Picker not available");
  const results = await mgr.select(["name", "tel"], { multiple: false });
  const [c] = normalize(results);
  return c ?? null;
}

export async function pickAllContacts(): Promise<PickedContact[]> {
  const mgr = getManager();
  if (!mgr) throw new Error("Contact Picker not available");
  const results = await mgr.select(["name", "tel"], { multiple: true });
  return normalize(results);
}
