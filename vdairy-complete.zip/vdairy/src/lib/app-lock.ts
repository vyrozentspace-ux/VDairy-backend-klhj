/**
 * App Lock — require the account PIN again when the app is re-opened.
 *
 * The PIN itself is never stored on the device: unlocking re-authenticates
 * against the backend with the same phone + PIN credentials used at sign-in.
 */

export const APP_LOCK_KEY = "vdairy.appLock";
/** Set once the user has unlocked in this app run. */
const UNLOCKED_KEY = "vdairy.appLock.unlocked";
/** Timestamp (ms) at which the app was last backgrounded. */
const HIDDEN_AT_KEY = "vdairy.appLock.hiddenAt";

/** Backgrounded for longer than this re-locks the app. */
export const RELOCK_AFTER_MS = 30_000;

export function isAppLockEnabled(): boolean {
  if (typeof window === "undefined") return false;
  return window.localStorage.getItem(APP_LOCK_KEY) === "1";
}

export function setAppLockEnabled(enabled: boolean) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(APP_LOCK_KEY, enabled ? "1" : "0");
  // Turning it on shouldn't lock the user out of the screen they're on.
  if (enabled) markUnlocked();
  else clearUnlocked();
}

export function isUnlockedThisRun(): boolean {
  if (typeof window === "undefined") return true;
  return window.sessionStorage.getItem(UNLOCKED_KEY) === "1";
}

export function markUnlocked() {
  if (typeof window === "undefined") return;
  window.sessionStorage.setItem(UNLOCKED_KEY, "1");
  window.sessionStorage.removeItem(HIDDEN_AT_KEY);
}

export function clearUnlocked() {
  if (typeof window === "undefined") return;
  window.sessionStorage.removeItem(UNLOCKED_KEY);
  window.sessionStorage.removeItem(HIDDEN_AT_KEY);
}

export function markHidden() {
  if (typeof window === "undefined") return;
  window.sessionStorage.setItem(HIDDEN_AT_KEY, String(Date.now()));
}

/** True when the app was in the background long enough to require the PIN again. */
export function shouldRelockOnResume(): boolean {
  if (typeof window === "undefined") return false;
  const raw = window.sessionStorage.getItem(HIDDEN_AT_KEY);
  if (!raw) return false;
  window.sessionStorage.removeItem(HIDDEN_AT_KEY);
  const hiddenAt = Number(raw);
  if (!Number.isFinite(hiddenAt)) return false;
  return Date.now() - hiddenAt >= RELOCK_AFTER_MS;
}
