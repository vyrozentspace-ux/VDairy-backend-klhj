import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Generic, remotely configurable content slots.
 *
 * A "slot" is a named place in the app (`slot_key`, e.g. "settings_tutorial_video"
 * or "dashboard_banner") where the Control Panel can inject a small piece of
 * content — a link, a banner or a bit of text — without an app release.
 *
 * Hide-if-empty is the rule everywhere: if a slot row is missing, inactive, or
 * lacks the data its content_type needs (e.g. a link with no url), the UI must
 * render nothing rather than a placeholder.
 */
export type ContentSlot = {
  id: string;
  slot_key: string;
  content_type: string;
  title: string | null;
  url: string | null;
  body: string | null;
  icon: string | null;
  display_order: number;
};

let cache: Map<string, ContentSlot> | null = null;
let inflight: Promise<Map<string, ContentSlot>> | null = null;

export async function loadContentSlots(): Promise<Map<string, ContentSlot>> {
  if (cache) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    const map = new Map<string, ContentSlot>();
    const { data } = await supabase
      .from("content_slots")
      .select("id, slot_key, content_type, title, url, body, icon, is_active, display_order")
      .eq("is_active", true)
      .order("display_order", { ascending: true });
    for (const row of data ?? []) {
      map.set(row.slot_key, {
        id: row.id,
        slot_key: row.slot_key,
        content_type: (row.content_type ?? "link").trim(),
        title: (row.title ?? "").trim() || null,
        url: (row.url ?? "").trim() || null,
        body: (row.body ?? "").trim() || null,
        icon: (row.icon ?? "").trim() || null,
        display_order: row.display_order ?? 0,
      });
    }
    cache = map;
    inflight = null;
    return map;
  })();
  return inflight;
}

/** Clears the in-memory cache (used after Control Panel edits). */
export function resetContentSlotsCache() {
  cache = null;
}

/**
 * Returns the configured slot, or null when nothing is configured / it is
 * inactive / it is unusable for its content type. Callers render nothing on null.
 */
export function useContentSlot(slotKey: string): ContentSlot | null {
  const [slot, setSlot] = useState<ContentSlot | null>(cache?.get(slotKey) ?? null);
  useEffect(() => {
    let cancelled = false;
    void loadContentSlots().then((map) => {
      if (cancelled) return;
      const found = map.get(slotKey) ?? null;
      setSlot(found && isRenderable(found) ? found : null);
    });
    return () => {
      cancelled = true;
    };
  }, [slotKey]);
  return slot;
}

export function isRenderable(slot: ContentSlot): boolean {
  if (slot.content_type === "link") return Boolean(slot.url);
  if (slot.content_type === "text") return Boolean(slot.body || slot.title);
  if (slot.content_type === "banner") return Boolean(slot.title || slot.body);
  return Boolean(slot.title || slot.body || slot.url);
}
