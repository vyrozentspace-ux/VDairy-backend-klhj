/**
 * Canonical (English) security question values. These are what gets persisted,
 * so existing accounts keep working; the UI renders the translated label via
 * `securityQuestionKey()`.
 */
export const SECURITY_QUESTIONS = [
  "What is your village name?",
  "What was your first cattle's name?",
  "What is your mother's maiden name?",
  "What is your father's first name?",
  "What is the name of your primary school?",
  "What is your favorite crop?",
  "What is the name of your closest friend?",
  "In which year did you start dairy farming?",
  "What is your date of birth (DD/MM)?",
  "What is the name of your dairy cooperative?",
] as const;

export type SecurityQuestion = (typeof SECURITY_QUESTIONS)[number];

const KEYS: Record<string, string> = {
  "What is your village name?": "auth.sq.village",
  "What was your first cattle's name?": "auth.sq.first_cattle",
  "What is your mother's maiden name?": "auth.sq.mother_maiden",
  "What is your father's first name?": "auth.sq.father_first_name",
  "What is the name of your primary school?": "auth.sq.primary_school",
  "What is your favorite crop?": "auth.sq.favorite_crop",
  "What is the name of your closest friend?": "auth.sq.closest_friend",
  "In which year did you start dairy farming?": "auth.sq.dairy_start_year",
  "What is your date of birth (DD/MM)?": "auth.sq.date_of_birth",
  "What is the name of your dairy cooperative?": "auth.sq.cooperative_name",
};

/** Translation key for a stored security question; falls back to the raw text. */
export function securityQuestionKey(question: string): string {
  return KEYS[question] ?? question;
}

/** Translated label for a stored security question. */
export function securityQuestionLabel(question: string, t: (key: string) => string): string {
  const key = KEYS[question];
  return key ? t(key) : question;
}
