import { supabase } from "@/integrations/supabase/client";
import { newId } from "@/lib/offline/queue";
import { saveOffline } from "@/lib/offline/sync";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export type FeedUnit = "Bag" | "Kg" | "Unit";

export type FeedDealer = {
  id: string;
  center_id: string;
  dealer_name: string;
  mobile: string | null;
  address: string | null;
  is_active: boolean;
  created_at: string;
};

export type FeedProduct = {
  id: string;
  center_id: string;
  product_name: string;
  unit: FeedUnit;
  default_rate: number | null;
  is_active: boolean;
  created_at: string;
};

export type FeedStockPurchase = {
  id: string;
  center_id: string;
  dealer_id: string | null;
  feed_product_id: string;
  purchase_date: string;
  quantity: number;
  rate: number;
  amount: number;
  receipt_no: string | null;
  entered_by: string | null;
  created_at: string;
};

export type FarmerFeedSale = {
  id: string;
  center_id: string;
  farmer_id: string;
  feed_product_id: string;
  sale_date: string;
  quantity: number;
  rate: number;
  amount: number;
  receipt_no: string | null;
  cash_payment: boolean;
  entered_by: string | null;
  created_at: string;
};

export type FeedDealerPayment = {
  id: string;
  center_id: string;
  dealer_id: string;
  payment_date: string;
  amount: number;
  comments: string | null;
  entered_by: string | null;
  created_at: string;
};

// ---------- Dealers ----------
export async function listDealers(centerId: string): Promise<FeedDealer[]> {
  const { data, error } = await db
    .from("feed_dealers")
    .select("*")
    .eq("center_id", centerId)
    .eq("is_active", true)
    .order("dealer_name");
  if (error) throw new Error(error.message);
  return (data ?? []) as FeedDealer[];
}
export async function getDealer(id: string): Promise<FeedDealer | null> {
  const { data, error } = await db.from("feed_dealers").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return data ?? null;
}
export async function createDealer(input: {
  center_id: string;
  dealer_name: string;
  mobile?: string | null;
  address?: string | null;
}): Promise<FeedDealer> {
  const row = { id: newId(), is_active: true, created_at: new Date().toISOString(), ...input };
  await saveOffline({
    kind: "dealer",
    table: "feed_dealers",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  return row as FeedDealer;
}
export async function dealerBalance(dealerId: string): Promise<number> {
  const { data, error } = await db.rpc("dealer_balance", { p_dealer_id: dealerId });
  if (error) throw new Error(error.message);
  return Number(data ?? 0);
}

// ---------- Products ----------
export async function listProducts(centerId: string): Promise<FeedProduct[]> {
  const { data, error } = await db
    .from("feed_products")
    .select("*")
    .eq("center_id", centerId)
    .eq("is_active", true)
    .order("product_name");
  if (error) throw new Error(error.message);
  return (data ?? []) as FeedProduct[];
}
export async function createProduct(input: {
  center_id: string;
  product_name: string;
  unit: FeedUnit;
  default_rate?: number | null;
}): Promise<FeedProduct> {
  const row = { id: newId(), is_active: true, created_at: new Date().toISOString(), ...input };
  await saveOffline({
    kind: "product",
    table: "feed_products",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  return row as FeedProduct;
}
export async function stockOnHand(productId: string): Promise<number> {
  const { data, error } = await db.rpc("feed_stock_on_hand", { p_feed_product_id: productId });
  if (error) throw new Error(error.message);
  return Number(data ?? 0);
}

// ---------- Stock purchases ----------
export async function listStockPurchases(centerId: string): Promise<FeedStockPurchase[]> {
  const { data, error } = await db
    .from("feed_stock_purchases")
    .select("*")
    .eq("center_id", centerId)
    .order("purchase_date", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}
export async function listStockPurchasesForProduct(
  productId: string,
): Promise<FeedStockPurchase[]> {
  const { data, error } = await db
    .from("feed_stock_purchases")
    .select("*")
    .eq("feed_product_id", productId)
    .order("purchase_date", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}
export async function listStockPurchasesForDealer(dealerId: string): Promise<FeedStockPurchase[]> {
  const { data, error } = await db
    .from("feed_stock_purchases")
    .select("*")
    .eq("dealer_id", dealerId)
    .order("purchase_date", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}
export async function createStockPurchase(
  input: Omit<FeedStockPurchase, "id" | "created_at">,
): Promise<FeedStockPurchase> {
  const row = { id: newId(), created_at: new Date().toISOString(), ...input };
  await saveOffline({
    kind: "stock_purchase",
    table: "feed_stock_purchases",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  return row as FeedStockPurchase;
}

// ---------- Farmer feed sales ----------
export async function listFeedSales(
  centerId: string,
  opts: { from?: string; to?: string; farmerId?: string } = {},
): Promise<FarmerFeedSale[]> {
  let q = db.from("farmer_feed_sales").select("*").eq("center_id", centerId);
  if (opts.from) q = q.gte("sale_date", opts.from);
  if (opts.to) q = q.lte("sale_date", opts.to);
  if (opts.farmerId) q = q.eq("farmer_id", opts.farmerId);
  const { data, error } = await q.order("sale_date", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}
export async function getFeedSale(id: string): Promise<FarmerFeedSale | null> {
  const { data, error } = await db.from("farmer_feed_sales").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return data ?? null;
}
export async function createFeedSale(
  input: Omit<FarmerFeedSale, "id" | "created_at">,
): Promise<FarmerFeedSale> {
  const row = { id: newId(), created_at: new Date().toISOString(), ...input };
  await saveOffline({
    kind: "feed_sale",
    table: "farmer_feed_sales",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  return row as FarmerFeedSale;
}
export async function updateFeedSale(id: string, patch: Partial<FarmerFeedSale>): Promise<void> {
  await saveOffline({
    kind: "feed_sale",
    table: "farmer_feed_sales",
    action: "update",
    rowId: id,
    payload: patch as Record<string, unknown>,
  });
}

// ---------- Dealer payments ----------
export async function listDealerPayments(dealerId: string): Promise<FeedDealerPayment[]> {
  const { data, error } = await db
    .from("feed_dealer_payments")
    .select("*")
    .eq("dealer_id", dealerId)
    .order("payment_date", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}
export async function createDealerPayment(
  input: Omit<FeedDealerPayment, "id" | "created_at">,
): Promise<FeedDealerPayment> {
  const row = { id: newId(), created_at: new Date().toISOString(), ...input };
  await saveOffline({
    kind: "dealer_payment",
    table: "feed_dealer_payments",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  return row as FeedDealerPayment;
}
