import { formatDayMonthYear } from "@/lib/date-locale";
import { supabase } from "@/integrations/supabase/client";
import { newId } from "@/lib/offline/queue";
import { saveOffline } from "@/lib/offline/sync";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export type MilkSaleSession = "morning" | "evening";
export type PayStatus = "paid" | "unpaid";
export type PayMode = "cash" | "upi" | "other";

export type MilkSaleCustomer = {
  id: string;
  center_id: string;
  name: string;
  mobile: string | null;
  address: string | null;
  created_at: string;
  updated_at?: string;
};

export type MilkSale = {
  id: string;
  center_id: string;
  customer_id: string | null;
  walk_in_name: string | null;
  walk_in_mobile: string | null;
  sale_date: string;
  session: MilkSaleSession;
  quantity_liters: number;
  rate_per_liter: number;
  total_amount: number;
  payment_status: PayStatus;
  payment_mode: PayMode | null;
  created_at: string;
  updated_at: string;
};

export async function listCustomers(centerId: string): Promise<MilkSaleCustomer[]> {
  const { data, error } = await db
    .from("milk_sale_customers")
    .select("*")
    .eq("center_id", centerId)
    .order("name");
  if (error) throw new Error(error.message);
  return (data ?? []) as MilkSaleCustomer[];
}

export async function createCustomer(input: {
  center_id: string;
  name: string;
  mobile?: string | null;
  address?: string | null;
}): Promise<MilkSaleCustomer> {
  const { data, error } = await db
    .from("milk_sale_customers")
    .insert({ ...input, mobile: input.mobile || null, address: input.address || null })
    .select("*")
    .single();
  if (error) throw new Error(error.message);
  return data as MilkSaleCustomer;
}

export async function updateCustomer(
  id: string,
  input: {
    name: string;
    mobile?: string | null;
    address?: string | null;
  },
): Promise<void> {
  const { error } = await db
    .from("milk_sale_customers")
    .update({ name: input.name, mobile: input.mobile || null, address: input.address || null })
    .eq("id", id);
  if (error) throw new Error(error.message);
}

export async function deleteCustomer(id: string): Promise<void> {
  const { error } = await db.from("milk_sale_customers").delete().eq("id", id);
  if (error) throw new Error(error.message);
}

export async function listSales(
  centerId: string,
  opts?: { from?: string; to?: string },
): Promise<MilkSale[]> {
  let q = db
    .from("milk_sales")
    .select("*")
    .eq("center_id", centerId)
    .order("sale_date", { ascending: false })
    .order("created_at", { ascending: false });
  if (opts?.from) q = q.gte("sale_date", opts.from);
  if (opts?.to) q = q.lte("sale_date", opts.to);
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return (data ?? []) as MilkSale[];
}

export async function getSale(id: string): Promise<MilkSale | null> {
  const { data, error } = await db.from("milk_sales").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? null) as MilkSale | null;
}

export type SaleInput = {
  center_id: string;
  customer_id: string | null;
  walk_in_name: string | null;
  walk_in_mobile: string | null;
  sale_date: string;
  session: MilkSaleSession;
  quantity_liters: number;
  rate_per_liter: number;
  total_amount: number;
  payment_status: PayStatus;
  payment_mode: PayMode | null;
  created_by?: string | null;
};

export async function createSale(input: SaleInput): Promise<MilkSale> {
  const now = new Date().toISOString();
  const row = { id: newId(), ...input, created_at: now, updated_at: now } as unknown as MilkSale;
  await saveOffline({
    kind: "milk_sale",
    table: "milk_sales",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  return row;
}

export async function updateSale(id: string, input: Partial<SaleInput>): Promise<void> {
  await saveOffline({
    kind: "milk_sale",
    table: "milk_sales",
    action: "update",
    rowId: id,
    payload: { ...input, updated_at: new Date().toISOString() } as Record<string, unknown>,
  });
}

export async function deleteSale(id: string): Promise<void> {
  await saveOffline({
    kind: "milk_sale",
    table: "milk_sales",
    action: "delete",
    rowId: id,
    payload: {},
  });
}

export async function logActivity(
  centerId: string,
  userId: string | null,
  action: string,
  details: Record<string, unknown>,
) {
  try {
    await db
      .from("activity_logs")
      .insert({ center_id: centerId, user_id: userId, action, details });
  } catch {
    /* non-fatal */
  }
}

export function formatINR(n: number): string {
  return `₹${Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

export function todayISO(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function formatDateLabel(iso: string, tr?: (k: string) => string): string {
  const today = todayISO();
  const d = new Date(iso + "T00:00:00");
  const y = new Date();
  const yISO = new Date(y.getFullYear(), y.getMonth(), y.getDate() - 1).toISOString().slice(0, 10);
  if (iso === today) return tr ? tr("core.today") : "Today";
  if (iso === yISO) return tr ? tr("core.yesterday") : "Yesterday";
  return formatDayMonthYear(d);
}

export type CustomerStats = { total_liters: number; total_amount: number };

export async function customerStats(centerId: string): Promise<Record<string, CustomerStats>> {
  const { data, error } = await db
    .from("milk_sales")
    .select("customer_id, quantity_liters, total_amount")
    .eq("center_id", centerId)
    .not("customer_id", "is", null);
  if (error) throw new Error(error.message);
  const out: Record<string, CustomerStats> = {};
  for (const r of (data ?? []) as Array<{
    customer_id: string;
    quantity_liters: number;
    total_amount: number;
  }>) {
    const s = out[r.customer_id] ?? { total_liters: 0, total_amount: 0 };
    s.total_liters += Number(r.quantity_liters);
    s.total_amount += Number(r.total_amount);
    out[r.customer_id] = s;
  }
  return out;
}
