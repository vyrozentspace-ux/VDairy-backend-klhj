import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { phoneToEmail, pinToPassword } from "./pin-auth";
import { DEFAULT_OPERATOR_PERMISSIONS, PERMISSION_KEYS } from "./permissions";

export const createOperator = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        center_id: z.string().uuid(),
        full_name: z.string().trim().min(2).max(100),
        phone: z.string().regex(/^[0-9]{10}$/),
        pin: z.string().regex(/^[0-9]{4}$/),
        permissions: z.record(z.boolean()).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    // Only the center owner may create operators.
    const { data: center } = await context.supabase
      .from("dairy_centers")
      .select("id, owner_id")
      .eq("id", data.center_id)
      .maybeSingle();
    if (!center || center.owner_id !== context.userId) {
      throw new Error("Only the center owner can add operators");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const email = phoneToEmail(data.phone);

    /**
     * Resolve the login this phone number belongs to.
     *
     * The profile row is NOT the source of truth: the login lives in the auth
     * system and the profile is a separate row that can legitimately be absent
     * (an operator that was removed, a sign-up that never finished, or a
     * restored/remixed database). Looking only at `profiles` used to make the
     * code think the number was free, then `createUser` failed with
     * "A user with this email address has already been registered" and the
     * Create Operator button could never succeed for that number again.
     * So always check the auth side too, and repair whatever is missing.
     */
    const { data: authIdByEmail } = await supabaseAdmin.rpc("auth_user_id_by_email", {
      _email: email,
    });
    const { data: profileByPhone } = await supabaseAdmin
      .from("profiles")
      .select("id, role")
      .eq("phone", data.phone)
      .maybeSingle();

    let operatorId = (authIdByEmail as string | null) ?? profileByPhone?.id ?? null;

    if (operatorId) {
      // Never hijack an owner account.
      const { data: prof } = await supabaseAdmin
        .from("profiles")
        .select("id, role")
        .eq("id", operatorId)
        .maybeSingle();
      if (prof?.role === "owner" || profileByPhone?.role === "owner") {
        throw new Error("This phone number already belongs to an owner account");
      }

      const { error: pwErr } = await supabaseAdmin.auth.admin.updateUserById(operatorId, {
        password: pinToPassword(data.pin),
        email_confirm: true,
        user_metadata: {
          full_name: data.full_name,
          phone: data.phone,
          role: "operator",
          language_preference: "en",
        },
      });
      if (pwErr) throw new Error(pwErr.message);
    } else {
      const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: pinToPassword(data.pin),
        email_confirm: true,
        user_metadata: {
          full_name: data.full_name,
          phone: data.phone,
          role: "operator",
          language_preference: "en",
        },
      });
      if (error) {
        // Lost a race with a concurrent create, or the login exists but was not
        // visible above. Re-resolve rather than dead-ending the owner.
        const { data: retryId } = await supabaseAdmin.rpc("auth_user_id_by_email", {
          _email: email,
        });
        if (!retryId) throw new Error(error.message);
        operatorId = retryId as string;
        const { error: pwErr } = await supabaseAdmin.auth.admin.updateUserById(operatorId, {
          password: pinToPassword(data.pin),
        });
        if (pwErr) throw new Error(pwErr.message);
      } else {
        operatorId = created.user!.id;
      }
    }

    // Always (re)write the profile row: without it the operator cannot sign in
    // or be listed, and this is what repairs half-created accounts.
    const { error: profileErr } = await supabaseAdmin.from("profiles").upsert(
      {
        id: operatorId,
        full_name: data.full_name,
        phone: data.phone,
        role: "operator",
        language_preference: "en",
      },
      { onConflict: "id" },
    );
    if (profileErr) throw new Error(profileErr.message);

    const permissions = { ...DEFAULT_OPERATOR_PERMISSIONS, ...(data.permissions ?? {}) };
    const { error: linkErr } = await supabaseAdmin
      .from("center_operators")
      .upsert(
        { center_id: data.center_id, operator_id: operatorId, is_active: true, permissions },
        { onConflict: "center_id,operator_id" },
      );
    if (linkErr) throw new Error(linkErr.message);

    return { ok: true, operator_id: operatorId };
  });


/**
 * Link or unlink one operator to one of the owner's centers. Linking an
 * operator to several centers lets a single phone+PIN login work across them.
 */
export const setOperatorCenterLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        center_id: z.string().uuid(),
        operator_id: z.string().uuid(),
        linked: z.boolean(),
        permissions: z.record(z.boolean()).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: center } = await context.supabase
      .from("dairy_centers")
      .select("owner_id")
      .eq("id", data.center_id)
      .maybeSingle();
    if (!center || center.owner_id !== context.userId)
      throw new Error("Only the center owner can manage operators");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (!data.linked) {
      const { error } = await supabaseAdmin
        .from("center_operators")
        .delete()
        .eq("center_id", data.center_id)
        .eq("operator_id", data.operator_id);
      if (error) throw new Error(error.message);
      return { ok: true, linked: false };
    }

    const permissions = { ...DEFAULT_OPERATOR_PERMISSIONS, ...(data.permissions ?? {}) };
    const { error } = await supabaseAdmin
      .from("center_operators")
      .upsert(
        { center_id: data.center_id, operator_id: data.operator_id, is_active: true, permissions },
        { onConflict: "center_id,operator_id" },
      );
    if (error) throw new Error(error.message);
    return { ok: true, linked: true };
  });

/**
 * Remove an operator completely: every link to a center owned by the caller is
 * deleted, and when no links remain anywhere the login itself is deleted so the
 * phone+PIN stops working.
 */
export const removeOperator = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ center_id: z.string().uuid(), operator_id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: center } = await context.supabase
      .from("dairy_centers")
      .select("owner_id")
      .eq("id", data.center_id)
      .maybeSingle();
    if (!center || center.owner_id !== context.userId)
      throw new Error("Only the center owner can manage operators");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: ownCenters } = await supabaseAdmin
      .from("dairy_centers")
      .select("id")
      .eq("owner_id", context.userId);
    const ownIds = (ownCenters ?? []).map((c) => c.id);

    const { error: delErr } = await supabaseAdmin
      .from("center_operators")
      .delete()
      .eq("operator_id", data.operator_id)
      .in("center_id", ownIds.length ? ownIds : [data.center_id]);
    if (delErr) throw new Error(delErr.message);

    const { data: remaining } = await supabaseAdmin
      .from("center_operators")
      .select("id")
      .eq("operator_id", data.operator_id);

    if (!remaining || remaining.length === 0) {
      // Only ever delete an operator account, never an owner account.
      // A missing profile row must NOT stop the deletion: leaving the login
      // behind is exactly what produced "already registered" dead-ends the
      // next time the owner tried to add that phone number again.
      const { data: prof } = await supabaseAdmin
        .from("profiles")
        .select("role")
        .eq("id", data.operator_id)
        .maybeSingle();
      const { data: ownsCenters } = await supabaseAdmin
        .from("dairy_centers")
        .select("id")
        .eq("owner_id", data.operator_id)
        .limit(1);
      const isOwnerAccount = prof?.role === "owner" || (ownsCenters?.length ?? 0) > 0;
      if (!isOwnerAccount) {
        await supabaseAdmin.from("profiles").delete().eq("id", data.operator_id);
        const { error } = await supabaseAdmin.auth.admin.deleteUser(data.operator_id);
        if (error) throw new Error(error.message);
      }
      return { ok: true, account_deleted: !isOwnerAccount };

    }
    return { ok: true, account_deleted: false };
  });

export const resetOperatorPin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        center_id: z.string().uuid(),
        operator_id: z.string().uuid(),
        pin: z.string().regex(/^[0-9]{4}$/),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: center } = await context.supabase
      .from("dairy_centers")
      .select("id, owner_id")
      .eq("id", data.center_id)
      .maybeSingle();
    if (!center || center.owner_id !== context.userId) {
      throw new Error("Only the center owner can reset an operator PIN");
    }
    const { data: link } = await context.supabase
      .from("center_operators")
      .select("id")
      .eq("center_id", data.center_id)
      .eq("operator_id", data.operator_id)
      .maybeSingle();
    if (!link) throw new Error("Operator is not linked to this center");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.operator_id, {
      password: pinToPassword(data.pin),
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
