/**
 * Tiny language registry so formatting helpers don't have to import the i18n
 * instance (which relies on Vite-only `import.meta.glob` and therefore can't be
 * loaded by plain Node/Bun test runners).
 */
let activeLanguage = "en";

export function setActiveLanguage(code: string) {
  activeLanguage = (code || "en").slice(0, 2);
}

export function getActiveLanguage(): string {
  return activeLanguage;
}
