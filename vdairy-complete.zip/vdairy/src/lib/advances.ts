import { supabase } from "@/integrations/supabase/client";
import { newId } from "@/lib/offline/queue";
import { saveOffline } from "@/lib/offline/sync";

export type AdvanceType = "Lump Sum" | "Monthly Installment";
export type AdvanceDeductionSource = "Manual" | "Invoice";

export type Advance = {
  id: string;
  center_id: string;
  farmer_id: string;
  advance_date: string;
  amount: number;
  advance_type: AdvanceType;
  monthly_installment_amount: number | null;
  term_months: number | null;
  interest_rate: number;
  comments: string | null;
  is_paid: boolean;
  entered_by: string | null;
  created_at: string;
  updated_at: string;
};

export type AdvanceDeduction = {
  id: string;
  center_id: string;
  advance_id: string;
  farmer_id: string;
  deduction_date: string;
  amount: number;
  source: AdvanceDeductionSource;
  comments: string | null;
  entered_by: string | null;
  created_at: string;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export async function listAdvances(centerId: string): Promise<Advance[]> {
  const { data, error } = await db
    .from("advances")
    .select("*")
    .eq("center_id", centerId)
    .order("advance_date", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as Advance[];
}

export async function listAdvancesForFarmer(farmerId: string): Promise<Advance[]> {
  const { data, error } = await db
    .from("advances")
    .select("*")
    .eq("farmer_id", farmerId)
    .order("advance_date", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as Advance[];
}

export async function listDeductionsForFarmer(farmerId: string): Promise<AdvanceDeduction[]> {
  const { data, error } = await db
    .from("advance_deductions")
    .select("*")
    .eq("farmer_id", farmerId)
    .order("deduction_date", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as AdvanceDeduction[];
}

export async function listAllDeductions(centerId: string): Promise<AdvanceDeduction[]> {
  const { data, error } = await db.from("advance_deductions").select("*").eq("center_id", centerId);
  if (error) throw new Error(error.message);
  return (data ?? []) as AdvanceDeduction[];
}

export async function getAdvance(id: string): Promise<Advance | null> {
  const { data, error } = await db.from("advances").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? null) as Advance | null;
}

export async function createAdvance(
  input: Omit<Advance, "id" | "created_at" | "updated_at" | "is_paid"> & { is_paid?: boolean },
): Promise<Advance> {
  const now = new Date().toISOString();
  const row = {
    id: newId(),
    is_paid: false,
    ...input,
    created_at: now,
    updated_at: now,
  } as unknown as Advance;
  const { synced } = await saveOffline({
    kind: "advance",
    table: "advances",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  if (synced) {
    await logAdvance(input.center_id, input.entered_by, "advance_added", {
      id: row.id,
      farmer_id: input.farmer_id,
      amount: input.amount,
      date: input.advance_date,
    });
  }
  return row;
}

export async function updateAdvance(id: string, patch: Partial<Advance>): Promise<void> {
  await saveOffline({
    kind: "advance",
    table: "advances",
    action: "update",
    rowId: id,
    payload: { ...patch, updated_at: new Date().toISOString() } as Record<string, unknown>,
  });
}

export async function recordRepayment(input: {
  centerId: string;
  farmerId: string;
  amount: number;
  date: string;
  comments: string | null;
  enteredBy: string | null;
}): Promise<{ ok: boolean; error?: string }> {
  const { data: outstanding, error: oe } = await db
    .from("advances")
    .select("id")
    .eq("farmer_id", input.farmerId)
    .eq("is_paid", false)
    .order("advance_date", { ascending: true })
    .limit(1);
  if (oe) throw new Error(oe.message);
  const advanceId = (outstanding ?? [])[0]?.id as string | undefined;
  if (!advanceId) return { ok: false, error: "No outstanding advance to repay" };

  const deductionId = newId();
  const { synced } = await saveOffline({
    kind: "repayment",
    table: "advance_deductions",
    action: "insert",
    rowId: deductionId,
    payload: {
      id: deductionId,
      center_id: input.centerId,
      advance_id: advanceId,
      farmer_id: input.farmerId,
      deduction_date: input.date,
      amount: input.amount,
      source: "Manual",
      comments: input.comments,
      entered_by: input.enteredBy,
      created_at: new Date().toISOString(),
    },
  });
  if (synced) await logAdvance(input.centerId, input.enteredBy, "advance_repayment", {
    advance_id: advanceId,
    farmer_id: input.farmerId,
    amount: input.amount,
    date: input.date,
  });
  return { ok: true };
}

export async function farmerBalance(farmerId: string): Promise<number> {
  const { data, error } = await db.rpc("farmer_advance_balance", { p_farmer_id: farmerId });
  if (error) throw new Error(error.message);
  return Number(data ?? 0);
}

export async function farmerBalancesForCenter(
  centerId: string,
): Promise<Record<string, { given: number; repaid: number; balance: number }>> {
  const [advs, deds] = await Promise.all([listAdvances(centerId), listAllDeductions(centerId)]);
  const acc: Record<string, { given: number; repaid: number; balance: number }> = {};
  for (const a of advs) {
    const rec = (acc[a.farmer_id] ??= { given: 0, repaid: 0, balance: 0 });
    rec.given += Number(a.amount);
  }
  for (const d of deds) {
    const rec = (acc[d.farmer_id] ??= { given: 0, repaid: 0, balance: 0 });
    rec.repaid += Number(d.amount);
  }
  for (const k of Object.keys(acc)) acc[k].balance = acc[k].given - acc[k].repaid;
  return acc;
}

async function logAdvance(
  centerId: string,
  userId: string | null,
  action: string,
  details: Record<string, unknown>,
) {
  try {
    await db
      .from("activity_logs")
      .insert({ center_id: centerId, user_id: userId, action, details });
  } catch {
    /* non-fatal */
  }
}

export function formatCurrency(n: number): string {
  return `₹${Math.abs(n).toFixed(2)}`;
}
