/**
 * Sync engine for the offline write queue.
 *
 * - Connectivity is read from @capacitor/network (native) and navigator.onLine
 *   (web preview), and the plugin's change listener triggers an automatic flush.
 * - Records are pushed in creation order, so an edit never overtakes its insert.
 * - Connectivity failures keep the record pending; genuine errors (validation,
 *   duplicate, permission) mark it "failed" with a message so it is visible in
 *   the pending-sync sheet instead of retrying invisibly forever.
 */
import { Network } from "@capacitor/network";
import { supabase } from "@/integrations/supabase/client";
import {
  dequeue,
  enqueue,
  loadQueue,
  patchRecord,
  type PendingRecord,
  type QueueAction,
} from "./queue";

const db = supabase as unknown as {
  from: (t: string) => {
    insert: (v: unknown) => Promise<{ error: { message: string; code?: string } | null }>;
    update: (v: unknown) => {
      eq: (c: string, v: string) => Promise<{ error: { message: string; code?: string } | null }>;
    };
    delete: () => {
      eq: (c: string, v: string) => Promise<{ error: { message: string; code?: string } | null }>;
    };
  };
};

export async function isOnline(): Promise<boolean> {
  try {
    const status = await Network.getStatus();
    return status.connected;
  } catch {
    return typeof navigator === "undefined" ? true : navigator.onLine;
  }
}

/** Network/transport failures are retryable; everything else is a real error. */
function isConnectivityError(message: string): boolean {
  const m = message.toLowerCase();
  return (
    m.includes("failed to fetch") ||
    m.includes("networkerror") ||
    m.includes("network request failed") ||
    m.includes("load failed") ||
    m.includes("fetch failed") ||
    m.includes("timeout") ||
    m.includes("offline")
  );
}

async function runRecord(rec: PendingRecord): Promise<void> {
  const t = db.from(rec.table);
  let error: { message: string } | null = null;
  if (rec.action === "insert") ({ error } = await t.insert(rec.payload));
  else if (rec.action === "update") ({ error } = await t.update(rec.payload).eq("id", rec.rowId));
  else ({ error } = await t.delete().eq("id", rec.rowId));
  if (error) throw new Error(error.message);
}

let flushing = false;

/**
 * Push every pending record, oldest first. Stops early on the first
 * connectivity failure so the order is preserved for the next attempt.
 */
export async function flushQueue(): Promise<{ synced: number; remaining: number }> {
  if (flushing) return { synced: 0, remaining: (await loadQueue()).length };
  flushing = true;
  let synced = 0;
  try {
    if (!(await isOnline())) return { synced: 0, remaining: (await loadQueue()).length };
    for (const rec of await loadQueue()) {
      if (rec.status === "failed") continue;
      try {
        await runRecord(rec);
        await dequeue(rec.id);
        synced++;
      } catch (e) {
        const message = e instanceof Error ? e.message : String(e);
        if (isConnectivityError(message)) {
          await patchRecord(rec.id, { attempts: rec.attempts + 1 });
          break;
        }
        await patchRecord(rec.id, {
          attempts: rec.attempts + 1,
          status: "failed",
          error: message,
        });
      }
    }
  } finally {
    flushing = false;
  }
  return { synced, remaining: (await loadQueue()).length };
}

/** Move a failed record back to pending and try again. */
export async function retryRecord(id: string): Promise<void> {
  await patchRecord(id, { status: "pending", error: undefined });
  await flushQueue();
}

export type SaveResult<T> = { synced: boolean; row: T };

/**
 * The single entry point used by every add/edit screen: persist locally first,
 * then attempt an immediate background sync.
 */
export async function saveOffline<T extends Record<string, unknown>>(input: {
  kind: string;
  table: string;
  action: QueueAction;
  rowId: string;
  payload: T;
}): Promise<SaveResult<T>> {
  const rec = await enqueue({
    kind: input.kind,
    table: input.table,
    action: input.action,
    rowId: input.rowId,
    payload: input.payload,
  });

  if (!(await isOnline())) return { synced: false, row: input.payload };

  try {
    await runRecord(rec);
    await dequeue(rec.id);
    return { synced: true, row: input.payload };
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    if (isConnectivityError(message)) return { synced: false, row: input.payload };
    // A genuine error: drop it from the queue and let the caller show it now.
    await dequeue(rec.id);
    throw new Error(message);
  }
}

let started = false;

/** Wire connectivity listeners once, then drain anything left from last run. */
export function startSyncEngine(): () => void {
  if (started || typeof window === "undefined") return () => {};
  started = true;

  const onOnline = () => void flushQueue();
  window.addEventListener("online", onOnline);
  const timer = window.setInterval(() => void flushQueue(), 30_000);

  let remove: (() => void) | undefined;
  void Network.addListener("networkStatusChange", (status) => {
    if (status.connected) void flushQueue();
  })
    .then((handle) => {
      remove = () => void handle.remove();
    })
    .catch(() => {
      /* plugin unavailable on this platform */
    });

  void flushQueue();

  return () => {
    started = false;
    window.removeEventListener("online", onOnline);
    window.clearInterval(timer);
    remove?.();
  };
}
