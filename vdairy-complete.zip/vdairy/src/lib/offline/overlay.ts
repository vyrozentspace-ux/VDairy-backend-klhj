/**
 * Overlay helpers so lists show locally-saved rows before they reach the server.
 *
 * A pending insert is prepended (or merged over an existing row), a pending
 * update is applied on top of the server row, and a pending delete removes it.
 */
import { useMemo } from "react";
import { useOfflineSync } from "@/contexts/OfflineSyncContext";
import type { PendingRecord } from "@/lib/offline/queue";

export type WithId = { id: string };

export function applyQueueOverlay<T extends WithId>(
  rows: T[],
  table: string,
  records: PendingRecord[],
  keep: (row: T) => boolean = () => true,
): T[] {
  const relevant = records.filter((r) => r.table === table && r.status !== "failed");
  if (relevant.length === 0) return rows;

  const byId = new Map<string, T>(rows.map((r) => [r.id, r]));
  for (const rec of relevant) {
    if (rec.action === "delete") {
      byId.delete(rec.rowId);
      continue;
    }
    const existing = byId.get(rec.rowId);
    const merged = { ...(existing ?? {}), ...(rec.payload as object), id: rec.rowId } as T;
    byId.set(rec.rowId, merged);
  }
  return Array.from(byId.values()).filter(keep);
}

/** Same as applyQueueOverlay, reactive to queue changes. */
export function useQueueOverlay<T extends WithId>(
  rows: T[],
  table: string,
  keep?: (row: T) => boolean,
): T[] {
  const { records } = useOfflineSync();
  return useMemo(() => applyQueueOverlay(rows, table, records, keep), [rows, table, records, keep]);
}
