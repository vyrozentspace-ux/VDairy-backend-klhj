/**
 * Offline write queue.
 *
 * Every create/edit action in the app first lands here (device storage via
 * @capacitor/preferences, which falls back to localStorage on the web), then
 * gets pushed to the backend. If the device is offline — or the push fails —
 * the record stays queued and is retried automatically once connectivity
 * returns. The queue survives a full app restart.
 */
import { Preferences } from "@capacitor/preferences";

export const QUEUE_KEY = "vdairy.pendingSync.v1";

export type QueueAction = "insert" | "update" | "delete";

export type PendingRecord = {
  /** Local queue id. */
  id: string;
  /** Human label for the pending-sync list, e.g. "farmer". */
  kind: string;
  table: string;
  action: QueueAction;
  /** Primary key of the affected row (pre-generated for inserts). */
  rowId: string;
  payload: Record<string, unknown>;
  createdAt: number;
  attempts: number;
  status: "pending" | "failed";
  /** Set when a non-connectivity error blocked the sync. */
  error?: string;
};

type Listener = (records: PendingRecord[]) => void;

let cache: PendingRecord[] | null = null;
const listeners = new Set<Listener>();

export function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

async function read(): Promise<PendingRecord[]> {
  if (cache) return cache;
  try {
    const { value } = await Preferences.get({ key: QUEUE_KEY });
    cache = value ? (JSON.parse(value) as PendingRecord[]) : [];
  } catch {
    cache = [];
  }
  return cache;
}

async function write(records: PendingRecord[]): Promise<void> {
  cache = records;
  try {
    await Preferences.set({ key: QUEUE_KEY, value: JSON.stringify(records) });
  } catch {
    /* storage full / unavailable — keep the in-memory copy */
  }
  for (const l of listeners) l(records);
}

export async function loadQueue(): Promise<PendingRecord[]> {
  const records = await read();
  return [...records].sort((a, b) => a.createdAt - b.createdAt);
}

/** Synchronous snapshot for render paths; empty until the queue is loaded. */
export function queueSnapshot(): PendingRecord[] {
  return cache ? [...cache].sort((a, b) => a.createdAt - b.createdAt) : [];
}

export function subscribeQueue(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export async function enqueue(
  record: Omit<PendingRecord, "id" | "createdAt" | "attempts" | "status">,
): Promise<PendingRecord> {
  const records = await read();
  const full: PendingRecord = {
    ...record,
    id: newId(),
    createdAt: Date.now(),
    attempts: 0,
    status: "pending",
  };
  await write([...records, full]);
  return full;
}

export async function dequeue(id: string): Promise<void> {
  const records = await read();
  await write(records.filter((r) => r.id !== id));
}

export async function patchRecord(id: string, patch: Partial<PendingRecord>): Promise<void> {
  const records = await read();
  await write(records.map((r) => (r.id === id ? { ...r, ...patch } : r)));
}

export async function clearFailed(): Promise<void> {
  const records = await read();
  await write(records.filter((r) => r.status !== "failed"));
}
