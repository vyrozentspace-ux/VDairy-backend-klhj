import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { phoneToEmail, pinToPassword } from "./pin-auth";

const registerSchema = z.object({
  full_name: z.string().trim().min(2).max(100),
  phone: z.string().regex(/^[0-9]{10}$/),
  pin: z.string().regex(/^[0-9]{4}$/),
  language_preference: z.string().default("en"),
  security_question_1: z.string().min(2),
  security_answer_1: z.string().min(1),
  security_question_2: z.string().min(2),
  security_answer_2: z.string().min(1),
  referred_by_code: z.string().max(8).optional().nullable(),
});

export const registerOwner = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => registerSchema.parse(input))
  .handler(async ({ data }) => {
    if (data.security_question_1 === data.security_question_2) {
      throw new Error("Security questions must be different");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("phone", data.phone)
      .maybeSingle();
    if (existing) throw new Error("An account with this phone number already exists");

    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: phoneToEmail(data.phone),
      password: pinToPassword(data.pin),
      email_confirm: true,
      user_metadata: {
        full_name: data.full_name,
        phone: data.phone,
        pin: data.pin,
        role: "owner",
        language_preference: data.language_preference,
        security_question_1: data.security_question_1,
        security_answer_1: data.security_answer_1,
        security_question_2: data.security_question_2,
        security_answer_2: data.security_answer_2,
        referred_by_code: data.referred_by_code ?? null,
      },
    });
    if (error) {
      console.error("[registerOwner] createUser failed", {
        name: error.name,
        status: (error as unknown as { status?: number }).status,
        code: (error as unknown as { code?: string }).code,
        message: error.message,
        raw: JSON.stringify(error),
      });
      const msg =
        error.message && error.message !== "{}"
          ? error.message
          : `Sign-up failed (status ${(error as unknown as { status?: number }).status ?? "?"})`;
      throw new Error(msg);
    }

    // Create the matching profile row (hashes the security answers server-side).
    const userId = created.user?.id;
    if (userId) {
      const { error: profErr } = await supabaseAdmin.rpc("create_profile_for_user", {
        _user_id: userId,
        _full_name: data.full_name,
        _phone: data.phone,
        _role: "owner",
        _language: data.language_preference,
        _q1: data.security_question_1,
        _a1: data.security_answer_1,
        _q2: data.security_question_2,
        _a2: data.security_answer_2,
        _referred_by_code: data.referred_by_code ?? "",
      });
      if (profErr) {
        await supabaseAdmin.auth.admin.deleteUser(userId);
        throw new Error(profErr.message);
      }
    }
    return { ok: true, user_id: created.user?.id };
  });

const verifyAnswersSchema = z.object({
  phone: z.string().regex(/^[0-9]{10}$/),
  answer_1: z.string().trim().min(1).max(100),
  answer_2: z.string().trim().min(1).max(100),
});

/**
 * Verify both security answers against the bcrypt hashes stored at
 * registration. Must pass before the reset flow may show the new-PIN step.
 */
export const verifySecurityAnswers = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => verifyAnswersSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: ok, error } = await supabaseAdmin.rpc("verify_security_answers", {
      _phone: data.phone,
      _a1: data.answer_1,
      _a2: data.answer_2,
    });
    if (error) throw new Error(error.message);
    if (!ok) throw new Error("Security answers are incorrect");
    return { ok: true };
  });

const resetSchema = z.object({
  phone: z.string().regex(/^[0-9]{10}$/),
  answer_1: z.string().min(1),
  answer_2: z.string().min(1),
  new_pin: z.string().regex(/^[0-9]{4}$/),
});

export const resetPinWithAnswers = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => resetSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: ok, error: verifyErr } = await supabaseAdmin.rpc("verify_security_answers", {
      _phone: data.phone,
      _a1: data.answer_1,
      _a2: data.answer_2,
    });
    if (verifyErr) throw new Error(verifyErr.message);
    if (!ok) throw new Error("Security answers are incorrect");

    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("phone", data.phone)
      .maybeSingle();
    if (!profile) throw new Error("Account not found");

    const { error: pwErr } = await supabaseAdmin.auth.admin.updateUserById(profile.id, {
      password: pinToPassword(data.new_pin),
    });
    if (pwErr) throw new Error(pwErr.message);
    return { ok: true };
  });

const changePinSchema = z.object({
  current_pin: z.string().regex(/^[0-9]{4}$/),
  new_pin: z.string().regex(/^[0-9]{4}$/),
});

/**
 * Change the signed-in user's PIN. The current PIN is re-verified with a real
 * password grant before the new one is written, so a stolen session alone
 * cannot rotate the PIN.
 */
export const changePin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => changePinSchema.parse(input))
  .handler(async ({ data, context }) => {
    if (data.current_pin === data.new_pin) {
      throw new Error("New PIN must be different from the current PIN");
    }
    const { data: profile, error: profErr } = await context.supabase
      .from("profiles")
      .select("phone")
      .eq("id", context.userId)
      .maybeSingle();
    if (profErr) throw new Error(profErr.message);
    if (!profile?.phone) throw new Error("Account not found");

    const url = process.env.SUPABASE_URL!;
    const key = process.env.SUPABASE_PUBLISHABLE_KEY ?? process.env.SUPABASE_ANON_KEY!;
    const verify = await fetch(`${url}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: key },
      body: JSON.stringify({
        email: phoneToEmail(profile.phone),
        password: pinToPassword(data.current_pin),
      }),
    });
    if (!verify.ok) throw new Error("Current PIN is incorrect");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: pwErr } = await supabaseAdmin.auth.admin.updateUserById(context.userId, {
      password: pinToPassword(data.new_pin),
    });
    if (pwErr) throw new Error(pwErr.message);
    return { ok: true };
  });
