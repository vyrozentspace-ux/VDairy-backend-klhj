// Central place for app-level branding constants.

export const APP_NAME = "VDairy";
export const APP_TAGLINE = "Dairy Collection Center Management";
export const LOGO_LETTER = "V";

export const META_DESCRIPTION =
  "VDairy helps dairy collection centers manage farmers, milk collection, and payments.";
export const OG_DESCRIPTION = "Dairy collection center management for rural India.";
