/**
 * Pure, side-effect free "smart notification" logic.
 *
 * Everything here is deterministic: given a moment in time plus the centre's
 * configuration and recent collection data, it returns the notifications that
 * *should* exist right now. Delivery (native local notification / in-app
 * banner) lives in `notifications.ts`, so this file can be unit-tested and
 * verified in the browser without any device.
 */

export const NOTIFICATION_CATEGORIES = [
  "collection_reminders",
  "payment_reminders",
  "customer_alerts",
  "app_updates",
  "marketing",
] as const;

export type NotificationCategory = (typeof NOTIFICATION_CATEGORIES)[number];
export type NotificationPrefs = Record<NotificationCategory, boolean>;

/** Every category is ON for new users — never default everything off. */
export const DEFAULT_NOTIFICATION_PREFS: NotificationPrefs = {
  collection_reminders: true,
  payment_reminders: true,
  customer_alerts: true,
  app_updates: true,
  marketing: true,
};

export type Shift = "morning" | "evening";

export type PlannedNotification = {
  /** Stable per-day identifier; used to fire each alert only once. */
  key: string;
  category: NotificationCategory;
  /** i18n key for the title. */
  titleKey: string;
  /** i18n key for the body. */
  bodyKey: string;
  /** Interpolation values for both keys. */
  vars?: Record<string, string | number>;
  /** When the notification should be delivered. */
  at: Date;
};

export type CenterShiftTimes = {
  morning_start_time: string | null;
  morning_end_time: string | null;
  evening_start_time: string | null;
  evening_end_time: string | null;
};

/** How many minutes before a shift starts the "get ready" reminder fires. */
export const SHIFT_REMINDER_LEAD_MINUTES = 15;

export function ymd(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** Combines a `HH:MM[:SS]` time string with the date part of `base`. */
export function atTimeOn(base: Date, time: string | null | undefined): Date | null {
  if (!time) return null;
  const m = /^(\d{1,2}):(\d{2})/.exec(time.trim());
  if (!m) return null;
  const d = new Date(base);
  d.setHours(Number(m[1]), Number(m[2]), 0, 0);
  return d;
}

/**
 * Reminders around each configured shift:
 *  - "Milk collection time" — `SHIFT_REMINDER_LEAD_MINUTES` before the start.
 *  - "Morning/Evening collection starts" — exactly at the start time.
 */
export function planShiftReminders(now: Date, times: CenterShiftTimes): PlannedNotification[] {
  const day = ymd(now);
  const out: PlannedNotification[] = [];
  const shifts: Array<{ shift: Shift; start: string | null }> = [
    { shift: "morning", start: times.morning_start_time },
    { shift: "evening", start: times.evening_start_time },
  ];
  for (const { shift, start } of shifts) {
    const startAt = atTimeOn(now, start);
    if (!startAt) continue;
    const pre = new Date(startAt.getTime() - SHIFT_REMINDER_LEAD_MINUTES * 60_000);
    out.push({
      key: `collection_pre_${shift}:${day}`,
      category: "collection_reminders",
      titleKey: "notif.collection_time_title",
      bodyKey: "notif.collection_time_body",
      vars: { minutes: SHIFT_REMINDER_LEAD_MINUTES, time: formatClock(startAt) },
      at: pre,
    });
    out.push({
      key: `collection_start_${shift}:${day}`,
      category: "collection_reminders",
      titleKey: shift === "morning" ? "notif.morning_start_title" : "notif.evening_start_title",
      bodyKey: "notif.shift_start_body",
      vars: { time: formatClock(startAt) },
      at: startAt,
    });
  }
  return out;
}

export function formatClock(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())}`;
}

export type CollectionRow = {
  farmer_id: string;
  collection_date: string;
  shift: string;
};

export type FarmerRef = { id: string; code: string; first_name: string; last_name: string | null };

/** A farmer is "regular" for a shift when they delivered on >= this many of the last 7 days. */
export const REGULAR_DAYS_THRESHOLD = 3;

/**
 * Missed-collection alerts: farmers who normally deliver in this shift but have
 * no entry today, evaluated only once the shift's end time has passed.
 */
export function planMissedCollectionAlerts(args: {
  now: Date;
  times: CenterShiftTimes;
  farmers: FarmerRef[];
  /** Collections from the previous 7 days (excluding today). */
  history: CollectionRow[];
  /** Today's collections. */
  today: CollectionRow[];
}): PlannedNotification[] {
  const { now, times, farmers, history, today } = args;
  const day = ymd(now);
  const out: PlannedNotification[] = [];
  const shifts: Array<{ shift: Shift; end: string | null }> = [
    { shift: "morning", end: times.morning_end_time },
    { shift: "evening", end: times.evening_end_time },
  ];

  for (const { shift, end } of shifts) {
    const endAt = atTimeOn(now, end);
    if (!endAt || now < endAt) continue;

    const daysByFarmer = new Map<string, Set<string>>();
    for (const row of history) {
      if (row.shift !== shift) continue;
      const set = daysByFarmer.get(row.farmer_id) ?? new Set<string>();
      set.add(row.collection_date);
      daysByFarmer.set(row.farmer_id, set);
    }
    const deliveredToday = new Set(
      today.filter((r) => r.shift === shift).map((r) => r.farmer_id),
    );

    const missed = farmers.filter(
      (f) =>
        (daysByFarmer.get(f.id)?.size ?? 0) >= REGULAR_DAYS_THRESHOLD && !deliveredToday.has(f.id),
    );
    if (missed.length === 0) continue;

    const names = missed
      .slice(0, 3)
      .map((f) => `${f.code} ${f.first_name}`.trim())
      .join(", ");
    out.push({
      key: `missed_${shift}:${day}`,
      category: "customer_alerts",
      titleKey: "notif.missed_title",
      bodyKey: missed.length > 3 ? "notif.missed_body_more" : "notif.missed_body",
      vars: { count: missed.length, names, extra: missed.length - 3 },
      at: endAt,
    });
  }
  return out;
}

/** Days before expiry at which a subscription reminder fires. */
export const SUBSCRIPTION_REMINDER_DAYS = [7, 3, 1] as const;

export function planSubscriptionReminders(
  now: Date,
  subscription: { trial_ends_at: string | null; status: string | null } | null,
): PlannedNotification[] {
  if (!subscription?.trial_ends_at) return [];
  const ends = new Date(subscription.trial_ends_at);
  if (Number.isNaN(ends.getTime())) return [];
  const msLeft = ends.getTime() - now.getTime();
  const daysLeft = Math.ceil(msLeft / 86_400_000);

  if (daysLeft <= 0) {
    return [
      {
        key: `subscription_expired:${ymd(ends)}`,
        category: "payment_reminders",
        titleKey: "notif.subscription_expired_title",
        bodyKey: "notif.subscription_expired_body",
        at: now,
      },
    ];
  }
  const hit = SUBSCRIPTION_REMINDER_DAYS.find((d) => daysLeft === d);
  if (!hit) return [];
  return [
    {
      key: `subscription_${hit}d:${ymd(ends)}`,
      category: "payment_reminders",
      titleKey: "notif.subscription_expiring_title",
      bodyKey: "notif.subscription_expiring_body",
      vars: { days: hit },
      at: now,
    },
  ];
}

/** Filters planned notifications down to the ones due now and allowed by prefs. */
export function selectDue(
  planned: PlannedNotification[],
  opts: {
    now: Date;
    prefs: NotificationPrefs;
    /** Keys already delivered. */
    fired: Set<string>;
    /** When false, payment/subscription notifications are suppressed entirely. */
    allowSubscription?: boolean;
    /** Grace window: a reminder still fires if missed by up to this many minutes. */
    graceMinutes?: number;
  },
): PlannedNotification[] {
  const grace = (opts.graceMinutes ?? 90) * 60_000;
  return planned.filter((n) => {
    if (!opts.prefs[n.category]) return false;
    if (n.category === "payment_reminders" && opts.allowSubscription === false) return false;
    if (opts.fired.has(n.key)) return false;
    const delta = opts.now.getTime() - n.at.getTime();
    return delta >= 0 && delta <= grace;
  });
}

/** Notifications in the future that a native device can pre-schedule. */
export function selectSchedulable(
  planned: PlannedNotification[],
  opts: { now: Date; prefs: NotificationPrefs; allowSubscription?: boolean },
): PlannedNotification[] {
  return planned.filter((n) => {
    if (!opts.prefs[n.category]) return false;
    if (n.category === "payment_reminders" && opts.allowSubscription === false) return false;
    return n.at.getTime() > opts.now.getTime();
  });
}

/** Days before the billing period ends at which a payment-due reminder fires. */
export const PAYMENT_DUE_REMINDER_DAYS = [7, 3, 1] as const;
/** Cadence of the "upgrade options" reminder once a centre is on a paid plan. */
export const UPGRADE_REMINDER_INTERVAL_DAYS = 10;

export type SubscriptionSnapshot = {
  status: string | null;
  plan: string | null;
  trial_ends_at: string | null;
  current_period_end: string | null;
  /** When the current plan started (falls back to the trial start). */
  plan_started_at?: string | null;
};

/**
 * Reminders for centres already on a paid plan:
 *  - payment due as the billing period approaches its end (7/3/1 days),
 *  - an upgrade-options nudge every 10 days.
 */
export function planPaidPlanReminders(
  now: Date,
  sub: SubscriptionSnapshot | null,
): PlannedNotification[] {
  if (!sub || sub.status !== "active" || !sub.plan) return [];
  const out: PlannedNotification[] = [];

  if (sub.current_period_end) {
    const end = new Date(sub.current_period_end);
    if (!Number.isNaN(end.getTime())) {
      const daysLeft = Math.ceil((end.getTime() - now.getTime()) / 86_400_000);
      const hit = PAYMENT_DUE_REMINDER_DAYS.find((d) => daysLeft === d);
      if (hit) {
        out.push({
          key: `payment_due_${hit}d:${ymd(end)}`,
          category: "payment_reminders",
          titleKey: "notif.payment_due_title",
          bodyKey: "notif.payment_due_body",
          vars: { days: hit },
          at: now,
        });
      }
    }
  }

  const started = sub.plan_started_at ? new Date(sub.plan_started_at) : null;
  if (started && !Number.isNaN(started.getTime())) {
    const daysOn = Math.floor((now.getTime() - started.getTime()) / 86_400_000);
    if (daysOn > 0 && daysOn % UPGRADE_REMINDER_INTERVAL_DAYS === 0) {
      out.push({
        key: `upgrade_options:${ymd(now)}`,
        category: "app_updates",
        titleKey: "notif.upgrade_options_title",
        bodyKey: "notif.upgrade_options_body",
        at: now,
      });
    }
  }
  return out;
}
