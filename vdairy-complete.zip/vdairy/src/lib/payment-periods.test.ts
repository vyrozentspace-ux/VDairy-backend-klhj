import assert from "node:assert/strict";
import { describe, test } from "node:test";
import { periodForDate, shiftPeriod } from "./payment-periods.ts";

describe("anchored payment periods", () => {
  const config = { paymentPeriod: "01-10, 11-20, 21-ME", startDate: "2026-07-06" };

  test("uses the configured anchor for every 10-day cycle", () => {
    assert.deepEqual(periodForDate(config, new Date("2026-08-04T00:00:00")), {
      start: "2026-07-26",
      end: "2026-08-04",
    });
  });

  test("moves between adjacent anchored cycles without gaps", () => {
    const current = periodForDate(config, new Date("2026-08-04T00:00:00"));
    assert.deepEqual(shiftPeriod(config, current, -1), { start: "2026-07-16", end: "2026-07-25" });
    assert.deepEqual(shiftPeriod(config, current, 1), { start: "2026-08-05", end: "2026-08-14" });
  });
});