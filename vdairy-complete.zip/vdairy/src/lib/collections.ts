import { supabase } from "@/integrations/supabase/client";
import { newId } from "@/lib/offline/queue";
import { saveOffline } from "@/lib/offline/sync";
import type { MilkType } from "@/lib/farmers";


export type Shift = "morning" | "evening";

export type Collection = {
  id: string;
  center_id: string;
  farmer_id: string;
  collection_date: string;
  shift: Shift;
  milk_type: MilkType;
  fat: number;
  snf: number | null;
  quantity_liters: number;
  rate_per_liter: number;
  total_amount: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export function currentShiftForNow(d = new Date()): Shift {
  return d.getHours() < 14 ? "morning" : "evening";
}

export function todayISO(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export async function listCollections(params: {
  centerId: string;
  date: string;
  shift?: Shift | "all";
}): Promise<Collection[]> {
  let q = db
    .from("collections")
    .select("*")
    .eq("center_id", params.centerId)
    .eq("collection_date", params.date)
    .order("created_at", { ascending: false });
  if (params.shift && params.shift !== "all") q = q.eq("shift", params.shift);
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return (data ?? []) as Collection[];
}

export async function getCollection(id: string): Promise<Collection | null> {
  const { data, error } = await db.from("collections").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? null) as Collection | null;
}

export async function createCollection(input: {
  center_id: string;
  farmer_id: string;
  collection_date: string;
  shift: Shift;
  milk_type: MilkType;
  fat: number;
  snf: number | null;
  quantity_liters: number;
  rate_per_liter: number;
  total_amount: number;
  created_by: string | null;
}): Promise<{ row: Collection; synced: boolean }> {
  const now = new Date().toISOString();
  const row = { id: newId(), ...input, created_at: now, updated_at: now } as Collection;
  const { synced } = await saveOffline({
    kind: "collection",
    table: "collections",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  if (synced) {
    await logCollectionActivity(input.center_id, input.created_by, "collection_created", {
      id: row.id,
      farmer_id: input.farmer_id,
    });
  }
  return { row, synced };
}

export async function updateCollection(
  id: string,
  patch: Partial<Collection>,
  meta?: { center_id?: string; created_by?: string | null },
): Promise<{ synced: boolean }> {
  const payload = { ...patch, updated_at: new Date().toISOString() };
  const { synced } = await saveOffline({
    kind: "collection",
    table: "collections",
    action: "update",
    rowId: id,
    payload: payload as unknown as Record<string, unknown>,
  });
  if (synced && meta?.center_id) {
    await logCollectionActivity(meta.center_id, meta.created_by ?? null, "collection_updated", {
      id,
    });
  }
  return { synced };
}

export async function deleteCollection(
  id: string,
  meta?: { center_id?: string; created_by?: string | null },
): Promise<{ synced: boolean }> {
  const { synced } = await saveOffline({
    kind: "collection",
    table: "collections",
    action: "delete",
    rowId: id,
    payload: {},
  });
  if (synced && meta?.center_id) {
    await logCollectionActivity(meta.center_id, meta.created_by ?? null, "collection_deleted", {
      id,
    });
  }
  return { synced };
}


async function logCollectionActivity(
  centerId: string,
  userId: string | null,
  action: string,
  details: Record<string, unknown>,
) {
  try {
    await db.from("activity_logs").insert({
      center_id: centerId,
      user_id: userId,
      action,
      details,
    });
  } catch {
    /* non-fatal */
  }
}
