import { getActiveLanguage } from "@/lib/active-language";

const LOCALE_TAGS: Record<string, string> = {
  en: "en-IN",
  hi: "hi-IN",
  mr: "mr-IN",
  ta: "ta-IN",
  te: "te-IN",
};

/** BCP-47 tag for the active (or given) app language. Digits stay Latin. */
export function localeTag(lang?: string): string {
  const code = (lang ?? getActiveLanguage() ?? "en").slice(0, 2);
  return `${LOCALE_TAGS[code] ?? "en-IN"}-u-nu-latn`;
}

export function toDate(value: string | Date): Date {
  if (value instanceof Date) return value;
  // Plain ISO date (YYYY-MM-DD) -> local midnight, avoids UTC shifting.
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return new Date(`${value}T00:00:00`);
  return new Date(value);
}

export function formatDate(
  value: string | Date,
  opts: Intl.DateTimeFormatOptions,
  lang?: string,
): string {
  const d = toDate(value);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat(localeTag(lang), opts).format(d);
}

/** e.g. 05 Jul */
export const formatDayMonth = (v: string | Date, lang?: string) =>
  formatDate(v, { day: "2-digit", month: "short" }, lang);

/** e.g. 05 Jul 2026 */
export const formatDayMonthYear = (v: string | Date, lang?: string) =>
  formatDate(v, { day: "2-digit", month: "short", year: "numeric" }, lang);

/** e.g. July 2026 */
export const formatMonthYear = (v: string | Date, lang?: string) =>
  formatDate(v, { month: "long", year: "numeric" }, lang);

/** e.g. Jul */
export const formatMonthShort = (v: string | Date, lang?: string) =>
  formatDate(v, { month: "short" }, lang);

/** Numeric dd/mm/yyyy, locale-formatted but always Latin digits. */
export const formatNumericDate = (v: string | Date, lang?: string) =>
  formatDate(v, { day: "2-digit", month: "2-digit", year: "numeric" }, lang);

/** e.g. Mon, 05 Jul */
export const formatWeekdayDayMonth = (v: string | Date, lang?: string) =>
  formatDate(v, { weekday: "short", day: "2-digit", month: "short" }, lang);
