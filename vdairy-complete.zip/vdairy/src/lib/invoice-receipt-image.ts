// Full itemized invoice receipt rendered to a PNG for WhatsApp / native share.
// Mirrors the in-app Invoice Detail screen: branding, farmer + period, every
// collection day as its own row, cattle feeds, itemized deductions, advances
// and the final Net Payment summary. Height is computed from the content, so
// any period length (5-day, 10-day, 15-day, monthly) renders correctly.

export type ReceiptCollectionRow = {
  date: string;
  session: string;
  milkType: string;
  liters: number;
  fat: number | null;
  snf: number | null;
  rate: number;
  amount: number;
};

export type ReceiptFeedRow = {
  date: string;
  product: string;
  qty: number;
  rate: number;
  amount: number;
};
export type ReceiptDeductionRow = { label: string; amount: number };
export type ReceiptAdvanceRow = { date: string; comments: string | null; amount: number };

export type InvoiceReceiptLabels = {
  title: string;
  collections: string;
  cattleFeeds: string;
  deductions: string;
  advanceGiven: string;
  summary: string;
  date: string;
  session: string;
  type: string;
  litre: string;
  fat: string;
  snf: string;
  rate: string;
  amount: string;
  product: string;
  qty: string;
  total: string;
  totalLitres: string;
  milkAmount: string;
  totalDeduction: string;
  previousBalance: string;
  netPayment: string;
  comments: string;
  closing: string;
};

export type InvoiceReceiptData = {
  centerName: string;
  farmerName: string;
  farmerCode?: string | null;
  periodLabel: string;
  collections: ReceiptCollectionRow[];
  feeds: ReceiptFeedRow[];
  deductions: ReceiptDeductionRow[];
  advances: ReceiptAdvanceRow[];
  totals: {
    liters: number;
    milkAmount: number;
    feedTotal: number;
    deductionTotal: number;
    previousBalance: number;
    advanceGiven: number;
    netPayment: number;
  };
  labels: InvoiceReceiptLabels;
};

const TEAL = "#0f766e";
const TEAL_DARK = "#134e4a";
const INK = "#0f172a";
const MUTED = "#64748b";
const LINE = "#e2e8f0";
const ROSE = "#e11d48";
const EMERALD = "#047857";

const W = 900;
const PAD = 36;
const CW = W - PAD * 2;
const ROW_H = 30;
const HEAD_H = 30;
const TITLE_H = 40;
const SECTION_GAP = 22;
const HEADER_H = 210;
const FOOTER_H = 96;

const money = (n: number) => `₹${Number(n).toFixed(2)}`;
const num = (n: number, d = 2) => Number(n).toFixed(d);

type Col = { key: string; label: string; w: number; align: "left" | "right" };

function cols(spec: [string, string, number, "left" | "right"][]): Col[] {
  const totalW = spec.reduce((s, c) => s + c[2], 0);
  return spec.map(([key, label, w, align]) => ({ key, label, w: (w / totalW) * CW, align }));
}

function sectionHeight(rowCount: number, withTotal = true) {
  return TITLE_H + HEAD_H + rowCount * ROW_H + (withTotal ? ROW_H + 4 : 0) + SECTION_GAP;
}

export function generateInvoiceReceiptImage(data: InvoiceReceiptData): Promise<Blob> {
  const L = data.labels;
  const hasFeeds = data.feeds.length > 0;
  const hasDeductions = data.deductions.length > 0 || data.totals.deductionTotal > 0;
  const hasAdvances = data.advances.length > 0;

  const summaryRows =
    2 +
    (Math.abs(data.totals.previousBalance) > 0.001 ? 1 : 0) +
    (Math.abs(data.totals.advanceGiven) > 0.001 ? 1 : 0);
  const summaryH = TITLE_H + summaryRows * ROW_H + 76 + SECTION_GAP;

  let H = HEADER_H;
  H += sectionHeight(data.collections.length);
  if (hasFeeds) H += sectionHeight(data.feeds.length);
  if (hasDeductions) H += sectionHeight(Math.max(data.deductions.length, 1));
  if (hasAdvances) H += sectionHeight(data.advances.length);
  H += summaryH + FOOTER_H;

  const scale = 2;
  const canvas = document.createElement("canvas");
  canvas.width = W * scale;
  canvas.height = H * scale;
  const ctx = canvas.getContext("2d")!;
  ctx.scale(scale, scale);

  const font = (size: number, weight = "") =>
    `${weight ? weight + " " : ""}${size}px system-ui, -apple-system, "Noto Sans", sans-serif`;

  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, W, H);
  ctx.textBaseline = "middle";

  // ── Branding header ──────────────────────────────────────────────
  ctx.fillStyle = TEAL;
  ctx.fillRect(0, 0, W, 6);

  ctx.fillStyle = TEAL;
  roundRect(ctx, PAD, 34, 60, 60, 14);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.font = font(36, "bold");
  ctx.textAlign = "center";
  ctx.fillText("V", PAD + 30, 65);
  ctx.textAlign = "left";

  ctx.fillStyle = TEAL_DARK;
  ctx.font = font(32, "bold");
  ctx.fillText("VDairy", PAD + 76, 52);
  ctx.fillStyle = MUTED;
  ctx.font = font(15);
  ctx.fillText(L.title, PAD + 76, 78);

  ctx.textAlign = "right";
  ctx.fillStyle = INK;
  ctx.font = font(20, "bold");
  ctx.fillText(data.centerName, W - PAD, 52);
  ctx.fillStyle = MUTED;
  ctx.font = font(15);
  ctx.fillText(data.periodLabel, W - PAD, 78);
  ctx.textAlign = "left";

  line(ctx, PAD, 112, W - PAD, 112);

  ctx.fillStyle = INK;
  ctx.font = font(24, "bold");
  ctx.fillText(data.farmerName, PAD, 142);
  ctx.fillStyle = MUTED;
  ctx.font = font(15);
  if (data.farmerCode) ctx.fillText(`Code ${data.farmerCode}`, PAD, 170);
  ctx.textAlign = "right";
  ctx.fillText(`${num(data.totals.liters, 2)} L`, W - PAD, 142);
  ctx.textAlign = "left";

  let y = HEADER_H - 14;

  const drawTable = (
    title: string,
    colDefs: Col[],
    rows: Record<string, string>[],
    totalCells?: { spanTo: number; label: string; values: Record<string, string> },
  ) => {
    ctx.fillStyle = TEAL_DARK;
    ctx.font = font(19, "bold");
    ctx.textAlign = "left";
    ctx.fillText(title, PAD, y + TITLE_H / 2);
    y += TITLE_H;

    // header row
    ctx.fillStyle = "#f1f5f9";
    ctx.fillRect(PAD, y, CW, HEAD_H);
    ctx.fillStyle = MUTED;
    ctx.font = font(14, "bold");
    let x = PAD;
    for (const c of colDefs) {
      ctx.textAlign = c.align;
      ctx.fillText(c.label, c.align === "right" ? x + c.w - 10 : x + 10, y + HEAD_H / 2);
      x += c.w;
    }
    y += HEAD_H;

    rows.forEach((r, i) => {
      if (i % 2 === 1) {
        ctx.fillStyle = "#f8fafc";
        ctx.fillRect(PAD, y, CW, ROW_H);
      }
      ctx.fillStyle = INK;
      ctx.font = font(15);
      let cx = PAD;
      for (const c of colDefs) {
        ctx.textAlign = c.align;
        ctx.fillText(
          clip(ctx, r[c.key] ?? "", c.w - 20),
          c.align === "right" ? cx + c.w - 10 : cx + 10,
          y + ROW_H / 2,
        );
        cx += c.w;
      }
      y += ROW_H;
    });

    if (totalCells) {
      line(ctx, PAD, y, W - PAD, y);
      y += 4;
      ctx.fillStyle = TEAL_DARK;
      ctx.font = font(16, "bold");
      let cx = PAD;
      colDefs.forEach((c, idx) => {
        if (idx === 0) {
          ctx.textAlign = "left";
          ctx.fillText(totalCells.label, cx + 10, y + ROW_H / 2);
        } else if (idx >= totalCells.spanTo) {
          const v = totalCells.values[c.key];
          if (v) {
            ctx.textAlign = c.align;
            ctx.fillText(v, c.align === "right" ? cx + c.w - 10 : cx + 10, y + ROW_H / 2);
          }
        }
        cx += c.w;
      });
      y += ROW_H;
    }
    y += SECTION_GAP;
  };

  // ── Collections ──────────────────────────────────────────────────
  const colCols = cols([
    ["date", L.date, 120, "left"],
    ["session", L.session, 105, "left"],
    ["type", L.type, 95, "left"],
    ["liters", L.litre, 80, "right"],
    ["fat", L.fat, 70, "right"],
    ["snf", L.snf, 70, "right"],
    ["rate", L.rate, 90, "right"],
    ["amount", L.amount, 120, "right"],
  ]);
  drawTable(
    `${L.collections} (${data.collections.length})`,
    colCols,
    data.collections.map((c) => ({
      date: c.date,
      session: c.session,
      type: c.milkType,
      liters: num(c.liters, 2),
      fat: c.fat != null ? num(c.fat, 1) : "—",
      snf: c.snf != null ? num(c.snf, 1) : "—",
      rate: num(c.rate, 2),
      amount: num(c.amount, 2),
    })),
    {
      spanTo: 3,
      label: L.total,
      values: { liters: num(data.totals.liters, 2), amount: num(data.totals.milkAmount, 2) },
    },
  );

  // ── Cattle feeds ─────────────────────────────────────────────────
  if (hasFeeds) {
    drawTable(
      L.cattleFeeds,
      cols([
        ["date", L.date, 130, "left"],
        ["product", L.product, 300, "left"],
        ["qty", L.qty, 100, "right"],
        ["rate", L.rate, 110, "right"],
        ["amount", L.amount, 130, "right"],
      ]),
      data.feeds.map((f) => ({
        date: f.date,
        product: f.product,
        qty: num(f.qty, 1),
        rate: num(f.rate, 2),
        amount: num(f.amount, 2),
      })),
      { spanTo: 4, label: L.total, values: { amount: num(data.totals.feedTotal, 2) } },
    );
  }

  // ── Deductions ───────────────────────────────────────────────────
  if (hasDeductions) {
    drawTable(
      L.deductions,
      cols([
        ["label", L.type, 620, "left"],
        ["amount", L.amount, 180, "right"],
      ]),
      data.deductions.map((d) => ({ label: d.label, amount: num(d.amount, 2) })),
      { spanTo: 1, label: L.total, values: { amount: num(data.totals.deductionTotal, 2) } },
    );
  }

  // ── Advances given ───────────────────────────────────────────────
  if (hasAdvances) {
    drawTable(
      L.advanceGiven,
      cols([
        ["date", L.date, 150, "left"],
        ["comments", L.comments, 470, "left"],
        ["amount", L.amount, 180, "right"],
      ]),
      data.advances.map((a) => ({
        date: a.date,
        comments: a.comments ?? "—",
        amount: num(a.amount, 2),
      })),
      { spanTo: 2, label: L.total, values: { amount: num(data.totals.advanceGiven, 2) } },
    );
  }

  // ── Final summary ────────────────────────────────────────────────
  ctx.fillStyle = TEAL_DARK;
  ctx.font = font(19, "bold");
  ctx.textAlign = "left";
  ctx.fillText(L.summary, PAD, y + TITLE_H / 2);
  y += TITLE_H;

  const sumRow = (label: string, value: string, color = INK) => {
    ctx.fillStyle = MUTED;
    ctx.font = font(16);
    ctx.textAlign = "left";
    ctx.fillText(label, PAD + 10, y + ROW_H / 2);
    ctx.fillStyle = color;
    ctx.font = font(16, "bold");
    ctx.textAlign = "right";
    ctx.fillText(value, W - PAD - 10, y + ROW_H / 2);
    y += ROW_H;
  };

  sumRow(L.milkAmount, money(data.totals.milkAmount));
  sumRow(L.totalDeduction, `− ${money(data.totals.deductionTotal)}`, ROSE);
  if (Math.abs(data.totals.previousBalance) > 0.001)
    sumRow(L.previousBalance, money(data.totals.previousBalance));
  if (Math.abs(data.totals.advanceGiven) > 0.001)
    sumRow(L.advanceGiven, `− ${money(data.totals.advanceGiven)}`, ROSE);

  y += 10;
  const net = data.totals.netPayment;
  ctx.fillStyle = net < 0 ? "#fff1f2" : "#ecfdf5";
  roundRect(ctx, PAD, y, CW, 60, 12);
  ctx.fill();
  ctx.strokeStyle = net < 0 ? "#fecdd3" : "#a7f3d0";
  ctx.stroke();
  ctx.fillStyle = net < 0 ? ROSE : EMERALD;
  ctx.font = font(20, "bold");
  ctx.textAlign = "left";
  ctx.fillText(L.netPayment, PAD + 18, y + 30);
  ctx.font = font(28, "bold");
  ctx.textAlign = "right";
  ctx.fillText(`${net < 0 ? "− " : ""}${money(Math.abs(net))}`, W - PAD - 18, y + 30);
  y += 60 + SECTION_GAP;

  // ── Footer ───────────────────────────────────────────────────────
  ctx.fillStyle = INK;
  ctx.font = font(16);
  ctx.textAlign = "center";
  ctx.fillText(L.closing, W / 2, y + 16);
  ctx.fillStyle = "#94a3b8";
  ctx.font = font(13);
  ctx.fillText("Generated by VDairy", W / 2, y + 44);
  ctx.textAlign = "left";

  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Canvas encode failed"))), "image/png");
  });
}

function clip(ctx: CanvasRenderingContext2D, text: string, maxW: number) {
  if (ctx.measureText(text).width <= maxW) return text;
  let out = text;
  while (out.length > 1 && ctx.measureText(out + "…").width > maxW) out = out.slice(0, -1);
  return out + "…";
}

function line(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number) {
  ctx.strokeStyle = LINE;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x1, y1 + 0.5);
  ctx.lineTo(x2, y2 + 0.5);
  ctx.stroke();
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** Share the detailed receipt image natively; falls back to text share. */
export async function shareInvoiceReceiptImage(
  data: InvoiceReceiptData,
  opts: { text: string; phone?: string | null },
) {
  const { shareText } = await import("@/lib/share");
  try {
    const blob = await generateInvoiceReceiptImage(data);
    const file = new File([blob], "invoice-receipt.png", { type: "image/png" });
    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    if (nav.canShare?.({ files: [file] }) && typeof navigator.share === "function") {
      await navigator.share({ files: [file], text: opts.text, title: data.labels.title });
      return;
    }
  } catch {
    /* fall through */
  }
  await shareText(opts.text, opts.phone);
}
