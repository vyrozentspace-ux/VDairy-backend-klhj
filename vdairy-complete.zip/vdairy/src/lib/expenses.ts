import { formatMonthYear } from "@/lib/date-locale";
import { supabase } from "@/integrations/supabase/client";
import { newId } from "@/lib/offline/queue";
import { saveOffline } from "@/lib/offline/sync";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export type PayMode = "cash" | "upi" | "other";

export type ExpenseCategory = {
  id: string;
  center_id: string | null;
  name: string;
  is_default: boolean;
  created_at: string;
};

export type DairyExpense = {
  id: string;
  center_id: string;
  category_id: string;
  custom_category_label: string | null;
  amount: number;
  expense_date: string;
  note: string | null;
  payment_mode: PayMode | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

export async function listCategories(centerId: string): Promise<ExpenseCategory[]> {
  const { data, error } = await db
    .from("expense_categories")
    .select("*")
    .or(`center_id.is.null,center_id.eq.${centerId}`);
  if (error) throw new Error(error.message);
  const rows = (data ?? []) as ExpenseCategory[];
  return rows.sort((a, b) => {
    if (a.is_default !== b.is_default) return a.is_default ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
}

export async function findOrCreateCustomCategory(
  centerId: string,
  label: string,
): Promise<ExpenseCategory> {
  const clean = label.trim();
  const { data: existing } = await db
    .from("expense_categories")
    .select("*")
    .eq("center_id", centerId)
    .ilike("name", clean)
    .maybeSingle();
  if (existing) return existing as ExpenseCategory;
  const { data, error } = await db
    .from("expense_categories")
    .insert({ center_id: centerId, name: clean, is_default: false })
    .select("*")
    .single();
  if (error) throw new Error(error.message);
  return data as ExpenseCategory;
}

export async function listExpenses(
  centerId: string,
  opts?: { from?: string; to?: string },
): Promise<DairyExpense[]> {
  let q = db
    .from("dairy_expenses")
    .select("*")
    .eq("center_id", centerId)
    .order("expense_date", { ascending: false })
    .order("created_at", { ascending: false });
  if (opts?.from) q = q.gte("expense_date", opts.from);
  if (opts?.to) q = q.lte("expense_date", opts.to);
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return (data ?? []) as DairyExpense[];
}

export async function getExpense(id: string): Promise<DairyExpense | null> {
  const { data, error } = await db.from("dairy_expenses").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? null) as DairyExpense | null;
}

export type ExpenseInput = {
  center_id: string;
  category_id: string;
  custom_category_label: string | null;
  amount: number;
  expense_date: string;
  note: string | null;
  payment_mode: PayMode | null;
  created_by?: string | null;
};

export async function createExpense(input: ExpenseInput): Promise<DairyExpense> {
  const now = new Date().toISOString();
  const row = { id: newId(), ...input, created_at: now, updated_at: now } as DairyExpense;
  await saveOffline({
    kind: "expense",
    table: "dairy_expenses",
    action: "insert",
    rowId: row.id,
    payload: row as unknown as Record<string, unknown>,
  });
  return row;
}

export async function updateExpense(id: string, input: Partial<ExpenseInput>): Promise<void> {
  await saveOffline({
    kind: "expense",
    table: "dairy_expenses",
    action: "update",
    rowId: id,
    payload: { ...input, updated_at: new Date().toISOString() } as Record<string, unknown>,
  });
}

export async function deleteExpense(id: string): Promise<void> {
  await saveOffline({
    kind: "expense",
    table: "dairy_expenses",
    action: "delete",
    rowId: id,
    payload: {},
  });
}

export function categoryLabel(
  exp: Pick<DairyExpense, "custom_category_label">,
  cat?: Pick<ExpenseCategory, "name">,
): string {
  if (exp.custom_category_label && exp.custom_category_label.trim())
    return exp.custom_category_label;
  return cat?.name ?? "—";
}

export function monthLabel(d: Date): string {
  return formatMonthYear(d);
}

export function monthRange(d: Date): { from: string; to: string } {
  const from = new Date(d.getFullYear(), d.getMonth(), 1);
  const to = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  const iso = (x: Date) =>
    `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
  return { from: iso(from), to: iso(to) };
}

export function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function formatINR(n: number): string {
  return `₹${Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}
