import { createInstance } from "i18next";
import { initReactI18next } from "react-i18next";
import { setActiveLanguage } from "@/lib/active-language";

const groupModules = import.meta.glob("../i18n/locales/*/*.json", {
  eager: true,
}) as Record<string, { default: Record<string, string> }>;

function buildResources() {
  const out: Record<string, { translation: Record<string, string> }> = {
    en: { translation: {} },
    hi: { translation: {} },
    mr: { translation: {} },
    ta: { translation: {} },
    te: { translation: {} },
  };
  for (const [path, mod] of Object.entries(groupModules)) {
    const m = /locales\/([a-z]{2})\/[^/]+\.json$/.exec(path);
    if (!m) continue;
    const lang = m[1];
    if (!out[lang]) out[lang] = { translation: {} };
    Object.assign(out[lang].translation, mod.default ?? {});
  }
  return out;
}

const resources = buildResources();

const i18n = createInstance();

export const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिंदी" },
  { code: "mr", label: "मराठी" },
  { code: "ta", label: "தமிழ்" },
  { code: "te", label: "తెలుగు" },
] as const;

export const APP_LANG_KEY = "vdairy.appLanguage";

function getInitialLang(): string {
  if (typeof window === "undefined") return "en";
  return window.localStorage.getItem(APP_LANG_KEY) ?? "en";
}

void i18n.use(initReactI18next).init({
  resources,
  lng: getInitialLang(),
  fallbackLng: "en",
  keySeparator: false,
  nsSeparator: false,
  initAsync: false,
  react: { useSuspense: false },
  interpolation: { escapeValue: false },
});

setActiveLanguage(i18n.language ?? "en");
i18n.on("languageChanged", (lng) => setActiveLanguage(lng));

export function setAppLanguage(code: string) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(APP_LANG_KEY, code);
    document.documentElement.lang = code;
  }
  setActiveLanguage(code);
  void i18n.changeLanguage(code);
}

export default i18n;
