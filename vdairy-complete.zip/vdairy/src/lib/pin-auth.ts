export function phoneToEmail(phone: string): string {
  return `${phone}@vdairy.app`;
}

export function pinToPassword(pin: string): string {
  return `${pin}-vdairy`;
}
