/** Per-operator permission flags stored in center_operators.permissions (JSONB). */
export const PERMISSION_KEYS = [
  "collection",
  "collection_history",
  "farmer",
  "food",
  "advance",
  "invoice",
  "invoice_view_only",
  "milk_sale",
  "dairy_expense",
  "rate_chart",
  "reports",
  "center_settings",
  "manage_operators",
  "send_messages",
] as const;

export type PermissionKey = (typeof PERMISSION_KEYS)[number];
export type Permissions = Record<PermissionKey, boolean>;

export const DEFAULT_OPERATOR_PERMISSIONS: Permissions = {
  collection: true,
  collection_history: false,
  farmer: true,
  food: true,
  advance: false,
  invoice: true,
  invoice_view_only: true,
  milk_sale: false,
  dairy_expense: false,
  rate_chart: false,
  reports: false,
  center_settings: false,
  manage_operators: false,
  send_messages: true,
};

export const PERMISSION_LABEL: Record<PermissionKey, string> = {
  collection: "Collection",
  collection_history: "View past collections",
  farmer: "Farmers",
  food: "Food / Feed",
  advance: "Advance",
  invoice: "Invoice (full)",
  invoice_view_only: "Invoice (view only)",
  milk_sale: "Milk Sale",
  dairy_expense: "Dairy Expense",
  rate_chart: "Rate Chart",
  reports: "Reports",
  center_settings: "Center Settings",
  manage_operators: "Manage Operators",
  send_messages: "Send Messages / Notices",
};

/** Coerce an unknown JSONB value into a complete permission set. */
export function normalizePermissions(value: unknown): Permissions {
  const src = (value ?? {}) as Record<string, unknown>;
  const out = {} as Permissions;
  for (const key of PERMISSION_KEYS) out[key] = src[key] === true;
  return out;
}

export const ALL_PERMISSIONS: Permissions = PERMISSION_KEYS.reduce((acc, k) => {
  acc[k] = true;
  return acc;
}, {} as Permissions);

/**
 * Route prefix -> permissions that grant access (any one is enough).
 * Routes not listed here are open to every signed-in member of a center.
 */
const ROUTE_PERMISSIONS: Array<{ prefix: string; any: PermissionKey[] }> = [
  { prefix: "/collection", any: ["collection"] },
  { prefix: "/farmers", any: ["farmer", "collection"] },
  { prefix: "/farmer", any: ["farmer"] },
  { prefix: "/food", any: ["food"] },
  { prefix: "/advance", any: ["advance"] },
  { prefix: "/invoice", any: ["invoice", "invoice_view_only"] },
  { prefix: "/milk-sale", any: ["milk_sale"] },
  { prefix: "/expense", any: ["dairy_expense"] },
  { prefix: "/rate-charts", any: ["rate_chart"] },
  { prefix: "/reports", any: ["reports"] },
  { prefix: "/notices", any: ["send_messages"] },
  { prefix: "/bonus", any: ["reports"] },
  { prefix: "/center-info", any: ["center_settings"] },
  { prefix: "/operators", any: ["manage_operators"] },
];

export function requiredPermissionsFor(pathname: string): PermissionKey[] | null {
  const match = ROUTE_PERMISSIONS.find(
    (r) => pathname === r.prefix || pathname.startsWith(`${r.prefix}/`),
  );
  return match ? match.any : null;
}
