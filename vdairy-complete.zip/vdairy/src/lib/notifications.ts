import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  DEFAULT_NOTIFICATION_PREFS,
  NOTIFICATION_CATEGORIES,
  type NotificationCategory,
  type NotificationPrefs,
  type PlannedNotification,
} from "./notification-engine";

/* -------------------------------------------------------------------------- */
/* Preferences                                                                 */
/* -------------------------------------------------------------------------- */

const PREFS_CACHE_KEY = "vdairy.notificationPrefs";

function readCache(): NotificationPrefs | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(PREFS_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const out = { ...DEFAULT_NOTIFICATION_PREFS };
    for (const key of NOTIFICATION_CATEGORIES) {
      if (typeof parsed[key] === "boolean") out[key] = parsed[key] as boolean;
    }
    return out;
  } catch {
    return null;
  }
}

function writeCache(prefs: NotificationPrefs) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(PREFS_CACHE_KEY, JSON.stringify(prefs));
}

/**
 * Loads the user's category preferences, creating the row (all ON) the first
 * time. Any failure falls back to "everything on" — we never silently mute.
 */
export async function loadNotificationPrefs(userId: string): Promise<NotificationPrefs> {
  const { data } = await supabase
    .from("user_notification_prefs")
    .select("collection_reminders, payment_reminders, customer_alerts, app_updates, marketing")
    .eq("user_id", userId)
    .maybeSingle();

  if (!data) {
    await supabase
      .from("user_notification_prefs")
      .upsert({ user_id: userId }, { onConflict: "user_id" });
    writeCache(DEFAULT_NOTIFICATION_PREFS);
    return { ...DEFAULT_NOTIFICATION_PREFS };
  }
  const prefs = { ...DEFAULT_NOTIFICATION_PREFS };
  for (const key of NOTIFICATION_CATEGORIES) {
    const v = (data as Record<string, unknown>)[key];
    if (typeof v === "boolean") prefs[key] = v;
  }
  writeCache(prefs);
  return prefs;
}

export async function saveNotificationPref(
  userId: string,
  category: NotificationCategory,
  value: boolean,
): Promise<{ error: string | null }> {
  const row: Record<string, string | boolean> = { user_id: userId };
  row[category] = value;
  const { error } = await supabase
    .from("user_notification_prefs")
    .upsert(row as never, { onConflict: "user_id" });
  return { error: error?.message ?? null };
}

/** React binding for the per-user category toggles. */
export function useNotificationPrefs(userId: string | null | undefined) {
  const [prefs, setPrefs] = useState<NotificationPrefs>(
    () => readCache() ?? { ...DEFAULT_NOTIFICATION_PREFS },
  );
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    if (!userId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    void loadNotificationPrefs(userId).then((p) => {
      if (!cancelled) {
        setPrefs(p);
        setLoading(false);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [userId]);

  const setCategory = useCallback(
    async (category: NotificationCategory, value: boolean) => {
      setPrefs((prev) => {
        const next = { ...prev, [category]: value };
        writeCache(next);
        return next;
      });
      if (userId) await saveNotificationPref(userId, category, value);
    },
    [userId],
  );

  return { prefs, loading, setCategory };
}

/* -------------------------------------------------------------------------- */
/* Owner-level control: may operators get subscription notifications?          */
/* -------------------------------------------------------------------------- */

export async function getOperatorSubscriptionNotifications(centerId: string): Promise<boolean> {
  const { data } = await supabase
    .from("dairy_centers")
    .select("operator_subscription_notifications")
    .eq("id", centerId)
    .maybeSingle();
  return (data as { operator_subscription_notifications?: boolean } | null)
    ?.operator_subscription_notifications !== false;
}

export async function setOperatorSubscriptionNotifications(centerId: string, value: boolean) {
  const { error } = await supabase
    .from("dairy_centers")
    .update({ operator_subscription_notifications: value })
    .eq("id", centerId);
  return { error: error?.message ?? null };
}

/* -------------------------------------------------------------------------- */
/* Delivery                                                                    */
/* -------------------------------------------------------------------------- */

export type InAppNotification = {
  id: string;
  title: string;
  body: string;
  category: NotificationCategory;
};

type Listener = (n: InAppNotification) => void;
const listeners = new Set<Listener>();

/** Web fallback channel: an in-app banner shown inside the app shell. */
export function onInAppNotification(fn: Listener) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function emitInAppNotification(n: InAppNotification) {
  for (const fn of listeners) fn(n);
}

export function isNativeApp(): boolean {
  if (typeof window === "undefined") return false;
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return typeof cap?.isNativePlatform === "function" ? cap.isNativePlatform() : false;
}

/** Requests OS permission on native; a no-op elsewhere. */
export async function ensureNotificationPermission(): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    const { LocalNotifications } = await import("@capacitor/local-notifications");
    const current = await LocalNotifications.checkPermissions();
    if (current.display === "granted") return true;
    const asked = await LocalNotifications.requestPermissions();
    return asked.display === "granted";
  } catch {
    return false;
  }
}

/** Stable positive 32-bit id derived from the notification key. */
function notificationId(key: string): number {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) | 0;
  return Math.abs(h) % 2_000_000_000;
}

/** Pre-schedules future reminders as native local notifications (Android). */
export async function scheduleNative(
  items: Array<PlannedNotification & { title: string; body: string }>,
): Promise<number> {
  if (!isNativeApp() || items.length === 0) return 0;
  try {
    const { LocalNotifications } = await import("@capacitor/local-notifications");
    const granted = await ensureNotificationPermission();
    if (!granted) return 0;
    await LocalNotifications.schedule({
      notifications: items.map((n) => ({
        id: notificationId(n.key),
        title: n.title,
        body: n.body,
        schedule: { at: n.at, allowWhileIdle: true },
        extra: { key: n.key, category: n.category },
      })),
    });
    return items.length;
  } catch {
    return 0;
  }
}

/**
 * Delivers a due notification right now: native local notification when
 * running in the APK, in-app banner in the browser. Both paths also persist an
 * `app_notifications` row (deduped by key) so it shows in the bell sheet.
 */
export async function deliverNow(
  n: PlannedNotification & { title: string; body: string },
  ctx: { userId: string; centerId: string | null },
): Promise<void> {
  if (isNativeApp()) {
    try {
      const { LocalNotifications } = await import("@capacitor/local-notifications");
      if (await ensureNotificationPermission()) {
        await LocalNotifications.schedule({
          notifications: [
            {
              id: notificationId(n.key),
              title: n.title,
              body: n.body,
              extra: { key: n.key, category: n.category },
            },
          ],
        });
      }
    } catch {
      /* fall through to the in-app banner */
    }
  }
  emitInAppNotification({ id: n.key, title: n.title, body: n.body, category: n.category });

  await supabase.from("app_notifications").insert({
    user_id: ctx.userId,
    center_id: ctx.centerId,
    kind: n.category,
    title: n.title,
    body: n.body,
    dedupe_key: n.key,
  });
}

/* -------------------------------------------------------------------------- */
/* Already-fired bookkeeping                                                   */
/* -------------------------------------------------------------------------- */

const FIRED_KEY = "vdairy.notificationsFired";

export function loadFiredKeys(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = window.localStorage.getItem(FIRED_KEY);
    return new Set<string>(raw ? (JSON.parse(raw) as string[]) : []);
  } catch {
    return new Set();
  }
}

export function markFired(keys: string[]) {
  if (typeof window === "undefined" || keys.length === 0) return;
  const set = loadFiredKeys();
  for (const k of keys) set.add(k);
  // Keep the list small — keys are day-scoped.
  const trimmed = Array.from(set).slice(-200);
  window.localStorage.setItem(FIRED_KEY, JSON.stringify(trimmed));
}
