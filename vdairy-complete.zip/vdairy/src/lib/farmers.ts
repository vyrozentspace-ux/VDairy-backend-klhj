import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type MilkType = "cow" | "buffalo" | "mixed";
export type Farmer = Database["public"]["Tables"]["farmers"]["Row"];
export type FarmerInsert = Database["public"]["Tables"]["farmers"]["Insert"];
export type FarmerUpdate = Database["public"]["Tables"]["farmers"]["Update"];

export const MILK_TYPE_LABEL: Record<MilkType, string> = {
  cow: "Cow",
  buffalo: "Buffalo",
  mixed: "Mixed",
};

export const MILK_TYPE_BADGE: Record<MilkType, string> = {
  cow: "bg-amber-50 text-amber-700 border-amber-200",
  buffalo: "bg-slate-100 text-slate-700 border-slate-200",
  mixed: "bg-teal-50 text-teal-700 border-teal-200",
};

export function formatMobile(m?: string | null) {
  if (!m) return "";
  const d = m.replace(/\D/g, "").slice(-10);
  if (d.length !== 10) return m;
  return `+91 ${d.slice(0, 5)} ${d.slice(5)}`;
}

export function farmerInitials(f: Pick<Farmer, "first_name" | "last_name">) {
  const a = (f.first_name?.[0] ?? "").toUpperCase();
  const b = (f.last_name?.[0] ?? "").toUpperCase();
  return a + b || a || "F";
}

export function farmerFullName(f: Pick<Farmer, "first_name" | "last_name" | "name_english">) {
  const parts = [f.first_name, f.last_name].filter(Boolean);
  return parts.join(" ") || f.name_english || "";
}

export async function logActivity(
  centerId: string,
  userId: string,
  action: string,
  details: Record<string, unknown> = {},
) {
  try {
    await supabase.from("activity_logs").insert({
      center_id: centerId,
      user_id: userId,
      action,
      details: details as never,
    });
  } catch {
    /* non-critical */
  }
}

export async function fetchFarmers(centerId: string): Promise<Farmer[]> {
  const { data, error } = await supabase
    .from("farmers")
    .select("*")
    .eq("center_id", centerId)
    .order("is_active", { ascending: false })
    .order("code", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function fetchFarmer(id: string): Promise<Farmer | null> {
  const { data, error } = await supabase.from("farmers").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function nextFarmerCode(centerId: string): Promise<string> {
  const { data } = await supabase.from("farmers").select("code").eq("center_id", centerId);
  const max = (data ?? []).reduce((m, r) => {
    const n = parseInt(String(r.code).replace(/\D/g, ""), 10);
    return Number.isFinite(n) && n > m ? n : m;
  }, 0);
  return String(max + 1);
}
