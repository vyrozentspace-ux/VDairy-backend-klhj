import { formatNumericDate } from "@/lib/date-locale";
export const PAYMENT_PERIOD_OPTIONS: { value: string; label: string; isDayCount?: boolean }[] = [
  { value: "01-10, 11-20, 21-ME", label: "01-10, 11-20, 21-ME (3 periods)" },
  { value: "01-15, 16-ME", label: "01-15, 16-ME (2 periods)" },
  { value: "01-ME", label: "01-ME (Monthly)" },
  {
    value: "01-05, 06-10, 11-15, 16-20, 21-25, 26-ME",
    label: "01-05, 06-10, 11-15, 16-20, 21-25, 26-ME (6 periods)",
  },
  { value: "06-15, 16-25, 26-05", label: "06-15, 16-25, 26-05 (custom cycle)", isDayCount: true },
  { value: "weekly-monday", label: "Weekly — Monday", isDayCount: true },
  { value: "weekly-tuesday", label: "Weekly — Tuesday", isDayCount: true },
  { value: "weekly-wednesday", label: "Weekly — Wednesday", isDayCount: true },
  { value: "weekly-thursday", label: "Weekly — Thursday", isDayCount: true },
  { value: "weekly-friday", label: "Weekly — Friday", isDayCount: true },
  { value: "weekly-saturday", label: "Weekly — Saturday", isDayCount: true },
  { value: "weekly-sunday", label: "Weekly — Sunday", isDayCount: true },
];

/**
 * Approximate length in days of a single period for the given payment_period setting.
 * Used for cycle navigation and per-cycle EMI conversion. Fallback: 10.
 */
export function paymentPeriodDays(value: string | null | undefined): number {
  if (!value) return 10;
  if (value.startsWith("weekly-")) return 7;
  switch (value) {
    case "01-10, 11-20, 21-ME":
      return 10;
    case "01-15, 16-ME":
      return 15;
    case "01-ME":
      return 30;
    case "01-05, 06-10, 11-15, 16-20, 21-25, 26-ME":
      return 5;
    case "06-15, 16-25, 26-05":
      return 10;
    default:
      return 10;
  }
}

export function formatDMY(d: Date): string {
  return formatNumericDate(d);
}

export function addDays(d: Date, n: number): Date {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}

/* ------------------------------------------------------------------ *
 * Period derivation
 * ------------------------------------------------------------------ */

export type PeriodConfig = {
  /** center_collection_settings.payment_period */
  paymentPeriod: string | null | undefined;
  /** center_collection_settings.payment_period_start_date (ISO yyyy-mm-dd) */
  startDate: string | null | undefined;
};

export type Period = { start: string; end: string };

const pad = (n: number) => String(n).padStart(2, "0");

export function toISODate(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function fromISODate(iso: string): Date {
  return new Date(`${iso}T00:00:00`);
}

function daysBetween(a: Date, b: Date): number {
  const ms =
    Date.UTC(a.getFullYear(), a.getMonth(), a.getDate()) -
    Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
  return Math.round(ms / 86400000);
}

/** Calendar day-of-month segments encoded by patterns like "01-10, 11-20, 21-ME". */
function calendarSegments(paymentPeriod: string | null | undefined): [number, number | "ME"][] {
  const value = paymentPeriod ?? "01-10, 11-20, 21-ME";
  const parts = value
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean);
  const segs: [number, number | "ME"][] = [];
  for (const p of parts) {
    const m = /^(\d{1,2})\s*-\s*(\d{1,2}|ME)$/i.exec(p);
    if (!m) continue;
    const from = Number(m[1]);
    const to = /^ME$/i.test(m[2]) ? ("ME" as const) : Number(m[2]);
    segs.push([from, to]);
  }
  if (!segs.length)
    return [
      [1, 10],
      [11, 20],
      [21, "ME"],
    ];
  return segs;
}

function calendarPeriodsForMonth(paymentPeriod: string | null | undefined, ref: Date): Period[] {
  const y = ref.getFullYear();
  const m = ref.getMonth();
  const lastDay = new Date(y, m + 1, 0).getDate();
  const iso = (dy: number) => `${y}-${pad(m + 1)}-${pad(Math.min(dy, lastDay))}`;
  const segs = calendarSegments(paymentPeriod).filter(([from, to]) => to === "ME" || to >= from);
  return segs.map(([from, to]) => ({
    start: iso(from),
    end: iso(to === "ME" ? lastDay : to),
  }));
}

/** True when the config defines an anchored day-count cycle rather than calendar segments. */
export function isAnchoredCycle(cfg: PeriodConfig): boolean {
  return !!cfg.startDate;
}

/** The period containing `date` for the given center configuration. */
export function periodForDate(cfg: PeriodConfig, date: Date = new Date()): Period {
  if (cfg.startDate) {
    const anchor = fromISODate(cfg.startDate);
    if (!Number.isNaN(anchor.getTime())) {
      const len = Math.max(1, paymentPeriodDays(cfg.paymentPeriod));
      const idx = Math.floor(daysBetween(date, anchor) / len);
      const start = addDays(anchor, idx * len);
      return { start: toISODate(start), end: toISODate(addDays(start, len - 1)) };
    }
  }
  const segs = calendarPeriodsForMonth(cfg.paymentPeriod, date);
  const iso = toISODate(date);
  return segs.find((s) => iso >= s.start && iso <= s.end) ?? segs[segs.length - 1];
}

/** Shift a period by `n` cycles (negative = earlier). */
export function shiftPeriod(cfg: PeriodConfig, period: Period, n: number): Period {
  if (n === 0) return period;
  const ref = n > 0 ? addDays(fromISODate(period.end), 1) : addDays(fromISODate(period.start), -1);
  const next = periodForDate(cfg, ref);
  return shiftPeriod(cfg, next, n > 0 ? n - 1 : n + 1);
}

/**
 * Quick-select choices around `ref`: for anchored cycles the two previous
 * cycles + current + next; for calendar cycles the segments of the month.
 */
export function periodOptions(cfg: PeriodConfig, ref: Date = new Date()): Period[] {
  if (cfg.startDate) {
    const current = periodForDate(cfg, ref);
    return [
      shiftPeriod(cfg, current, -2),
      shiftPeriod(cfg, current, -1),
      current,
      shiftPeriod(cfg, current, 1),
    ];
  }
  return calendarPeriodsForMonth(cfg.paymentPeriod, ref);
}
