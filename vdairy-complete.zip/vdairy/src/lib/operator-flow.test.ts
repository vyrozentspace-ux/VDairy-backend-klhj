import assert from "node:assert/strict";
import { describe, test } from "node:test";
import { readFileSync } from "node:fs";

describe("operator creation regression guard", () => {
  test("keeps the submit control wired to the authenticated server function", () => {
    const route = readFileSync(new URL("../routes/operators.tsx", import.meta.url), "utf8");
    assert.ok(route.includes('data-testid="create-operator"'));
    assert.ok(route.includes("onClick={() => void submit()}"));
    assert.ok(route.includes("await createOperator({"));
  });

  test("uses privileged auth lookup only inside the protected server handler", () => {
    const fn = readFileSync(new URL("./operators.functions.ts", import.meta.url), "utf8");
    assert.ok(fn.includes(".middleware([requireSupabaseAuth])"));
    assert.ok(fn.includes('await import("@/integrations/supabase/client.server")'));
    assert.ok(fn.includes('supabaseAdmin.rpc("auth_user_id_by_email"'));
  });
});