import { Bell } from "lucide-react";
import { useTranslation } from "react-i18next";
import { BottomSheet } from "./BottomSheet";

export function NotificationsSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t } = useTranslation();
  return (
    <BottomSheet open={open} onClose={onClose} title={t("core.notifications")}>
      <div className="px-4 pb-6 pt-2 flex flex-col items-center text-center gap-2">
        <span className="h-12 w-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
          <Bell className="h-5 w-5" />
        </span>
        <p className="text-sm font-semibold text-slate-700">{t("core.no_notifications_yet")}</p>
        <p className="text-xs text-slate-500 max-w-xs">{t("core.notifications_body")}</p>
      </div>
    </BottomSheet>
  );
}
