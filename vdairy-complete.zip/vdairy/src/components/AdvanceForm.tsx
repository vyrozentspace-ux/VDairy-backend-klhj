import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { AlertCircle, Calculator, Edit2, MessageCircle } from "lucide-react";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchFarmers,
  farmerFullName,
  MILK_TYPE_LABEL,
  type Farmer,
  type MilkType,
} from "@/lib/farmers";
import {
  createAdvance,
  getAdvance,
  updateAdvance,
  farmerBalance,
  type AdvanceType,
} from "@/lib/advances";
import { paymentPeriodDays } from "@/lib/payment-periods";
import { cn } from "@/lib/utils";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

function todayISO(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function maskMobile(mobile: string | null | undefined, t: (k: string) => string): string {
  if (!mobile) return t("advance.no_mobile");
  const digits = mobile.replace(/\D/g, "");
  if (digits.length < 6) return mobile;
  return `${digits.slice(0, 6)}XXXX`;
}

export function AdvanceForm({
  mode,
  advanceId,
  prefillFarmerId,
  onBack,
}: {
  mode: "create" | "edit";
  advanceId?: string;
  prefillFarmerId?: string;
  onBack: () => void;
}) {
  const { t } = useTranslation();
  const { userId } = useAuth();
  const { selected } = useCenter();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedShareMessage, setSavedShareMessage] = useState<string | null>(null);
  const [periodDays, setPeriodDays] = useState(10);
  const [farmers, setFarmers] = useState<Farmer[]>([]);

  // Form state
  const [farmerQuery, setFarmerQuery] = useState("");
  const [farmer, setFarmer] = useState<Farmer | null>(null);
  const [date, setDate] = useState(todayISO());
  const [amount, setAmount] = useState("");
  const [advanceType, setAdvanceType] = useState<AdvanceType>("Lump Sum");
  const [interestRate, setInterestRate] = useState("");
  const [months, setMonths] = useState("");
  const [manualEmi, setManualEmi] = useState("");
  const [emiMode, setEmiMode] = useState<"calc" | "manual">("calc");
  const [comments, setComments] = useState("");

  const farmerInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [{ data: settings }, fs] = await Promise.all([
          db
            .from("center_collection_settings")
            .select("payment_period")
            .eq("center_id", selected.id)
            .maybeSingle(),
          fetchFarmers(selected.id),
        ]);
        if (cancelled) return;
        setPeriodDays(paymentPeriodDays(settings?.payment_period ?? null));
        setFarmers(fs);

        if (mode === "edit" && advanceId) {
          const a = await getAdvance(advanceId);
          if (a && !cancelled) {
            const f = fs.find((x) => x.id === a.farmer_id) ?? null;
            setFarmer(f);
            setFarmerQuery(f ? farmerFullName(f) : "");
            setDate(a.advance_date);
            setAmount(String(a.amount));
            setAdvanceType(a.advance_type);
            setInterestRate(String(a.interest_rate));
            setComments(a.comments ?? "");
            if (a.term_months != null) setMonths(String(a.term_months));
            if (a.advance_type === "Monthly Installment" && a.monthly_installment_amount != null) {
              if (a.term_months == null) {
                setEmiMode("manual");
                setManualEmi(String(a.monthly_installment_amount));
              }
            }
          }
        } else if (prefillFarmerId) {
          const f = fs.find((x) => x.id === prefillFarmerId) ?? null;
          if (f) {
            setFarmer(f);
            setFarmerQuery(farmerFullName(f));
          }
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id, mode, advanceId, prefillFarmerId]);

  const matches = useMemo(() => {
    const q = farmerQuery.trim().toLowerCase();
    if (!q || farmer) return [];
    return farmers
      .filter((f) => {
        if (!f.is_active) return false;
        const code = String(f.code).toLowerCase();
        const name = farmerFullName(f).toLowerCase();
        return code.startsWith(q) || name.includes(q);
      })
      .slice(0, 8);
  }, [farmerQuery, farmers, farmer]);

  useEffect(() => {
    // Auto-select if exactly one match
    if (matches.length === 1 && !farmer) setFarmer(matches[0]);
  }, [matches, farmer]);

  const amountN = Number(amount);
  const rateN = Number(interestRate);
  const monthsN = Number(months);
  const calcValid =
    Number.isFinite(amountN) &&
    amountN > 0 &&
    Number.isFinite(monthsN) &&
    monthsN > 0 &&
    Number.isFinite(rateN) &&
    rateN >= 0;
  const totalInterest = calcValid ? amountN * (rateN / 100) * monthsN : 0;
  const totalRepayable = calcValid ? amountN + totalInterest : 0;
  const calcMonthly = calcValid ? totalRepayable / monthsN : 0;
  const perCycle = calcMonthly * (periodDays / 30);

  const chosenEmi =
    advanceType === "Monthly Installment"
      ? emiMode === "manual"
        ? Number(manualEmi)
        : calcMonthly
      : null;

  const canSave =
    !!farmer &&
    amountN > 0 &&
    !!selected &&
    (advanceType === "Lump Sum" ||
      (chosenEmi != null && Number.isFinite(chosenEmi) && chosenEmi > 0));

  const resetForm = () => {
    setFarmer(null);
    setFarmerQuery("");
    setDate(todayISO());
    setAmount("");
    setAdvanceType("Lump Sum");
    setInterestRate("");
    setMonths("");
    setManualEmi("");
    setEmiMode("calc");
    setComments("");
    setError(null);
    setSavedShareMessage(null);
    setTimeout(() => farmerInputRef.current?.focus(), 50);
  };

  const doSave = async () => {
    setError(null);
    if (!canSave || !selected || !farmer) return;
    setSaving(true);
    try {
      const payload = {
        center_id: selected.id,
        farmer_id: farmer.id,
        advance_date: date,
        amount: amountN,
        advance_type: advanceType,
        monthly_installment_amount:
          advanceType === "Monthly Installment" ? Number(chosenEmi!.toFixed(2)) : null,
        // Loan term drives the interest-inclusive total repayable used for auto-settlement.
        term_months:
          advanceType === "Monthly Installment" && Number.isFinite(monthsN) && monthsN > 0
            ? Math.round(monthsN)
            : null,
        interest_rate: Number.isFinite(rateN) ? rateN : 0,
        comments: comments.trim() || null,
        entered_by: userId,
      };

      if (mode === "edit" && advanceId) {
        await updateAdvance(advanceId, payload);
        toast.success(t("advance.advance_updated"));
        navigate({ to: "/advance" });
        return;
      }

      await createAdvance(payload);
      const bal = await farmerBalance(farmer.id);
      const msg = [
        `${selected.name}`,
        t("advance.share_farmer_line", { name: farmerFullName(farmer), code: farmer.code }),
        t("advance.share_date_line", { date }),
        t("advance.advance_amount", { amount: amountN.toFixed(2), type: advanceType }),
        rateN > 0 ? t("advance.interest", { rate: rateN }) : null,
        t("advance.new_balance", { balance: bal.toFixed(2) }),
      ]
        .filter(Boolean)
        .join("\n");
      setSavedShareMessage(msg);
      toast.success(t("advance.advance_saved"));

      if (farmer.mobile) {
        const smsHref = `sms:${farmer.mobile}?body=${encodeURIComponent(msg)}`;
        try {
          window.location.href = smsHref;
        } catch {
          /* ignore */
        }
      }

      resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("advance.failed_to_save"));
    } finally {
      setSaving(false);
    }
  };

  const shareWhatsApp = async () => {
    if (!savedShareMessage) return;
    const url = `https://wa.me/${farmer?.mobile ?? ""}?text=${encodeURIComponent(savedShareMessage)}`;
    try {
      if (navigator.share) {
        await navigator.share({ text: savedShareMessage });
      } else {
        window.open(url, "_blank");
      }
    } catch {
      /* cancel */
    }
  };

  return (
    <>
      <AppHeader
        title={mode === "edit" ? t("advance.edit_advance") : t("advance.new_advance")}
        onBack={onBack}
      />
      {loading ? (
        <div className="py-16 flex justify-center">
          <Spinner />
        </div>
      ) : (
        <div className="p-4 space-y-4 pb-24">
          <div className="text-xs text-slate-500 -mt-2">{selected?.name}</div>

          {savedShareMessage && (
            <button
              type="button"
              onClick={shareWhatsApp}
              className="w-full h-12 rounded-lg font-semibold text-sm inline-flex items-center justify-center gap-2 text-white transition"
              style={{ backgroundColor: "#25D366" }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#1da851")}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#25D366")}
            >
              <MessageCircle className="h-4 w-4" /> {t("advance.share_on_whatsapp")}
            </button>
          )}

          <Field label={t("advance.farmer_code_or_name")}>
            <TextInput
              ref={farmerInputRef}
              value={farmerQuery}
              disabled={mode === "edit"}
              onChange={(e) => {
                setFarmerQuery(e.target.value);
                if (
                  farmer &&
                  !e.target.value
                    .toLowerCase()
                    .includes(farmerFullName(farmer).toLowerCase().slice(0, 3))
                ) {
                  setFarmer(null);
                }
              }}
              placeholder={t("food.type_code_or_name")}
            />
            {!farmer && matches.length > 1 && (
              <div className="mt-2 rounded-lg border border-slate-200 bg-white shadow-sm max-h-60 overflow-y-auto">
                {matches.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => {
                      setFarmer(f);
                      setFarmerQuery(farmerFullName(f));
                    }}
                    className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 border-b border-slate-100 last:border-0"
                  >
                    <div>
                      <div className="text-sm font-medium text-slate-800">{farmerFullName(f)}</div>
                      <div className="text-xs text-slate-500">
                        {t("advance.code_colon", { code: f.code })}
                      </div>
                    </div>
                    <div className="text-xs text-teal-600">
                      {MILK_TYPE_LABEL[f.milk_type as MilkType]}
                    </div>
                  </button>
                ))}
              </div>
            )}
            {!farmer && farmerQuery.trim() && matches.length === 0 && (
              <p className="mt-1 text-xs text-rose-600">{t("advance.no_farmer_found")}</p>
            )}
          </Field>

          {farmer && (
            <div className="rounded-lg bg-teal-50 border border-teal-200 p-3 flex items-center justify-between">
              <div className="min-w-0">
                <div className="text-sm font-semibold text-teal-900 truncate">
                  {farmerFullName(farmer)}
                </div>
                <div className="text-xs text-teal-700">{maskMobile(farmer.mobile, t)}</div>
              </div>
              <div className="text-xs font-semibold text-teal-700">
                {MILK_TYPE_LABEL[farmer.milk_type as MilkType]}
              </div>
            </div>
          )}

          <Field label={t("advance.date")}>
            <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>

          <Field label={t("advance.amount_inr")}>
            <TextInput
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
              inputMode="decimal"
              placeholder="0.00"
            />
          </Field>

          <Field label={t("advance.repayment_type")}>
            <div className="flex rounded-lg border border-slate-200 bg-white p-1 gap-1">
              {(["Lump Sum", "Monthly Installment"] as const).map((rt) => {
                const active = advanceType === rt;
                return (
                  <button
                    key={rt}
                    type="button"
                    onClick={() => setAdvanceType(rt)}
                    className={cn(
                      "flex-1 h-9 rounded-md text-sm font-semibold transition",
                      active ? "bg-teal-600 text-white" : "text-slate-600",
                    )}
                  >
                    {rt === "Monthly Installment"
                      ? t("advance.advance_type_emi")
                      : t("advance.advance_type_lump_sum")}
                  </button>
                );
              })}
            </div>
          </Field>

          {advanceType === "Lump Sum" && (
            <Field label={t("advance.interest_rate")}>
              <TextInput
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value.replace(/[^0-9.]/g, ""))}
                inputMode="decimal"
                placeholder="0"
                suffix={<span className="text-xs text-slate-400 pr-2">%</span>}
              />
            </Field>
          )}

          {advanceType === "Monthly Installment" && emiMode === "calc" && (
            <>
              <Field label={t("advance.number_of_months")}>
                <TextInput
                  value={months}
                  onChange={(e) => setMonths(e.target.value.replace(/[^0-9]/g, ""))}
                  inputMode="numeric"
                  placeholder={t("advance.months_placeholder")}
                />
              </Field>
              <Field label={t("advance.interest_rate")} hint={t("advance.interest_rate_emi_hint")}>
                <TextInput
                  value={interestRate}
                  onChange={(e) => setInterestRate(e.target.value.replace(/[^0-9.]/g, ""))}
                  inputMode="decimal"
                  placeholder="0"
                  suffix={
                    <span className="text-xs text-slate-400 pr-2">
                      {t("advance.per_month_suffix")}
                    </span>
                  }
                />
              </Field>

              {calcValid && (
                <div className="rounded-lg bg-teal-50 border border-teal-200 p-4 space-y-2">
                  <div className="flex items-center gap-2 text-teal-700 font-semibold text-sm">
                    <Calculator className="h-4 w-4" /> {t("advance.emi_calculation")}
                  </div>
                  <div className="flex justify-between text-sm text-slate-700">
                    <span>{t("advance.total_interest")}</span>
                    <span className="font-semibold">₹{totalInterest.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-slate-700">
                    <span>{t("advance.total_repayable")}</span>
                    <span className="font-semibold">₹{totalRepayable.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-teal-200 pt-2 mt-2">
                    <div className="flex justify-between items-baseline">
                      <span className="text-sm text-teal-700">
                        {t("advance.monthly_installment")}
                      </span>
                      <span className="font-bold text-teal-700 text-lg">
                        ₹{calcMonthly.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs text-teal-700 mt-1">
                      <span>{t("advance.per_cycle", { days: periodDays })}</span>
                      <span>₹{perCycle.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={() => setEmiMode("manual")}
                className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700"
              >
                <Edit2 className="h-3.5 w-3.5" /> {t("advance.enter_monthly_manually")}
              </button>
            </>
          )}

          {advanceType === "Monthly Installment" && emiMode === "manual" && (
            <>
              <Field
                label={t("advance.monthly_installment_amount")}
                hint={t("advance.monthly_installment_hint")}
              >
                <TextInput
                  value={manualEmi}
                  onChange={(e) => setManualEmi(e.target.value.replace(/[^0-9.]/g, ""))}
                  inputMode="decimal"
                  placeholder="0.00"
                />
              </Field>
              <Field label={t("advance.interest_rate")}>
                <TextInput
                  value={interestRate}
                  onChange={(e) => setInterestRate(e.target.value.replace(/[^0-9.]/g, ""))}
                  inputMode="decimal"
                  placeholder="0"
                  suffix={
                    <span className="text-xs text-slate-400 pr-2">
                      {t("advance.per_month_suffix")}
                    </span>
                  }
                />
              </Field>
              <button
                type="button"
                onClick={() => setEmiMode("calc")}
                className="inline-flex items-center gap-1.5 text-sm text-teal-600 hover:text-teal-700"
              >
                <Calculator className="h-3.5 w-3.5" /> {t("advance.use_emi_calculator")}
              </button>
            </>
          )}

          <Field label={t("advance.comments")}>
            <TextInput
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder={t("advance.optional_placeholder")}
            />
          </Field>

          {error && (
            <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
              <AlertCircle className="h-4 w-4 mt-0.5" /> <span>{error}</span>
            </div>
          )}
        </div>
      )}

      <div className="sticky bottom-0 bg-white border-t border-slate-200 px-4 py-3 safe-bottom">
        <div className="grid grid-cols-2 gap-2">
          <Button variant="secondary" onClick={resetForm} disabled={saving}>
            {t("advance.reset")}
          </Button>
          <Button onClick={doSave} disabled={!canSave || saving} loading={saving}>
            {mode === "edit" ? t("advance.update") : t("advance.save")}
          </Button>
        </div>
      </div>
    </>
  );
}
