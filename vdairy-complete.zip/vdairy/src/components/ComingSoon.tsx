import { Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";
import { APP_NAME } from "@/lib/app-config";

export function ComingSoon({ title }: { title?: string }) {
  const { t } = useTranslation();
  const heading = title ?? t("core.coming_soon");
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 text-center gap-3">
      <div className="h-14 w-14 rounded-full bg-teal-50 flex items-center justify-center">
        <Sparkles className="h-7 w-7 text-teal-700" />
      </div>
      <h2 className="text-lg font-semibold text-slate-800">{heading}</h2>
      <p className="text-sm text-slate-500 max-w-xs">
        {t("core.coming_soon_body", { appName: APP_NAME })}
      </p>
    </div>
  );
}
