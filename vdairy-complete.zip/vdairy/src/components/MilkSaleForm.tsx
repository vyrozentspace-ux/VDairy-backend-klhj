import { useEffect, useMemo, useState } from "react";
import { Moon, Search, Sun, UserPlus, X } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import {
  createCustomer,
  createSale,
  listCustomers,
  logActivity,
  todayISO,
  updateSale,
  type MilkSale,
  type MilkSaleCustomer,
  type MilkSaleSession,
  type PayMode,
  type PayStatus,
} from "@/lib/milk-sales";
import { cn } from "@/lib/utils";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

type Mode = "create" | "edit";

export function MilkSaleForm({
  mode,
  existing,
  onDone,
  onBack,
}: {
  mode: Mode;
  existing?: MilkSale;
  onDone: () => void;
  onBack: () => void;
}) {
  const { t } = useTranslation();
  const { selected } = useCenter();
  const { userId } = useAuth();

  const [customers, setCustomers] = useState<MilkSaleCustomer[]>([]);
  const [customerMode, setCustomerMode] = useState<"walk_in" | "registered">(
    existing?.customer_id ? "registered" : "walk_in",
  );
  const [customerId, setCustomerId] = useState<string | null>(existing?.customer_id ?? null);
  const [walkName, setWalkName] = useState<string>(existing?.walk_in_name ?? "");
  const [walkMobile, setWalkMobile] = useState<string>(existing?.walk_in_mobile ?? "");

  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newMobile, setNewMobile] = useState("");
  const [newAddr, setNewAddr] = useState("");
  const [addBusy, setAddBusy] = useState(false);

  const [saleDate, setSaleDate] = useState<string>(existing?.sale_date ?? todayISO());
  const [session, setSession] = useState<MilkSaleSession>(existing?.session ?? "morning");
  const [qty, setQty] = useState<string>(existing ? String(existing.quantity_liters) : "");
  const [rate, setRate] = useState<string>(existing ? String(existing.rate_per_liter) : "");
  const [status, setStatus] = useState<PayStatus>(existing?.payment_status ?? "unpaid");
  const [payMode, setPayMode] = useState<PayMode | null>(existing?.payment_mode ?? null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!selected) return;
    void listCustomers(selected.id)
      .then(setCustomers)
      .catch(() => setCustomers([]));
  }, [selected?.id]);

  useEffect(() => {
    if (mode === "edit" || existing) return;
    if (!selected) return;
    (async () => {
      const { data } = await db
        .from("center_collection_settings")
        .select("default_milk_sale_rate")
        .eq("center_id", selected.id)
        .maybeSingle();
      const r = data?.default_milk_sale_rate;
      if (r != null) setRate(String(r));
    })();
  }, [selected?.id, mode]);

  const total = useMemo(() => {
    const q = parseFloat(qty || "0");
    const r = parseFloat(rate || "0");
    return isFinite(q * r) ? q * r : 0;
  }, [qty, rate]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter(
      (c) => c.name.toLowerCase().includes(q) || (c.mobile ?? "").includes(q),
    );
  }, [customers, search]);

  const selectedCustomer = customers.find((c) => c.id === customerId) ?? null;

  async function submitAddCustomer() {
    if (!selected || !newName.trim()) return;
    setAddBusy(true);
    try {
      const c = await createCustomer({
        center_id: selected.id,
        name: newName.trim(),
        mobile: newMobile.trim() || null,
        address: newAddr.trim() || null,
      });
      setCustomers((prev) => [...prev, c].sort((a, b) => a.name.localeCompare(b.name)));
      setCustomerId(c.id);
      setAddOpen(false);
      setNewName("");
      setNewMobile("");
      setNewAddr("");
      void logActivity(selected.id, userId, "milk_sale_customer_added", { name: c.name });
      toast.success(t("sales.customerAdded"));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("sales.failed"));
    } finally {
      setAddBusy(false);
    }
  }

  async function submit() {
    if (!selected) return;
    const q = parseFloat(qty);
    const r = parseFloat(rate);
    if (!isFinite(q) || q <= 0) return toast.error(t("sales.enterQuantity"));
    if (!isFinite(r) || r <= 0) return toast.error(t("sales.enterRate"));
    if (customerMode === "registered" && !customerId) return toast.error(t("sales.pickCustomer"));
    setSaving(true);
    try {
      const payload = {
        center_id: selected.id,
        customer_id: customerMode === "registered" ? customerId : null,
        walk_in_name: customerMode === "walk_in" ? walkName.trim() || null : null,
        walk_in_mobile: customerMode === "walk_in" ? walkMobile.trim() || null : null,
        sale_date: saleDate,
        session,
        quantity_liters: q,
        rate_per_liter: r,
        total_amount: q * r,
        payment_status: status,
        payment_mode: status === "paid" ? payMode : null,
      };
      if (mode === "create") {
        const sale = await createSale({ ...payload, created_by: userId ?? undefined });
        void logActivity(selected.id, userId, "milk_sale_added", {
          id: sale.id,
          total_amount: sale.total_amount,
        });
        toast.success(t("sales.saleRecorded"));
      } else if (existing) {
        await updateSale(existing.id, payload);
        void logActivity(selected.id, userId, "milk_sale_updated", { id: existing.id });
        toast.success(t("sales.saleUpdated"));
      }
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("sales.failed"));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-full bg-slate-50 flex flex-col">
      <AppHeader
        title={mode === "create" ? t("sales.addSaleTitle") : t("sales.editSaleTitle")}
        onBack={onBack}
      />
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
        {/* Customer mode segmented */}
        <div className="flex p-1 rounded-lg border border-slate-200 bg-white">
          {(["walk_in", "registered"] as const).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setCustomerMode(k)}
              className={cn(
                "flex-1 h-10 rounded-md text-sm font-medium transition",
                customerMode === k ? "bg-teal-700 text-white" : "text-slate-500",
              )}
            >
              {k === "walk_in" ? t("sales.walkIn") : t("sales.registeredCustomer")}
            </button>
          ))}
        </div>

        {customerMode === "walk_in" ? (
          <div className="space-y-3">
            <Field label={t("sales.customerName")}>
              <TextInput
                value={walkName}
                onChange={(e) => setWalkName(e.target.value)}
                placeholder={t("sales.name")}
              />
            </Field>
            <Field label={t("sales.mobile")}>
              <TextInput
                prefix="+91"
                inputMode="numeric"
                maxLength={10}
                value={walkMobile}
                onChange={(e) => setWalkMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
                placeholder={t("sales.tenDigit")}
              />
            </Field>
          </div>
        ) : selectedCustomer ? (
          <div className="rounded-lg border border-teal-200 bg-teal-50 p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-semibold">
              {selectedCustomer.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-slate-800 truncate">
                {selectedCustomer.name}
              </div>
              <div className="text-xs text-slate-500 truncate">
                {selectedCustomer.mobile ? `+91 ${selectedCustomer.mobile}` : t("sales.noMobile")}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setCustomerId(null)}
              className="p-2 rounded-full hover:bg-teal-100"
            >
              <X className="w-4 h-4 text-teal-700" />
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <TextInput
              prefix={<Search className="w-4 h-4" />}
              placeholder={t("sales.searchByName")}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <div className="max-h-48 overflow-y-auto rounded-lg border border-slate-200 bg-white divide-y">
              {filtered.length === 0 ? (
                <div className="p-3 text-xs text-slate-400 text-center">
                  {t("sales.noCustomers")}
                </div>
              ) : (
                filtered.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setCustomerId(c.id)}
                    className="w-full text-left p-3 hover:bg-slate-50 flex items-center gap-3"
                  >
                    <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center text-xs font-semibold">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-slate-800 truncate">{c.name}</div>
                      <div className="text-xs text-slate-500 truncate">
                        {c.mobile ? `+91 ${c.mobile}` : t("sales.noMobile")}
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
            <button
              type="button"
              onClick={() => setAddOpen(true)}
              className="w-full flex items-center justify-center gap-2 h-11 rounded-lg border border-dashed border-teal-300 bg-teal-50 text-teal-700 text-sm font-medium"
            >
              <UserPlus className="w-4 h-4" /> {t("sales.addNewCustomer")}
            </button>
          </div>
        )}

        {/* Date + Session */}
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("sales.date")}>
            <TextInput type="date" value={saleDate} onChange={(e) => setSaleDate(e.target.value)} />
          </Field>
          <Field label={t("sales.session")}>
            <div className="flex h-12 rounded-lg border border-slate-200 overflow-hidden">
              <button
                type="button"
                onClick={() => setSession("morning")}
                className={cn(
                  "flex-1 flex items-center justify-center gap-1 text-sm font-medium rounded-l-lg",
                  session === "morning" ? "bg-amber-50 text-amber-700" : "bg-white text-slate-500",
                )}
              >
                <Sun className="w-4 h-4" /> {t("sales.am")}
              </button>
              <button
                type="button"
                onClick={() => setSession("evening")}
                className={cn(
                  "flex-1 flex items-center justify-center gap-1 text-sm font-medium rounded-r-lg border-l border-slate-200",
                  session === "evening"
                    ? "bg-indigo-50 text-indigo-700"
                    : "bg-white text-slate-500",
                )}
              >
                <Moon className="w-4 h-4" /> {t("sales.pm")}
              </button>
            </div>
          </Field>
        </div>

        <Field label={t("sales.quantityLiters")}>
          <TextInput
            inputMode="decimal"
            value={qty}
            onChange={(e) => setQty(e.target.value)}
            placeholder="0.0"
          />
        </Field>
        <Field label={t("sales.ratePerLiter")}>
          <TextInput
            prefix="₹"
            inputMode="decimal"
            value={rate}
            onChange={(e) => setRate(e.target.value)}
            placeholder="0.00"
          />
        </Field>

        <div className="rounded-lg bg-teal-50 border border-teal-100 px-4 h-12 flex items-center justify-between">
          <span className="text-sm font-medium text-teal-800">{t("sales.totalAmount")}</span>
          <span className="text-lg font-bold text-teal-700">₹{total.toFixed(2)}</span>
        </div>

        {/* Payment status */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">
            {t("sales.paymentStatus")}
          </label>
          <div className="flex p-1 rounded-lg border border-slate-200 bg-white">
            {(["unpaid", "paid"] as const).map((k) => {
              const active = status === k;
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() => setStatus(k)}
                  className={cn(
                    "flex-1 h-10 rounded-md text-sm font-medium transition capitalize",
                    active && k === "unpaid"
                      ? "bg-rose-600 text-white"
                      : active && k === "paid"
                        ? "bg-emerald-600 text-white"
                        : "text-slate-500",
                  )}
                >
                  {k === "paid" ? t("sales.paid") : t("sales.unpaid")}
                </button>
              );
            })}
          </div>
        </div>

        {status === "paid" && (
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              {t("sales.paymentMode")}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(["cash", "upi", "other"] as PayMode[]).map((m) => {
                const active = payMode === m;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setPayMode(m)}
                    className={cn(
                      "h-11 rounded-lg border text-sm font-medium capitalize",
                      active
                        ? "border-teal-500 bg-teal-50 text-teal-700"
                        : "border-slate-200 bg-white text-slate-500",
                    )}
                  >
                    {m === "upi" ? "UPI" : m === "cash" ? t("sales.cash") : t("sales.other")}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <Button onClick={submit} loading={saving}>
          {mode === "create" ? t("sales.saveSale") : t("sales.updateSale")}
        </Button>
      </div>

      {addOpen && (
        <div className="fixed inset-0 z-40 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-800">{t("sales.addCustomer")}</h3>
              <button
                type="button"
                onClick={() => setAddOpen(false)}
                className="p-1 rounded-full hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <Field label={t("sales.name")}>
              <TextInput
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder={t("sales.fullName")}
              />
            </Field>
            <Field label={t("sales.mobile")}>
              <TextInput
                prefix="+91"
                inputMode="numeric"
                maxLength={10}
                value={newMobile}
                onChange={(e) => setNewMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
              />
            </Field>
            <Field label={t("sales.address")}>
              <TextInput value={newAddr} onChange={(e) => setNewAddr(e.target.value)} />
            </Field>
            <Button onClick={submitAddCustomer} loading={addBusy} disabled={!newName.trim()}>
              {t("sales.addCustomer")}
            </Button>
          </div>
        </div>
      )}

      {saving && (
        <div className="fixed inset-0 bg-white/40 flex items-center justify-center pointer-events-none">
          <Spinner size={22} color="#0F766E" />
        </div>
      )}
    </div>
  );
}
