import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { BottomSheet } from "./BottomSheet";
import { Button } from "./Button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { logActivity } from "@/lib/farmers";
import { Field } from "./Field";

type Entry = { name: string; mobile: string; selected: boolean };

function parse(input: string, unknownLabel: string): Entry[] {
  const lines = input
    .split(/\r?\n|;/)
    .map((l) => l.trim())
    .filter(Boolean);
  return lines.map((line) => {
    const parts = line.split(/[,\t|]/).map((p) => p.trim());
    let name = "";
    let mobile = "";
    if (parts.length >= 2) {
      name = parts[0];
      mobile = parts[1].replace(/\D/g, "").slice(-10);
    } else {
      const m = line.match(/(\d[\d\s\-()]{8,})/);
      mobile = m ? m[1].replace(/\D/g, "").slice(-10) : "";
      name = line.replace(m?.[1] ?? "", "").trim() || unknownLabel;
    }
    return { name: name || unknownLabel, mobile, selected: !!mobile };
  });
}

export function ContactsSyncSheet({
  open,
  onClose,
  onDone,
}: {
  open: boolean;
  onClose: () => void;
  onDone: () => void;
}) {
  const { t } = useTranslation();
  const [raw, setRaw] = useState("");
  const [busy, setBusy] = useState(false);
  const { userId } = useAuth();
  const { selected } = useCenter();

  const entries = useMemo(() => parse(raw, t("core.unknown")), [raw, t]);

  const importSelected = async () => {
    if (!selected || !userId) return;
    const chosen = entries.filter((e) => e.selected && e.mobile.length === 10);
    if (chosen.length === 0) return toast.error(t("core.nothing_to_import"));
    setBusy(true);
    const rows = chosen.map((e) => {
      const [first, ...rest] = e.name.split(" ");
      return {
        center_id: selected.id,
        first_name: first || e.name,
        last_name: rest.join(" ") || null,
        mobile: e.mobile,
        created_by: userId,
        code: "",
      };
    });
    const { error } = await supabase.from("farmers").insert(rows);
    setBusy(false);
    if (error) return toast.error(error.message);
    void logActivity(selected.id, userId, "farmer_bulk_created", { count: rows.length });
    toast.success(t("core.imported_n_farmers", { n: rows.length }));
    setRaw("");
    onDone();
  };

  return (
    <BottomSheet open={open} onClose={onClose} title={t("core.sync_from_contacts")}>
      <div className="px-3 pb-2 space-y-3">
        <p className="text-xs text-slate-500">
          {t("core.paste_contact_prefix")}{" "}
          <span className="font-mono text-slate-700">{t("core.name_mobile_format")}</span>{" "}
          {t("core.native_contact_picker_note")}
        </p>
        <Field>
          <textarea
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            rows={5}
            placeholder={t("core.contacts_sample_placeholder")}
            className="w-full rounded-lg border border-slate-200 p-3 text-sm outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
          />
        </Field>
        {entries.length > 0 && (
          <div className="max-h-56 overflow-y-auto border border-slate-100 rounded-lg divide-y divide-slate-100">
            {entries.map((e, i) => (
              <label
                key={i}
                className="flex items-center gap-3 px-3 py-2 text-sm cursor-pointer hover:bg-slate-50"
              >
                <input
                  type="checkbox"
                  checked={e.selected}
                  onChange={(ev) => {
                    const next = entries.slice();
                    next[i] = { ...e, selected: ev.target.checked };
                    setRaw(next.map((r) => `${r.name}, ${r.mobile}`).join("\n"));
                  }}
                  className="accent-teal-700"
                />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-slate-800 truncate">{e.name}</div>
                  <div className="text-xs text-slate-500">
                    {e.mobile || <span className="text-rose-500">{t("core.invalid_mobile")}</span>}
                  </div>
                </div>
              </label>
            ))}
          </div>
        )}
        <div className="flex gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>
            {t("core.cancel")}
          </Button>
          <Button loading={busy} onClick={importSelected} disabled={entries.length === 0}>
            {t("core.import_count", {
              n: entries.filter((e) => e.selected && e.mobile.length === 10).length || "",
            })}
          </Button>
        </div>
      </div>
    </BottomSheet>
  );
}
