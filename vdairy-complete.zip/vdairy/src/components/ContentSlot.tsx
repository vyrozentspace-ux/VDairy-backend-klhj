import { ExternalLink, Info, PlayCircle, Youtube } from "lucide-react";
import { useContentSlot, type ContentSlot as Slot } from "@/lib/content-slots";

/**
 * Renders whatever the Control Panel has configured for `slotKey`.
 * Renders nothing when the slot is missing, inactive or incomplete.
 *
 * Add a new place in the app by:
 *   1. inserting a row in `content_slots` with a new unique `slot_key`
 *   2. dropping <ContentSlot slotKey="my_new_slot" /> where it should appear
 * No further app change is needed to edit/clear it later.
 */
export function ContentSlot({ slotKey, className }: { slotKey: string; className?: string }) {
  const slot = useContentSlot(slotKey);
  if (!slot) return null;

  if (slot.content_type === "link") {
    return (
      <a
        href={slot.url ?? "#"}
        target="_blank"
        rel="noopener noreferrer"
        className={
          className ?? "w-full flex items-center gap-3 p-3 text-left hover:bg-slate-50"
        }
      >
        <span className="text-slate-500">{iconFor(slot)}</span>
        <span className="flex-1">
          <span className="block text-sm font-medium text-slate-800">{slot.title ?? slot.url}</span>
          {slot.body && <span className="block text-xs text-slate-500">{slot.body}</span>}
        </span>
        <ExternalLink className="h-4 w-4 text-slate-400" />
      </a>
    );
  }

  if (slot.content_type === "banner") {
    const inner = (
      <>
        {slot.title && <div className="text-sm font-semibold text-teal-800">{slot.title}</div>}
        {slot.body && <div className="text-xs text-teal-700 mt-0.5">{slot.body}</div>}
      </>
    );
    const cls =
      className ?? "block rounded-lg border border-teal-200 bg-teal-50 p-3";
    return slot.url ? (
      <a href={slot.url} target="_blank" rel="noopener noreferrer" className={cls}>
        {inner}
      </a>
    ) : (
      <div className={cls}>{inner}</div>
    );
  }

  // "text" and any unknown type render as plain informational text.
  return (
    <div className={className ?? "p-3"}>
      {slot.title && <div className="text-sm font-medium text-slate-800">{slot.title}</div>}
      {slot.body && <div className="text-xs text-slate-500 mt-0.5">{slot.body}</div>}
    </div>
  );
}

function iconFor(slot: Slot) {
  switch (slot.icon) {
    case "play":
      return <PlayCircle className="h-4 w-4" />;
    case "youtube":
      return <Youtube className="h-4 w-4" />;
    case "info":
      return <Info className="h-4 w-4" />;
    default:
      return <ExternalLink className="h-4 w-4" />;
  }
}
