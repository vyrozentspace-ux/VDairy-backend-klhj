import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

export function Spinner({
  size = 16,
  className,
  color = "currentColor",
}: {
  size?: number;
  className?: string;
  color?: string;
}) {
  const { t } = useTranslation();
  return (
    <span
      role="status"
      aria-label={t("core.loading")}
      className={cn("inline-block rounded-full animate-spin-ring", className)}
      style={{
        width: size,
        height: size,
        border: `2px solid ${color}`,
        borderTopColor: "transparent",
      }}
    />
  );
}
