import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { Calculator, ChevronDown, Plus, Trash2 } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Alert } from "@/components/Alert";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Spinner } from "@/components/Spinner";
import { useCenter } from "@/contexts/CenterContext";
import {
  generateMatrixRates,
  generateRatesFromSamples,
  getRateChart,
  saveChartWithRows,
  stepsBetween,
  type MilkType,
  type RateChartRow,
} from "@/lib/rate-charts";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const MILK_TYPES: { value: MilkType; key: string }[] = [
  { value: "cow", key: "ratechart.cow" },
  { value: "buffalo", key: "ratechart.buffalo" },
  { value: "mixed", key: "ratechart.mixed" },
];

const MODES = [
  { value: "fat_snf", key: "ratechart.fat_snf" },
  { value: "fat_only", key: "ratechart.fat_only" },
  { value: "total_solid", key: "ratechart.total_solid" },
] as const;

export function RateChartForm({ chartId }: { chartId?: string }) {
  const { t } = useTranslation();
  const { selected } = useCenter();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(!!chartId);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [name, setName] = useState("");
  const [milkType, setMilkType] = useState<MilkType>("cow");
  const [baseRate, setBaseRate] = useState("32.00");
  const [fatMin, setFatMin] = useState("3.0");
  const [fatMax, setFatMax] = useState("10.0");
  const [fatStep, setFatStep] = useState("0.1");
  const [snfMin, setSnfMin] = useState("7.0");
  const [snfMax, setSnfMax] = useState("9.5");
  const [snfStep, setSnfStep] = useState("0.1");
  const [mode, setMode] = useState<"fat_snf" | "fat_only" | "total_solid">("fat_snf");
  const [rows, setRows] = useState<RateChartRow[]>([]);
  const [milkLocked, setMilkLocked] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [overwriteAsk, setOverwriteAsk] = useState(false);
  const [method, setMethod] = useState<"formula" | "samples">("formula");
  const [samples, setSamples] = useState<{ fat: string; snf: string; rate: string }[]>([
    { fat: "", snf: "", rate: "" },
    { fat: "", snf: "", rate: "" },
    { fat: "", snf: "", rate: "" },
  ]);

  useEffect(() => {
    if (!selected) return;
    void (async () => {
      const { data } = await db
        .from("center_collection_settings")
        .select("calculation_mode")
        .eq("center_id", selected.id)
        .maybeSingle();
      if (data?.calculation_mode) setMode(data.calculation_mode);
    })();
  }, [selected]);

  useEffect(() => {
    if (!chartId) return;
    void (async () => {
      try {
        const { chart, rows } = await getRateChart(chartId);
        setName(chart.chart_name);
        setMilkType(chart.milk_type);
        setBaseRate(String(chart.base_rate ?? ""));
        setFatMin(String(chart.fat_min));
        setFatMax(String(chart.fat_max));
        setFatStep(String(chart.fat_step));
        setSnfMin(String(chart.snf_min));
        setSnfMax(String(chart.snf_max));
        setSnfStep(String(chart.snf_step));
        setRows(rows);
        setMilkLocked(rows.length > 0);
        setCollapsed(rows.length > 0);
      } catch (err) {
        setError(err instanceof Error ? err.message : t("ratechart.could_not_load"));
      } finally {
        setLoading(false);
      }
    })();
  }, [chartId]);

  const fats = useMemo(
    () => stepsBetween(Number(fatMin), Number(fatMax), Number(fatStep)),
    [fatMin, fatMax, fatStep],
  );
  const snfs = useMemo(
    () => stepsBetween(Number(snfMin), Number(snfMax), Number(snfStep)),
    [snfMin, snfMax, snfStep],
  );

  const rowMap = useMemo(() => {
    const m = new Map<string, RateChartRow>();
    for (const r of rows) m.set(`${r.fat_value}|${r.snf_value}`, r);
    return m;
  }, [rows]);

  const { minRate, maxRate } = useMemo(() => {
    if (!rows.length) return { minRate: 0, maxRate: 0 };
    const vals = rows.map((r) => Number(r.rate));
    return { minRate: Math.min(...vals), maxRate: Math.max(...vals) };
  }, [rows]);

  const rangeOk = () => {
    if (fats.length === 0 || snfs.length === 0) {
      setError(t("ratechart.err_ranges"));
      return false;
    }
    if (fats.length * snfs.length > 5000) {
      setError(t("ratechart.err_matrix_large"));
      return false;
    }
    return true;
  };

  const chartRange = () => ({
    fat_min: Number(fatMin),
    fat_max: Number(fatMax),
    fat_step: Number(fatStep),
    snf_min: Number(snfMin),
    snf_max: Number(snfMax),
    snf_step: Number(snfStep),
  });

  const generateFromFormula = () => {
    const base = Number(baseRate);
    if (!base || Number.isNaN(base)) {
      setError(t("ratechart.err_base_rate"));
      return;
    }
    if (!rangeOk()) return;
    setRows(generateMatrixRates({ base_rate: base, ...chartRange() }));
    setError("");
    setCollapsed(true);
  };

  const parsedSamples = useMemo(
    () =>
      samples
        .map((s) => ({ fat: Number(s.fat), snf: Number(s.snf), rate: Number(s.rate) }))
        .filter(
          (s) =>
            s.fat > 0 &&
            s.snf > 0 &&
            s.rate > 0 &&
            Number.isFinite(s.fat) &&
            Number.isFinite(s.snf) &&
            Number.isFinite(s.rate),
        ),
    [samples],
  );

  const generateFromSamples = () => {
    if (parsedSamples.length < 3) {
      setError(t("ratechart.err_samples_min"));
      return;
    }
    if (!rangeOk()) return;
    const generated = generateRatesFromSamples(chartRange(), parsedSamples);
    if (!generated.length) {
      setError(t("ratechart.err_samples_min"));
      return;
    }
    setRows(generated);
    setError("");
    setCollapsed(true);
  };

  const generate = () => (method === "samples" ? generateFromSamples() : generateFromFormula());

  const regenerate = () => setOverwriteAsk(true);

  const editCell = (fat: number, snf: number, value: string) => {
    const num = Number(value);
    if (Number.isNaN(num)) return;
    setRows((prev) => {
      const key = `${fat}|${snf}`;
      const idx = prev.findIndex((r) => `${r.fat_value}|${r.snf_value}` === key);
      if (idx === -1) return [...prev, { fat_value: fat, snf_value: snf, rate: num }];
      const copy = [...prev];
      copy[idx] = { ...copy[idx], rate: num };
      return copy;
    });
  };

  const save = async () => {
    if (!selected) return;
    if (name.trim().length < 2) {
      setError(t("ratechart.err_chart_name"));
      return;
    }
    if (!rows.length) {
      setError(t("ratechart.err_generate_first"));
      return;
    }
    setSaving(true);
    setError("");
    try {
      // save calc mode to center settings
      await db
        .from("center_collection_settings")
        .upsert({ center_id: selected.id, calculation_mode: mode }, { onConflict: "center_id" });
      await saveChartWithRows({
        id: chartId,
        center_id: selected.id,
        milk_type: milkType,
        chart_name: name.trim(),
        base_rate: method === "samples" ? Number(minRate.toFixed(2)) : Number(baseRate),
        fat_min: Number(fatMin),
        fat_max: Number(fatMax),
        fat_step: Number(fatStep),
        snf_min: Number(snfMin),
        snf_max: Number(snfMax),
        snf_step: Number(snfStep),
        rows,
      });
      toast.success(chartId ? t("ratechart.updated") : t("ratechart.created"));
      navigate({ to: "/rate-charts" });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("ratechart.could_not_save"));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <>
        <AppHeader title={chartId ? t("ratechart.title_edit") : t("ratechart.title_new")} />
        <div className="p-8 flex justify-center">
          <Spinner />
        </div>
      </>
    );
  }

  return (
    <>
      <AppHeader title={chartId ? t("ratechart.title_edit") : t("ratechart.title_new")} />
      <div className="pb-28">
        <div className="p-4 space-y-4">
          {error && <Alert message={error} />}

          <div className="rounded-lg border border-slate-200 bg-white">
            <button
              type="button"
              onClick={() => setCollapsed((c) => !c)}
              className="w-full flex items-center justify-between px-4 py-3"
            >
              <span className="text-sm font-semibold text-slate-800">
                {t("ratechart.chart_setup")}
              </span>
              <ChevronDown
                className={cn(
                  "h-4 w-4 text-slate-500 transition-transform",
                  collapsed && "-rotate-90",
                )}
              />
            </button>
            {!collapsed && (
              <div className="p-4 pt-0 flex flex-col gap-3">
                <Field label={t("ratechart.chart_name")}>
                  <TextInput
                    placeholder={t("ratechart.chart_name_placeholder")}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </Field>

                <Field label={t("ratechart.milk_type")}>
                  <div className="flex gap-2">
                    {MILK_TYPES.map((m) => (
                      <button
                        key={m.value}
                        type="button"
                        disabled={milkLocked}
                        onClick={() => {
                          if (milkLocked) {
                            toast.error(t("ratechart.milk_locked"));
                            return;
                          }
                          setMilkType(m.value);
                        }}
                        className={cn(
                          "px-4 py-2 rounded-full text-sm font-medium transition",
                          milkType === m.value
                            ? "bg-teal-700 text-white"
                            : "bg-slate-100 text-slate-600",
                          milkLocked && "opacity-60",
                        )}
                      >
                        {t(m.key)}
                      </button>
                    ))}
                  </div>
                </Field>

                <Field label={t("ratechart.method")}>
                  <div className="flex gap-2 flex-wrap">
                    {(
                      [
                        { value: "formula", key: "ratechart.method_formula" },
                        { value: "samples", key: "ratechart.method_samples" },
                      ] as const
                    ).map((m) => (
                      <button
                        key={m.value}
                        type="button"
                        onClick={() => setMethod(m.value)}
                        className={cn(
                          "px-4 py-2 rounded-full text-sm font-medium",
                          method === m.value
                            ? "bg-teal-700 text-white"
                            : "bg-slate-100 text-slate-600",
                        )}
                      >
                        {t(m.key)}
                      </button>
                    ))}
                  </div>
                </Field>

                {method === "formula" ? (
                  <Field label={t("ratechart.base_rate")}>
                    <TextInput
                      prefix="₹"
                      inputMode="decimal"
                      value={baseRate}
                      onChange={(e) => setBaseRate(e.target.value)}
                      placeholder="32.00"
                    />
                  </Field>
                ) : (
                  <div>
                    <div className="text-sm font-medium text-slate-700 mb-1">
                      {t("ratechart.samples_title")}
                    </div>
                    <p className="text-xs text-slate-500 mb-2">{t("ratechart.samples_hint")}</p>
                    <div className="flex flex-col gap-2">
                      <div className="grid grid-cols-[1fr_1fr_1fr_32px] gap-2 text-xs font-medium text-slate-500">
                        <span>{t("ratechart.sample_fat")}</span>
                        <span>{t("ratechart.sample_snf")}</span>
                        <span>{t("ratechart.sample_rate")}</span>
                        <span />
                      </div>
                      {samples.map((s, i) => (
                        <div key={i} className="grid grid-cols-[1fr_1fr_1fr_32px] gap-2 items-center">
                          <TextInput
                            inputMode="decimal"
                            aria-label={`${t("ratechart.sample_fat")} ${i + 1}`}
                            value={s.fat}
                            onChange={(e) =>
                              setSamples((prev) =>
                                prev.map((p, j) => (j === i ? { ...p, fat: e.target.value } : p)),
                              )
                            }
                            placeholder="3.5"
                          />
                          <TextInput
                            inputMode="decimal"
                            aria-label={`${t("ratechart.sample_snf")} ${i + 1}`}
                            value={s.snf}
                            onChange={(e) =>
                              setSamples((prev) =>
                                prev.map((p, j) => (j === i ? { ...p, snf: e.target.value } : p)),
                              )
                            }
                            placeholder="8.0"
                          />
                          <TextInput
                            prefix="₹"
                            inputMode="decimal"
                            aria-label={`${t("ratechart.sample_rate")} ${i + 1}`}
                            value={s.rate}
                            onChange={(e) =>
                              setSamples((prev) =>
                                prev.map((p, j) => (j === i ? { ...p, rate: e.target.value } : p)),
                              )
                            }
                            placeholder="32"
                          />
                          <button
                            type="button"
                            aria-label={t("ratechart.remove_example")}
                            disabled={samples.length <= 3}
                            onClick={() => setSamples((prev) => prev.filter((_, j) => j !== i))}
                            className={cn(
                              "h-8 w-8 flex items-center justify-center rounded-md text-slate-400",
                              samples.length <= 3 ? "opacity-30" : "hover:text-red-600",
                            )}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                    <button
                      type="button"
                      disabled={samples.length >= 8}
                      onClick={() =>
                        setSamples((prev) =>
                          prev.length >= 8 ? prev : [...prev, { fat: "", snf: "", rate: "" }],
                        )
                      }
                      className={cn(
                        "mt-2 inline-flex items-center gap-1 text-sm font-medium text-teal-700",
                        samples.length >= 8 && "opacity-40",
                      )}
                    >
                      <Plus className="h-4 w-4" />
                      {t("ratechart.add_example")}
                    </button>
                  </div>
                )}

                <div>
                  <div className="text-sm font-medium text-slate-700 mb-2">
                    {t("ratechart.fat_range")}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <TextInput
                      inputMode="decimal"
                      value={fatMin}
                      onChange={(e) => setFatMin(e.target.value)}
                      placeholder={t("ratechart.min")}
                    />
                    <TextInput
                      inputMode="decimal"
                      value={fatMax}
                      onChange={(e) => setFatMax(e.target.value)}
                      placeholder={t("ratechart.max")}
                    />
                    <TextInput
                      inputMode="decimal"
                      value={fatStep}
                      onChange={(e) => setFatStep(e.target.value)}
                      placeholder={t("ratechart.step")}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {t("ratechart.fat_increment_hint", { step: fatStep || "0.1" })}
                  </p>
                </div>

                <div>
                  <div className="text-sm font-medium text-slate-700 mb-2">
                    {t("ratechart.snf_range")}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <TextInput
                      inputMode="decimal"
                      value={snfMin}
                      onChange={(e) => setSnfMin(e.target.value)}
                      placeholder={t("ratechart.min")}
                    />
                    <TextInput
                      inputMode="decimal"
                      value={snfMax}
                      onChange={(e) => setSnfMax(e.target.value)}
                      placeholder={t("ratechart.max")}
                    />
                    <TextInput
                      inputMode="decimal"
                      value={snfStep}
                      onChange={(e) => setSnfStep(e.target.value)}
                      placeholder={t("ratechart.step")}
                    />
                  </div>
                </div>

                <Field label={t("ratechart.calc_mode")}>
                  <div className="flex gap-2 flex-wrap">
                    {MODES.map((m) => (
                      <button
                        key={m.value}
                        type="button"
                        onClick={() => setMode(m.value)}
                        className={cn(
                          "px-4 py-2 rounded-full text-sm font-medium",
                          mode === m.value
                            ? "bg-teal-700 text-white"
                            : "bg-slate-100 text-slate-600",
                        )}
                      >
                        {t(m.key)}
                      </button>
                    ))}
                  </div>
                </Field>

                <Button variant="secondary" onClick={rows.length ? regenerate : generate}>
                  <Calculator className="h-4 w-4" />
                  {rows.length
                    ? t("ratechart.regenerate_matrix")
                    : method === "samples"
                      ? t("ratechart.generate_from_samples")
                      : t("ratechart.generate_matrix")}
                </Button>
              </div>
            )}
          </div>

          {rows.length > 0 && (
            <div className="rounded-lg border border-slate-200 bg-white">
              <div className="sticky top-14 z-10 bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between rounded-t-lg">
                <span className="inline-flex items-center rounded-full bg-slate-100 text-slate-700 text-xs px-2.5 py-1 font-medium">
                  ₹{minRate.toFixed(2)} – ₹{maxRate.toFixed(2)}
                </span>
                <button
                  type="button"
                  onClick={regenerate}
                  className="text-xs font-medium text-teal-700 hover:text-teal-800"
                >
                  {t("ratechart.regenerate_from_formula")}
                </button>
              </div>
              <div className="overflow-auto max-h-[65vh]">
                <table className="border-separate border-spacing-0 text-sm">
                  <thead>
                    <tr>
                      <th className="sticky left-0 top-0 z-20 bg-slate-50 border-b border-r border-slate-200 px-2 py-2 text-xs font-semibold text-slate-500">
                        {t("ratechart.matrix_header")}
                      </th>
                      {snfs.map((s) => (
                        <th
                          key={s}
                          className="sticky top-0 z-10 bg-slate-50 border-b border-slate-200 px-2 py-2 text-xs font-semibold text-slate-600 min-w-[56px]"
                        >
                          {s.toFixed(1)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {fats.map((f) => (
                      <tr key={f}>
                        <th className="sticky left-0 z-10 bg-slate-50 border-b border-r border-slate-200 px-2 py-1 text-xs font-semibold text-slate-600">
                          {f.toFixed(1)}
                        </th>
                        {snfs.map((s) => {
                          const cell = rowMap.get(`${f}|${s}`);
                          return (
                            <td key={s} className="border-b border-slate-100 p-0.5">
                              <input
                                type="number"
                                step="0.01"
                                defaultValue={cell?.rate ?? ""}
                                onBlur={(e) => editCell(f, s, e.target.value)}
                                className="w-14 h-8 text-center text-sm border border-transparent rounded focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none"
                              />
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={overwriteAsk}
        title={t("ratechart.regenerate_matrix")}
        message={t("ratechart.overwrite_confirm")}
        onCancel={() => setOverwriteAsk(false)}
        onConfirm={() => {
          setOverwriteAsk(false);
          generate();
        }}
      />

      <div className="fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-slate-200 safe-bottom">
        <div className="max-w-md mx-auto p-3">
          <Button onClick={save} loading={saving} disabled={!rows.length || saving}>
            {t("ratechart.save")}
          </Button>
        </div>
      </div>
    </>
  );
}
