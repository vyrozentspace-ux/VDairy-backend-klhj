import { useState } from "react";
import { useTranslation } from "react-i18next";
import { AlertTriangle, CloudOff, RefreshCw } from "lucide-react";
import { BottomSheet } from "@/components/BottomSheet";
import { Button } from "@/components/Button";
import { useOfflineSync } from "@/contexts/OfflineSyncContext";

/**
 * Persistent "Pending sync (N)" indicator. Tapping it opens a sheet listing
 * every queued record, including the reason any of them failed.
 */
export function PendingSyncBadge() {
  const { t } = useTranslation();
  const { records, pendingCount, failedCount, online, flush, retry } = useOfflineSync();
  const [open, setOpen] = useState(false);

  const total = pendingCount + failedCount;
  if (total === 0) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={
          failedCount > 0
            ? "flex items-center gap-1.5 rounded-full border border-red-200 bg-red-50 px-2.5 py-1 text-xs font-medium text-red-700"
            : "flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-xs font-medium text-amber-700"
        }
        aria-label={t("sync.pending_count", { n: total })}
      >
        {failedCount > 0 ? (
          <AlertTriangle className="h-3.5 w-3.5" />
        ) : (
          <CloudOff className="h-3.5 w-3.5" />
        )}
        {t("sync.pending_count", { n: total })}
      </button>

      <BottomSheet open={open} onClose={() => setOpen(false)} title={t("sync.title")}>
        <div className="px-4 pb-4 space-y-3">
          <p className="text-xs text-slate-500">
            {online ? t("sync.online_hint") : t("sync.offline_hint")}
          </p>
          <ul className="space-y-2 max-h-72 overflow-y-auto">
            {records.map((r) => (
              <li key={r.id} className="rounded-xl border border-slate-200 p-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-medium text-slate-800">
                    {t(`sync.kind_${r.kind}`, { defaultValue: r.kind })}
                  </span>
                  <span
                    className={
                      r.status === "failed"
                        ? "text-[11px] font-medium text-red-600"
                        : "text-[11px] font-medium text-amber-600"
                    }
                  >
                    {r.status === "failed" ? t("sync.status_failed") : t("sync.status_pending")}
                  </span>
                </div>
                <div className="mt-0.5 text-[11px] text-slate-500">
                  {new Date(r.createdAt).toLocaleString()}
                </div>
                {r.status === "failed" && (
                  <>
                    <p className="mt-1 text-xs text-red-600 break-words">{r.error}</p>
                    <button
                      type="button"
                      onClick={() => void retry(r.id)}
                      className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-teal-700"
                    >
                      <RefreshCw className="h-3 w-3" /> {t("sync.retry")}
                    </button>
                  </>
                )}
              </li>
            ))}
          </ul>
          <Button onClick={() => void flush()} className="w-full">
            {t("sync.sync_now")}
          </Button>
        </div>
      </BottomSheet>
    </>
  );
}
