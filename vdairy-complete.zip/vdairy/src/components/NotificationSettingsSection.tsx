import { useEffect, useState } from "react";
import { Bell } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Switch } from "@/components/Switch";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { NOTIFICATION_CATEGORIES } from "@/lib/notification-engine";
import {
  getOperatorSubscriptionNotifications,
  setOperatorSubscriptionNotifications,
  useNotificationPrefs,
} from "@/lib/notifications";

/** Per-user notification category toggles (+ owner-level operator control). */
export function NotificationSettingsSection() {
  const { t } = useTranslation();
  const { userId } = useAuth();
  const { selected, isOwner } = useCenter();
  const { prefs, setCategory } = useNotificationPrefs(userId);
  const [operatorSubs, setOperatorSubs] = useState(true);

  useEffect(() => {
    if (!isOwner || !selected?.id) return;
    void getOperatorSubscriptionNotifications(selected.id).then(setOperatorSubs);
  }, [isOwner, selected?.id]);

  return (
    <div className="rounded-lg border border-slate-200 bg-white divide-y divide-slate-100">
      <div className="p-3">
        <p className="flex items-center gap-2 text-sm font-semibold text-slate-800">
          <Bell className="h-4 w-4 text-slate-500" /> {t("notif.section_title")}
        </p>
        <p className="mt-0.5 text-xs text-slate-500">{t("notif.section_hint")}</p>
      </div>
      {NOTIFICATION_CATEGORIES.map((cat) => (
        <div key={cat} className="flex items-center justify-between gap-3 p-3">
          <span className="text-sm font-medium text-slate-700">{t(`notif.cat_${cat}`)}</span>
          <Switch
            checked={prefs[cat]}
            label={t(`notif.cat_${cat}`)}
            onChange={(v) => void setCategory(cat, v)}
          />
        </div>
      ))}
      {isOwner && selected && (
        <div className="flex items-center justify-between gap-3 p-3">
          <span className="flex-1">
            <span className="block text-sm font-medium text-slate-700">
              {t("notif.owner_operator_subs")}
            </span>
            <span className="block text-xs text-slate-500">
              {t("notif.owner_operator_subs_hint")}
            </span>
          </span>
          <Switch
            checked={operatorSubs}
            label={t("notif.owner_operator_subs")}
            onChange={(v) => {
              setOperatorSubs(v);
              void setOperatorSubscriptionNotifications(selected.id, v);
            }}
          />
        </div>
      )}
    </div>
  );
}
