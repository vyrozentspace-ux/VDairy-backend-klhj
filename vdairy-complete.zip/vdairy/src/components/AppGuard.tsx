import { useEffect } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";

import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { requiredPermissionsFor } from "@/lib/permissions";

/** Routes reachable without a session. */
const PUBLIC_PATHS = ["/", "/login", "/register", "/forgot-password"];

/** Signed-in routes that do not require a selected center. */
const NO_CENTER_PATHS = ["/centers", "/onboarding/create-center", "/store"];

function matches(pathname: string, list: string[]) {
  return list.some((p) => pathname === p || pathname.startsWith(`${p}/`));
}

/**
 * Global guard for top-level module routes (milk-sale, expense, food, invoice,
 * advance, farmer, notices, rate-charts, …) that are not nested under /_shell.
 * Unauthenticated -> /login, signed-in without a center -> /centers.
 */
export function AppGuard() {
  const { loading, session } = useAuth();
  const { loading: centerLoading, selectedId, centers, canAny } = useCenter();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (loading) return;
    if (matches(pathname, PUBLIC_PATHS)) return;

    if (!session) {
      navigate({ to: "/login", replace: true });
      return;
    }

    if (matches(pathname, NO_CENTER_PATHS)) return;
    if (centerLoading) return;
    if (!selectedId && centers.length !== 1) {
      navigate({ to: "/centers", replace: true });
      return;
    }
    if (!selectedId) return;

    const required = requiredPermissionsFor(pathname);
    if (required && !canAny(required)) {
      navigate({ to: "/denied", replace: true });
    }
  }, [loading, session, centerLoading, selectedId, centers.length, pathname, navigate, canAny]);

  return null;
}
