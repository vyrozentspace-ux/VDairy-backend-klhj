import { useEffect, useState } from "react";
import { Lock, Eye, EyeOff } from "lucide-react";
import { useTranslation } from "react-i18next";

import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Alert } from "@/components/Alert";
import { Logo } from "@/components/Logo";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { phoneToEmail, pinToPassword } from "@/lib/pin-auth";
import {
  isAppLockEnabled,
  isUnlockedThisRun,
  markHidden,
  markUnlocked,
  shouldRelockOnResume,
} from "@/lib/app-lock";

/**
 * Renders a full-screen PIN prompt whenever App Lock is on and the app has
 * just been started, reloaded, or resumed from the background.
 */
export function AppLockGate() {
  const { t } = useTranslation();
  const { session, profile, logout } = useAuth();
  const [locked, setLocked] = useState(false);
  const [pin, setPin] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  // Lock on first run of the app (fresh load / restart).
  useEffect(() => {
    if (!session) return;
    if (isAppLockEnabled() && !isUnlockedThisRun()) setLocked(true);
  }, [session]);

  // Lock again after the app has been in the background.
  useEffect(() => {
    if (typeof document === "undefined") return;
    const onVisibility = () => {
      if (document.visibilityState === "hidden") {
        markHidden();
        return;
      }
      if (isAppLockEnabled() && shouldRelockOnResume()) setLocked(true);
    };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", markHidden);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", markHidden);
    };
  }, []);

  useEffect(() => {
    if (locked) {
      setPin("");
      setError("");
    }
  }, [locked]);

  if (!locked || !session) return null;

  const phone = profile?.phone ?? "";

  const unlock = async () => {
    if (pin.length !== 4) {
      setError(t("settings.app_lock_invalid_pin"));
      return;
    }
    if (!phone) {
      setError(t("settings.app_lock_wrong_pin"));
      return;
    }
    setBusy(true);
    setError("");
    const { error: err } = await supabase.auth.signInWithPassword({
      email: phoneToEmail(phone),
      password: pinToPassword(pin),
    });
    setBusy(false);
    if (err) {
      setError(t("settings.app_lock_wrong_pin"));
      setPin("");
      return;
    }
    markUnlocked();
    setLocked(false);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t("settings.app_lock_title")}
      className="fixed inset-0 z-[100] bg-white safe-top safe-bottom flex flex-col"
    >
      <div className="flex-1 flex flex-col justify-center px-6 max-w-md w-full mx-auto">
        <div className="flex flex-col items-center text-center gap-3">
          <Logo size="sm" />
          <span className="mt-2 h-14 w-14 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center">
            <Lock className="h-6 w-6" />
          </span>
          <h1 className="text-xl font-bold text-slate-800">{t("settings.app_lock_title")}</h1>
          <p className="text-sm text-slate-500">
            {t("settings.app_lock_subtitle", { name: profile?.full_name ?? "" })}
          </p>
        </div>

        <div className="mt-6 flex flex-col gap-3">
          {error && <Alert message={error} />}
          <Field label={t("settings.app_lock_enter_pin")}>
            <TextInput
              autoFocus
              type={show ? "text" : "password"}
              inputMode="numeric"
              maxLength={4}
              value={pin}
              invalid={!!error}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
              onKeyDown={(e) => {
                if (e.key === "Enter") void unlock();
              }}
              suffix={
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  className="p-2 text-slate-400"
                  aria-label={show ? t("auth.hide_pin") : t("auth.show_pin")}
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              }
            />
          </Field>
          <Button onClick={() => void unlock()} loading={busy}>
            {t("settings.app_lock_unlock")}
          </Button>
          <Button
            variant="ghost"
            onClick={async () => {
              await logout();
              setLocked(false);
            }}
          >
            {t("settings.sign_out")}
          </Button>
        </div>
      </div>
    </div>
  );
}
