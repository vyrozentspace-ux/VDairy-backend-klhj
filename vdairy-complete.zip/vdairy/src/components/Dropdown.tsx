import { useEffect, useRef, useState, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

export interface DropdownOption {
  value: string;
  label: ReactNode;
  disabled?: boolean;
}

export function Dropdown({
  value,
  onChange,
  options,
  placeholder,
  className,
}: {
  value: string | null;
  onChange: (v: string) => void;
  options: DropdownOption[];
  placeholder?: string;
  className?: string;
}) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("mousedown", handler);
    return () => window.removeEventListener("mousedown", handler);
  }, [open]);

  const selected = options.find((o) => o.value === value);
  const placeholderText = placeholder ?? t("core.select_ellipsis");

  return (
    <div ref={ref} className={cn("relative w-full", className)}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex items-center justify-between w-full h-12 px-3 rounded-lg border bg-white text-sm text-left transition border-slate-200 hover:border-slate-300 focus:outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
      >
        <span className={cn(selected ? "text-slate-800" : "text-slate-400")}>
          {selected?.label ?? placeholderText}
        </span>
        <ChevronDown
          className={cn("h-4 w-4 text-slate-400 transition-transform", open && "rotate-180")}
        />
      </button>
      {open && (
        <div className="absolute z-30 mt-1 w-full rounded-lg border border-slate-200 bg-white shadow-lg animate-fade-in max-h-64 overflow-y-auto">
          {options.map((opt) => (
            <button
              key={opt.value}
              type="button"
              disabled={opt.disabled}
              onClick={() => {
                if (opt.disabled) return;
                onChange(opt.value);
                setOpen(false);
              }}
              className={cn(
                "block w-full text-left px-3 py-2.5 text-sm transition",
                opt.value === value
                  ? "bg-teal-50 text-teal-800 font-medium"
                  : "text-slate-700 hover:bg-slate-50",
                opt.disabled && "opacity-40 cursor-not-allowed hover:bg-transparent",
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
