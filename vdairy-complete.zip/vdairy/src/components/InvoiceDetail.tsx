import { deductionTypeLabel } from "@/lib/labels";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import {
  AlertCircle,
  CheckCircle,
  ChevronDown,
  IndianRupee,
  Loader2,
  MessageCircle,
  MoreVertical,
  Moon,
  Printer,
  RotateCcw,
  Share2,
  Sun,
  Trash2,
} from "lucide-react";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import { fetchFarmer, farmerFullName, type Farmer } from "@/lib/farmers";
import {
  computePreview,
  deleteInvoice,
  fmtDMY,
  generateInvoice,
  getInvoice,
  listInvoiceDeductions,
  logInvoice,
  markInvoicePaid,
  markInvoiceUnpaid,
  type Invoice,
  type InvoiceDeductionRow,
} from "@/lib/invoices";
import type { Collection } from "@/lib/collections";
import { buildInvoiceSmsFromDetail, openSmsApp } from "@/lib/sms-receipt";
import { cn } from "@/lib/utils";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

type FeedSale = {
  id: string;
  sale_date: string;
  quantity: number;
  rate: number;
  amount: number;
  cash_payment: boolean;
  feed_product_id: string;
};
type AdvanceLite = { id: string; advance_date: string; amount: number; comments: string | null };

export function InvoiceDetail(
  props:
    | { mode: "view"; invoiceId: string }
    | { mode: "preview"; farmerId: string; periodStart: string; periodEnd: string },
) {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { userId, profile } = useAuth();

  const [loading, setLoading] = useState(true);
  const [farmer, setFarmer] = useState<Farmer | null>(null);
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [dedRows, setDedRows] = useState<InvoiceDeductionRow[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [feedSales, setFeedSales] = useState<FeedSale[]>([]);
  const [advances, setAdvances] = useState<AdvanceLite[]>([]);
  const [productMap, setProductMap] = useState<Record<string, string>>({});
  const [computed, setComputed] = useState<Awaited<ReturnType<typeof computePreview>> | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [confirmAsk, setConfirmAsk] = useState<{
    message: string;
    title?: string;
    destructive?: boolean;
    confirmLabel?: string;
    run: () => void;
  } | null>(null);

  const isPreview = props.mode === "preview";
  const canEdit = !!profile;

  const periodStart = isPreview ? props.periodStart : (invoice?.period_start ?? "");
  const periodEnd = isPreview ? props.periodEnd : (invoice?.period_end ?? "");
  const farmerId = isPreview ? props.farmerId : (invoice?.farmer_id ?? "");
  const centerId = selected?.id ?? invoice?.center_id ?? "";

  // Guards against an earlier load (e.g. the default period, before the
  // center's configured cycle resolves) overwriting newer results.
  const loadSeq = useRef(0);

  const load = async () => {
    if (!selected) return;
    const seq = ++loadSeq.current;
    const stale = () => seq !== loadSeq.current;
    setLoading(true);
    try {
      let inv: Invoice | null = null;
      let fId = "";
      let pStart = "";
      let pEnd = "";
      if (props.mode === "view") {
        inv = await getInvoice(props.invoiceId);
        if (stale()) return;
        if (!inv) {
          toast.error(t("invoice.notFound"));
          navigate({ to: "/invoice" });
          return;
        }
        fId = inv.farmer_id;
        pStart = inv.period_start;
        pEnd = inv.period_end;
        setInvoice(inv);
        const ded = await listInvoiceDeductions(inv.id);
        if (stale()) return;
        setDedRows(ded);
      } else {
        fId = props.farmerId;
        pStart = props.periodStart;
        pEnd = props.periodEnd;
        setInvoice(null);
        setDedRows([]);
      }

      // Feed sales shown on this receipt: for a saved invoice, the ones linked to it;
      // for a live preview, only sales not already settled by an earlier paid invoice.
      let feedQuery = db
        .from("farmer_feed_sales")
        .select("*")
        .eq("center_id", selected.id)
        .eq("farmer_id", fId)
        .gte("sale_date", pStart)
        .lte("sale_date", pEnd)
        .eq("cash_payment", false);
      feedQuery = inv
        ? feedQuery.or(`invoice_id.eq.${inv.id},is_settled.eq.false`)
        : feedQuery.eq("is_settled", false);

      const [f, cols, feeds, advs, prods] = await Promise.all([
        fetchFarmer(fId),
        db
          .from("collections")
          .select("*")
          .eq("center_id", selected.id)
          .eq("farmer_id", fId)
          .gte("collection_date", pStart)
          .lte("collection_date", pEnd)
          .order("collection_date")
          .order("shift"),
        feedQuery.order("sale_date"),
        db
          .from("advances")
          .select("id,advance_date,amount,comments")
          .eq("center_id", selected.id)
          .eq("farmer_id", fId)
          .gte("advance_date", pStart)
          .lte("advance_date", pEnd)
          .order("advance_date"),
        db.from("feed_products").select("id,product_name").eq("center_id", selected.id),
      ]);
      if (stale()) return;
      setFarmer(f);
      setCollections((cols.data ?? []) as Collection[]);
      setFeedSales((feeds.data ?? []) as FeedSale[]);
      setAdvances((advs.data ?? []) as AdvanceLite[]);
      const pmap: Record<string, string> = {};
      for (const p of (prods.data ?? []) as { id: string; product_name: string }[])
        pmap[p.id] = p.product_name;
      setProductMap(pmap);

      const c = inv
        ? {
            total_liter: Number(inv.total_liter),
            total_milk_amount: Number(inv.total_milk_amount),
            total_feed_amount: Number(inv.total_feed_amount),
            manual_deductions: Number(inv.total_deduction) - Number(inv.total_feed_amount),
            total_deduction: Number(inv.total_deduction),
            total_advance_given: Number(inv.total_advance_given),
            previous_balance: Number(inv.previous_balance),
            amount_due: Number(inv.amount_due),
            new_balance: Number(inv.new_balance),
          }
        : await computePreview({
            centerId: selected.id,
            farmerId: fId,
            periodStart: pStart,
            periodEnd: pEnd,
          });
      if (stale()) return;
      setComputed(c);
    } finally {
      if (seq === loadSeq.current) setLoading(false);
    }
  };

  useEffect(() => {
    void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [
    selected?.id,
    props.mode === "view" ? props.invoiceId : props.farmerId,
    props.mode === "preview" ? props.periodStart : "",
    props.mode === "preview" ? props.periodEnd : "",
  ]);

  const doGenerate = async () => {
    if (!selected || !farmerId) return;
    setBusy(true);
    try {
      const id = await generateInvoice({
        centerId: selected.id,
        farmerId,
        periodStart,
        periodEnd,
        createdBy: userId,
      });
      await logInvoice(selected.id, userId, "invoice_generated", {
        invoice_id: id,
        farmer_id: farmerId,
        period_start: periodStart,
        period_end: periodEnd,
      });
      toast.success(t("invoice.invoiceGenerated"));
      navigate({ to: "/invoice/view/$invoiceId", params: { invoiceId: id } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedUnknown"));
    } finally {
      setBusy(false);
    }
  };

  const doMarkPaid = () => {
    if (!invoice) return;
    setConfirmAsk({
      title: t("invoice.actions.markAsPaid"),
      message: t("invoice.confirmMarkPaid"),
      confirmLabel: t("invoice.actions.markAsPaid"),
      run: () => void runMarkPaid(),
    });
  };

  const runMarkPaid = async () => {
    if (!invoice) return;
    // Build the receipt from data already on screen and open the SMS app right
    // away; the database write happens in parallel.
    const smsText = farmer && computed && centerId ? buildFullText() : "";
    const paid = markInvoicePaid(invoice.id);
    if (smsText && farmer) openSmsApp(farmer.mobile, smsText);
    try {
      await paid;
      toast.success(t("invoice.markedPaid"));
      void logInvoice(centerId, userId, "invoice_marked_paid", { invoice_id: invoice.id });
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedUnknown"));
    }
  };

  const doMarkUnpaid = () => {
    if (!invoice) return;
    setConfirmAsk({
      title: t("invoice.actions.markAsUnpaid"),
      message: t("invoice.confirmMarkUnpaid"),
      confirmLabel: t("invoice.actions.markAsUnpaid"),
      run: () => void runMarkUnpaid(),
    });
  };

  const runMarkUnpaid = async () => {
    if (!invoice) return;
    try {
      await markInvoiceUnpaid(invoice.id);
      await logInvoice(centerId, userId, "invoice_marked_unpaid", { invoice_id: invoice.id });
      toast.success(t("invoice.markedUnpaid"));
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedUnknown"));
    }
  };

  const doDelete = () => {
    if (!invoice) return;
    if (invoice.status === "Paid") {
      toast.error(t("invoice.cannotDeletePaid"));
      return;
    }
    setConfirmAsk({
      title: t("invoice.actions.deleteInvoice"),
      message: t("invoice.confirmDeleteInvoice"),
      confirmLabel: t("invoice.actions.deleteInvoice"),
      destructive: true,
      run: () => void runDelete(),
    });
  };

  const runDelete = async () => {
    if (!invoice) return;
    try {
      await deleteInvoice(invoice.id);
      await logInvoice(centerId, userId, "invoice_deleted", { invoice_id: invoice.id });
      toast.success(t("invoice.deleted"));
      navigate({ to: "/invoice" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedUnknown"));
    }
  };

  /** Full itemized plain-text receipt (same content as the auto-SMS). */
  const buildFullText = () => {
    if (!farmer || !computed) return "";
    return buildInvoiceSmsFromDetail({
      centerName: selected?.name ?? "",
      farmerName: farmerFullName(farmer),
      farmerCode: farmer.code,
      periodStart: fmtDMY(periodStart),
      periodEnd: fmtDMY(periodEnd),
      fmtDate: fmtDMY,
      detail: {
        collections: collections.map((c) => ({
          collection_date: c.collection_date,
          shift: c.shift,
          milk_type: c.milk_type,
          fat: Number(c.fat),
          snf: c.snf != null ? Number(c.snf) : null,
          quantity_liters: Number(c.quantity_liters),
          rate_per_liter: Number(c.rate_per_liter),
          total_amount: Number(c.total_amount),
        })),
        feedSales: feedSales.map((s) => ({
          sale_date: s.sale_date,
          product_name: productMap[s.feed_product_id] ?? "Feed",
          quantity: Number(s.quantity),
          rate: Number(s.rate),
          amount: Number(s.amount),
        })),
        advanceDeductions: dedRows
          .filter((d) => d.deduction_type !== "Feed")
          .map((d) => ({
            deduction_date: d.created_at.slice(0, 10),
            amount: Number(d.deduction_amount),
          })),
        advancesGiven: advances.map((a) => ({
          advance_date: a.advance_date,
          amount: Number(a.amount),
          comments: a.comments,
        })),
      },
      totals: computed,
    });
  };

  // Manual, image-based branded receipt share — full itemized daily breakdown.
  const doShare = async () => {
    if (!farmer || !computed) return;
    const [{ shareInvoiceReceiptImage }, { receiptDict }] = await Promise.all([
      import("@/lib/invoice-receipt-image"),
      import("@/lib/sms-receipt"),
    ]);
    const d = receiptDict();
    const text = await buildFullText();

    const deductionItems =
      dedRows.length > 0
        ? dedRows.map((r) => ({
            label: deductionTypeLabel(t, r.deduction_type),
            amount: Number(r.deduction_amount),
          }))
        : [
            ...feedSales.map((s) => ({
              label: `${d.feed} ${fmtDMY(s.sale_date)} (${productMap[s.feed_product_id] ?? "Feed"})`,
              amount: Number(s.amount),
            })),
            ...(computed.manual_deductions > 0
              ? [{ label: d.advance, amount: computed.manual_deductions }]
              : []),
          ];

    await shareInvoiceReceiptImage(
      {
        centerName: selected?.name ?? "",
        farmerName: farmerFullName(farmer),
        farmerCode: farmer.code,
        periodLabel: `${fmtDMY(periodStart)} – ${fmtDMY(periodEnd)}`,
        collections: collections.map((c) => ({
          date: fmtDMY(c.collection_date),
          session: /^m/i.test(c.shift) ? d.morning : d.evening,
          milkType: c.milk_type,
          liters: Number(c.quantity_liters),
          fat: c.fat != null ? Number(c.fat) : null,
          snf: c.snf != null ? Number(c.snf) : null,
          rate: Number(c.rate_per_liter),
          amount: Number(c.total_amount),
        })),
        feeds: feedSales.map((s) => ({
          date: fmtDMY(s.sale_date),
          product: productMap[s.feed_product_id] ?? "Feed",
          qty: Number(s.quantity),
          rate: Number(s.rate),
          amount: Number(s.amount),
        })),
        deductions: deductionItems,
        advances: advances.map((a) => ({
          date: fmtDMY(a.advance_date),
          comments: a.comments,
          amount: Number(a.amount),
        })),
        totals: {
          liters: computed.total_liter,
          milkAmount: computed.total_milk_amount,
          feedTotal: computed.total_feed_amount,
          deductionTotal: computed.total_deduction,
          previousBalance: computed.previous_balance,
          advanceGiven: computed.total_advance_given,
          netPayment: computed.new_balance,
        },
        labels: {
          title: d.invoiceTitle,
          collections: d.collectionTitle,
          cattleFeeds: d.cattleFeeds,
          deductions: d.deductions,
          advanceGiven: d.advanceGiven,
          summary: d.summary,
          date: d.date,
          session: d.session,
          type: t("invoice.tableType"),
          litre: d.liters,
          fat: d.fat,
          snf: d.snf,
          rate: d.rate,
          amount: d.amount,
          product: t("invoice.tableProduct"),
          qty: d.qty,
          total: d.total,
          totalLitres: d.totalLiters,
          milkAmount: d.milkAmount,
          totalDeduction: d.deductions,
          previousBalance: d.previousBalance,
          netPayment: d.balanceRemaining,
          comments: t("invoice.tableComments"),
          closing: d.closing,
        },
      },
      { text, phone: farmer.mobile },
    );
  };

  const doWhatsApp = async () => {
    const text = await buildFullText();
    window.open(
      `https://wa.me/${(farmer?.mobile ?? "").replace(/\D/g, "")}?text=${encodeURIComponent(text)}`,
      "_blank",
    );
  };

  const summarySentence = useMemo(() => {
    if (!computed) return "";
    const parts = [
      t("invoice.summarySentence", {
        start: fmtDMY(periodStart),
        end: fmtDMY(periodEnd),
        milk: computed.total_milk_amount.toFixed(2),
      }),
    ];
    if (computed.total_feed_amount > 0)
      parts.push(t("invoice.summarySentenceFeed", { feed: computed.total_feed_amount.toFixed(2) }));
    if (computed.manual_deductions > 0)
      parts.push(
        t("invoice.summarySentenceAdvance", { advance: computed.manual_deductions.toFixed(2) }),
      );
    return parts.join("") + ".";
  }, [computed, periodStart, periodEnd]);

  if (loading || !computed) {
    return (
      <>
        <AppHeader title={t("invoice.title")} onBack={() => navigate({ to: "/invoice" })} />
        <div className="py-16 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-teal-700" />
        </div>
      </>
    );
  }

  const status: "Unpaid" | "Paid" = invoice?.status ?? "Unpaid";
  const canPay =
    status === "Unpaid" &&
    computed.new_balance > 0.009 &&
    !!(farmer?.payment_mobile || farmer?.mobile);
  // "Net Payment" (formerly "New Balance") — the exact amount payable to the farmer.
  const netPayment = computed.new_balance;

  return (
    <>
      <AppHeader
        title={t("invoice.title")}
        onBack={() => navigate({ to: "/invoice" })}
        right={
          canEdit ? (
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              className="h-9 w-9 rounded-full hover:bg-slate-100 flex items-center justify-center"
            >
              <MoreVertical className="h-4 w-4" />
            </button>
          ) : null
        }
      />

      {/* Farmer info bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
        <div className="min-w-0">
          <div className="font-semibold text-slate-800 truncate">
            {farmer ? farmerFullName(farmer) : ""}
          </div>
          <div className="text-xs text-slate-500">
            {t("invoice.farmerCode", { code: farmer?.code })} · {fmtDMY(periodStart)} –{" "}
            {fmtDMY(periodEnd)}
          </div>
        </div>
        <span
          className={cn(
            "text-xs font-semibold rounded-full px-2.5 py-1",
            status === "Paid" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700",
          )}
        >
          {status === "Paid" ? t("invoice.status.paid") : t("invoice.status.unpaid")}
        </span>
      </div>

      {/* Manual WhatsApp share (image receipt) — top of receipt view */}
      <div className="px-4 pt-3">
        <button
          type="button"
          onClick={() => void doShare()}
          className="w-full h-11 rounded-lg text-white text-sm font-semibold inline-flex items-center justify-center gap-2"
          style={{ backgroundColor: "#25D366" }}
        >
          <MessageCircle className="h-4 w-4" /> {t("invoice.shareWhatsApp")}
        </button>
      </div>

      {/* ── At-a-glance summary: the three numbers that matter ── */}
      <div className="mx-4 mt-4 rounded-2xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-4">
          <div className="text-[11px] uppercase tracking-wide text-slate-400 font-semibold">
            {t("invoice.grossMilkAmount")}
          </div>
          <div className="mt-1 text-3xl font-extrabold text-slate-900 tabular-nums">
            ₹{computed.total_milk_amount.toFixed(2)}
          </div>
          <div className="text-xs text-slate-400 mt-0.5">
            {computed.total_liter.toFixed(1)} L · {t("invoice.beforeDeductions")}
          </div>
        </div>

        <div className="px-5 py-4 border-t border-slate-100 bg-rose-50/40">
          <div className="text-[11px] uppercase tracking-wide text-rose-400 font-semibold">
            {t("invoice.totalDeduction")}
          </div>
          <div className="mt-1 text-2xl font-bold text-rose-600 tabular-nums">
            −₹{computed.total_deduction.toFixed(2)}
          </div>
          <div className="text-xs text-slate-500 mt-1 flex flex-wrap gap-x-3">
            {computed.total_feed_amount > 0 && (
              <span>
                {t("invoice.deductionFeed")} ₹{computed.total_feed_amount.toFixed(2)}
              </span>
            )}
            {computed.manual_deductions > 0 && (
              <span>
                {t("invoice.deductionAdvanceRepayment")} ₹{computed.manual_deductions.toFixed(2)}
              </span>
            )}
          </div>
        </div>

        <div className="px-5 py-5 border-t border-slate-100 bg-emerald-50/60">
          <div className="text-[11px] uppercase tracking-wide text-emerald-600 font-semibold">
            {t("invoice.newBalance")}
          </div>
          <div
            className={cn(
              "mt-1 text-4xl font-extrabold tabular-nums",
              netPayment < 0 ? "text-rose-600" : "text-emerald-700",
            )}
          >
            {netPayment < 0 ? "−" : ""}₹{Math.abs(netPayment).toFixed(2)}
          </div>
          <div className="text-xs text-slate-500 mt-1">{t("invoice.netPaymentNote")}</div>
        </div>
      </div>

      {/* Secondary figures */}
      <div className="mx-4 mt-3 grid grid-cols-2 gap-3 rounded-xl border border-slate-200 bg-white p-4 text-sm">
        <SummaryCell label={t("invoice.amountDue")} value={`₹${computed.amount_due.toFixed(2)}`} />
        <SummaryCell
          label={t("invoice.previousBalance")}
          value={`₹${computed.previous_balance.toFixed(2)}`}
        />
        <SummaryCell
          label={t("invoice.totalAdvanceGiven")}
          value={`₹${computed.total_advance_given.toFixed(2)}`}
        />
        <SummaryCell label={t("invoice.totalLitres")} value={computed.total_liter.toFixed(2)} />
      </div>

      {/* Plain-language summary */}
      <div className="mx-4 mt-3 rounded-xl bg-slate-50 border border-slate-200 p-3 text-sm text-slate-600 leading-relaxed">
        {summarySentence}
      </div>

      <div className="p-4 space-y-3 pb-32">
        {/* Collections */}
        <Section
          title={t("invoice.collections")}
          count={collections.length}
          legend={
            <span className="inline-flex items-center gap-1 text-xs text-slate-400">
              <Sun className="h-3 w-3" />M<Moon className="h-3 w-3 ml-2" />E
            </span>
          }
        >
          {collections.length === 0 ? (
            <EmptyCard>{t("invoice.noRecords")}</EmptyCard>
          ) : (
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="text-left px-2 py-1.5">{t("invoice.tableDt")}</th>
                  <th className="text-center px-1 py-1.5">{t("invoice.tableME")}</th>
                  <th className="text-left px-1 py-1.5">{t("invoice.tableMilk")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.tableLitre")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.tableFat")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.tableSnf")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.tableRate")}</th>
                  <th className="text-right px-2 py-1.5">{t("invoice.tableAmount")}</th>
                </tr>
              </thead>
              <tbody>
                {collections.map((c, i) => (
                  <tr key={c.id} className={i % 2 === 1 ? "bg-slate-50/50" : ""}>
                    <td className="px-2 py-1.5 whitespace-nowrap">{fmtDMY(c.collection_date)}</td>
                    <td className="px-1 py-1.5 text-center">
                      {c.shift === "morning" ? (
                        <Sun className="h-3 w-3 inline text-amber-500" />
                      ) : (
                        <Moon className="h-3 w-3 inline text-indigo-500" />
                      )}
                    </td>
                    <td className="px-1 py-1.5">{c.milk_type.slice(0, 3).toUpperCase()}</td>
                    <td className="px-1 py-1.5 text-right">
                      {Number(c.quantity_liters).toFixed(1)}
                    </td>
                    <td className="px-1 py-1.5 text-right">{Number(c.fat).toFixed(1)}</td>
                    <td className="px-1 py-1.5 text-right">
                      {c.snf != null ? Number(c.snf).toFixed(1) : "—"}
                    </td>
                    <td className="px-1 py-1.5 text-right">
                      {Number(c.rate_per_liter).toFixed(2)}
                    </td>
                    <td className="px-2 py-1.5 text-right font-medium">
                      {Number(c.total_amount).toFixed(2)}
                    </td>
                  </tr>
                ))}
                <tr className="border-t-2 border-slate-300 font-bold">
                  <td colSpan={3} className="px-2 py-1.5">
                    {t("invoice.tableTotal")}
                  </td>
                  <td className="px-1 py-1.5 text-right">{computed.total_liter.toFixed(1)}</td>
                  <td colSpan={3} />
                  <td className="px-2 py-1.5 text-right">
                    {computed.total_milk_amount.toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          )}
        </Section>

        {/* Cattle Feeds */}
        {feedSales.length > 0 && (
          <Section title={t("invoice.cattleFeeds")} count={feedSales.length}>
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="text-left px-2 py-1.5">{t("invoice.tableDt")}</th>
                  <th className="text-left px-1 py-1.5">{t("invoice.tableProduct")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.tableQty")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.tableRate")}</th>
                  <th className="text-right px-2 py-1.5">{t("invoice.tableAmount")}</th>
                </tr>
              </thead>
              <tbody>
                {feedSales.map((s) => (
                  <tr key={s.id}>
                    <td className="px-2 py-1.5 whitespace-nowrap">{fmtDMY(s.sale_date)}</td>
                    <td className="px-1 py-1.5">{productMap[s.feed_product_id] ?? "—"}</td>
                    <td className="px-1 py-1.5 text-right">{Number(s.quantity).toFixed(1)}</td>
                    <td className="px-1 py-1.5 text-right">{Number(s.rate).toFixed(2)}</td>
                    <td className="px-2 py-1.5 text-right font-medium">
                      {Number(s.amount).toFixed(2)}
                    </td>
                  </tr>
                ))}
                <tr className="border-t-2 border-slate-300 font-bold">
                  <td colSpan={4} className="px-2 py-1.5">
                    {t("invoice.tableTotal")}
                  </td>
                  <td className="px-2 py-1.5 text-right">
                    {computed.total_feed_amount.toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          </Section>
        )}

        {/* Deduction details */}
        {(dedRows.length > 0 || computed.total_deduction > 0) && (
          <Section title={t("invoice.deductionDetails")}>
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="text-left px-2 py-1.5">{t("invoice.tableType")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.deducted")}</th>
                  <th className="text-right px-1 py-1.5">{t("invoice.tableBalance")}</th>
                  <th className="text-right px-2 py-1.5">{t("invoice.deposit")}</th>
                </tr>
              </thead>
              <tbody>
                {dedRows.length > 0 ? (
                  dedRows.map((d) => (
                    <tr key={d.id}>
                      <td className="px-2 py-1.5">{deductionTypeLabel(t, d.deduction_type)}</td>
                      <td className="px-1 py-1.5 text-right">
                        {Number(d.deduction_amount).toFixed(2)}
                      </td>
                      <td
                        className={cn(
                          "px-1 py-1.5 text-right",
                          Number(d.balance_after) < 0 ? "text-rose-600" : "text-emerald-600",
                        )}
                      >
                        {Number(d.balance_after).toFixed(2)}
                      </td>
                      <td className="px-2 py-1.5 text-right">
                        {Number(d.deposit) > 0 ? Number(d.deposit).toFixed(2) : "—"}
                      </td>
                    </tr>
                  ))
                ) : (
                  <>
                    {computed.total_feed_amount > 0 && (
                      <tr>
                        <td className="px-2 py-1.5">{t("invoice.deductionFeed")}</td>
                        <td className="px-1 py-1.5 text-right">
                          {computed.total_feed_amount.toFixed(2)}
                        </td>
                        <td className="px-1 py-1.5 text-right">—</td>
                        <td className="px-2 py-1.5 text-right">—</td>
                      </tr>
                    )}
                    {computed.manual_deductions > 0 && (
                      <tr>
                        <td className="px-2 py-1.5">{t("invoice.deductionAdvanceRepayment")}</td>
                        <td className="px-1 py-1.5 text-right">
                          {computed.manual_deductions.toFixed(2)}
                        </td>
                        <td className="px-1 py-1.5 text-right">—</td>
                        <td className="px-2 py-1.5 text-right">—</td>
                      </tr>
                    )}
                  </>
                )}
                <tr className="border-t-2 border-slate-300 font-bold text-rose-600">
                  <td className="px-2 py-1.5">{t("invoice.tableTotal")}</td>
                  <td className="px-1 py-1.5 text-right">{computed.total_deduction.toFixed(2)}</td>
                  <td colSpan={2} />
                </tr>
              </tbody>
            </table>
          </Section>
        )}

        {/* Advance Given */}
        {advances.length > 0 && (
          <Section title={t("invoice.totalAdvanceGiven")} count={advances.length}>
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="text-left px-2 py-1.5">{t("invoice.date")}</th>
                  <th className="text-left px-1 py-1.5">{t("invoice.tableComments")}</th>
                  <th className="text-right px-2 py-1.5">{t("invoice.tableAmount")}</th>
                </tr>
              </thead>
              <tbody>
                {advances.map((a) => (
                  <tr key={a.id}>
                    <td className="px-2 py-1.5">{fmtDMY(a.advance_date)}</td>
                    <td className="px-1 py-1.5">{a.comments ?? "—"}</td>
                    <td className="px-2 py-1.5 text-right font-medium">
                      {Number(a.amount).toFixed(2)}
                    </td>
                  </tr>
                ))}
                <tr className="border-t-2 border-slate-300 font-bold">
                  <td colSpan={2} className="px-2 py-1.5">
                    {t("invoice.tableTotal")}
                  </td>
                  <td className="px-2 py-1.5 text-right">
                    {computed.total_advance_given.toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          </Section>
        )}

        {/* Final calculation */}
        <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <h2 className="px-4 py-3 text-sm font-semibold text-slate-700 border-b border-slate-100">
            {t("invoice.finalCalculation")}
          </h2>
          <dl className="divide-y divide-slate-100 text-sm">
            <CalcRow
              label={t("invoice.milkAmount")}
              value={`₹${computed.total_milk_amount.toFixed(2)}`}
            />
            <CalcRow
              label={t("invoice.totalDeduction")}
              value={`−₹${computed.total_deduction.toFixed(2)}`}
              tone="negative"
            />
            <CalcRow
              label={t("invoice.previousBalance")}
              value={`₹${computed.previous_balance.toFixed(2)}`}
            />
            <CalcRow
              label={t("invoice.totalAdvanceGiven")}
              value={`−₹${computed.total_advance_given.toFixed(2)}`}
              tone="negative"
            />
            <CalcRow
              label={t("invoice.newBalance")}
              value={`${netPayment < 0 ? "−" : ""}₹${Math.abs(netPayment).toFixed(2)}`}
              strong
            />
          </dl>
        </section>

        {Math.abs(computed.previous_balance) > 0.001 && (
          <div className="text-center text-[11px] text-slate-400 pt-1">
            {t("invoice.previousBalanceNote", { amount: computed.previous_balance.toFixed(2) })}
          </div>
        )}
      </div>

      {/* Bottom action bar */}
      <div className="fixed bottom-0 left-0 right-0 border-t border-slate-200 bg-white px-4 py-3 safe-bottom">
        {isPreview ? (
          <Button onClick={doGenerate} loading={busy} disabled={busy}>
            {t("invoice.generateInvoice")}
          </Button>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => toast.info(t("invoice.comingSoon"))}
              className="h-11 rounded-lg border border-slate-200 text-slate-700 text-sm font-semibold inline-flex items-center justify-center gap-1.5"
            >
              <Printer className="h-4 w-4" /> {t("invoice.savePdf")}
            </button>
            <button
              type="button"
              onClick={doWhatsApp}
              className="h-11 rounded-lg text-white text-sm font-semibold inline-flex items-center justify-center gap-1.5"
              style={{ backgroundColor: "#25D366" }}
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </button>
            <button
              type="button"
              onClick={doShare}
              className="h-11 rounded-lg border border-slate-200 text-slate-700 text-sm font-semibold inline-flex items-center justify-center gap-1.5"
            >
              <Share2 className="h-4 w-4" /> {t("invoice.share")}
            </button>
          </div>
        )}
      </div>

      <BottomSheet
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        title={t("invoice.actions.title")}
      >
        {canPay && (
          <SheetItem
            icon={<IndianRupee className="h-4 w-4" />}
            label={t("invoice.actions.payNow")}
            onClick={() => {
              setMenuOpen(false);
              navigate({ to: "/invoice" });
            }}
          />
        )}
        {invoice && status === "Unpaid" && (
          <SheetItem
            icon={<CheckCircle className="h-4 w-4" />}
            label={t("invoice.actions.markAsPaid")}
            onClick={() => {
              setMenuOpen(false);
              void doMarkPaid();
            }}
          />
        )}
        {invoice && status === "Paid" && (
          <SheetItem
            icon={<RotateCcw className="h-4 w-4" />}
            label={t("invoice.actions.markAsUnpaid")}
            onClick={() => {
              setMenuOpen(false);
              void doMarkUnpaid();
            }}
          />
        )}
        {invoice && (
          <SheetItem
            icon={<Share2 className="h-4 w-4" />}
            label={t("invoice.actions.shareReceipt")}
            onClick={() => {
              setMenuOpen(false);
              void doShare();
            }}
          />
        )}
        <SheetItem
          icon={<Printer className="h-4 w-4" />}
          label={t("invoice.actions.print")}
          onClick={() => {
            setMenuOpen(false);
            toast.info(t("invoice.comingSoon"));
          }}
        />
        {invoice && status === "Unpaid" && (
          <SheetItem
            icon={<Trash2 className="h-4 w-4" />}
            label={t("invoice.actions.deleteInvoice")}
            danger
            onClick={() => {
              setMenuOpen(false);
              void doDelete();
            }}
          />
        )}
      </BottomSheet>

      <ConfirmDialog
        open={!!confirmAsk}
        title={confirmAsk?.title}
        message={confirmAsk?.message ?? ""}
        confirmLabel={confirmAsk?.confirmLabel}
        destructive={confirmAsk?.destructive}
        onCancel={() => setConfirmAsk(null)}
        onConfirm={() => {
          const c = confirmAsk;
          setConfirmAsk(null);
          c?.run();
        }}
      />

      {!farmer && !loading && (
        <div className="fixed bottom-20 left-4 right-4 flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
          <AlertCircle className="h-4 w-4 mt-0.5" /> {t("invoice.farmerNotFound")}
        </div>
      )}
    </>
  );
}

function Section({
  title,
  legend,
  count,
  defaultOpen = true,
  children,
}: {
  title: string;
  legend?: React.ReactNode;
  count?: number;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between gap-2 px-4 py-3 text-left"
      >
        <span className="flex items-center gap-2">
          <h2 className="text-sm font-semibold text-slate-700">{title}</h2>
          {typeof count === "number" && (
            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-semibold text-slate-500">
              {count}
            </span>
          )}
        </span>
        <span className="flex items-center gap-2">
          {legend}
          <span className="text-[11px] font-medium text-teal-700">
            {open ? t("invoice.hideDetails") : t("invoice.showDetails")}
          </span>
          <ChevronDown
            className={cn("h-4 w-4 text-slate-400 transition-transform", open && "rotate-180")}
          />
        </span>
      </button>
      {open && <div className="border-t border-slate-100">{children}</div>}
    </section>
  );
}

function EmptyCard({ children }: { children: React.ReactNode }) {
  return <div className="p-6 text-center text-sm text-slate-500">{children}</div>;
}
function SummaryCell({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] uppercase text-slate-400 font-semibold">{label}</div>
      <div className="font-bold text-slate-800">{value}</div>
    </div>
  );
}

function CalcRow({
  label,
  value,
  tone,
  strong,
}: {
  label: string;
  value: string;
  tone?: "negative";
  strong?: boolean;
}) {
  return (
    <div
      className={cn("flex items-center justify-between px-4 py-2.5", strong && "bg-emerald-50/60")}
    >
      <dt className={cn("text-slate-600", strong && "font-semibold text-slate-800")}>{label}</dt>
      <dd
        className={cn(
          "tabular-nums font-medium",
          tone === "negative" ? "text-rose-600" : "text-slate-800",
          strong && "text-lg font-extrabold text-emerald-700",
        )}
      >
        {value}
      </dd>
    </div>
  );
}
