import { ChevronLeft } from "lucide-react";
import { useRouter } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useTranslation } from "react-i18next";
import { PendingSyncBadge } from "@/components/PendingSyncBadge";


export function AppHeader({
  title,
  right,
  onBack,
  showBack = true,
}: {
  title: string;
  right?: ReactNode;
  onBack?: () => void;
  showBack?: boolean;
}) {
  const router = useRouter();
  const { t } = useTranslation();
  return (
    <header className="sticky top-0 z-20 bg-white border-b border-slate-200 safe-top">
      <div className="flex items-center h-14 px-3 gap-2">
        {showBack ? (
          <button
            type="button"
            onClick={onBack ?? (() => router.history.back())}
            className="p-2 -ml-2 rounded-lg text-slate-700 hover:bg-slate-100"
            aria-label={t("core.back")}
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
        ) : (
          <div className="w-6" />
        )}
        <h1 className="flex-1 font-semibold text-slate-800 text-base truncate">{title}</h1>
        <PendingSyncBadge />
        {right}

      </div>
    </header>
  );
}
