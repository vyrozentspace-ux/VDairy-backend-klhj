import { AlertCircle } from "lucide-react";

export function Alert({ message }: { message: string }) {
  if (!message) return null;
  return (
    <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 p-3 animate-fade-in">
      <AlertCircle className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
      <p className="text-sm font-medium text-rose-700">{message}</p>
    </div>
  );
}
