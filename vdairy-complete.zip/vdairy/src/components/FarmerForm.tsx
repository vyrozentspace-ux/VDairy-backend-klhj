import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { useNavigate } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { Field, TextInput } from "@/components/Field";
import { Button } from "@/components/Button";
import { MilkTypePills } from "@/components/MilkTypePills";
import { supabase } from "@/integrations/supabase/client";
import { newId } from "@/lib/offline/queue";
import { saveOffline } from "@/lib/offline/sync";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { Alert } from "@/components/Alert";
import { Link } from "@tanstack/react-router";
import {
  countActiveFarmers,
  fetchSubscriptionState,
  memberLimitMessage,
} from "@/lib/subscriptions";
import {
  fetchFarmer,
  logActivity,
  nextFarmerCode,
  type Farmer,
  type MilkType,
} from "@/lib/farmers";

export function FarmerForm({ farmerId }: { farmerId?: string }) {
  const { t } = useTranslation();
  const editing = !!farmerId;
  const navigate = useNavigate();
  const { userId } = useAuth();
  const { selected } = useCenter();

  const [loading, setLoading] = useState(editing);
  const [code, setCode] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [nameEnglish, setNameEnglish] = useState("");
  const [mobile, setMobile] = useState("");
  const [paymentMobile, setPaymentMobile] = useState("");
  const [email, setEmail] = useState("");
  const [milkType, setMilkType] = useState<MilkType | null>("cow");
  const [village, setVillage] = useState("");
  const [address, setAddress] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  /** Plan member-limit block (only applies when adding a new farmer). */
  const [limitMessage, setLimitMessage] = useState<string | null>(null);

  useEffect(() => {
    if (editing || !selected) return;
    let cancelled = false;
    void (async () => {
      try {
        const [sub, count] = await Promise.all([
          fetchSubscriptionState(selected.id),
          countActiveFarmers(selected.id),
        ]);
        if (cancelled) return;
        setLimitMessage(
          memberLimitMessage({
            activeFarmers: count,
            maxFarmers: sub?.maxFarmers ?? null,
            planCode: sub?.plan ?? null,
          }),
        );
      } catch {
        /* never block on a lookup failure */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id, editing]);

  useEffect(() => {
    (async () => {
      if (!selected) return;
      if (editing && farmerId) {
        const f = await fetchFarmer(farmerId);
        if (f) fill(f);
      } else {
        setCode(await nextFarmerCode(selected.id));
      }
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.id, farmerId]);

  const fill = (f: Farmer) => {
    setCode(f.code);
    setFirstName(f.first_name);
    setLastName(f.last_name ?? "");
    setNameEnglish(f.name_english ?? "");
    setMobile(f.mobile ?? "");
    setPaymentMobile(f.payment_mobile ?? "");
    setEmail(f.email ?? "");
    setMilkType(f.milk_type as MilkType);
    setVillage(f.village ?? "");
    setAddress(f.address ?? "");
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!firstName.trim()) e.firstName = t("farmers.error_first_name_required");
    if (!milkType) e.milkType = t("farmers.error_select_milk_type");
    if (mobile && !/^\d{10}$/.test(mobile)) e.mobile = t("farmers.error_mobile_digits");
    if (paymentMobile && !/^\d{10}$/.test(paymentMobile))
      e.paymentMobile = t("farmers.error_mobile_digits");
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      e.email = t("farmers.error_email_invalid");
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = async () => {
    if (!validate() || !selected || !userId || !milkType) return;
    if (!editing && limitMessage) {
      toast.error(limitMessage);
      return;
    }
    setSaving(true);
    const payload = {
      center_id: selected.id,
      code: code.trim() || "",
      first_name: firstName.trim(),
      last_name: lastName.trim() || null,
      name_english: nameEnglish.trim() || null,
      mobile: mobile.trim() || null,
      payment_mobile: paymentMobile.trim() || null,
      email: email.trim() || null,
      milk_type: milkType,
      village: village.trim() || null,
      address: address.trim() || null,
      created_by: userId,
    };

    try {
      if (editing && farmerId) {
        const { synced } = await saveOffline({
          kind: "farmer",
          table: "farmers",
          action: "update",
          rowId: farmerId,
          payload: { ...payload, updated_at: new Date().toISOString() },
        });
        toast.success(synced ? t("farmers.farmer_updated") : t("sync.saved_locally"));
        if (synced) void logActivity(selected.id, userId, "farmer_updated", { farmer_id: farmerId });
        navigate({ to: "/farmer/$id", params: { id: farmerId } });
      } else {
        const now = new Date().toISOString();
        const id = newId();
        const { synced } = await saveOffline({
          kind: "farmer",
          table: "farmers",
          action: "insert",
          rowId: id,
          payload: { id, is_active: true, ...payload, created_at: now, updated_at: now },
        });
        toast.success(synced ? t("farmers.farmer_added") : t("sync.saved_locally"));
        if (synced) {
          void logActivity(selected.id, userId, "farmer_created", { farmer_id: id });
          navigate({ to: "/farmer/$id", params: { id } });
        } else {
          // The detail page reads from the server, so send queued farmers to the list.
          navigate({ to: "/farmers" });
        }
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AppHeader title={editing ? t("farmers.title_edit") : t("farmers.title_add")} />
      {loading ? (
        <div className="flex-1 flex items-center justify-center py-16 text-slate-500 text-sm">
          {t("farmers.loading")}
        </div>
      ) : (
        <div className="p-4 space-y-4">
          {limitMessage && (
            <div className="space-y-2" data-testid="member-limit-block">
              <Alert message={limitMessage} />
              <Link
                to="/subscription"
                className="inline-flex h-9 items-center rounded-lg bg-teal-700 px-3 text-xs font-semibold text-white hover:bg-teal-800"
              >
                {t("sub.upgrade_cta")}
              </Link>
            </div>
          )}
          <Field label={t("farmers.code")} hint={t("farmers.code_hint")}>
            <TextInput
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder={t("farmers.code_placeholder")}
            />
          </Field>
          <Field label={t("farmers.first_name")} error={errors.firstName}>
            <TextInput
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder={t("farmers.first_name_placeholder")}
              invalid={!!errors.firstName}
            />
          </Field>
          <Field label={t("farmers.last_name")}>
            <TextInput
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              placeholder={t("farmers.last_name_placeholder")}
            />
          </Field>
          <Field label={t("farmers.full_name_english")}>
            <TextInput
              value={nameEnglish}
              onChange={(e) => setNameEnglish(e.target.value)}
              placeholder={t("farmers.full_name_english_placeholder")}
            />
          </Field>
          <Field label={t("farmers.mobile_number")} error={errors.mobile}>
            <TextInput
              value={mobile}
              onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder={t("farmers.mobile_placeholder")}
              prefix="+91"
              inputMode="numeric"
              invalid={!!errors.mobile}
            />
          </Field>
          <Field
            label={t("farmers.payment_mobile")}
            hint={t("farmers.payment_mobile_hint")}
            error={errors.paymentMobile}
          >
            <TextInput
              value={paymentMobile}
              onChange={(e) => setPaymentMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
              prefix="+91"
              inputMode="numeric"
              invalid={!!errors.paymentMobile}
            />
          </Field>
          <Field label={t("farmers.email")} error={errors.email}>
            <TextInput
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t("farmers.email_placeholder")}
              type="email"
              invalid={!!errors.email}
            />
          </Field>
          <Field label={t("farmers.milk_type")} error={errors.milkType}>
            <MilkTypePills value={milkType} onChange={setMilkType} />
          </Field>
          <Field label={t("farmers.village")}>
            <TextInput
              value={village}
              onChange={(e) => setVillage(e.target.value)}
              placeholder={t("farmers.village_placeholder")}
            />
          </Field>
          <Field label={t("farmers.address")}>
            <textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows={3}
              placeholder={t("farmers.address_placeholder")}
              className="w-full rounded-lg border border-slate-200 p-3 text-sm outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
            />
          </Field>
          <Button
            loading={saving}
            disabled={!firstName.trim() || !milkType || (!editing && !!limitMessage)}
            onClick={save}
          >
            {editing ? t("farmers.update_farmer") : t("farmers.save_farmer")}
          </Button>
        </div>
      )}
    </>
  );
}
