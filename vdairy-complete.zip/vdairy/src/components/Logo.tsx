import { cn } from "@/lib/utils";
import { APP_NAME, LOGO_LETTER } from "@/lib/app-config";

type Size = "sm" | "md" | "lg";
type Variant = "default" | "white";

const SIZES: Record<Size, { box: string; text: string; letter: string; gap: string }> = {
  sm: { box: "h-8 w-8", text: "text-lg", letter: "text-lg", gap: "gap-2" },
  md: { box: "h-10 w-10", text: "text-xl", letter: "text-xl", gap: "gap-2.5" },
  lg: { box: "h-14 w-14", text: "text-3xl", letter: "text-3xl", gap: "gap-3" },
};

export function Logo({
  size = "md",
  variant = "default",
  className,
}: {
  size?: Size;
  variant?: Variant;
  className?: string;
}) {
  const s = SIZES[size];
  const isWhite = variant === "white";
  return (
    <div className={cn("inline-flex items-center", s.gap, className)}>
      <div
        className={cn(
          "flex items-center justify-center rounded-lg font-bold shadow-sm",
          s.box,
          s.letter,
          isWhite ? "bg-white text-teal-700" : "bg-teal-700 text-white",
        )}
      >
        {LOGO_LETTER}
      </div>
      <span
        className={cn(
          "font-bold tracking-tight",
          s.text,
          isWhite ? "text-white" : "text-slate-800",
        )}
      >
        {APP_NAME}
      </span>
    </div>
  );
}
