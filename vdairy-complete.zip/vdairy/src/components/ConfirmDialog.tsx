import { useTranslation } from "react-i18next";

export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel,
  cancelLabel,
  destructive,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title?: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const { t } = useTranslation();
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/40 px-4"
      data-testid="confirm-dialog"
    >
      <div className="w-full max-w-sm rounded-xl bg-white p-4 shadow-2xl animate-fade-in">
        <div className="text-base font-semibold text-slate-800">
          {title ?? t("core.confirmTitle")}
        </div>
        <p className="mt-2 text-sm text-slate-600">{message}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            type="button"
            data-testid="confirm-dialog-cancel"
            onClick={onCancel}
            className="h-11 rounded-lg bg-slate-100 text-sm font-semibold text-slate-700"
          >
            {cancelLabel ?? t("core.cancel")}
          </button>
          <button
            type="button"
            data-testid="confirm-dialog-confirm"
            onClick={onConfirm}
            className={`h-11 rounded-lg text-sm font-semibold text-white ${destructive ? "bg-rose-600" : "bg-teal-600"}`}
          >
            {confirmLabel ?? t("core.confirm")}
          </button>
        </div>
      </div>
    </div>
  );
}
