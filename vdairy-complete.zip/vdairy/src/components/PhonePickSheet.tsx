import { useTranslation } from "react-i18next";
import { BottomSheet } from "./BottomSheet";

export function PhonePickSheet({
  open,
  onClose,
  name,
  phones,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  name: string;
  phones: string[];
  onPick: (phone: string) => void;
}) {
  const { t } = useTranslation();
  return (
    <BottomSheet open={open} onClose={onClose} title={t("core.pick_number_for", { name })}>
      <div className="px-2 pb-2">
        {phones.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => onPick(p)}
            className="w-full text-left px-4 py-3 rounded-lg text-sm text-slate-800 hover:bg-slate-50 border-b border-slate-100 last:border-0"
          >
            +91 {p.slice(0, 5)} {p.slice(5)}
          </button>
        ))}
      </div>
    </BottomSheet>
  );
}
