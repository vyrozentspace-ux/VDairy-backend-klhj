import { useEffect, useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import {
  createExpense,
  findOrCreateCustomCategory,
  listCategories,
  todayISO,
  updateExpense,
  type DairyExpense,
  type ExpenseCategory,
  type PayMode,
} from "@/lib/expenses";
import { cn } from "@/lib/utils";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const OTHER = "__other__";

export function ExpenseForm({
  mode,
  existing,
  onDone,
  onBack,
}: {
  mode: "create" | "edit";
  existing?: DairyExpense;
  onDone: () => void;
  onBack: () => void;
}) {
  const { t } = useTranslation();
  const { selected } = useCenter();
  const { userId } = useAuth();
  const [cats, setCats] = useState<ExpenseCategory[]>([]);
  const [catId, setCatId] = useState<string>(
    existing?.custom_category_label ? OTHER : (existing?.category_id ?? ""),
  );
  const [customLabel, setCustomLabel] = useState<string>(existing?.custom_category_label ?? "");
  const [amount, setAmount] = useState<string>(existing ? String(existing.amount) : "");
  const [date, setDate] = useState<string>(existing?.expense_date ?? todayISO());
  const [note, setNote] = useState<string>(existing?.note ?? "");
  const [mmode, setMmode] = useState<PayMode | null>(existing?.payment_mode ?? null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!selected) return;
    void listCategories(selected.id)
      .then(setCats)
      .catch(() => setCats([]));
  }, [selected?.id]);

  const isOther = catId === OTHER;

  const canSave = useMemo(() => {
    const a = parseFloat(amount);
    if (!isFinite(a) || a <= 0) return false;
    if (!catId) return false;
    if (isOther && !customLabel.trim()) return false;
    return true;
  }, [amount, catId, isOther, customLabel]);

  async function submit() {
    if (!selected || !canSave) return;
    setSaving(true);
    try {
      let categoryId = catId;
      let customLbl: string | null = null;
      if (isOther) {
        const cat = await findOrCreateCustomCategory(selected.id, customLabel.trim());
        categoryId = cat.id;
        customLbl = customLabel.trim();
      }
      const payload = {
        center_id: selected.id,
        category_id: categoryId,
        custom_category_label: customLbl,
        amount: parseFloat(amount),
        expense_date: date,
        note: note.trim() || null,
        payment_mode: mmode,
      };
      if (mode === "create") {
        const row = await createExpense({ ...payload, created_by: userId ?? undefined });
        await db
          .from("activity_logs")
          .insert({
            center_id: selected.id,
            user_id: userId,
            action: "expense_added",
            details: { id: row.id, amount: row.amount },
          })
          .then(
            () => {},
            () => {},
          );
        toast.success(t("expense.added_success"));
      } else if (existing) {
        await updateExpense(existing.id, payload);
        await db
          .from("activity_logs")
          .insert({
            center_id: selected.id,
            user_id: userId,
            action: "expense_updated",
            details: { id: existing.id },
          })
          .then(
            () => {},
            () => {},
          );
        toast.success(t("expense.updated_success"));
      }
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("expense.save_failed"));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-full bg-slate-50 flex flex-col">
      <AppHeader
        title={mode === "create" ? t("expense.add_title") : t("expense.edit_title")}
        onBack={onBack}
      />
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
        <Field label={t("expense.category")}>
          <div className="relative">
            <select
              value={catId}
              onChange={(e) => setCatId(e.target.value)}
              className="w-full h-12 rounded-lg border border-slate-200 bg-white px-3 pr-10 text-sm text-slate-800 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100 appearance-none"
            >
              <option value="">{t("expense.select_category")}</option>
              {cats.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
              <option value={OTHER}>{t("expense.other")}</option>
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </Field>

        {isOther && (
          <Field label={t("expense.custom_category_label")}>
            <TextInput
              value={customLabel}
              onChange={(e) => setCustomLabel(e.target.value)}
              placeholder={t("expense.custom_category_placeholder")}
            />
          </Field>
        )}

        <Field label={t("expense.amount")}>
          <TextInput
            prefix="₹"
            inputMode="decimal"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={t("expense.amount_placeholder")}
          />
        </Field>

        <Field label={t("expense.date")}>
          <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>

        <Field label={t("expense.note_optional")}>
          <TextInput
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={t("expense.note_placeholder")}
          />
        </Field>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">
            {t("expense.payment_mode_optional")}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(["cash", "upi", "other"] as PayMode[]).map((m) => {
              const active = mmode === m;
              return (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMmode(active ? null : m)}
                  className={cn(
                    "h-11 rounded-lg border text-sm font-medium capitalize",
                    active
                      ? "border-teal-500 bg-teal-50 text-teal-700"
                      : "border-slate-200 bg-white text-slate-500",
                  )}
                >
                  {t(`expense.mode_${m}`)}
                </button>
              );
            })}
          </div>
        </div>

        <Button onClick={submit} loading={saving} disabled={!canSave}>
          {mode === "create" ? t("expense.save_expense") : t("expense.update_expense")}
        </Button>
      </div>
    </div>
  );
}
