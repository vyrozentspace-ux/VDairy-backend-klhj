import { useEffect, useState } from "react";
import { Bell, X } from "lucide-react";
import { useTranslation } from "react-i18next";
import { onInAppNotification, type InAppNotification } from "@/lib/notifications";

/**
 * Web fallback delivery channel for smart notifications.
 * On a compiled APK the same notification arrives as an OS local notification;
 * in the browser preview it appears here so the logic stays verifiable.
 */
export function InAppNotificationBanner() {
  const { t } = useTranslation();
  const [items, setItems] = useState<InAppNotification[]>([]);

  useEffect(() => {
    const off = onInAppNotification((n) => {
      setItems((prev) => (prev.some((p) => p.id === n.id) ? prev : [...prev, n]));
      window.setTimeout(() => setItems((prev) => prev.filter((p) => p.id !== n.id)), 12_000);
    });
    return () => {
      off();
    };
  }, []);

  if (items.length === 0) return null;

  return (
    <div
      className="fixed inset-x-0 top-2 z-50 mx-auto flex max-w-md flex-col gap-2 px-3"
      role="status"
      aria-live="polite"
    >
      {items.map((n) => (
        <div
          key={n.id}
          data-testid="in-app-notification"
          className="flex items-start gap-3 rounded-xl border border-teal-200 bg-white p-3 shadow-lg"
        >
          <span className="mt-0.5 text-teal-700">
            <Bell className="h-4 w-4" />
          </span>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-slate-800">{n.title}</p>
            <p className="text-xs text-slate-600">{n.body}</p>
          </div>
          <button
            type="button"
            aria-label={t("core.dismiss")}
            className="text-slate-400 hover:text-slate-600"
            onClick={() => setItems((prev) => prev.filter((p) => p.id !== n.id))}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
