import { useEffect, useRef, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function BottomSheet({
  open,
  onClose,
  title,
  children,
  className,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const scrollTopRef = useRef(0);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    scrollTopRef.current = window.scrollY;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      window.scrollTo({ top: scrollTopRef.current, behavior: "instant" });
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-end" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-slate-900/40 animate-fade-in" onClick={onClose} />
      <div
        className={cn(
          "relative w-full max-w-md max-h-[calc(100dvh-1rem)] overflow-y-auto overscroll-contain mx-auto bg-white rounded-t-2xl shadow-2xl animate-slide-up safe-bottom",
          className,
        )}
      >
        <div className="flex justify-center pt-2">
          <div className="h-1 w-10 rounded-full bg-slate-200" />
        </div>
        {title && (
          <div className="px-5 pt-3 pb-2 text-base font-semibold text-slate-800">{title}</div>
        )}
        <div className="px-2 pb-3">{children}</div>
      </div>
    </div>
  );
}

export function SheetItem({
  icon,
  label,
  onClick,
  danger,
  meta,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  danger?: boolean;
  meta?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left text-sm font-medium transition",
        danger ? "text-rose-600 hover:bg-rose-50" : "text-slate-700 hover:bg-slate-50",
      )}
    >
      <span
        className={cn(
          "h-9 w-9 rounded-full flex items-center justify-center",
          danger ? "bg-rose-50 text-rose-600" : "bg-slate-100 text-slate-600",
        )}
      >
        {icon}
      </span>
      <span className="flex-1">{label}</span>
      {meta && <span className="text-xs text-slate-400">{meta}</span>}
    </button>
  );
}
