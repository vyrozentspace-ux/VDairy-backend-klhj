import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { AlertCircle, ChevronDown, MessageCircle, X } from "lucide-react";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Spinner } from "@/components/Spinner";
import { BottomSheet } from "@/components/BottomSheet";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import {
  fetchFarmers,
  farmerFullName,
  logActivity,
  MILK_TYPE_LABEL,
  type Farmer,
} from "@/lib/farmers";
import {
  createFeedSale,
  createProduct,
  getFeedSale,
  listProducts,
  updateFeedSale,
  type FeedProduct,
  type FeedUnit,
} from "@/lib/food";

function todayISO(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function maskMobile(m: string | null | undefined, t: (k: string) => string): string {
  if (!m) return t("food.no_mobile");
  const d = m.replace(/\D/g, "");
  return d.length < 6 ? m : `${d.slice(0, 6)}XXXX`;
}

export function FoodForm({
  mode,
  saleId,
  prefillFarmerId,
  onBack,
}: {
  mode: "create" | "edit";
  saleId?: string;
  prefillFarmerId?: string;
  onBack: () => void;
}) {
  const { t } = useTranslation();
  const { userId } = useAuth();
  const { selected } = useCenter();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedShareMessage, setSavedShareMessage] = useState<string | null>(null);
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [products, setProducts] = useState<FeedProduct[]>([]);

  const [farmerQuery, setFarmerQuery] = useState("");
  const [farmer, setFarmer] = useState<Farmer | null>(null);
  const [date, setDate] = useState(todayISO());
  const [product, setProduct] = useState<FeedProduct | null>(null);
  const [rate, setRate] = useState("");
  const [quantity, setQuantity] = useState("");
  const [receiptNo, setReceiptNo] = useState("");
  const [cashPayment, setCashPayment] = useState<"no" | "yes">("no");
  const [useSameFeed, setUseSameFeed] = useState(false);

  const [productSheet, setProductSheet] = useState(false);
  const [newProductOpen, setNewProductOpen] = useState(false);
  const [newProdName, setNewProdName] = useState("");
  const [newProdUnit, setNewProdUnit] = useState<FeedUnit>("Bag");
  const [newProdRate, setNewProdRate] = useState("");

  const farmerInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const [fs, ps] = await Promise.all([fetchFarmers(selected.id), listProducts(selected.id)]);
        if (cancelled) return;
        setFarmers(fs);
        setProducts(ps);

        if (mode === "edit" && saleId) {
          const s = await getFeedSale(saleId);
          if (s && !cancelled) {
            const f = fs.find((x) => x.id === s.farmer_id) ?? null;
            setFarmer(f);
            setFarmerQuery(f ? farmerFullName(f) : "");
            setDate(s.sale_date);
            setProduct(ps.find((p) => p.id === s.feed_product_id) ?? null);
            setRate(String(s.rate));
            setQuantity(String(s.quantity));
            setReceiptNo(s.receipt_no ?? "");
            setCashPayment(s.cash_payment ? "yes" : "no");
          }
        } else if (prefillFarmerId) {
          const f = fs.find((x) => x.id === prefillFarmerId);
          if (f) {
            setFarmer(f);
            setFarmerQuery(farmerFullName(f));
          }
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id, mode, saleId, prefillFarmerId]);

  const matches = useMemo(() => {
    const q = farmerQuery.trim().toLowerCase();
    if (!q || farmer) return [];
    return farmers
      .filter((f) => {
        if (!f.is_active) return false;
        const code = String(f.code).toLowerCase();
        const name = farmerFullName(f).toLowerCase();
        return code.startsWith(q) || name.includes(q);
      })
      .slice(0, 8);
  }, [farmerQuery, farmers, farmer]);

  useEffect(() => {
    if (matches.length === 1 && !farmer) setFarmer(matches[0]);
  }, [matches, farmer]);

  const rateN = Number(rate),
    qtyN = Number(quantity);
  const amount = Number.isFinite(rateN) && Number.isFinite(qtyN) ? rateN * qtyN : 0;
  const canSave = !!selected && !!farmer && !!product && rateN > 0 && qtyN > 0;

  const pickProduct = (p: FeedProduct) => {
    setProduct(p);
    if (p.default_rate != null && !rate) setRate(String(p.default_rate));
    setProductSheet(false);
  };

  const addNewProduct = async () => {
    if (!selected || !newProdName.trim()) return;
    try {
      const p = await createProduct({
        center_id: selected.id,
        product_name: newProdName.trim(),
        unit: newProdUnit,
        default_rate: newProdRate ? Number(newProdRate) : null,
      });
      await logActivity(selected.id, userId ?? "", "feed_product_added", {
        id: p.id,
        product_name: p.product_name,
      });
      setProducts((cur) =>
        [...cur, p].sort((a, b) => a.product_name.localeCompare(b.product_name)),
      );
      pickProduct(p);
      setNewProductOpen(false);
      setNewProdName("");
      setNewProdRate("");
      setNewProdUnit("Bag");
      toast.success(t("food.product_added"));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("food.failed_to_add_product"));
    }
  };

  const resetForm = (keepProduct: boolean) => {
    setFarmer(null);
    setFarmerQuery("");
    setDate(todayISO());
    setQuantity("");
    setReceiptNo("");
    setCashPayment("no");
    if (!keepProduct) {
      setProduct(null);
      setRate("");
    }
    setError(null);
    setSavedShareMessage(null);
    setTimeout(() => farmerInputRef.current?.focus(), 50);
  };

  const doSave = async () => {
    setError(null);
    if (!canSave || !selected || !farmer || !product) return;
    setSaving(true);
    try {
      const payload = {
        center_id: selected.id,
        farmer_id: farmer.id,
        feed_product_id: product.id,
        sale_date: date,
        quantity: qtyN,
        rate: rateN,
        amount: Number(amount.toFixed(2)),
        receipt_no: receiptNo.trim() || null,
        cash_payment: cashPayment === "yes",
        entered_by: userId ?? null,
      };
      if (mode === "edit" && saleId) {
        await updateFeedSale(saleId, payload);
        await logActivity(selected.id, userId ?? "", "food_sale_updated", { id: saleId });
        toast.success(t("food.food_sale_updated"));
        navigate({ to: "/food" });
        return;
      }
      const s = await createFeedSale(payload);
      await logActivity(selected.id, userId ?? "", "food_sale_added", {
        id: s.id,
        farmer_id: farmer.id,
        amount: payload.amount,
      });

      const msg = [
        `${selected.name}`,
        `${t("food.farmer_label", { name: farmerFullName(farmer), code: farmer.code })}`,
        `${t("food.date_label", { date })}`,
        `${t("food.feed_label", { name: product.product_name })}`,
        `${qtyN} ${product.unit} x ₹${rateN} = ₹${payload.amount.toFixed(2)}`,
        cashPayment === "yes" ? t("food.paid_in_cash") : t("food.to_deduct_from_invoice"),
      ].join("\n");
      setSavedShareMessage(msg);
      toast.success(t("food.food_sale_saved"));

      if (farmer.mobile) {
        try {
          window.location.href = `sms:${farmer.mobile}?body=${encodeURIComponent(msg)}`;
        } catch {
          /* ignore */
        }
      }
      resetForm(useSameFeed);
    } catch (err) {
      setError(err instanceof Error ? err.message : t("food.failed_to_save"));
    } finally {
      setSaving(false);
    }
  };

  const shareWA = async () => {
    if (!savedShareMessage) return;
    const url = `https://wa.me/${farmer?.mobile ?? ""}?text=${encodeURIComponent(savedShareMessage)}`;
    try {
      if (navigator.share) await navigator.share({ text: savedShareMessage });
      else window.open(url, "_blank");
    } catch {
      /* cancel */
    }
  };

  return (
    <>
      <AppHeader
        title={mode === "edit" ? t("food.edit_food") : t("food.add_food")}
        onBack={onBack}
      />
      {loading ? (
        <div className="py-16 flex justify-center">
          <Spinner />
        </div>
      ) : (
        <div className="p-4 space-y-4 pb-28">
          <div className="text-xs text-slate-500 -mt-2">{selected?.name}</div>

          {savedShareMessage && (
            <button
              type="button"
              onClick={shareWA}
              className="w-full h-12 rounded-lg font-semibold text-sm inline-flex items-center justify-center gap-2 text-white"
              style={{ backgroundColor: "#25D366" }}
            >
              <MessageCircle className="h-4 w-4" /> {t("food.share_on_whatsapp")}
            </button>
          )}

          <Field label={t("food.farmer_code_or_name")}>
            <TextInput
              ref={farmerInputRef}
              value={farmerQuery}
              disabled={mode === "edit"}
              onChange={(e) => {
                setFarmerQuery(e.target.value);
                if (
                  farmer &&
                  !e.target.value
                    .toLowerCase()
                    .includes(farmerFullName(farmer).toLowerCase().slice(0, 3))
                )
                  setFarmer(null);
              }}
              placeholder={t("food.type_code_or_name")}
            />
            {!farmer && farmerQuery.trim() && matches.length === 0 && (
              <div className="mt-1.5 text-xs text-rose-600">{t("food.no_farmer_found")}</div>
            )}
            {!farmer && matches.length > 1 && (
              <div className="mt-2 rounded-lg border border-slate-200 bg-white shadow-sm max-h-60 overflow-y-auto">
                {matches.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => {
                      setFarmer(f);
                      setFarmerQuery(farmerFullName(f));
                    }}
                    className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 border-b border-slate-100 last:border-0"
                  >
                    <span className="text-sm text-slate-700">
                      {f.code} · {farmerFullName(f)}
                    </span>
                    <span className="text-xs text-slate-400">
                      {MILK_TYPE_LABEL[f.milk_type as keyof typeof MILK_TYPE_LABEL]}
                    </span>
                  </button>
                ))}
              </div>
            )}
            {farmer && (
              <div className="mt-2 rounded-lg bg-teal-50 border border-teal-100 px-3 py-2 flex items-center justify-between">
                <div className="min-w-0">
                  <div className="font-semibold text-teal-800 text-sm truncate">
                    {farmerFullName(farmer)} ({farmer.code})
                  </div>
                  <div className="text-xs text-teal-700">
                    {maskMobile(farmer.mobile, t)} ·{" "}
                    {MILK_TYPE_LABEL[farmer.milk_type as keyof typeof MILK_TYPE_LABEL]}
                  </div>
                </div>
                {mode !== "edit" && (
                  <button
                    type="button"
                    onClick={() => {
                      setFarmer(null);
                      setFarmerQuery("");
                    }}
                    className="h-8 w-8 rounded-full hover:bg-teal-100 flex items-center justify-center text-teal-700"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
            )}
          </Field>

          <Field label={t("food.payment_date")}>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full h-12 rounded-lg border border-slate-200 px-3 text-sm text-slate-800"
            />
          </Field>

          <Field label={t("food.product")}>
            <button
              type="button"
              onClick={() => setProductSheet(true)}
              className="w-full h-12 rounded-lg border border-slate-200 bg-white px-3 flex items-center justify-between text-sm"
            >
              <span className={product ? "text-slate-800" : "text-slate-400"}>
                {product
                  ? `${product.product_name} (${product.unit})`
                  : t("food.tap_to_select_product")}
              </span>
              <ChevronDown className="h-4 w-4 text-slate-400" />
            </button>
            <button
              type="button"
              onClick={() => setNewProductOpen(true)}
              className="mt-2 text-xs font-semibold text-teal-700 hover:underline"
            >
              {t("food.add_new_product_link")}
            </button>
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label={`${t("food.rate")} ${product ? `(₹ / ${product.unit})` : "(₹)"}`}>
              <TextInput
                type="number"
                inputMode="decimal"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                placeholder="0"
              />
            </Field>
            <Field label={`${t("food.quantity")} ${product ? `(${product.unit})` : ""}`}>
              <TextInput
                type="number"
                inputMode="decimal"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="0"
              />
            </Field>
          </div>

          <div className="rounded-lg bg-slate-100 px-3 py-3 flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              {t("food.amount")}
            </span>
            <span className="font-bold text-slate-800 text-lg">₹{amount.toFixed(2)}</span>
          </div>

          <Field label={t("food.receipt_no_optional")}>
            <TextInput
              value={receiptNo}
              onChange={(e) => setReceiptNo(e.target.value)}
              placeholder={t("food.receipt_no_placeholder")}
            />
          </Field>

          <Field label={t("food.cash_payment")}>
            <select
              value={cashPayment}
              onChange={(e) => setCashPayment(e.target.value as "no" | "yes")}
              className="w-full h-12 rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-800"
            >
              <option value="no">{t("food.cash_deduct")}</option>
              <option value="yes">{t("food.cash_paid")}</option>
            </select>
          </Field>

          {mode === "create" && (
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={useSameFeed}
                onChange={(e) => setUseSameFeed(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-teal-600"
              />
              {t("food.use_same_feed")}
            </label>
          )}

          {error && (
            <div className="rounded-lg bg-rose-50 border border-rose-100 px-3 py-2 flex items-start gap-2 text-sm text-rose-700">
              <AlertCircle className="h-4 w-4 mt-0.5" /> {error}
            </div>
          )}
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 p-3 grid grid-cols-2 gap-3 safe-bottom">
        <Button variant="secondary" onClick={() => resetForm(false)}>
          {t("food.reset")}
        </Button>
        <Button onClick={doSave} loading={saving} disabled={!canSave}>
          {mode === "edit" ? t("food.update") : t("food.save")}
        </Button>
      </div>

      <BottomSheet
        open={productSheet}
        onClose={() => setProductSheet(false)}
        title={t("food.select_product")}
      >
        <div className="max-h-[60vh] overflow-y-auto">
          <button
            type="button"
            onClick={() => {
              setProductSheet(false);
              setNewProductOpen(true);
            }}
            className="w-full text-left px-4 py-3 text-sm font-semibold text-teal-700 hover:bg-teal-50 border-b border-slate-100"
          >
            {t("food.add_new_product")}
          </button>
          {products.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-slate-500">
              {t("food.no_products_yet")}
            </div>
          ) : (
            products.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => pickProduct(p)}
                className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-50 border-b border-slate-50 last:border-0"
              >
                <span className="text-sm text-slate-800">{p.product_name}</span>
                <span className="text-xs text-slate-400">{p.unit}</span>
              </button>
            ))
          )}
        </div>
      </BottomSheet>

      <BottomSheet
        open={newProductOpen}
        onClose={() => setNewProductOpen(false)}
        title={t("food.new_product")}
      >
        <div className="p-3 space-y-3">
          <Field label={t("food.product_name")}>
            <TextInput
              value={newProdName}
              onChange={(e) => setNewProdName(e.target.value)}
              placeholder={t("food.product_name_placeholder")}
              autoFocus
            />
          </Field>
          <Field label={t("food.unit")}>
            <div className="grid grid-cols-3 gap-2">
              {(["Bag", "Kg", "Unit"] as FeedUnit[]).map((u) => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setNewProdUnit(u)}
                  className={`h-11 rounded-lg border text-sm font-semibold ${newProdUnit === u ? "bg-teal-700 text-white border-teal-700" : "bg-white text-slate-700 border-slate-200"}`}
                >
                  {u}
                </button>
              ))}
            </div>
          </Field>
          <Field label={t("food.default_rate_optional")}>
            <TextInput
              type="number"
              inputMode="decimal"
              value={newProdRate}
              onChange={(e) => setNewProdRate(e.target.value)}
              placeholder="0"
            />
          </Field>
          <Button onClick={addNewProduct} disabled={!newProdName.trim()}>
            {t("food.add_product")}
          </Button>
        </div>
      </BottomSheet>
    </>
  );
}
