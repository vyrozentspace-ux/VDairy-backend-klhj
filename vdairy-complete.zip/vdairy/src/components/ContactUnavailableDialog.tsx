import { AlertCircle } from "lucide-react";
import { useTranslation } from "react-i18next";
import { APP_NAME } from "@/lib/app-config";
import { Button } from "./Button";

export function ContactUnavailableDialog({
  open,
  onClose,
  reason,
}: {
  open: boolean;
  onClose: () => void;
  reason?: "unavailable" | "denied";
}) {
  const { t } = useTranslation();
  if (!open) return null;
  const denied = reason === "denied";
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-end sm:items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-2xl p-5 space-y-4 animate-slide-up">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <AlertCircle className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <h3 className="font-semibold text-slate-800">
              {denied ? t("core.contacts_permission_denied") : t("core.contacts_not_available")}
            </h3>
            <p className="mt-1 text-xs text-slate-500 leading-relaxed">
              {denied ? (
                <>
                  {t("core.contacts_denied_body_prefix", { appName: APP_NAME })}{" "}
                  <span className="font-medium text-slate-700">
                    {t("core.contacts_denied_body_path", { appName: APP_NAME })}
                  </span>{" "}
                  {t("core.contacts_denied_body_suffix")}
                </>
              ) : (
                <>{t("core.contacts_unavailable_body")}</>
              )}
            </p>
          </div>
        </div>
        <Button onClick={onClose}>{t("core.got_it")}</Button>
      </div>
    </div>
  );
}
