import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function MobileFrame({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className="min-h-screen w-full bg-slate-50 flex justify-center">
      <div className={cn("w-full max-w-md min-h-screen bg-white flex flex-col", className)}>
        {children}
      </div>
    </div>
  );
}
