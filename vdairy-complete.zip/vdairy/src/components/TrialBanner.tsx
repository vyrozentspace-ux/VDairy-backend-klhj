import { Link } from "@tanstack/react-router";
import { Crown } from "lucide-react";
import { useTranslation } from "react-i18next";
import type { SubscriptionState } from "@/lib/subscriptions";

/**
 * Dashboard subscription banner.
 * - during the 3-day trial: countdown
 * - after the trial ends: "Upgrade your plan"
 * - after auto-deactivation (10 days from registration): deactivated notice
 * Renders nothing for centres on a paid plan.
 */
export function TrialBanner({ subscription }: { subscription: SubscriptionState | null }) {
  const { t } = useTranslation();
  if (!subscription) return null;
  const { status, trialDaysLeft, daysUntilDeactivation } = subscription;
  if (status === "active") return null;

  const deactivated = status === "deactivated";
  const expired = status === "expired";

  const tone = deactivated
    ? "border-rose-200 bg-rose-50 text-rose-900"
    : expired
      ? "border-amber-300 bg-amber-50 text-amber-900"
      : "border-teal-200 bg-teal-50 text-teal-900";

  const title = deactivated
    ? t("sub.deactivated_title")
    : expired
      ? t("sub.upgrade_title")
      : t("sub.trial_banner_title", { n: trialDaysLeft ?? 0 });

  const body = deactivated
    ? t("sub.deactivated_body")
    : expired
      ? `${t("sub.upgrade_body")} ${t("sub.status_expired", { n: daysUntilDeactivation ?? 0 })}`
      : t("sub.trial_banner_body");

  return (
    <div
      data-testid="trial-banner"
      className={`flex items-start gap-3 rounded-lg border px-3 py-2.5 text-sm ${tone}`}
    >
      <span className="h-8 w-8 rounded-full bg-white/70 flex items-center justify-center shrink-0">
        <Crown className="h-4 w-4" />
      </span>
      <div className="flex-1 min-w-0">
        <div className="font-semibold">{title}</div>
        <div className="text-xs opacity-90">{body}</div>
        <Link
          to="/subscription"
          className="mt-2 inline-flex h-9 items-center rounded-lg bg-teal-700 px-3 text-xs font-semibold text-white hover:bg-teal-800"
        >
          {t("sub.upgrade_cta")}
        </Link>
      </div>
    </div>
  );
}
