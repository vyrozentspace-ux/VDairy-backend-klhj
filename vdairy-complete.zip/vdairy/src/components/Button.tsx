import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Spinner } from "./Spinner";

type Variant = "primary" | "secondary" | "danger" | "ghost";

const VARIANT_CLASSES: Record<Variant, string> = {
  primary:
    "bg-teal-700 text-white hover:bg-teal-800 active:bg-teal-900 disabled:bg-slate-200 disabled:text-slate-400",
  secondary:
    "bg-white text-slate-800 border border-slate-200 hover:bg-slate-50 disabled:text-slate-400",
  danger: "bg-rose-600 text-white hover:bg-rose-700 disabled:bg-slate-200 disabled:text-slate-400",
  ghost: "bg-transparent text-slate-600 hover:bg-slate-100 disabled:text-slate-400",
};

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  loading?: boolean;
  children?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = "primary", loading, disabled, className, children, ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cn(
        "inline-flex items-center justify-center w-full h-12 rounded-lg font-semibold text-sm gap-2",
        "transition-[background-color,color,transform,opacity] duration-150 ease-out",
        "active:scale-[0.985] disabled:cursor-not-allowed disabled:active:scale-100",
        VARIANT_CLASSES[variant],
        className,
      )}
      {...rest}
    >
      {loading && <Spinner size={16} color="white" />}
      {children}
    </button>
  );
});
