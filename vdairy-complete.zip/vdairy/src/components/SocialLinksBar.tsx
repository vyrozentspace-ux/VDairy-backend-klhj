import { useTranslation } from "react-i18next";
import { Youtube, Instagram, Facebook, MessageCircle, Twitter, Send, Link2 } from "lucide-react";
import { useSocialLinks } from "@/lib/app-settings";

const ICONS: Record<string, typeof Youtube> = {
  youtube: Youtube,
  instagram: Instagram,
  facebook: Facebook,
  whatsapp: MessageCircle,
  twitter: Twitter,
  x: Twitter,
  telegram: Send,
};

const TINTS: Record<string, string> = {
  youtube: "bg-red-50 text-red-600 border-red-100",
  instagram: "bg-pink-50 text-pink-600 border-pink-100",
  facebook: "bg-blue-50 text-blue-600 border-blue-100",
  whatsapp: "bg-emerald-50 text-emerald-600 border-emerald-100",
  twitter: "bg-slate-100 text-slate-700 border-slate-200",
  x: "bg-slate-100 text-slate-700 border-slate-200",
  telegram: "bg-sky-50 text-sky-600 border-sky-100",
};

/**
 * "Follow us" row on the Dashboard.
 *
 * Entirely driven by the remotely-configurable `social_links` table: if no
 * active link with a non-empty URL is configured, nothing renders at all.
 */
export function SocialLinksBar() {
  const { t } = useTranslation();
  const links = useSocialLinks();

  if (links.length === 0) return null;

  return (
    <section className="pb-2" data-testid="social-links">
      <p className="mb-2 text-center text-xs font-semibold uppercase tracking-wide text-slate-400">
        {t("dashboard.follow_us")}
      </p>
      <div className="flex items-center justify-center gap-3">
        {links.map((link) => {
          const Icon = ICONS[link.platform] ?? Link2;
          const tint = TINTS[link.platform] ?? "bg-slate-100 text-slate-700 border-slate-200";
          return (
            <a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noreferrer noopener"
              aria-label={link.label || link.platform}
              title={link.label || link.platform}
              className={`h-11 w-11 rounded-full border flex items-center justify-center transition hover:opacity-80 ${tint}`}
            >
              <Icon className="h-5 w-5" />
            </a>
          );
        })}
      </div>
    </section>
  );
}
