import { cn } from "@/lib/utils";
import { farmerInitials, type Farmer } from "@/lib/farmers";

export function FarmerAvatar({
  farmer,
  size = 40,
  showCode = true,
  className,
}: {
  farmer: Pick<Farmer, "first_name" | "last_name" | "code">;
  size?: number;
  showCode?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("relative shrink-0", className)} style={{ width: size, height: size }}>
      <div
        className="h-full w-full rounded-full bg-teal-100 text-teal-700 font-bold flex items-center justify-center"
        style={{ fontSize: Math.max(12, size * 0.4) }}
      >
        {farmerInitials(farmer)}
      </div>
      {showCode && (
        <span className="absolute -top-1 -left-1 min-w-[18px] h-[18px] px-1 rounded-full bg-teal-700 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white">
          {farmer.code}
        </span>
      )}
    </div>
  );
}
