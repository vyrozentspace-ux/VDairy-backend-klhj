import { cn } from "@/lib/utils";
import { MILK_TYPE_LABEL, type MilkType } from "@/lib/farmers";

const OPTIONS: MilkType[] = ["cow", "buffalo", "mixed"];

export function MilkTypePills({
  value,
  onChange,
  size = "md",
}: {
  value: MilkType | null;
  onChange: (v: MilkType) => void;
  size?: "sm" | "md";
}) {
  return (
    <div className="flex gap-2">
      {OPTIONS.map((t) => {
        const active = value === t;
        return (
          <button
            type="button"
            key={t}
            onClick={() => onChange(t)}
            className={cn(
              "flex-1 rounded-lg font-medium text-sm transition border",
              size === "sm" ? "h-9 px-3" : "h-11 px-3",
              active
                ? "bg-teal-700 text-white border-teal-700"
                : "bg-white text-slate-700 border-slate-200 hover:border-slate-300",
            )}
          >
            {MILK_TYPE_LABEL[t]}
          </button>
        );
      })}
    </div>
  );
}
