import { forwardRef, useId, type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Field({
  label,
  hint,
  error,
  children,
  className,
}: {
  label?: string;
  hint?: string;
  error?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("w-full", className)}>
      {label && <label className="block text-sm font-medium text-slate-700 mb-1.5">{label}</label>}
      {children}
      {error ? (
        <p className="mt-1.5 text-xs text-rose-600 animate-fade-in">{error}</p>
      ) : hint ? (
        <p className="mt-1.5 text-xs text-slate-400">{hint}</p>
      ) : null}
    </div>
  );
}

type TextInputProps = Omit<InputHTMLAttributes<HTMLInputElement>, "prefix"> & {
  prefix?: ReactNode;
  suffix?: ReactNode;
  invalid?: boolean;
};

export const TextInput = forwardRef<HTMLInputElement, TextInputProps>(function TextInput(
  { prefix, suffix, invalid, className, ...rest },
  ref,
) {
  const id = useId();
  return (
    <div
      className={cn(
        "flex items-stretch h-12 rounded-lg border bg-white overflow-hidden transition",
        invalid
          ? "border-rose-500 focus-within:ring-2 focus-within:ring-rose-200"
          : "border-slate-200 focus-within:border-teal-500 focus-within:ring-2 focus-within:ring-teal-100",
      )}
    >
      {prefix && (
        <span className="flex items-center px-3 bg-slate-50 border-r border-slate-200 text-slate-600 text-sm font-medium">
          {prefix}
        </span>
      )}
      <input
        ref={ref}
        id={rest.id ?? id}
        className={cn(
          "flex-1 min-w-0 px-3 bg-transparent outline-none text-sm text-slate-800 placeholder:text-slate-400",
          className,
        )}
        {...rest}
      />
      {suffix && <span className="flex items-center pr-2">{suffix}</span>}
    </div>
  );
});
