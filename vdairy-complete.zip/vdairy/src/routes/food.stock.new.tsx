import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AlertCircle, ChevronDown } from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { BottomSheet } from "@/components/BottomSheet";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import {
  createStockPurchase,
  listDealers,
  listProducts,
  type FeedDealer,
  type FeedProduct,
} from "@/lib/food";
import { logActivity } from "@/lib/farmers";

export const Route = createFileRoute("/food/stock/new")({
  component: NewStock,
});

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function NewStock() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { userId } = useAuth();

  const [loading, setLoading] = useState(true);
  const [dealers, setDealers] = useState<FeedDealer[]>([]);
  const [products, setProducts] = useState<FeedProduct[]>([]);

  const [dealer, setDealer] = useState<FeedDealer | null>(null);
  const [product, setProduct] = useState<FeedProduct | null>(null);
  const [date, setDate] = useState(todayISO());
  const [quantity, setQuantity] = useState("");
  const [rate, setRate] = useState("");
  const [receipt, setReceipt] = useState("");
  const [dealerSheet, setDealerSheet] = useState(false);
  const [productSheet, setProductSheet] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [ds, ps] = await Promise.all([listDealers(selected.id), listProducts(selected.id)]);
        if (cancelled) return;
        setDealers(ds);
        setProducts(ps);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  const qtyN = Number(quantity),
    rateN = Number(rate);
  const amount = Number.isFinite(qtyN) && Number.isFinite(rateN) ? qtyN * rateN : 0;
  const canSave = !!selected && !!product && qtyN > 0 && rateN > 0;

  const submit = async () => {
    setError(null);
    if (!canSave || !selected || !product) return;
    setSaving(true);
    try {
      await createStockPurchase({
        center_id: selected.id,
        dealer_id: dealer?.id ?? null,
        feed_product_id: product.id,
        purchase_date: date,
        quantity: qtyN,
        rate: rateN,
        amount: Number(amount.toFixed(2)),
        receipt_no: receipt.trim() || null,
        entered_by: userId ?? null,
      });
      await logActivity(selected.id, userId ?? "", "stock_purchase_added", {
        product_id: product.id,
        amount,
      });
      toast.success(t("food.stock_purchase_saved"));
      navigate({ to: "/food/stock" });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("food.failed_to_save"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AppHeader
        title={t("food.add_stock_purchase")}
        onBack={() => navigate({ to: "/food/stock" })}
      />
      {loading ? (
        <div className="py-16 flex justify-center">
          <Spinner />
        </div>
      ) : (
        <div className="p-4 space-y-4 pb-28">
          <div className="text-xs text-slate-500 -mt-2">{selected?.name}</div>

          <Field label={t("food.dealer_optional")}>
            <button
              type="button"
              onClick={() => setDealerSheet(true)}
              className="w-full h-12 rounded-lg border border-slate-200 bg-white px-3 flex items-center justify-between text-sm"
            >
              <span className={dealer ? "text-slate-800" : "text-slate-400"}>
                {dealer?.dealer_name ?? t("food.tap_to_select_dealer")}
              </span>
              <ChevronDown className="h-4 w-4 text-slate-400" />
            </button>
          </Field>

          <Field label={t("food.product")}>
            <button
              type="button"
              onClick={() => setProductSheet(true)}
              className="w-full h-12 rounded-lg border border-slate-200 bg-white px-3 flex items-center justify-between text-sm"
            >
              <span className={product ? "text-slate-800" : "text-slate-400"}>
                {product
                  ? `${product.product_name} (${product.unit})`
                  : t("food.tap_to_select_product")}
              </span>
              <ChevronDown className="h-4 w-4 text-slate-400" />
            </button>
          </Field>

          <Field label={t("food.payment_date")}>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full h-12 rounded-lg border border-slate-200 px-3 text-sm"
            />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label={t("food.quantity")}>
              <TextInput
                type="number"
                inputMode="decimal"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="0"
              />
            </Field>
            <Field label={t("food.rate")}>
              <TextInput
                type="number"
                inputMode="decimal"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                placeholder="0"
              />
            </Field>
          </div>

          <div className="rounded-lg bg-slate-100 px-3 py-3 flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              {t("food.amount")}
            </span>
            <span className="font-bold text-slate-800 text-lg">₹{amount.toFixed(2)}</span>
          </div>

          <Field label={t("food.receipt_no_optional")}>
            <TextInput value={receipt} onChange={(e) => setReceipt(e.target.value)} />
          </Field>

          {error && (
            <div className="rounded-lg bg-rose-50 border border-rose-100 px-3 py-2 flex items-start gap-2 text-sm text-rose-700">
              <AlertCircle className="h-4 w-4 mt-0.5" /> {error}
            </div>
          )}
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 p-3 grid grid-cols-2 gap-3 safe-bottom">
        <Button variant="secondary" onClick={() => navigate({ to: "/food/stock" })}>
          {t("food.cancel")}
        </Button>
        <Button onClick={submit} loading={saving} disabled={!canSave}>
          {t("food.save")}
        </Button>
      </div>

      <BottomSheet
        open={dealerSheet}
        onClose={() => setDealerSheet(false)}
        title={t("food.select_dealer")}
      >
        <div className="max-h-[60vh] overflow-y-auto">
          <button
            type="button"
            onClick={() => {
              setDealer(null);
              setDealerSheet(false);
            }}
            className="w-full text-left px-4 py-3 text-sm font-medium text-slate-500 hover:bg-slate-50 border-b border-slate-100"
          >
            {t("food.no_dealer")}
          </button>
          {dealers.map((d) => (
            <button
              key={d.id}
              type="button"
              onClick={() => {
                setDealer(d);
                setDealerSheet(false);
              }}
              className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-50 border-b border-slate-50 last:border-0"
            >
              <span className="text-sm text-slate-800">{d.dealer_name}</span>
              {d.mobile && <span className="text-xs text-slate-400">{d.mobile}</span>}
            </button>
          ))}
        </div>
      </BottomSheet>

      <BottomSheet
        open={productSheet}
        onClose={() => setProductSheet(false)}
        title={t("food.select_product")}
      >
        <div className="max-h-[60vh] overflow-y-auto">
          {products.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-slate-500">
              {t("food.no_products_yet")}
            </div>
          ) : (
            products.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  setProduct(p);
                  setProductSheet(false);
                }}
                className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-50 border-b border-slate-50 last:border-0"
              >
                <span className="text-sm text-slate-800">{p.product_name}</span>
                <span className="text-xs text-slate-400">{p.unit}</span>
              </button>
            ))
          )}
        </div>
      </BottomSheet>
    </>
  );
}
