import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ExpenseForm } from "@/components/ExpenseForm";

export const Route = createFileRoute("/expense/new")({
  component: NewExp,
});

function NewExp() {
  const navigate = useNavigate();
  return (
    <ExpenseForm
      mode="create"
      onBack={() => navigate({ to: "/expense" })}
      onDone={() => navigate({ to: "/expense", replace: true })}
    />
  );
}
