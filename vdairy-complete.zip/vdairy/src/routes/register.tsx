import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Eye, EyeOff } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Alert } from "@/components/Alert";
import { Dropdown } from "@/components/Dropdown";
import { LANGUAGES, setAppLanguage } from "@/lib/i18n";
import { SECURITY_QUESTIONS, securityQuestionLabel } from "@/lib/security-questions";
import { registerOwner } from "@/lib/auth.functions";
import { useAuth } from "@/contexts/AuthContext";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/register")({
  ssr: false,
  component: RegisterScreen,
});

function RegisterScreen() {
  const { t, i18n } = useTranslation();
  const register = useServerFn(registerOwner);
  const { loginWithPin } = useAuth();
  const navigate = useNavigate();

  const language = i18n.resolvedLanguage ?? i18n.language ?? "en";
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [q1, setQ1] = useState<string | null>(null);
  const [a1, setA1] = useState("");
  const [q2, setQ2] = useState<string | null>(null);
  const [a2, setA2] = useState("");
  const [referral, setReferral] = useState("");
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const pinsMatch = pin.length === 4 && confirmPin.length === 4 && pin === confirmPin;
  const canSubmit =
    fullName.trim().length >= 2 &&
    phone.length === 10 &&
    pin.length === 4 &&
    pinsMatch &&
    q1 &&
    q2 &&
    q1 !== q2 &&
    a1.trim() &&
    a2.trim() &&
    acceptedTerms;

  const q1Options = useMemo(
    () =>
      SECURITY_QUESTIONS.map((q) => ({
        value: q,
        label: securityQuestionLabel(q, t),
        disabled: q === q2,
      })),
    [q2, t, i18n.language],
  );
  const q2Options = useMemo(
    () =>
      SECURITY_QUESTIONS.map((q) => ({
        value: q,
        label: securityQuestionLabel(q, t),
        disabled: q === q1,
      })),
    [q1, t, i18n.language],
  );

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setLoading(true);
    setError("");
    try {
      await register({
        data: {
          full_name: fullName.trim(),
          phone,
          pin,
          language_preference: language,
          security_question_1: q1!,
          security_answer_1: a1,
          security_question_2: q2!,
          security_answer_2: a2,
          referred_by_code: referral.trim() ? referral.trim().toUpperCase() : null,
        },
      });
      await loginWithPin(phone, pin);
      navigate({ to: "/onboarding/create-center", replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("auth.could_not_create_account"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white safe-top safe-bottom">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200">
        <Logo size="sm" />
        <Link to="/login" className="text-sm text-teal-700 font-medium">
          {t("auth.back_to_login")}
        </Link>
      </div>

      <div className="px-6 py-6 max-w-md mx-auto">
        <h1 className="text-2xl font-bold text-slate-800">{t("auth.create_owner_account")}</h1>
        <p className="text-sm text-slate-500 mt-1 mb-6">
          {t("auth.create_owner_account_subtitle")}
        </p>

        <form onSubmit={submit} className="flex flex-col gap-4">
          {error && <Alert message={error} />}

          <Field label={t("auth.language")}>
            <Dropdown
              value={language}
              onChange={setAppLanguage}
              options={LANGUAGES.map((l) => ({ value: l.code, label: l.label }))}
            />
          </Field>

          <Field label={t("auth.full_name")}>
            <TextInput
              placeholder={t("auth.full_name_placeholder")}
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              maxLength={100}
            />
          </Field>

          <Field label={t("auth.phone_number")}>
            <TextInput
              prefix="+91"
              inputMode="numeric"
              maxLength={10}
              placeholder={t("auth.phone_placeholder")}
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
            />
          </Field>

          <Field label={t("auth.set_pin")} hint={t("auth.set_pin_hint")}>
            <TextInput
              type={showPin ? "text" : "password"}
              inputMode="numeric"
              maxLength={4}
              placeholder={t("auth.pin_placeholder")}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
              suffix={
                <button
                  type="button"
                  onClick={() => setShowPin((v) => !v)}
                  className="p-2 text-slate-400 hover:text-slate-600"
                  aria-label={showPin ? t("auth.hide_pin") : t("auth.show_pin")}
                >
                  {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              }
            />
          </Field>

          <Field
            label={t("auth.confirm_password")}
            error={confirmPin.length === 4 && !pinsMatch ? t("auth.pins_do_not_match") : undefined}
          >
            <TextInput
              type={showPin ? "text" : "password"}
              inputMode="numeric"
              maxLength={4}
              placeholder={t("auth.re_enter_pin")}
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
              invalid={confirmPin.length === 4 && !pinsMatch}
            />
          </Field>

          <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
            <h2 className="text-sm font-semibold text-slate-800">{t("auth.security_questions")}</h2>
            <p className="text-xs text-slate-500 mt-0.5 mb-3">
              {t("auth.security_questions_hint")}
            </p>
            <div className="flex flex-col gap-3">
              <Field>
                <Dropdown
                  value={q1}
                  onChange={setQ1}
                  options={q1Options}
                  placeholder={t("auth.select_question_1")}
                />
              </Field>
              <TextInput
                placeholder={t("auth.your_answer")}
                value={a1}
                onChange={(e) => setA1(e.target.value)}
              />
              <Field>
                <Dropdown
                  value={q2}
                  onChange={setQ2}
                  options={q2Options}
                  placeholder={t("auth.select_question_2")}
                />
              </Field>
              <TextInput
                placeholder={t("auth.your_answer")}
                value={a2}
                onChange={(e) => setA2(e.target.value)}
              />
            </div>
          </div>

          <Field label={t("auth.referral_code_optional")} hint={t("auth.referral_code_hint")}>
            <TextInput
              maxLength={8}
              value={referral}
              onChange={(e) => setReferral(e.target.value.toUpperCase().slice(0, 8))}
              placeholder={t("auth.referral_code_placeholder")}
            />
          </Field>

          <label className="flex items-start gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 cursor-pointer">
            <input
              type="checkbox"
              checked={acceptedTerms}
              onChange={(e) => setAcceptedTerms(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-teal-700 shrink-0"
              aria-label={t("auth.accept_terms_aria")}
            />
            <span className="text-xs leading-relaxed text-slate-600">
              {t("auth.accept_terms_prefix")}{" "}
              <Link
                to="/terms"
                className="font-semibold text-teal-700 underline"
                onClick={(e) => e.stopPropagation()}
              >
                {t("settings.terms_title")}
              </Link>
              {t("auth.accept_terms_suffix")}
            </span>
          </label>

          <Button type="submit" disabled={!canSubmit} loading={loading}>
            {t("auth.create_account")}
          </Button>
        </form>
      </div>
    </div>
  );
}
