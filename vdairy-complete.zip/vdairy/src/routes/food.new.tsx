import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { z } from "zod";
import { FoodForm } from "@/components/FoodForm";

const searchSchema = z.object({ farmer_id: z.string().optional() });

export const Route = createFileRoute("/food/new")({
  validateSearch: searchSchema,
  component: NewFood,
});

function NewFood() {
  const search = useSearch({ from: "/food/new" });
  const navigate = useNavigate();
  return (
    <FoodForm
      mode="create"
      prefillFarmerId={search.farmer_id}
      onBack={() => navigate({ to: "/food" })}
    />
  );
}
