import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Contact,
  MoreVertical,
  Phone,
  Plus,
  Search,
  ShoppingCart,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";

import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import {
  createCustomer,
  customerStats,
  deleteCustomer,
  formatINR,
  listCustomers,
  logActivity,
  updateCustomer,
  type CustomerStats,
  type MilkSaleCustomer,
} from "@/lib/milk-sales";

export const Route = createFileRoute("/milk-sale/customers")({
  component: CustomersScreen,
});

function CustomersScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { profile, userId } = useAuth();
  const isOwner = profile?.role === "owner";

  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState<MilkSaleCustomer[]>([]);
  const [stats, setStats] = useState<Record<string, CustomerStats>>({});
  const [search, setSearch] = useState("");

  const [addOpen, setAddOpen] = useState(false);
  const [editing, setEditing] = useState<MilkSaleCustomer | null>(null);
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [addr, setAddr] = useState("");
  const [busy, setBusy] = useState(false);

  const [menuFor, setMenuFor] = useState<MilkSaleCustomer | null>(null);
  const [confirmDelId, setConfirmDelId] = useState<string | null>(null);

  async function reload() {
    if (!selected) return;
    setLoading(true);
    try {
      const [cs, st] = await Promise.all([listCustomers(selected.id), customerStats(selected.id)]);
      setRows(cs);
      setStats(st);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    void reload(); /* eslint-disable-next-line */
  }, [selected?.id]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((c) => c.name.toLowerCase().includes(q) || (c.mobile ?? "").includes(q));
  }, [rows, search]);

  function openAdd() {
    setEditing(null);
    setName("");
    setMobile("");
    setAddr("");
    setAddOpen(true);
  }
  function openEdit(c: MilkSaleCustomer) {
    setEditing(c);
    setName(c.name);
    setMobile(c.mobile ?? "");
    setAddr(c.address ?? "");
    setAddOpen(true);
    setMenuFor(null);
  }

  async function saveModal() {
    if (!selected || !name.trim()) return;
    setBusy(true);
    try {
      if (editing) {
        await updateCustomer(editing.id, {
          name: name.trim(),
          mobile: mobile.trim() || null,
          address: addr.trim() || null,
        });
        toast.success(t("sales.customerUpdated"));
      } else {
        const c = await createCustomer({
          center_id: selected.id,
          name: name.trim(),
          mobile: mobile.trim() || null,
          address: addr.trim() || null,
        });
        void logActivity(selected.id, userId, "milk_sale_customer_added", { name: c.name });
        toast.success(t("sales.customerAdded"));
      }
      setAddOpen(false);
      void reload();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("sales.failed"));
    } finally {
      setBusy(false);
    }
  }

  async function doDelete(id: string) {
    try {
      await deleteCustomer(id);
      toast.success(t("sales.customerRemoved"));
      setConfirmDelId(null);
      setMenuFor(null);
      void reload();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("sales.failed"));
    }
  }

  return (
    <div className="min-h-full bg-slate-50 flex flex-col">
      <AppHeader
        title={t("sales.titleCustomers")}
        onBack={() => navigate({ to: "/milk-sale" })}
        right={
          <button
            type="button"
            onClick={openAdd}
            className="w-10 h-10 rounded-full bg-teal-700 text-white flex items-center justify-center"
            aria-label={t("sales.addCustomer")}
          >
            <Plus className="w-4 h-4" />
          </button>
        }
      />
      <div className="bg-white border-b border-slate-200 px-4 py-2">
        <div className="text-xs text-slate-500 mb-2">
          {t(rows.length === 1 ? "sales.customersCount_one" : "sales.customersCount_other", {
            count: rows.length,
          })}
        </div>
        <TextInput
          prefix={<Search className="w-4 h-4" />}
          placeholder={t("sales.search")}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-8 flex justify-center">
            <Spinner size={22} color="#0F766E" />
          </div>
        ) : rows.length === 0 ? (
          <div className="p-8 flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-3">
              <Users className="w-6 h-6 text-slate-400" />
            </div>
            <div className="font-semibold text-slate-700">{t("sales.noCustomersAdded")}</div>
            <div className="text-xs text-slate-500 mt-1 max-w-[240px]">
              {t("sales.noCustomersDescription")}
            </div>
            <div className="mt-4 w-full max-w-[220px]">
              <Button onClick={openAdd}>{t("sales.addCustomer")}</Button>
            </div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-500">
            {t("sales.noCustomersMatch")}
          </div>
        ) : (
          <ul className="bg-white divide-y">
            {filtered.map((c) => {
              const s = stats[c.id];
              return (
                <li key={c.id}>
                  <button
                    type="button"
                    onClick={() => setMenuFor(c)}
                    className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-slate-50"
                  >
                    <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-semibold">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-slate-800 truncate">{c.name}</div>
                      <div className="text-xs text-slate-500 truncate">
                        {c.mobile ? `+91 ${c.mobile}` : t("sales.noMobile")}
                        {s && ` · ${s.total_liters.toFixed(1)}L · ${formatINR(s.total_amount)}`}
                      </div>
                    </div>
                    {c.mobile && (
                      <a
                        href={`tel:+91${c.mobile}`}
                        onClick={(e) => e.stopPropagation()}
                        className="w-8 h-8 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center"
                        aria-label={t("sales.callAria")}
                      >
                        <Phone className="w-4 h-4" />
                      </a>
                    )}
                    <MoreVertical className="w-4 h-4 text-slate-400" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <BottomSheet open={!!menuFor} onClose={() => setMenuFor(null)} title={menuFor?.name}>
        <SheetItem
          icon={<Contact className="w-4 h-4" />}
          label={t("sales.syncFromContacts")}
          onClick={() => {
            setMenuFor(null);
            toast.info(t("sales.contactSyncComingSoon"));
          }}
        />
        <SheetItem
          icon={<ShoppingCart className="w-4 h-4" />}
          label={t("sales.editCustomer")}
          onClick={() => menuFor && openEdit(menuFor)}
        />
        {isOwner && menuFor && (
          <SheetItem
            icon={<Trash2 className="w-4 h-4" />}
            label={t("sales.removeCustomer")}
            onClick={() => setConfirmDelId(menuFor.id)}
            danger
          />
        )}
      </BottomSheet>

      {confirmDelId && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white rounded-lg p-4 space-y-3">
            <div className="text-sm font-semibold text-slate-800">
              {t("sales.removeCustomerConfirmTitle")}
            </div>
            <div className="text-xs text-slate-500">
              {t("sales.removeCustomerConfirmDescription")}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="secondary" onClick={() => setConfirmDelId(null)}>
                {t("sales.cancel")}
              </Button>
              <Button variant="danger" onClick={() => doDelete(confirmDelId)}>
                {t("sales.remove")}
              </Button>
            </div>
          </div>
        </div>
      )}

      {addOpen && (
        <div className="fixed inset-0 z-40 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-800">
                {editing ? t("sales.editCustomer") : t("sales.addCustomer")}
              </h3>
              <button
                type="button"
                onClick={() => setAddOpen(false)}
                className="p-1 rounded-full hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <Field label={t("sales.name")}>
              <TextInput
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t("sales.name")}
              />
            </Field>
            <Field label={t("sales.mobile")}>
              <TextInput
                prefix="+91"
                inputMode="numeric"
                maxLength={10}
                value={mobile}
                onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
              />
            </Field>
            <Field label={t("sales.address")}>
              <TextInput value={addr} onChange={(e) => setAddr(e.target.value)} />
            </Field>
            <Button onClick={saveModal} loading={busy} disabled={!name.trim()}>
              {editing ? t("sales.saveChanges") : t("sales.addCustomer")}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
