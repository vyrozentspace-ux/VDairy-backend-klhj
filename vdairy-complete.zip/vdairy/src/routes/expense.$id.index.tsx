import { formatDayMonthYear } from "@/lib/date-locale";
import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Trash2, TrendingDown } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import {
  categoryLabel,
  deleteExpense,
  formatINR,
  getExpense,
  listCategories,
  type DairyExpense,
  type ExpenseCategory,
} from "@/lib/expenses";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

export const Route = createFileRoute("/expense/$id/")({
  component: ExpDetail,
});

function ExpDetail() {
  const { t } = useTranslation();
  const { id } = useParams({ from: "/expense/$id/" });
  const navigate = useNavigate();
  const { profile, userId } = useAuth();
  const { selected } = useCenter();
  const isOwner = profile?.role === "owner";

  const [row, setRow] = useState<DairyExpense | null>(null);
  const [cat, setCat] = useState<ExpenseCategory | null>(null);
  const [loading, setLoading] = useState(true);
  const [confirmDel, setConfirmDel] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    (async () => {
      const r = await getExpense(id);
      setRow(r);
      if (r && selected) {
        const cs = await listCategories(selected.id);
        setCat(cs.find((c) => c.id === r.category_id) ?? null);
      }
      setLoading(false);
    })();
  }, [id, selected?.id]);

  async function doDelete() {
    if (!row) return;
    setDeleting(true);
    try {
      await deleteExpense(row.id);
      if (selected) {
        await db
          .from("activity_logs")
          .insert({
            center_id: selected.id,
            user_id: userId,
            action: "expense_deleted",
            details: { id: row.id },
          })
          .then(
            () => {},
            () => {},
          );
      }
      toast.success(t("expense.deleted_success"));
      navigate({ to: "/expense", replace: true });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("expense.delete_failed"));
    } finally {
      setDeleting(false);
    }
  }

  if (loading)
    return (
      <div className="p-8 flex justify-center">
        <Spinner size={22} color="#0F766E" />
      </div>
    );
  if (!row) return <div className="p-8 text-center text-slate-500">{t("expense.not_found")}</div>;

  const label = categoryLabel(row, cat ?? undefined);
  const dateStr = formatDayMonthYear(row.expense_date);
  const modeStr = row.payment_mode
    ? row.payment_mode === "upi"
      ? t("expense.mode_upi")
      : t(`expense.mode_${row.payment_mode}`)
    : null;

  return (
    <div className="min-h-full bg-slate-50">
      <AppHeader
        title={t("expense.detail_title")}
        onBack={() => navigate({ to: "/expense" })}
        right={
          isOwner ? (
            <button
              type="button"
              onClick={() => navigate({ to: "/expense/$id/edit", params: { id: row.id } })}
              className="h-10 px-3 rounded-lg text-teal-700 text-sm font-semibold"
            >
              {t("expense.edit")}
            </button>
          ) : undefined
        }
      />
      <div className="p-4 space-y-3 pb-24">
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center">
              <TrendingDown className="w-5 h-5 text-rose-600" />
            </div>
            <div>
              <div className="text-[10px] uppercase text-slate-400">{t("expense.category")}</div>
              <div className="text-sm font-semibold text-slate-800">{label}</div>
            </div>
          </div>
          <div className="border-t border-slate-200 mt-3 pt-3">
            <div className="text-[10px] uppercase text-slate-400">{t("expense.amount")}</div>
            <div className="text-2xl font-bold text-rose-600">{formatINR(Number(row.amount))}</div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-500">{t("expense.date")}</span>
            <span className="text-slate-800 font-medium">{dateStr}</span>
          </div>
          {modeStr && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">{t("expense.payment_mode")}</span>
              <span className="text-slate-800 font-medium">{modeStr}</span>
            </div>
          )}
          {row.note && (
            <div className="border-t border-slate-200 pt-2">
              <div className="text-xs text-slate-400 mb-1">{t("expense.note")}</div>
              <div className="text-sm text-slate-700">{row.note}</div>
            </div>
          )}
        </div>

        {isOwner && (
          <div className="bg-rose-50 border border-rose-100 rounded-lg p-4">
            {!confirmDel ? (
              <button
                type="button"
                onClick={() => setConfirmDel(true)}
                className="w-full flex items-center justify-center gap-2 h-11 rounded-lg text-rose-600 font-semibold text-sm"
              >
                <Trash2 className="w-4 h-4" /> {t("expense.delete_expense")}
              </button>
            ) : (
              <div className="space-y-2">
                <div className="text-sm text-rose-800">{t("expense.delete_confirm")}</div>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="secondary" onClick={() => setConfirmDel(false)}>
                    {t("expense.cancel")}
                  </Button>
                  <Button variant="danger" onClick={doDelete} loading={deleting}>
                    {t("expense.delete")}
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
