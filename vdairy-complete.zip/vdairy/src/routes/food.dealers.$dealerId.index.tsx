import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { MapPin, Phone, Plus } from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Spinner } from "@/components/Spinner";
import {
  getDealer,
  listDealerPayments,
  listProducts,
  listStockPurchasesForDealer,
  type FeedDealer,
  type FeedDealerPayment,
  type FeedProduct,
  type FeedStockPurchase,
} from "@/lib/food";
import { useCenter } from "@/contexts/CenterContext";
import { formatDMY } from "@/lib/payment-periods";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/food/dealers/$dealerId/")({
  component: DealerDetail,
});

function DealerDetail() {
  const { t } = useTranslation();
  const { dealerId } = useParams({ from: "/food/dealers/$dealerId/" });
  const navigate = useNavigate();
  const { selected } = useCenter();

  const [loading, setLoading] = useState(true);
  const [dealer, setDealer] = useState<FeedDealer | null>(null);
  const [purchases, setPurchases] = useState<FeedStockPurchase[]>([]);
  const [payments, setPayments] = useState<FeedDealerPayment[]>([]);
  const [products, setProducts] = useState<FeedProduct[]>([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [d, ps, py, prods] = await Promise.all([
          getDealer(dealerId),
          listStockPurchasesForDealer(dealerId),
          listDealerPayments(dealerId),
          selected ? listProducts(selected.id) : Promise.resolve([]),
        ]);
        if (cancelled) return;
        setDealer(d);
        setPurchases(ps);
        setPayments(py);
        setProducts(prods);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [dealerId, selected?.id]);

  const productById = useMemo(() => Object.fromEntries(products.map((p) => [p.id, p])), [products]);
  const totalPurchased = purchases.reduce((s, r) => s + Number(r.amount), 0);
  const totalPaid = payments.reduce((s, r) => s + Number(r.amount), 0);
  const balance = totalPurchased - totalPaid;

  return (
    <>
      <AppHeader
        title={dealer?.dealer_name ?? t("food.dealer")}
        onBack={() => navigate({ to: "/food/dealers" })}
        right={
          <button
            type="button"
            aria-label={t("food.dealer_payment")}
            onClick={() =>
              navigate({ to: "/food/dealers/$dealerId/payment", params: { dealerId } })
            }
            className="h-10 w-10 rounded-full bg-teal-700 text-white flex items-center justify-center hover:bg-teal-800"
          >
            <Plus className="h-5 w-5" />
          </button>
        }
      />
      {loading ? (
        <div className="py-16 flex justify-center">
          <Spinner />
        </div>
      ) : !dealer ? (
        <div className="py-16 text-center text-sm text-slate-500">{t("food.dealer_not_found")}</div>
      ) : (
        <div className="p-4 space-y-4 pb-24">
          {(dealer.mobile || dealer.address) && (
            <div className="text-xs text-slate-600 space-y-1">
              {dealer.mobile && (
                <div className="flex items-center gap-2">
                  <Phone className="h-3.5 w-3.5 text-slate-400" /> {dealer.mobile}
                </div>
              )}
              {dealer.address && (
                <div className="flex items-center gap-2">
                  <MapPin className="h-3.5 w-3.5 text-slate-400" /> {dealer.address}
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-3 gap-2 bg-white border border-slate-200 rounded-lg p-3 text-center">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-slate-400">
                {t("food.purchased")}
              </div>
              <div className="font-bold text-slate-800">₹{totalPurchased.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-slate-400">
                {t("food.paid")}
              </div>
              <div className="font-bold text-slate-800">₹{totalPaid.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-slate-400">
                {t("food.balance")}
              </div>
              <div
                className={cn(
                  "font-bold text-lg",
                  balance > 0 ? "text-rose-600" : "text-emerald-600",
                )}
              >
                ₹{balance.toFixed(2)}
              </div>
            </div>
          </div>

          <Section title={t("food.purchase_history")}>
            {purchases.length === 0 ? (
              <EmptyRow label={t("food.no_purchases_yet")} />
            ) : (
              purchases.map((p) => {
                const prod = productById[p.feed_product_id];
                return (
                  <div key={p.id} className="px-3 py-2.5 flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-medium text-slate-800 text-sm">
                        {prod?.product_name ?? "—"}
                      </div>
                      <div className="text-xs text-slate-400">
                        {formatDMY(new Date(p.purchase_date))} · {Number(p.quantity)} x ₹
                        {Number(p.rate)}
                      </div>
                    </div>
                    <div className="font-bold text-slate-800 text-sm shrink-0">
                      ₹{Number(p.amount).toFixed(2)}
                    </div>
                  </div>
                );
              })
            )}
          </Section>

          <Section title={t("food.payment_history")}>
            {payments.length === 0 ? (
              <EmptyRow label={t("food.no_payments_yet")} />
            ) : (
              payments.map((p) => (
                <div key={p.id} className="px-3 py-2.5 flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-medium text-slate-800 text-sm">
                      {formatDMY(new Date(p.payment_date))}
                    </div>
                    {p.comments && <div className="text-xs text-slate-400">{p.comments}</div>}
                  </div>
                  <div className="font-bold text-emerald-600 text-sm shrink-0">
                    ₹{Number(p.amount).toFixed(2)}
                  </div>
                </div>
              ))
            )}
          </Section>
        </div>
      )}
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
      <div className="bg-slate-50 border-b border-slate-100 px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
        {title}
      </div>
      <div className="divide-y divide-slate-50">{children}</div>
    </div>
  );
}
function EmptyRow({ label }: { label: string }) {
  return <div className="px-3 py-4 text-center text-sm text-slate-400">{label}</div>;
}
