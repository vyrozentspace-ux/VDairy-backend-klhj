import { formatDayMonthYear } from "@/lib/date-locale";
import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Moon, Sun, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import {
  deleteSale,
  formatINR,
  getSale,
  listCustomers,
  logActivity,
  updateSale,
  type MilkSale,
  type MilkSaleCustomer,
  type PayMode,
  type PayStatus,
} from "@/lib/milk-sales";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/milk-sale/$id/")({
  component: SaleDetail,
});

function SaleDetail() {
  const { t } = useTranslation();
  const { id } = useParams({ from: "/milk-sale/$id/" });
  const navigate = useNavigate();
  const { profile, userId } = useAuth();
  const { selected } = useCenter();
  const isOwner = profile?.role === "owner";

  const [sale, setSale] = useState<MilkSale | null>(null);
  const [customer, setCustomer] = useState<MilkSaleCustomer | null>(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState<PayStatus>("unpaid");
  const [pmode, setPmode] = useState<PayMode | null>(null);
  const [savingPay, setSavingPay] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await getSale(id);
      setSale(s);
      if (s?.customer_id && selected) {
        const cs = await listCustomers(selected.id);
        setCustomer(cs.find((c) => c.id === s.customer_id) ?? null);
      }
      if (s) {
        setStatus(s.payment_status);
        setPmode(s.payment_mode);
      }
      setLoading(false);
    })();
  }, [id, selected?.id]);

  const dirty = useMemo(() => {
    if (!sale) return false;
    return (
      sale.payment_status !== status ||
      (sale.payment_mode ?? null) !== (status === "paid" ? pmode : null)
    );
  }, [sale, status, pmode]);

  async function updatePayment() {
    if (!sale || !dirty) return;
    setSavingPay(true);
    try {
      await updateSale(sale.id, {
        payment_status: status,
        payment_mode: status === "paid" ? pmode : null,
      });
      if (selected)
        void logActivity(selected.id, userId, "milk_sale_updated", { id: sale.id, payment: true });
      toast.success(t("sales.paymentUpdated"));
      setSale({ ...sale, payment_status: status, payment_mode: status === "paid" ? pmode : null });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("sales.failed"));
    } finally {
      setSavingPay(false);
    }
  }

  async function doDelete() {
    if (!sale) return;
    setDeleting(true);
    try {
      await deleteSale(sale.id);
      if (selected) void logActivity(selected.id, userId, "milk_sale_deleted", { id: sale.id });
      toast.success(t("sales.saleDeleted"));
      navigate({ to: "/milk-sale", replace: true });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : t("sales.failed"));
    } finally {
      setDeleting(false);
    }
  }

  if (loading)
    return (
      <div className="p-8 flex justify-center">
        <Spinner size={22} color="#0F766E" />
      </div>
    );
  if (!sale) return <div className="p-8 text-center text-slate-500">{t("sales.saleNotFound")}</div>;

  const name = sale.customer_id
    ? (customer?.name ?? t("sales.customerLabel"))
    : sale.walk_in_name
      ? t("sales.walkInWithName", { name: sale.walk_in_name })
      : t("sales.walkIn");
  const mobile = customer?.mobile ?? sale.walk_in_mobile;

  return (
    <div className="min-h-full bg-slate-50">
      <AppHeader
        title={t("sales.saleDetailTitle")}
        onBack={() => navigate({ to: "/milk-sale" })}
        right={
          <button
            type="button"
            onClick={() => navigate({ to: "/milk-sale/$id/edit", params: { id: sale.id } })}
            className="h-10 px-3 rounded-lg text-teal-700 text-sm font-semibold"
          >
            {t("sales.edit")}
          </button>
        }
      />
      <div className="p-4 space-y-3 pb-24">
        <div className="bg-white rounded-lg border border-slate-200 p-4">
          <div className="text-[10px] uppercase text-slate-400 mb-1">{t("sales.customer")}</div>
          <div className="text-sm font-semibold text-slate-800">{name}</div>
          {mobile && <div className="text-xs text-slate-500 mt-0.5">+91 {mobile}</div>}
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4 space-y-2">
          <Row label={t("sales.date")} value={formatDayMonthYear(sale.sale_date)} />
          <Row
            label={t("sales.session")}
            value={
              <span className="inline-flex items-center gap-1">
                {sale.session === "morning" ? (
                  <Sun className="w-4 h-4 text-amber-500" />
                ) : (
                  <Moon className="w-4 h-4 text-indigo-500" />
                )}
                {sale.session === "morning" ? t("sales.morning") : t("sales.evening")}
              </span>
            }
          />
          <Row label={t("sales.quantity")} value={`${Number(sale.quantity_liters).toFixed(1)} L`} />
          <Row
            label={t("sales.ratePerLiter")}
            value={`₹${Number(sale.rate_per_liter).toFixed(2)}`}
          />
          <div className="border-t border-slate-200 pt-2 flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-700">{t("sales.totalAmount")}</span>
            <span className="text-lg font-bold text-teal-700">
              {formatINR(Number(sale.total_amount))}
            </span>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-4 space-y-3">
          <div className="text-sm font-semibold text-slate-700">{t("sales.paymentStatus")}</div>
          <div className="flex p-1 rounded-lg border border-slate-200 bg-white">
            {(["unpaid", "paid"] as const).map((k) => {
              const active = status === k;
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() => setStatus(k)}
                  className={cn(
                    "flex-1 h-10 rounded-md text-sm font-medium capitalize",
                    active && k === "unpaid"
                      ? "bg-rose-600 text-white"
                      : active && k === "paid"
                        ? "bg-emerald-600 text-white"
                        : "text-slate-500",
                  )}
                >
                  {k === "unpaid" ? t("sales.unpaid") : t("sales.paid")}
                </button>
              );
            })}
          </div>
          {status === "paid" && (
            <div className="grid grid-cols-3 gap-2">
              {(["cash", "upi", "other"] as PayMode[]).map((m) => {
                const active = pmode === m;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setPmode(m)}
                    className={cn(
                      "h-11 rounded-lg border text-sm font-medium capitalize",
                      active
                        ? "border-teal-500 bg-teal-50 text-teal-700"
                        : "border-slate-200 bg-white text-slate-500",
                    )}
                  >
                    {m === "upi" ? "UPI" : m === "cash" ? t("sales.cash") : t("sales.other")}
                  </button>
                );
              })}
            </div>
          )}
          <Button onClick={updatePayment} loading={savingPay} disabled={!dirty}>
            {t("sales.updatePayment")}
          </Button>
        </div>

        {isOwner && (
          <div className="bg-rose-50 border border-rose-100 rounded-lg p-4">
            {!confirmDel ? (
              <button
                type="button"
                onClick={() => setConfirmDel(true)}
                className="w-full flex items-center justify-center gap-2 h-11 rounded-lg text-rose-600 font-semibold text-sm"
              >
                <Trash2 className="w-4 h-4" /> {t("sales.deleteSale")}
              </button>
            ) : (
              <div className="space-y-2">
                <div className="text-sm text-rose-800">{t("sales.confirmDeleteSale")}</div>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="secondary" onClick={() => setConfirmDel(false)}>
                    {t("sales.cancel")}
                  </Button>
                  <Button variant="danger" onClick={doDelete} loading={deleting}>
                    {t("sales.delete")}
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-slate-500">{label}</span>
      <span className="text-slate-800 font-medium">{value}</span>
    </div>
  );
}
