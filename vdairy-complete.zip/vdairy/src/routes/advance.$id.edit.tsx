import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { AdvanceForm } from "@/components/AdvanceForm";

export const Route = createFileRoute("/advance/$id/edit")({
  component: EditAdvanceScreen,
});

function EditAdvanceScreen() {
  const { id } = useParams({ from: "/advance/$id/edit" });
  const navigate = useNavigate();
  return <AdvanceForm mode="edit" advanceId={id} onBack={() => navigate({ to: "/advance" })} />;
}
