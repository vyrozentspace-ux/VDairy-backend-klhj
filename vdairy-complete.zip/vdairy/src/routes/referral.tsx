import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Copy, Check, Gift, Users, CalendarPlus, Share2, BadgeIndianRupee } from "lucide-react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AppHeader } from "@/components/AppHeader";
import { Alert } from "@/components/Alert";
import { Button } from "@/components/Button";
import { useCenter } from "@/contexts/CenterContext";
import { APP_NAME } from "@/lib/app-config";
import { useAppSettings } from "@/lib/app-settings";

export const Route = createFileRoute("/referral")({
  ssr: false,
  component: ReferralScreen,
  head: () => ({
    meta: [
      { title: "Refer a Dairy | Dairy Collection Manager" },
      {
        name: "description",
        content:
          "Share your dairy referral code and earn bonus subscription days when a referred centre buys a paid plan.",
      },
      { property: "og:title", content: "Refer a Dairy | Dairy Collection Manager" },
      {
        property: "og:description",
        content:
          "Share your dairy referral code and earn bonus subscription days when a referred centre buys a paid plan.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

type Stats = {
  referral_code: string | null;
  referred_count: number;
  bonus_days: number;
};

function ReferralScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const settings = useAppSettings();

  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!selected?.id) return;
    let cancelled = false;
    (async () => {
      const { data, error: err } = await supabase.rpc("referral_stats", {
        p_center_id: selected.id,
      });
      if (cancelled) return;
      if (err) {
        setError(err.message);
        return;
      }
      const row = Array.isArray(data) ? data[0] : data;
      setStats(
        row
          ? {
              referral_code: row.referral_code ?? null,
              referred_count: Number(row.referred_count ?? 0),
              bonus_days: Number(row.bonus_days ?? 0),
            }
          : { referral_code: null, referred_count: 0, bonus_days: 0 },
      );
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  const code = stats?.referral_code ?? "—";
  const hasCode = !!stats?.referral_code;
  const bonusDays = settings.referral_bonus_days || String(stats?.bonus_days ?? 0);

  // The signup link is remotely configurable and may be cleared entirely —
  // in that case the message must read cleanly without a dangling ": ".
  const shareMessage = t("settings.referral_share_message", {
    app: APP_NAME,
    code,
    days: bonusDays,
    link: settings.referral_signup_link,
  })
    .replace(/:\s*(?=\n|$)/g, "")
    .replace(/[ \t]+\n/g, "\n");


  const copy = async () => {
    if (!hasCode) return;
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError(t("settings.referral_copy_failed"));
    }
  };

  const share = async () => {
    if (!hasCode) return;
    const nav = typeof navigator !== "undefined" ? navigator : undefined;
    if (nav?.share) {
      try {
        await nav.share({
          title: t("settings.referral_share_title", { app: APP_NAME }),
          text: shareMessage,
        });
        return;
      } catch (err) {
        // User dismissed the share sheet — nothing to report.
        if (err instanceof DOMException && err.name === "AbortError") return;
      }
    }
    try {
      await nav?.clipboard.writeText(shareMessage);
      toast.success(t("settings.referral_share_copied"));
    } catch {
      setError(t("settings.referral_copy_failed"));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={t("settings.referral")} onBack={() => navigate({ to: "/more" })} />
      <div className="max-w-md mx-auto px-6 py-6 flex flex-col gap-4">
        {error && <Alert message={error} />}

        <div className="rounded-lg border border-teal-200 bg-teal-50 p-4">
          <div className="flex items-center gap-2 text-teal-800 font-semibold text-sm">
            <Gift className="h-4 w-4" /> {t("settings.referral_your_code")}
          </div>
          <div className="mt-3 flex items-center gap-2">
            <span className="flex-1 rounded-lg bg-white border border-teal-200 px-3 py-2 text-center text-lg font-bold tracking-[0.2em] text-teal-800">
              {code}
            </span>
            <button
              type="button"
              onClick={copy}
              disabled={!hasCode}
              className="h-11 w-11 rounded-lg bg-teal-700 text-white flex items-center justify-center disabled:bg-slate-300"
              aria-label={t("settings.referral_copy")}
            >
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            </button>
          </div>

          <Button
            className="mt-3 bg-teal-700"
            onClick={() => void share()}
            disabled={!hasCode}
            data-testid="referral-share"
          >
            <Share2 className="h-4 w-4" />
            {t("settings.referral_share", { app: APP_NAME })}
          </Button>

          <p className="mt-3 text-xs text-teal-800/80">
            {t("settings.referral_hint", { days: bonusDays })}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <StatCard
            icon={<Users className="h-4 w-4" />}
            label={t("settings.referral_centers_joined")}
            value={String(stats?.referred_count ?? 0)}
          />
          <StatCard
            icon={<CalendarPlus className="h-4 w-4" />}
            label={t("settings.referral_bonus_days")}
            value={String(stats?.bonus_days ?? 0)}
          />
        </div>

        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-2 text-amber-800 font-semibold text-sm">
            <BadgeIndianRupee className="h-4 w-4" /> {t("settings.referral_how_title")}
          </div>
          <ol className="mt-2 flex flex-col gap-1.5 text-xs text-amber-900/90 list-decimal pl-4">
            <li>{t("settings.referral_how_1")}</li>
            <li>{t("settings.referral_how_2")}</li>
            <li>{t("settings.referral_how_3", { days: bonusDays })}</li>
          </ol>
          <p className="mt-2 text-xs font-semibold text-amber-900">
            {t("settings.referral_no_expiry")}
          </p>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4">
      <span className="text-slate-500">{icon}</span>
      <p className="mt-2 text-2xl font-bold text-slate-800">{value}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </div>
  );
}
