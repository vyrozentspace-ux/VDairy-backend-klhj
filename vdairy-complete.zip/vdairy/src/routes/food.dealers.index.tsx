import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Users } from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { BottomSheet } from "@/components/BottomSheet";
import { Field, TextInput } from "@/components/Field";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { createDealer, dealerBalance, listDealers, type FeedDealer } from "@/lib/food";
import { logActivity } from "@/lib/farmers";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/food/dealers/")({
  component: DealersScreen,
});

function DealersScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { userId } = useAuth();
  const [loading, setLoading] = useState(true);
  const [dealers, setDealers] = useState<FeedDealer[]>([]);
  const [balances, setBalances] = useState<Record<string, number>>({});
  const [addOpen, setAddOpen] = useState(false);
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [address, setAddress] = useState("");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    if (!selected) return;
    setLoading(true);
    try {
      const list = await listDealers(selected.id);
      setDealers(list);
      const entries = await Promise.all(
        list.map(async (d) => [d.id, await dealerBalance(d.id)] as const),
      );
      setBalances(Object.fromEntries(entries));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [selected?.id]);

  const submit = async () => {
    if (!selected || !name.trim()) return;
    setSaving(true);
    try {
      const d = await createDealer({
        center_id: selected.id,
        dealer_name: name.trim(),
        mobile: mobile.trim() || null,
        address: address.trim() || null,
      });
      await logActivity(selected.id, userId ?? "", "dealer_added", {
        id: d.id,
        dealer_name: d.dealer_name,
      });
      toast.success(t("food.dealer_added"));
      setName("");
      setMobile("");
      setAddress("");
      setAddOpen(false);
      void load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("food.failed_to_add"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AppHeader
        title={t("food.dealers")}
        onBack={() => navigate({ to: "/food" })}
        right={
          <button
            type="button"
            onClick={() => setAddOpen(true)}
            aria-label={t("food.add_dealer")}
            className="h-10 w-10 rounded-full bg-teal-700 text-white flex items-center justify-center hover:bg-teal-800"
          >
            <Plus className="h-5 w-5" />
          </button>
        }
      />
      <div className="p-4 pb-24">
        {loading ? (
          <div className="py-16 flex justify-center">
            <Spinner />
          </div>
        ) : dealers.length === 0 ? (
          <div className="py-16 flex flex-col items-center gap-3">
            <span className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300">
              <Users className="h-7 w-7" />
            </span>
            <p className="text-sm text-slate-500">{t("food.no_dealers")}</p>
            <Button onClick={() => setAddOpen(true)} className="max-w-xs">
              <Plus className="h-4 w-4" /> {t("food.add_dealer")}
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            {dealers.map((d) => {
              const bal = balances[d.id] ?? 0;
              return (
                <button
                  key={d.id}
                  type="button"
                  onClick={() =>
                    navigate({ to: "/food/dealers/$dealerId", params: { dealerId: d.id } })
                  }
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-3 flex justify-between items-center hover:border-teal-300"
                >
                  <div className="min-w-0 text-left">
                    <div className="font-semibold text-slate-800 truncate">{d.dealer_name}</div>
                    {d.mobile && <div className="text-xs text-slate-400 mt-0.5">{d.mobile}</div>}
                  </div>
                  <div
                    className={cn(
                      "font-bold text-sm shrink-0",
                      bal > 0 ? "text-rose-600" : "text-emerald-600",
                    )}
                  >
                    ₹{bal.toFixed(2)}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <BottomSheet open={addOpen} onClose={() => setAddOpen(false)} title={t("food.add_dealer")}>
        <div className="p-3 space-y-3">
          <Field label={t("food.dealer_name")}>
            <TextInput value={name} onChange={(e) => setName(e.target.value)} autoFocus />
          </Field>
          <Field label={t("food.mobile_optional")}>
            <TextInput
              type="tel"
              inputMode="numeric"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
            />
          </Field>
          <Field label={t("food.address_optional")}>
            <TextInput value={address} onChange={(e) => setAddress(e.target.value)} />
          </Field>
          <Button onClick={submit} loading={saving} disabled={!name.trim()}>
            {t("food.save")}
          </Button>
        </div>
      </BottomSheet>
    </>
  );
}
