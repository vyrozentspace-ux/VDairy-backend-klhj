import { formatMonthShort } from "@/lib/date-locale";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Award } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { Spinner } from "@/components/Spinner";
import { supabase } from "@/integrations/supabase/client";
import { useCenter } from "@/contexts/CenterContext";
import { fetchFarmers, farmerFullName, type Farmer } from "@/lib/farmers";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/bonus")({
  component: BonusScreen,
});

function financialYearRange(_lang?: string, d = new Date()) {
  const y = d.getFullYear();
  const m = d.getMonth();
  const startYear = m < 3 ? y - 1 : y;
  const iso = (yr: number, mo: number, dy: number) =>
    `${yr}-${String(mo + 1).padStart(2, "0")}-${String(dy).padStart(2, "0")}`;
  return {
    from: iso(startYear, 3, 1),
    to: iso(startYear + 1, 2, 31),
    label: `${formatMonthShort(new Date(startYear, 3, 1))} ${startYear} \u2013 ${formatMonthShort(new Date(startYear + 1, 2, 1))} ${startYear + 1}`,
  };
}

function formatINR(n: number) {
  return `₹${n.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}

function BonusScreen() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const fy = useMemo(() => financialYearRange(i18n.language), [i18n.language]);
  const [loading, setLoading] = useState(true);
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [totals, setTotals] = useState<Record<string, { liters: number; amount: number }>>({});

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const fs = await fetchFarmers(selected.id);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data } = await (supabase as any)
        .from("collections")
        .select("farmer_id, quantity_liters, total_amount")
        .eq("center_id", selected.id)
        .gte("collection_date", fy.from)
        .lte("collection_date", fy.to);
      if (cancelled) return;
      const agg: Record<string, { liters: number; amount: number }> = {};
      for (const r of (data ?? []) as {
        farmer_id: string;
        quantity_liters: number;
        total_amount: number;
      }[]) {
        const cur = agg[r.farmer_id] ?? { liters: 0, amount: 0 };
        cur.liters += Number(r.quantity_liters);
        cur.amount += Number(r.total_amount);
        agg[r.farmer_id] = cur;
      }
      setFarmers(fs);
      setTotals(agg);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id, fy.from, fy.to]);

  const rows = useMemo(() => {
    return farmers
      .map((f) => ({ f, t: totals[f.id] ?? { liters: 0, amount: 0 } }))
      .filter((r) => r.t.liters > 0)
      .sort((a, b) => b.t.liters - a.t.liters);
  }, [farmers, totals]);

  const grand = rows.reduce(
    (acc, r) => ({ liters: acc.liters + r.t.liters, amount: acc.amount + r.t.amount }),
    { liters: 0, amount: 0 },
  );

  return (
    <>
      <AppHeader title={t("auth.annual_bonus")} onBack={() => navigate({ to: "/dashboard" })} />
      <div className="p-4 space-y-4 pb-24">
        <div className="rounded-lg bg-teal-700 text-white p-4">
          <div className="flex items-center gap-2 text-teal-100 text-xs uppercase tracking-wider">
            <Award className="h-4 w-4" /> {t("auth.financial_year")}
          </div>
          <div className="mt-1 font-bold text-lg">{fy.label}</div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <div>
              <div className="text-[10px] uppercase text-teal-100">{t("auth.total_liters")}</div>
              <div className="text-xl font-bold">{grand.liters.toFixed(1)}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase text-teal-100">{t("auth.total_amount")}</div>
              <div className="text-xl font-bold">{formatINR(grand.amount)}</div>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="py-16 flex justify-center">
            <Spinner />
          </div>
        ) : rows.length === 0 ? (
          <div className="py-16 text-center text-sm text-slate-500">
            {t("auth.no_collection_activity")}
          </div>
        ) : (
          <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
            <div className="bg-slate-50 border-b border-slate-100 px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500 grid grid-cols-[auto,1fr,auto,auto] gap-3">
              <span>#</span>
              <span>{t("auth.farmer")}</span>
              <span className="text-right">{t("auth.liters")}</span>
              <span className="text-right">{t("auth.amount")}</span>
            </div>
            <div className="divide-y divide-slate-100">
              {rows.map((r) => (
                <div
                  key={r.f.id}
                  className="px-3 py-2.5 grid grid-cols-[auto,1fr,auto,auto] gap-3 items-center text-sm"
                >
                  <span className="text-slate-400 w-6">{r.f.code}</span>
                  <span className="text-slate-800 truncate">{farmerFullName(r.f)}</span>
                  <span className="text-right text-slate-700">{r.t.liters.toFixed(1)}</span>
                  <span className="text-right font-semibold text-teal-700">
                    {formatINR(r.t.amount)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        <p className="text-xs text-slate-500 text-center">{t("auth.bonus_summary_note")}</p>
      </div>
    </>
  );
}
