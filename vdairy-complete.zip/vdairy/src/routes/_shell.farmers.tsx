import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useTranslation } from "react-i18next";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Contact,
  Loader2,
  MoreVertical,
  Phone,
  Plus,
  Search,
  Trash2,
  Users,
  Milk,
} from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { FarmerAvatar } from "@/components/FarmerAvatar";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { MilkTypePills } from "@/components/MilkTypePills";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchFarmers,
  formatMobile,
  farmerFullName,
  logActivity,
  type Farmer,
  type MilkType,
} from "@/lib/farmers";
import { useQueueOverlay } from "@/lib/offline/overlay";
import { cn } from "@/lib/utils";
import { ContactUnavailableDialog } from "@/components/ContactUnavailableDialog";
import { hasContactPicker } from "@/lib/contacts";

export const Route = createFileRoute("/_shell/farmers")({
  component: FarmersList,
});

function FarmersList() {
  const { t } = useTranslation();
  const { selected } = useCenter();
  const { profile, userId } = useAuth();
  const isOwner = profile?.role === "owner";
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [serverFarmers, setServerFarmers] = useState<Farmer[]>([]);
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [contactsUnavailable, setContactsUnavailable] = useState(false);

  const openContactImport = () => {
    if (!hasContactPicker()) {
      setContactsUnavailable(true);
      return;
    }
    navigate({ to: "/farmers/import-contacts" });
  };
  const [sheetFarmer, setSheetFarmer] = useState<Farmer | null>(null);
  const [milkSheet, setMilkSheet] = useState<Farmer | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Farmer | null>(null);
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    if (!selected) return;
    setLoading(true);
    try {
      setServerFarmers(await fetchFarmers(selected.id));
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.id]);

  // Farmers still queued offline appear in the list right away.
  const farmers = useQueueOverlay(serverFarmers, "farmers");


  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return farmers;
    return farmers.filter((f) => {
      const name = farmerFullName(f).toLowerCase();
      return (
        name.includes(q) ||
        (f.name_english ?? "").toLowerCase().includes(q) ||
        String(f.code).toLowerCase().includes(q) ||
        (f.mobile ?? "").includes(q)
      );
    });
  }, [farmers, query]);

  const active = filtered.filter((f) => f.is_active);
  const inactive = filtered.filter((f) => !f.is_active);
  const totalActive = farmers.filter((f) => f.is_active).length;
  const totalInactive = farmers.length - totalActive;

  const handleSetMilk = async (f: Farmer, mt: MilkType) => {
    setBusy(true);
    const { error } = await supabase.from("farmers").update({ milk_type: mt }).eq("id", f.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(t("farmers.milk_type_updated"));
    if (userId && selected)
      void logActivity(selected.id, userId, "farmer_milk_type_changed", {
        farmer_id: f.id,
        milk_type: mt,
      });
    setMilkSheet(null);
    setSheetFarmer(null);
    void refresh();
  };

  const handleToggleActive = async (f: Farmer) => {
    setBusy(true);
    const { error } = await supabase
      .from("farmers")
      .update({ is_active: !f.is_active })
      .eq("id", f.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(f.is_active ? t("farmers.farmer_deactivated") : t("farmers.farmer_activated"));
    if (userId && selected)
      void logActivity(
        selected.id,
        userId,
        f.is_active ? "farmer_deactivated" : "farmer_activated",
        { farmer_id: f.id },
      );
    setSheetFarmer(null);
    void refresh();
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    setBusy(true);
    const { error } = await supabase.from("farmers").delete().eq("id", confirmDelete.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(t("farmers.farmer_deleted"));
    if (userId && selected)
      void logActivity(selected.id, userId, "farmer_deleted", {
        farmer_id: confirmDelete.id,
        name: farmerFullName(confirmDelete),
      });
    setConfirmDelete(null);
    setSheetFarmer(null);
    void refresh();
  };

  return (
    <>
      <AppHeader
        title={t("farmers.title")}
        onBack={() => navigate({ to: "/dashboard" })}
        right={
          <div className="flex items-center gap-1 relative">
            {isOwner && (
              <button
                type="button"
                onClick={openContactImport}
                aria-label={t("farmers.sync_from_contacts_aria")}
                className="h-11 w-11 rounded-full flex items-center justify-center text-teal-700 hover:bg-teal-50"
              >
                <Contact className="h-5 w-5" />
              </button>
            )}
            <Link
              to="/farmer/new"
              aria-label={t("farmers.add_farmer")}
              className="h-11 w-11 rounded-full flex items-center justify-center text-teal-700 hover:bg-teal-50"
            >
              <Plus className="h-5 w-5" />
            </Link>
            <button
              type="button"
              onClick={() => setMenuOpen((v) => !v)}
              aria-label={t("farmers.more")}
              className="h-11 w-11 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100"
            >
              <MoreVertical className="h-5 w-5" />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-11 mt-1 w-52 bg-white border border-slate-200 rounded-lg shadow-lg z-30 animate-fade-in">
                <Link
                  to="/farmer/register"
                  onClick={() => setMenuOpen(false)}
                  className="block px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-lg"
                >
                  {t("farmers.farmer_register")}
                </Link>
              </div>
            )}
          </div>
        }
      />

      <div className="sticky top-14 z-10 bg-white border-b border-slate-200 px-4 py-3 space-y-3">
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="text-emerald-600 font-medium">
            {t("farmers.active_count", { count: totalActive })}
          </span>
          <span className="text-slate-300">|</span>
          <span>{t("farmers.inactive_count", { count: totalInactive })}</span>
          <span className="text-slate-300">|</span>
          <span>{t("farmers.total_count", { count: farmers.length })}</span>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("farmers.search_by_name_code_mobile")}
            className="w-full h-10 rounded-lg bg-slate-50 border border-slate-200 pl-9 pr-3 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex-1 flex items-center justify-center py-16">
          <Loader2 className="h-6 w-6 text-teal-700 animate-spin" />
        </div>
      ) : farmers.length === 0 ? (
        <EmptyState isOwner={isOwner} onContacts={openContactImport} />
      ) : filtered.length === 0 ? (
        <div className="text-center text-sm text-slate-500 py-12">
          {t("farmers.no_farmers_match_search")}
        </div>
      ) : (
        <div>
          {active.map((f) => (
            <FarmerRow
              key={f.id}
              farmer={f}
              onOpen={() => navigate({ to: "/farmer/$id", params: { id: f.id } })}
              onMenu={() => setSheetFarmer(f)}
            />
          ))}
          {inactive.length > 0 && (
            <>
              <div className="bg-slate-100 px-4 py-1.5 text-[11px] uppercase font-semibold text-slate-500 tracking-wider">
                {t("farmers.inactive")}
              </div>
              {inactive.map((f) => (
                <div key={f.id} className="opacity-70">
                  <FarmerRow
                    farmer={f}
                    onOpen={() => navigate({ to: "/farmer/$id", params: { id: f.id } })}
                    onMenu={() => setSheetFarmer(f)}
                  />
                </div>
              ))}
            </>
          )}
        </div>
      )}

      {/* Row action sheet */}
      <BottomSheet
        open={!!sheetFarmer && !confirmDelete}
        onClose={() => setSheetFarmer(null)}
        title={sheetFarmer ? farmerFullName(sheetFarmer) : ""}
      >
        {sheetFarmer && (
          <div className="space-y-1">
            {isOwner && (
              <SheetItem
                icon={<Contact className="h-4 w-4" />}
                label={t("farmers.sync_from_contacts")}
                onClick={() => {
                  setSheetFarmer(null);
                  openContactImport();
                }}
              />
            )}
            <SheetItem
              icon={<Milk className="h-4 w-4" />}
              label={t("farmers.set_milk_type")}
              meta={sheetFarmer.milk_type}
              onClick={() => setMilkSheet(sheetFarmer)}
            />
            <SheetItem
              icon={<Users className="h-4 w-4" />}
              label={sheetFarmer.is_active ? t("farmers.deactivate") : t("farmers.activate")}
              onClick={() => handleToggleActive(sheetFarmer)}
            />
            {isOwner && (
              <SheetItem
                icon={<Trash2 className="h-4 w-4" />}
                label={t("farmers.remove_farmer")}
                danger
                onClick={() => setConfirmDelete(sheetFarmer)}
              />
            )}
          </div>
        )}
      </BottomSheet>

      {/* Milk type sub-sheet */}
      <BottomSheet
        open={!!milkSheet}
        onClose={() => setMilkSheet(null)}
        title={t("farmers.milk_type")}
      >
        {milkSheet && (
          <div className="p-2">
            <MilkTypePills
              value={milkSheet.milk_type as MilkType}
              onChange={(next) => handleSetMilk(milkSheet, next)}
            />
          </div>
        )}
      </BottomSheet>

      {/* Delete confirm */}
      <BottomSheet
        open={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        title={t("farmers.delete_this_farmer")}
      >
        <div className="px-3 pb-2">
          <p className="text-sm text-slate-500 mb-4">
            {t("farmers.confirm_delete_message", {
              name: confirmDelete ? farmerFullName(confirmDelete) : "",
            })}
          </p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setConfirmDelete(null)}>
              {t("farmers.cancel")}
            </Button>
            <Button variant="danger" loading={busy} onClick={handleDelete}>
              {t("farmers.delete")}
            </Button>
          </div>
        </div>
      </BottomSheet>

      <ContactUnavailableDialog
        open={contactsUnavailable}
        onClose={() => setContactsUnavailable(false)}
      />
    </>
  );
}

function FarmerRow({
  farmer,
  onOpen,
  onMenu,
}: {
  farmer: Farmer;
  onOpen: () => void;
  onMenu: () => void;
}) {
  const { t } = useTranslation();
  const timer = useRef<number | null>(null);
  const longPressed = useRef(false);

  const startPress = () => {
    longPressed.current = false;
    timer.current = window.setTimeout(() => {
      longPressed.current = true;
      onMenu();
    }, 500);
  };
  const endPress = () => {
    if (timer.current) window.clearTimeout(timer.current);
  };

  return (
    <div
      onClick={() => {
        if (longPressed.current) return;
        onOpen();
      }}
      onTouchStart={startPress}
      onTouchEnd={endPress}
      onTouchMove={endPress}
      className={cn(
        "flex items-center gap-3 px-4 py-3 bg-white border-b border-slate-100 cursor-pointer active:bg-slate-50",
      )}
    >
      <FarmerAvatar farmer={farmer} />
      <div className="flex-1 min-w-0">
        <div className="font-semibold text-sm text-slate-800 truncate">
          {farmerFullName(farmer)}
        </div>
        <div className="text-xs text-slate-500 truncate">
          {farmer.mobile ? formatMobile(farmer.mobile) : t("farmers.no_mobile")}
        </div>
      </div>
      {farmer.mobile && (
        <a
          href={`tel:${farmer.mobile}`}
          onClick={(e) => e.stopPropagation()}
          aria-label={t("farmers.call_farmer")}
          className="h-9 w-9 rounded-full flex items-center justify-center bg-teal-50 text-teal-700 hover:bg-teal-100"
        >
          <Phone className="h-4 w-4" />
        </a>
      )}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onMenu();
        }}
        aria-label={t("farmers.more")}
        className="h-9 w-9 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100"
      >
        <MoreVertical className="h-4 w-4" />
      </button>
    </div>
  );
}

function EmptyState({ isOwner, onContacts }: { isOwner: boolean; onContacts: () => void }) {
  const { t } = useTranslation();
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 py-16 text-center gap-3">
      <div className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center">
        <Users className="h-8 w-8 text-slate-400" />
      </div>
      <h2 className="text-lg font-bold text-slate-800">{t("farmers.no_farmers_added_yet")}</h2>
      <p className="text-sm text-slate-500 max-w-xs">{t("farmers.empty_state_message")}</p>
      <div className="w-full max-w-xs mt-2 space-y-2">
        <Link to="/farmer/new">
          <Button>
            <Plus className="h-4 w-4" /> {t("farmers.add_farmer")}
          </Button>
        </Link>
        {isOwner && (
          <button
            type="button"
            onClick={onContacts}
            className="w-full h-12 rounded-lg bg-teal-50 text-teal-700 font-semibold text-sm hover:bg-teal-100 flex items-center justify-center gap-2"
          >
            <Contact className="h-4 w-4" /> {t("farmers.sync_from_contacts")}
          </button>
        )}
      </div>
    </div>
  );
}
