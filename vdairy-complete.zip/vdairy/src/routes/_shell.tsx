import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";

import { MobileFrame } from "@/components/MobileFrame";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { Spinner } from "@/components/Spinner";
import { InAppNotificationBanner } from "@/components/InAppNotificationBanner";
import { useNotificationRunner } from "@/hooks/useNotificationRunner";

export const Route = createFileRoute("/_shell")({
  ssr: false,
  component: ShellLayout,
});

function ShellLayout() {
  const { loading, session, userId } = useAuth();
  const { loading: centerLoading, selectedId, centers, isOwner } = useCenter();
  const navigate = useNavigate();

  // Smart notification engine: runs while the app is open and pre-schedules
  // today's upcoming reminders natively on Android.
  useNotificationRunner({ userId: userId ?? null, centerId: selectedId, isOwner });

  useEffect(() => {
    if (loading) return;
    if (!session) {
      navigate({ to: "/login", replace: true });
      return;
    }
    if (!centerLoading && !selectedId && centers.length !== 1) {
      navigate({ to: "/centers", replace: true });
    }
  }, [loading, session, centerLoading, selectedId, centers.length, navigate]);

  if (loading || (session && centerLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size={24} color="#0F766E" />
      </div>
    );
  }

  return (
    <MobileFrame>
      <InAppNotificationBanner />
      <Outlet />
    </MobileFrame>
  );
}
