import { milkTypeLabel, shiftLabel } from "@/lib/labels";
import { formatDayMonth } from "@/lib/date-locale";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  ChevronLeft,
  ChevronRight,
  Droplets,
  MoreVertical,
  Plus,
  Trash2,
  Pencil,
} from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { FarmerAvatar } from "@/components/FarmerAvatar";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { useCenter } from "@/contexts/CenterContext";
import { useAuth } from "@/contexts/AuthContext";
import {
  deleteCollection,
  listCollections,
  todayISO,
  type Collection,
  type Shift,
} from "@/lib/collections";
import { fetchFarmers, farmerFullName, type Farmer } from "@/lib/farmers";
import { useQueueOverlay } from "@/lib/offline/overlay";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/_shell/collection")({
  component: CollectionList,
});

const SHIFT_TABS: { value: Shift | "all"; labelKey: string }[] = [
  { value: "all", labelKey: "collection.all" },
  { value: "morning", labelKey: "collection.morning" },
  { value: "evening", labelKey: "collection.evening" },
];

function fmtDateLabel(iso: string, tr: (key: string, opts?: Record<string, unknown>) => string) {
  const d = new Date(iso + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const diff = Math.round((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  const base = formatDayMonth(d);
  if (diff === 0) return tr("collection.today_date", { date: base });
  if (diff === -1) return tr("collection.yesterday_date", { date: base });
  if (diff === 1) return tr("collection.tomorrow_date", { date: base });
  return base;
}

function shiftDate(iso: string, delta: number) {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + delta);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function CollectionList() {
  const { t } = useTranslation();
  const { selected, can } = useCenter();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const isOwner = profile?.role === "owner";
  // Operators without the "view past collections" permission are locked to today.
  const canViewHistory = can("collection_history");
  const [date, setDate] = useState<string>(todayISO());
  const [shift, setShift] = useState<Shift | "all">("all");
  const [loading, setLoading] = useState(true);
  const [serverRows, setServerRows] = useState<Collection[]>([]);
  const [farmers, setFarmers] = useState<Record<string, Farmer>>({});
  const [menuFor, setMenuFor] = useState<Collection | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Collection | null>(null);

  const refresh = async () => {
    if (!selected) return;
    setLoading(true);
    try {
      const [list, fs] = await Promise.all([
        listCollections({ centerId: selected.id, date, shift }),
        fetchFarmers(selected.id),
      ]);
      setServerRows(list);
      const map: Record<string, Farmer> = {};
      for (const f of fs) map[f.id] = f;
      setFarmers(map);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("collection.failed_to_load"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void refresh();
  }, [selected?.id, date, shift]); // eslint-disable-line react-hooks/exhaustive-deps

  // Rows still queued offline are shown alongside the server rows.
  const keep = useCallback(
    (r: Collection) =>
      r.center_id === selected?.id &&
      r.collection_date === date &&
      (shift === "all" || r.shift === shift),
    [selected?.id, date, shift],
  );
  const rows = useQueueOverlay(serverRows, "collections", keep);

  const summary = useMemo(() => {
    const totalLiters = rows.reduce((s, r) => s + Number(r.quantity_liters), 0);
    const totalAmount = rows.reduce((s, r) => s + Number(r.total_amount), 0);
    const avgFat = rows.length ? rows.reduce((s, r) => s + Number(r.fat), 0) / rows.length : 0;
    return { totalLiters, totalAmount, avgFat };
  }, [rows]);

  const onDelete = async () => {
    if (!confirmDelete) return;
    try {
      await deleteCollection(confirmDelete.id, {
        center_id: confirmDelete.center_id,
        created_by: confirmDelete.created_by,
      });
      toast.success(t("collection.collection_deleted"));
      setConfirmDelete(null);
      await refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("collection.failed_to_delete"));
    }
  };

  return (
    <>
      <AppHeader
        title={t("collection.collections")}
        onBack={() => navigate({ to: "/dashboard" })}
        right={
          <Link
            to="/collection/new"
            className="h-11 w-11 rounded-full bg-teal-700 text-white flex items-center justify-center"
            aria-label={t("collection.new_collection")}
          >
            <Plus className="h-5 w-5" />
          </Link>
        }
      />

      <div className="sticky top-14 z-10 bg-white border-b border-slate-200 px-3 py-3 space-y-3">
        <div className="flex items-center justify-between">
          {canViewHistory ? (
            <>
              <button
                type="button"
                onClick={() => setDate(shiftDate(date, -1))}
                className="h-9 w-9 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 transition-colors duration-150"
                aria-label={t("collection.previous_day")}
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <label className="relative">
                <span className="text-sm font-semibold text-slate-800 px-3 py-1.5 rounded-lg hover:bg-slate-100 cursor-pointer">
                  {fmtDateLabel(date, t)}
                </span>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </label>
              <button
                type="button"
                onClick={() => setDate(shiftDate(date, 1))}
                className="h-9 w-9 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 transition-colors duration-150"
                aria-label={t("collection.next_day")}
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          ) : (
            <span className="mx-auto text-sm font-semibold text-slate-800 px-3 py-1.5">
              {fmtDateLabel(date, t)}
            </span>
          )}
        </div>
        <div className="flex gap-2">
          {SHIFT_TABS.map((tab) => (
            <button
              key={tab.value}
              onClick={() => setShift(tab.value)}
              className={cn(
                "flex-1 h-9 rounded-full text-sm font-medium",
                shift === tab.value ? "bg-teal-700 text-white" : "bg-slate-100 text-slate-600",
              )}
            >
              {t(tab.labelKey)}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4">
        <div className="rounded-lg bg-teal-50 border border-teal-100 p-4 flex justify-between text-sm mb-3">
          <div>
            <div className="text-[11px] uppercase text-teal-700 font-semibold">
              {t("collection.total_liters")}
            </div>
            <div className="font-bold text-teal-800">{summary.totalLiters.toFixed(1)} L</div>
          </div>
          <div>
            <div className="text-[11px] uppercase text-teal-700 font-semibold">
              {t("collection.avg_fat")}
            </div>
            <div className="font-bold text-teal-800">{summary.avgFat.toFixed(2)}</div>
          </div>
          <div>
            <div className="text-[11px] uppercase text-teal-700 font-semibold">
              {t("collection.amount")}
            </div>
            <div className="font-bold text-teal-800">₹{summary.totalAmount.toFixed(2)}</div>
          </div>
        </div>

        {loading ? (
          <div className="py-8 flex justify-center">
            <Spinner />
          </div>
        ) : rows.length === 0 ? (
          <div className="py-12 flex flex-col items-center text-center gap-3">
            <span className="h-14 w-14 rounded-full bg-slate-100 flex items-center justify-center">
              <Droplets className="h-6 w-6 text-slate-400" />
            </span>
            <p className="text-sm text-slate-600">{t("collection.no_collections_for_date")}</p>
            <Button onClick={() => navigate({ to: "/collection/new" })}>
              <Plus className="h-4 w-4" /> {t("collection.add_collection")}
            </Button>
          </div>
        ) : (
          <div className="rounded-lg overflow-hidden bg-white border border-slate-100">
            {rows.map((r) => {
              const f = farmers[r.farmer_id];
              return (
                <div
                  key={r.id}
                  className="flex items-center gap-3 px-3 py-3 border-b border-slate-100 last:border-b-0"
                >
                  {f ? (
                    <FarmerAvatar farmer={f} size={36} />
                  ) : (
                    <div className="h-9 w-9 rounded-full bg-slate-100" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-slate-800 truncate">
                      {f ? farmerFullName(f) : t("collection.unknown")}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {shiftLabel(t, r.shift)} · {milkTypeLabel(t, r.milk_type)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-500">
                      {t("collection.fat_value", { value: Number(r.fat).toFixed(1) })}
                      {r.snf != null
                        ? ` · ${t("collection.snf_value", { value: Number(r.snf).toFixed(1) })}`
                        : ""}
                    </div>
                    <div className="text-sm font-bold text-slate-800">
                      ₹{Number(r.total_amount).toFixed(2)}
                    </div>
                    <div className="text-xs text-slate-500">
                      {Number(r.quantity_liters).toFixed(1)} L
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setMenuFor(r)}
                    className="h-8 w-8 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100"
                    aria-label={t("collection.more")}
                  >
                    <MoreVertical className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <BottomSheet
        open={!!menuFor}
        onClose={() => setMenuFor(null)}
        title={t("collection.collection")}
      >
        {menuFor && (
          <>
            <SheetItem
              icon={<Pencil className="h-4 w-4" />}
              label={t("collection.edit")}
              onClick={() => {
                const id = menuFor.id;
                setMenuFor(null);
                navigate({ to: "/collection/new", search: { id } });
              }}
            />
            {isOwner && (
              <SheetItem
                icon={<Trash2 className="h-4 w-4" />}
                label={t("collection.delete")}
                danger
                onClick={() => {
                  setConfirmDelete(menuFor);
                  setMenuFor(null);
                }}
              />
            )}
          </>
        )}
      </BottomSheet>

      <BottomSheet
        open={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        title={t("collection.delete_collection_confirm")}
      >
        <div className="px-4 pb-4">
          <p className="text-sm text-slate-600 mb-4">{t("collection.delete_collection_body")}</p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setConfirmDelete(null)}>
              {t("collection.cancel")}
            </Button>
            <Button variant="danger" onClick={onDelete}>
              {t("collection.delete")}
            </Button>
          </div>
        </div>
      </BottomSheet>
    </>
  );
}
