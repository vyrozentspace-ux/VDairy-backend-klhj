import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { MilkSaleForm } from "@/components/MilkSaleForm";
import { useTranslation } from "react-i18next";

import { Spinner } from "@/components/Spinner";
import { getSale, type MilkSale } from "@/lib/milk-sales";

export const Route = createFileRoute("/milk-sale/$id/edit")({
  component: EditSale,
});

function EditSale() {
  const { t } = useTranslation();
  const { id } = useParams({ from: "/milk-sale/$id/edit" });
  const navigate = useNavigate();
  const [sale, setSale] = useState<MilkSale | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    void getSale(id)
      .then(setSale)
      .finally(() => setLoading(false));
  }, [id]);
  if (loading)
    return (
      <div className="p-8 flex justify-center">
        <Spinner size={22} color="#0F766E" />
      </div>
    );
  if (!sale) return <div className="p-8 text-center text-slate-500">{t("sales.saleNotFound")}</div>;
  return (
    <MilkSaleForm
      mode="edit"
      existing={sale}
      onBack={() => navigate({ to: "/milk-sale/$id", params: { id } })}
      onDone={() => navigate({ to: "/milk-sale", replace: true })}
    />
  );
}
