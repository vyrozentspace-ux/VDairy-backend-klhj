import { formatDayMonth } from "@/lib/date-locale";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Plus,
  RefreshCw,
  TrendingDown,
} from "lucide-react";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import {
  categoryLabel,
  formatINR,
  listCategories,
  listExpenses,
  monthLabel,
  monthRange,
  type DairyExpense,
  type ExpenseCategory,
} from "@/lib/expenses";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/expense/")({
  component: ExpenseList,
});

function ExpenseList() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { profile } = useAuth();
  const isOwner = profile?.role === "owner";

  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState<DairyExpense[]>([]);
  const [cats, setCats] = useState<Record<string, ExpenseCategory>>({});
  const [month, setMonth] = useState<Date>(new Date());
  const [showAll, setShowAll] = useState(false);
  const [rFrom, setRFrom] = useState("");
  const [rTo, setRTo] = useState("");
  const [catFilter, setCatFilter] = useState<string>("all");

  async function reload() {
    if (!selected) return;
    setRows([]);
    setLoading(true);
    try {
      const opts = showAll ? { from: rFrom || undefined, to: rTo || undefined } : monthRange(month);
      const [rs, cs] = await Promise.all([
        listExpenses(selected.id, opts),
        listCategories(selected.id),
      ]);
      setRows(rs);
      setCats(Object.fromEntries(cs.map((c) => [c.id, c])));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    void reload(); /* eslint-disable-next-line */
  }, [selected?.id, month, showAll, rFrom, rTo]);

  const filtered = useMemo(() => {
    if (catFilter === "all") return rows;
    return rows.filter(
      (r) => (r.custom_category_label ?? cats[r.category_id]?.name ?? "") === catFilter,
    );
  }, [rows, catFilter, cats]);

  const total = filtered.reduce((a, r) => a + Number(r.amount), 0);

  const catBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of rows) {
      const label = r.custom_category_label ?? cats[r.category_id]?.name ?? "—";
      map.set(label, (map.get(label) ?? 0) + Number(r.amount));
    }
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [rows, cats]);

  const usedCategories = useMemo(() => {
    const set = new Set<string>();
    for (const r of rows) set.add(r.custom_category_label ?? cats[r.category_id]?.name ?? "—");
    return Array.from(set);
  }, [rows, cats]);

  return (
    <div className="min-h-full bg-slate-50 flex flex-col">
      <AppHeader
        title={t("expense.title")}
        onBack={() => navigate({ to: "/dashboard" })}
        right={
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={reload}
              className="w-10 h-10 rounded-full text-slate-600 hover:bg-slate-100 flex items-center justify-center"
              aria-label={t("expense.reload")}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            {isOwner && (
              <button
                type="button"
                onClick={() => navigate({ to: "/expense/new" })}
                className="w-10 h-10 rounded-full bg-teal-700 text-white flex items-center justify-center"
                aria-label={t("expense.add_expense")}
              >
                <Plus className="w-4 h-4" />
              </button>
            )}
          </div>
        }
      />
      {selected && (
        <div className="px-4 py-1.5 text-xs text-slate-500 bg-white border-b border-slate-200">
          {selected.name}
        </div>
      )}

      <div className="bg-white border-b border-slate-200 px-4 py-3">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[10px] uppercase text-slate-400">{t("expense.total_expense")}</div>
            <div className="text-2xl font-bold text-rose-600">{formatINR(total)}</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] uppercase text-slate-400">{t("expense.entries")}</div>
            <div className="text-lg font-bold text-slate-700">{filtered.length}</div>
          </div>
        </div>
        {rows.length > 0 && (
          <div className="mt-3 space-y-1">
            {catBreakdown.slice(0, 5).map(([label, amt]) => (
              <div key={label} className="flex justify-between text-xs">
                <span className="text-slate-500 truncate max-w-[60%]">{label}</span>
                <span className="text-slate-700 font-medium">{formatINR(amt)}</span>
              </div>
            ))}
            {catBreakdown.length > 5 && (
              <div className="text-xs text-slate-400">
                {t("expense.more_categories", { count: catBreakdown.length - 5 })}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="bg-white border-b border-slate-200 px-4 py-2">
        {!showAll ? (
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}
              className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="text-sm font-semibold text-slate-800">{monthLabel(month)}</div>
            <button
              type="button"
              onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}
              className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-800">
                {t("expense.all_records")}
              </span>
              <button
                type="button"
                onClick={() => setShowAll(false)}
                className="text-xs text-teal-600"
              >
                {t("expense.back_to_month")}
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="date"
                value={rFrom}
                onChange={(e) => setRFrom(e.target.value)}
                className="h-10 rounded-lg border border-slate-200 px-2 text-sm"
              />
              <input
                type="date"
                value={rTo}
                onChange={(e) => setRTo(e.target.value)}
                className="h-10 rounded-lg border border-slate-200 px-2 text-sm"
              />
            </div>
          </div>
        )}
      </div>
      {!showAll && (
        <button
          type="button"
          onClick={() => setShowAll(true)}
          className="bg-white border-b border-slate-200 px-4 py-2 text-xs text-teal-600 flex items-center gap-1"
        >
          <CalendarDays className="w-3.5 h-3.5" /> {t("expense.show_all_records")}
        </button>
      )}

      {usedCategories.length > 0 && (
        <div className="bg-white border-b border-slate-200 px-4 py-2 flex gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setCatFilter("all")}
            className={cn(
              "px-3 h-8 rounded-full text-xs font-medium",
              catFilter === "all" ? "bg-teal-700 text-white" : "bg-slate-100 text-slate-500",
            )}
          >
            {t("expense.all")}
          </button>
          {usedCategories.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCatFilter(c)}
              className={cn(
                "px-3 h-8 rounded-full text-xs font-medium max-w-[140px] truncate",
                catFilter === c ? "bg-teal-700 text-white" : "bg-slate-100 text-slate-500",
              )}
            >
              {c}
            </button>
          ))}
        </div>
      )}

      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-8 flex justify-center">
            <Spinner size={22} color="#0F766E" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-3">
              <TrendingDown className="w-6 h-6 text-slate-400" />
            </div>
            <div className="font-semibold text-slate-700">{t("expense.no_expenses_recorded")}</div>
            <div className="text-xs text-slate-500 mt-1 max-w-[240px]">
              {catFilter === "all" ? t("expense.empty_period") : t("expense.empty_category")}
            </div>
            {isOwner && (
              <div className="mt-4 w-full max-w-[220px]">
                <Button onClick={() => navigate({ to: "/expense/new" })}>
                  {t("expense.add_expense_btn")}
                </Button>
              </div>
            )}
          </div>
        ) : (
          <ul className="bg-white divide-y">
            {filtered.map((r) => {
              const label = categoryLabel(r, cats[r.category_id]);
              const date = formatDayMonth(r.expense_date);
              const parts = [date, r.note, r.payment_mode ? r.payment_mode.toUpperCase() : null]
                .filter(Boolean)
                .join(" · ");
              return (
                <li key={r.id}>
                  <button
                    type="button"
                    onClick={() => navigate({ to: "/expense/$id", params: { id: r.id } })}
                    className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-slate-50"
                  >
                    <div className="w-9 h-9 rounded-full bg-rose-50 flex items-center justify-center flex-shrink-0">
                      <TrendingDown className="w-4 h-4 text-rose-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-slate-800 truncate">{label}</div>
                      <div className="text-xs text-slate-500 truncate">{parts}</div>
                    </div>
                    <div className="text-sm font-bold text-rose-600">
                      {formatINR(Number(r.amount))}
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
