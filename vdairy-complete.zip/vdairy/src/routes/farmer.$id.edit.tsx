import { createFileRoute } from "@tanstack/react-router";
import { FarmerForm } from "@/components/FarmerForm";

export const Route = createFileRoute("/farmer/$id/edit")({
  component: EditFarmer,
});

function EditFarmer() {
  const { id } = Route.useParams();
  return <FarmerForm farmerId={id} />;
}
