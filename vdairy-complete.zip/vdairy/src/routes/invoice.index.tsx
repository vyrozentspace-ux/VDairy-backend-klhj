import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import {
  CheckCircle,
  ChevronDown,
  FileText,
  IndianRupee,
  Loader2,
  MoreVertical,
  PhoneOff,
  Plus,
  RefreshCw,
} from "lucide-react";

import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { fetchFarmers, farmerFullName, type Farmer } from "@/lib/farmers";
import {
  computePreview,
  confirmInvoicePayment,
  createInvoicePayment,
  farmersWithActivity,
  fmtDMYShort,
  generateInvoice,
  listInvoices,
  logInvoice,
  markInvoicePaid,
  markInvoiceUnpaid,
  type Invoice,
} from "@/lib/invoices";
import { usePeriodConfig } from "@/hooks/usePeriodConfig";
import { periodForDate, periodOptions } from "@/lib/payment-periods";
import { buildInvoiceSmsFromDetail, invoiceSmsText, openSmsApp } from "@/lib/sms-receipt";
import { cn } from "@/lib/utils";

const searchSchema = z.object({ farmer_id: z.string().optional() });

export const Route = createFileRoute("/invoice/")({
  validateSearch: searchSchema,
  component: InvoiceListScreen,
});

type Row = {
  farmer: Farmer;
  invoice: Invoice | null;
  amount_due: number;
  new_balance: number;
  total_liter: number;
  total_milk_amount: number;
  total_deduction: number;
  total_feed_amount: number;
  manual_deductions: number;
  previous_balance: number;
  total_advance_given: number;
  status: "Unpaid" | "Paid";
};

function InvoiceListScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { farmer_id: filterFarmerId } = useSearch({ from: "/invoice/" });
  const { selected } = useCenter();
  const { userId } = useAuth();

  const [periodOpen, setPeriodOpen] = useState(false);
  const { config, loaded: configLoaded } = usePeriodConfig();
  const [{ start, end }, setPeriod] = useState(() =>
    periodForDate({ paymentPeriod: null, startDate: null }),
  );
  const [periodTouched, setPeriodTouched] = useState(false);
  const [pendingStart, setPendingStart] = useState(start);
  const [pendingEnd, setPendingEnd] = useState(end);

  // Once the center's configured cycle is known, snap to the period it defines.
  useEffect(() => {
    if (!configLoaded || periodTouched) return;
    setPeriod(periodForDate(config));
  }, [configLoaded, config.paymentPeriod, config.startDate, periodTouched]);

  const [tab, setTab] = useState<"Unpaid" | "Paid">("Unpaid");
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const [payFallback, setPayFallback] = useState<{
    row: Row;
    upiUri: string;
    paymentId: string;
  } | null>(null);
  const [payConfirm, setPayConfirm] = useState<{ row: Row; paymentId: string } | null>(null);
  const [paySheet, setPaySheet] = useState<Row | null>(null);
  const [confirmGen, setConfirmGen] = useState<{ missing: Row[]; count: number } | null>(null);
  const visibilityRef = useRef<{ paymentId: string; row: Row } | null>(null);

  useEffect(() => {
    setPendingStart(start);
    setPendingEnd(end);
  }, [start, end]);

  // Guards against an earlier load (default period, before the center's
  // configured cycle resolves) overwriting newer results.
  const loadSeq = useRef(0);

  const load = async () => {
    if (!selected) return;
    const seq = ++loadSeq.current;
    const stale = () => seq !== loadSeq.current;
    setRows([]);
    setLoading(true);
    try {
      const [allFarmers, invs, activeIds] = await Promise.all([
        fetchFarmers(selected.id),
        listInvoices(selected.id, { farmerId: filterFarmerId, from: start, to: end }),
        farmersWithActivity(selected.id, start, end),
      ]);
      const invByFarmer = new Map<string, Invoice>();
      for (const iv of invs) {
        if (iv.period_start === start && iv.period_end === end) invByFarmer.set(iv.farmer_id, iv);
      }
      const candidates = filterFarmerId
        ? allFarmers.filter((f) => f.id === filterFarmerId)
        : allFarmers.filter((f) => activeIds.has(f.id) || invByFarmer.has(f.id));

      const built: Row[] = await Promise.all(
        candidates.map(async (f) => {
          const inv = invByFarmer.get(f.id) ?? null;
          if (inv) {
            return {
              farmer: f,
              invoice: inv,
              amount_due: Number(inv.amount_due),
              new_balance: Number(inv.new_balance),
              total_liter: Number(inv.total_liter),
              total_milk_amount: Number(inv.total_milk_amount),
              total_deduction: Number(inv.total_deduction),
              total_feed_amount: Number(inv.total_feed_amount),
              manual_deductions: Number(inv.total_deduction) - Number(inv.total_feed_amount),
              previous_balance: Number(inv.previous_balance),
              total_advance_given: Number(inv.total_advance_given),
              status: inv.status,
            };
          }
          const p = await computePreview({
            centerId: selected.id,
            farmerId: f.id,
            periodStart: start,
            periodEnd: end,
          });
          return {
            farmer: f,
            invoice: null,
            amount_due: p.amount_due,
            new_balance: p.new_balance,
            total_liter: p.total_liter,
            total_milk_amount: p.total_milk_amount,
            total_deduction: p.total_deduction,
            total_feed_amount: p.total_feed_amount,
            manual_deductions: p.manual_deductions,
            previous_balance: p.previous_balance,
            total_advance_given: p.total_advance_given,
            status: "Unpaid",
          };
        }),
      );

      if (stale()) return;
      built.sort((a, b) => farmerFullName(a.farmer).localeCompare(farmerFullName(b.farmer)));
      setRows(built);
    } catch (err) {
      if (!stale()) toast.error(err instanceof Error ? err.message : t("invoice.loadFailed"));
    } finally {
      if (seq === loadSeq.current) setLoading(false);
    }
  };

  useEffect(() => {
    void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [selected?.id, start, end, filterFarmerId]);

  const filteredRows = useMemo(() => rows.filter((r) => r.status === tab), [rows, tab]);
  const unpaidCount = rows.filter((r) => r.status === "Unpaid").length;
  const paidCount = rows.filter((r) => r.status === "Paid").length;

  const summary = useMemo(
    () =>
      filteredRows.reduce(
        (acc, r) => ({
          liter: acc.liter + r.total_liter,
          milk: acc.milk + r.total_milk_amount,
          deduction: acc.deduction + r.total_deduction,
          due: acc.due + r.amount_due,
          count: acc.count + 1,
        }),
        { liter: 0, milk: 0, deduction: 0, due: 0, count: 0 },
      ),
    [filteredRows],
  );

  const applyPeriod = () => {
    if (pendingStart && pendingEnd && pendingStart <= pendingEnd) {
      setPeriod({ start: pendingStart, end: pendingEnd });
      setPeriodTouched(true);
    }
    setPeriodOpen(false);
  };

  const openRow = (r: Row) => {
    if (r.invoice)
      navigate({ to: "/invoice/view/$invoiceId", params: { invoiceId: r.invoice.id } });
    else
      navigate({
        to: "/invoice/preview/$farmerId",
        params: { farmerId: r.farmer.id },
        search: { start, end },
      });
  };

  const ensureInvoice = async (r: Row): Promise<string> => {
    if (r.invoice) return r.invoice.id;
    if (!selected) throw new Error("No center");
    const id = await generateInvoice({
      centerId: selected.id,
      farmerId: r.farmer.id,
      periodStart: start,
      periodEnd: end,
      createdBy: userId,
    });
    await logInvoice(selected.id, userId, "invoice_generated", {
      invoice_id: id,
      farmer_id: r.farmer.id,
      period_start: start,
      period_end: end,
    });
    return id;
  };

  const runGenerateAll = async (missing: Row[]) => {
    if (!selected) return;
    setGenerating(true);
    try {
      for (const r of missing) {
        await generateInvoice({
          centerId: selected.id,
          farmerId: r.farmer.id,
          periodStart: start,
          periodEnd: end,
          createdBy: userId,
        });
        await logInvoice(selected.id, userId, "invoice_generated", {
          farmer_id: r.farmer.id,
          period_start: start,
          period_end: end,
        });
      }
      toast.success(t("invoice.generated", { count: missing.length }));
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.generateFailed"));
    } finally {
      setGenerating(false);
    }
  };

  const generateAllMissing = () => {
    if (!selected) return;
    const missing = rows.filter((r) => !r.invoice);
    if (missing.length === 0) {
      toast.info(t("invoice.noNewInvoices"));
      return;
    }
    setConfirmGen({ missing, count: missing.length });
  };

  /** Build the full itemized invoice receipt text (needs one detail read). */
  const buildInvoiceSms = async (r: Row) => {
    if (!selected) return "";
    const { fetchReceiptDetail } = await import("@/lib/invoices");
    const detail = await fetchReceiptDetail({
      centerId: selected.id,
      farmerId: r.farmer.id,
      periodStart: start,
      periodEnd: end,
    });
    return buildInvoiceSmsFromDetail({
      centerName: selected.name,
      farmerName: farmerFullName(r.farmer),
      farmerCode: r.farmer.code,
      periodStart: fmtDMYShort(start),
      periodEnd: fmtDMYShort(end),
      fmtDate: fmtDMYShort,
      detail,
      totals: {
        total_liter: r.total_liter,
        total_milk_amount: r.total_milk_amount,
        total_feed_amount: r.total_feed_amount,
        manual_deductions: r.manual_deductions,
        total_deduction: r.total_deduction,
        amount_due: r.amount_due,
        new_balance: r.new_balance,
        previous_balance: r.previous_balance,
        total_advance_given: r.total_advance_given,
      },
    });
  };

  /** Auto-open the native SMS app with the full itemized invoice receipt. */
  const sendInvoiceSms = async (r: Row) => {
    const text = await buildInvoiceSms(r);
    if (text) openSmsApp(r.farmer.mobile, text);
  };

  const quickPaid = async (r: Row) => {
    if (!selected) return;
    // Start the receipt read in parallel with the write so the SMS app opens
    // as soon as possible instead of after the whole save chain.
    const smsPromise = buildInvoiceSms(r).catch(() => "");
    try {
      const invId = await ensureInvoice(r);
      const paid = markInvoicePaid(invId);
      const text = await smsPromise;
      if (text) openSmsApp(r.farmer.mobile, text);
      await paid;
      toast.success(t("invoice.markedPaid"));
      void logInvoice(selected.id, userId, "invoice_marked_paid", {
        invoice_id: invId,
        farmer_id: r.farmer.id,
      });
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedUnknown"));
    }
  };

  /** Long-press on a Paid invoice reveals "Mark as Unpaid". */
  const [unpaidSheet, setUnpaidSheet] = useState<Row | null>(null);
  const holdTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startHold = (r: Row) => {
    if (r.status !== "Paid" || !r.invoice?.id) return;
    holdTimer.current = setTimeout(() => setUnpaidSheet(r), 550);
  };
  const cancelHold = () => {
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
  };
  const doMarkUnpaid = async (r: Row) => {
    setUnpaidSheet(null);
    if (!selected || !r.invoice?.id) return;
    try {
      await markInvoiceUnpaid(r.invoice?.id);
      await logInvoice(selected.id, userId, "invoice_marked_unpaid", {
        invoice_id: r.invoice?.id,
        farmer_id: r.farmer.id,
      });
      toast.success(t("invoice.markedUnpaid"));
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedUnknown"));
    }
  };

  /** Net Payment (post-deduction) — the exact figure shown on the receipt. */
  const netPayable = (r: Row) => r.new_balance;
  /** UPI can only send money out — a non-positive net means the farmer owes the center. */
  const canUpiPay = (r: Row) => netPayable(r) > 0.009;

  const startUpiPay = (r: Row) => {
    if (!selected) return;
    if (!canUpiPay(r)) {
      toast.error(t("invoice.nothingPayable"));
      return;
    }
    const payTo = r.farmer.payment_mobile || r.farmer.mobile;
    if (!payTo) return;

    // Build UPI URI synchronously and fire the redirect FIRST so the UPI app
    // launches instantly on tap. All DB / logging work happens after.
    const upiUri = `upi://pay?pa=${encodeURIComponent(payTo)}@upi&pn=${encodeURIComponent(farmerFullName(r.farmer))}&am=${netPayable(r).toFixed(2)}&tn=${encodeURIComponent(`Invoice — ${selected.name}`)}&cu=INR`;

    let opened = false;
    const startedAt = Date.now();
    const onVisibility = () => {
      if (document.hidden) opened = true;
    };
    document.addEventListener("visibilitychange", onVisibility);

    try {
      window.location.href = upiUri;
    } catch {
      /* handled below */
    }

    // Persist invoice + payment record in the background (does not block the redirect).
    void (async () => {
      try {
        const invId = await ensureInvoice(r);
        const paymentId = await createInvoicePayment({
          invoiceId: invId,
          farmerId: r.farmer.id,
          amount: netPayable(r),
          paymentNumberUsed: payTo,
          upiUri,
          initiatedBy: userId,
        });

        setTimeout(() => {
          document.removeEventListener("visibilitychange", onVisibility);
          if (!opened && Date.now() - startedAt < 3000) {
            setPayFallback({ row: r, upiUri, paymentId });
          } else {
            visibilityRef.current = { paymentId, row: r };
          }
        }, 1200);
      } catch (err) {
        document.removeEventListener("visibilitychange", onVisibility);
        toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedToRecord"));
      }
    })();
  };

  // When user returns to tab after UPI app, show confirm dialog
  useEffect(() => {
    const onVis = () => {
      if (!document.hidden && visibilityRef.current) {
        setPayConfirm(visibilityRef.current);
        visibilityRef.current = null;
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  const confirmUpiPayment = async (paymentId: string, row: Row) => {
    if (!selected) return;
    try {
      await confirmInvoicePayment(paymentId);
      await logInvoice(selected.id, userId, "invoice_paid_via_upi", {
        payment_id: paymentId,
        farmer_id: row.farmer.id,
      });
      toast.success(t("invoice.paymentConfirmed"));
      setPayConfirm(null);
      setPayFallback(null);
      sendInvoiceSms(row);
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("invoice.paymentFailedUnknown"));
    }
  };

  return (
    <>
      <AppHeader
        title={t("invoice.title")}
        onBack={() => navigate({ to: "/dashboard" })}
        right={
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => void load()}
              aria-label={t("invoice.reload")}
              className="h-9 w-9 rounded-full text-slate-600 hover:bg-slate-100 flex items-center justify-center"
            >
              <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
            </button>
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-label={t("invoice.more")}
              className="h-9 w-9 rounded-full text-slate-600 hover:bg-slate-100 flex items-center justify-center"
            >
              <MoreVertical className="h-4 w-4" />
            </button>
          </div>
        }
      />

      <div className="text-xs text-slate-500 px-4 pt-2">{selected?.name}</div>

      {/* Generate bar */}
      <div className="mt-2 bg-teal-50 border-y border-teal-100 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-teal-800 font-medium">
          <FileText className="h-4 w-4" /> {t("invoice.title")}
        </div>
        <button
          type="button"
          onClick={generateAllMissing}
          disabled={generating}
          className="inline-flex items-center gap-1.5 rounded-md border border-teal-600 bg-white text-teal-700 text-xs font-semibold px-3 py-1.5 hover:bg-teal-50 disabled:opacity-60"
        >
          {generating ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <Plus className="h-3.5 w-3.5" />
          )}
          {t("invoice.generateInvoice")}
        </button>
      </div>

      {/* Period selector */}
      <div className="border-b border-slate-200 bg-white px-4 py-3">
        <button
          type="button"
          onClick={() => setPeriodOpen((v) => !v)}
          className="w-full inline-flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
        >
          <span>
            {fmtDMYShort(start)} - {fmtDMYShort(end)}
          </span>
          <ChevronDown className={cn("h-4 w-4 transition", periodOpen && "rotate-180")} />
        </button>
        {periodOpen && (
          <div className="mt-3 space-y-3">
            <div className="text-[11px] uppercase font-semibold text-slate-400 tracking-wide">
              {t("invoice.quickSelect")}
            </div>
            <div className="flex flex-wrap gap-2">
              {periodOptions(config).map((p) => (
                <button
                  key={`${p.start}-${p.end}`}
                  type="button"
                  onClick={() => {
                    setPendingStart(p.start);
                    setPendingEnd(p.end);
                  }}
                  className={cn(
                    "rounded-full px-3 py-1 text-xs font-semibold border",
                    pendingStart === p.start && pendingEnd === p.end
                      ? "bg-teal-600 border-teal-600 text-white"
                      : "bg-white border-slate-200 text-slate-700",
                  )}
                >
                  {fmtDMYShort(p.start)} – {fmtDMYShort(p.end)}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <label className="text-xs text-slate-500">
                {t("invoice.from")}
                <input
                  type="date"
                  value={pendingStart}
                  onChange={(e) => setPendingStart(e.target.value)}
                  className="mt-1 w-full h-10 rounded-lg border border-slate-200 px-2 text-sm"
                />
              </label>
              <label className="text-xs text-slate-500">
                {t("invoice.to")}
                <input
                  type="date"
                  value={pendingEnd}
                  onChange={(e) => setPendingEnd(e.target.value)}
                  className="mt-1 w-full h-10 rounded-lg border border-slate-200 px-2 text-sm"
                />
              </label>
            </div>
            <Button onClick={applyPeriod}>{t("invoice.apply")}</Button>
          </div>
        )}
      </div>

      {/* Paid/Unpaid tabs */}
      <div className="border-b border-slate-200 bg-white px-4 py-2 flex gap-2">
        {(["Unpaid", "Paid"] as const).map((st) => {
          const active = tab === st;
          const count = st === "Unpaid" ? unpaidCount : paidCount;
          return (
            <button
              key={st}
              type="button"
              onClick={() => setTab(st)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold",
                active ? "bg-teal-700 text-white" : "bg-slate-100 text-slate-600",
              )}
            >
              {st === "Unpaid" ? t("invoice.status.unpaid") : t("invoice.status.paid")}
              <span
                className={cn(
                  "rounded-full px-1.5 py-0.5 text-[10px]",
                  active ? "bg-white/20" : "bg-white text-slate-500",
                )}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* List */}
      <div className="pb-24">
        {loading ? (
          <div className="p-4 space-y-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 animate-pulse">
                <div className="h-9 w-9 rounded-full bg-slate-100" />
                <div className="flex-1 space-y-1.5">
                  <div className="h-3 w-32 bg-slate-100 rounded" />
                  <div className="h-2.5 w-20 bg-slate-100 rounded" />
                </div>
                <div className="h-8 w-16 bg-slate-100 rounded" />
              </div>
            ))}
          </div>
        ) : filteredRows.length === 0 ? (
          <div className="py-16 text-center text-sm text-slate-500">
            {rows.length === 0
              ? t("invoice.noActivityInPeriod")
              : t("invoice.noStatusInvoices", { status: tab.toLowerCase() })}
          </div>
        ) : (
          <div className="divide-y divide-slate-100 bg-white">
            {filteredRows.map((r, idx) => {
              const payTo = r.farmer.payment_mobile || r.farmer.mobile;
              return (
                <div
                  key={r.farmer.id}
                  className="flex items-center gap-3 px-4 py-3"
                  onPointerDown={() => startHold(r)}
                  onPointerUp={cancelHold}
                  onPointerLeave={cancelHold}
                  onPointerCancel={cancelHold}
                  onContextMenu={(e) => {
                    if (r.status === "Paid") {
                      e.preventDefault();
                      setUnpaidSheet(r);
                    }
                  }}
                >
                  <button
                    type="button"
                    onClick={() => openRow(r)}
                    className="flex-1 flex items-center gap-3 text-left min-w-0"
                  >
                    <div className="w-8 flex flex-col items-center text-slate-500 shrink-0">
                      <span className="text-sm font-semibold">{idx + 1}</span>
                      {r.status === "Paid" && (
                        <CheckCircle className="h-3.5 w-3.5 text-teal-600 mt-0.5" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div
                        className={cn(
                          "text-sm font-semibold truncate",
                          r.new_balance < 0 ? "text-rose-600" : "text-emerald-700",
                        )}
                      >
                        {farmerFullName(r.farmer)}
                      </div>
                      <div className="text-xs text-slate-500">Code {r.farmer.code}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div
                        className={cn(
                          "text-sm font-bold",
                          r.new_balance < 0 ? "text-rose-600" : "text-emerald-600",
                        )}
                      >
                        ₹{r.amount_due.toFixed(2)}
                      </div>
                      <div
                        className={cn(
                          "text-xs",
                          r.new_balance < 0 ? "text-rose-600" : "text-emerald-600",
                        )}
                      >
                        {r.new_balance < 0 ? "-" : ""}₹{Math.abs(r.new_balance).toFixed(2)}
                      </div>
                    </div>
                  </button>
                  {r.status === "Unpaid" && (
                    <div className="flex flex-col gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => void quickPaid(r)}
                        className="inline-flex items-center gap-1 rounded-md bg-teal-700 text-white text-[11px] font-semibold px-2 py-1 hover:bg-teal-800"
                      >
                        <CheckCircle className="h-3 w-3" /> {t("invoice.paidButton")}
                      </button>
                      {canUpiPay(r) &&
                        (payTo ? (
                          <button
                            type="button"
                            onClick={() => setPaySheet(r)}
                            className="inline-flex items-center gap-1 rounded-md bg-emerald-600 text-white text-[11px] font-semibold px-2 py-1 hover:bg-emerald-700"
                          >
                            <IndianRupee className="h-3 w-3" /> {t("invoice.pay")}
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              navigate({ to: "/farmer/$id/edit", params: { id: r.farmer.id } })
                            }
                            className="inline-flex items-center gap-1 rounded-md bg-slate-200 text-slate-500 text-[11px] font-semibold px-2 py-1"
                          >
                            <PhoneOff className="h-3 w-3" /> {t("invoice.noMobile")}
                          </button>
                        ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom summary bar */}
      <div className="fixed bottom-0 left-0 right-0 border-t border-slate-200 bg-white px-2 py-2 safe-bottom">
        <div className="grid grid-cols-5 gap-1 text-center text-xs">
          <div>
            <div className="text-slate-400 text-[10px]">{t("invoice.liters")}</div>
            <div className="font-semibold">{summary.liter.toFixed(1)}</div>
          </div>
          <div>
            <div className="text-slate-400 text-[10px]">{t("invoice.summaryAmount")}</div>
            <div className="font-semibold text-teal-700">₹{summary.milk.toFixed(0)}</div>
          </div>
          <div>
            <div className="text-slate-400 text-[10px]">{t("invoice.deducted")}</div>
            <div className="font-semibold">₹{summary.deduction.toFixed(0)}</div>
          </div>
          <div>
            <div className="text-slate-400 text-[10px]">{t("invoice.due")}</div>
            <div className="font-semibold text-emerald-600">₹{summary.due.toFixed(0)}</div>
          </div>
          <div>
            <div className="text-slate-400 text-[10px]">{t("invoice.farmers")}</div>
            <div className="font-semibold">{summary.count}</div>
          </div>
        </div>
      </div>

      <BottomSheet open={menuOpen} onClose={() => setMenuOpen(false)}>
        <SheetItem
          icon={<CheckCircle className="h-4 w-4" />}
          label={t("invoice.viewPaidInvoices")}
          onClick={() => {
            setTab("Paid");
            setMenuOpen(false);
          }}
        />
      </BottomSheet>

      {/* Long-press on a Paid invoice → revert to Unpaid */}
      <BottomSheet
        open={!!unpaidSheet}
        onClose={() => setUnpaidSheet(null)}
        title={unpaidSheet ? farmerFullName(unpaidSheet.farmer) : ""}
      >
        {unpaidSheet && (
          <SheetItem
            icon={<CheckCircle className="h-4 w-4" />}
            label={t("invoice.actions.markAsUnpaid")}
            onClick={() => {
              void doMarkUnpaid(unpaidSheet);
            }}
          />
        )}
      </BottomSheet>

      {/* Quick pay confirmation sheet — pay without opening the invoice */}
      <BottomSheet
        open={!!paySheet}
        onClose={() => setPaySheet(null)}
        title={t("invoice.actions.payNow")}
      >
        {paySheet && (
          <div className="px-3 pb-2">
            <div className="rounded-lg border border-slate-200 p-3">
              <div className="text-sm text-slate-500">{t("invoice.paying")}</div>
              <div className="text-base font-semibold text-slate-800">
                {farmerFullName(paySheet.farmer)}
              </div>
              <div className="text-xs text-slate-500">Code {paySheet.farmer.code}</div>
              <div className="mt-3 flex items-end justify-between">
                <span className="text-xs uppercase font-semibold text-slate-400">
                  {t("invoice.amountDue")}
                </span>
                <span className="text-2xl font-bold text-emerald-600">
                  ₹{netPayable(paySheet).toFixed(2)}
                </span>
              </div>
              <div className="mt-1 text-[11px] text-slate-400 text-right">
                Milk ₹{paySheet.total_milk_amount.toFixed(2)} − {t("invoice.totalDeduction")} ₹
                {paySheet.total_deduction.toFixed(2)}
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPaySheet(null)}
                className="h-11 rounded-lg bg-slate-100 text-slate-700 text-sm font-semibold"
              >
                {t("invoice.noCancel")}
              </button>
              <button
                type="button"
                data-testid="confirm-pay"
                onClick={() => {
                  const r = paySheet;
                  setPaySheet(null);
                  if (r) startUpiPay(r);
                }}
                className="h-11 rounded-lg bg-emerald-600 text-white text-sm font-semibold inline-flex items-center justify-center gap-1.5"
              >
                <IndianRupee className="h-4 w-4" /> {t("invoice.payViaUpi")}
              </button>
            </div>
          </div>
        )}
      </BottomSheet>

      <ConfirmDialog
        open={!!confirmGen}
        title={t("invoice.generateInvoice")}
        message={confirmGen ? t("invoice.confirmGenerateBulk", { count: confirmGen.count }) : ""}
        confirmLabel={t("invoice.generateInvoice")}
        onCancel={() => setConfirmGen(null)}
        onConfirm={() => {
          const c = confirmGen;
          setConfirmGen(null);
          if (c) void runGenerateAll(c.missing);
        }}
      />

      {/* UPI fallback modal */}
      {payFallback && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 px-4">
          <div className="w-full max-w-sm bg-white rounded-xl p-4 shadow-2xl">
            <div className="text-[11px] font-bold uppercase tracking-wide text-teal-600">
              {t("invoice.upiFallbackBrand")}
            </div>
            <div className="text-base font-semibold text-slate-800">
              {t("invoice.upiFallbackTitle")}
            </div>
            <p className="mt-1 text-sm text-slate-600">{t("invoice.upiFallbackDescription")}</p>
            <div className="mt-3 rounded-lg border border-slate-200 p-3 space-y-2 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">{t("invoice.upiFallbackMobileLabel")}</span>
                <span className="font-medium text-slate-800">
                  {payFallback.row.farmer.payment_mobile || payFallback.row.farmer.mobile}
                </span>
                <button
                  type="button"
                  className="text-xs text-teal-600 font-semibold ml-2"
                  onClick={() =>
                    navigator.clipboard.writeText(
                      payFallback.row.farmer.payment_mobile || payFallback.row.farmer.mobile || "",
                    )
                  }
                >
                  {t("invoice.upiFallbackCopy")}
                </button>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">{t("invoice.upiFallbackAmountLabel")}</span>
                <span className="font-medium text-slate-800">
                  ₹{netPayable(payFallback.row).toFixed(2)}
                </span>
                <button
                  type="button"
                  className="text-xs text-teal-600 font-semibold ml-2"
                  onClick={() =>
                    navigator.clipboard.writeText(netPayable(payFallback.row).toFixed(2))
                  }
                >
                  {t("invoice.upiFallbackCopy")}
                </button>
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                navigator.clipboard.writeText(
                  `${payFallback.row.farmer.payment_mobile || payFallback.row.farmer.mobile} — ₹${netPayable(payFallback.row).toFixed(2)}`,
                )
              }
              className="mt-3 w-full h-10 rounded-lg bg-slate-100 text-slate-700 text-sm font-semibold hover:bg-slate-200"
            >
              {t("invoice.upiFallbackCopyAll")}
            </button>
            <p className="mt-4 text-sm text-slate-700 text-center">
              {t("invoice.upiConfirmQuestion", {
                amount: netPayable(payFallback.row).toFixed(2),
                name: farmerFullName(payFallback.row.farmer),
              })}
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPayFallback(null)}
                className="h-10 rounded-lg bg-slate-100 text-slate-700 text-sm font-semibold"
              >
                {t("invoice.noCancel")}
              </button>
              <button
                type="button"
                onClick={() => void confirmUpiPayment(payFallback.paymentId, payFallback.row)}
                className="h-10 rounded-lg bg-emerald-600 text-white text-sm font-semibold"
              >
                {t("invoice.yesPaid")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UPI return confirmation */}
      {payConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 px-4">
          <div className="w-full max-w-sm bg-white rounded-xl p-4 shadow-2xl">
            <div className="text-base font-semibold text-slate-800">
              {t("invoice.paymentConfirmTitle")}
            </div>
            <p className="mt-2 text-sm text-slate-700">
              {t("invoice.paymentConfirmQuestion", {
                amount: netPayable(payConfirm.row).toFixed(2),
                name: farmerFullName(payConfirm.row.farmer),
              })}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPayConfirm(null)}
                className="h-10 rounded-lg bg-slate-100 text-slate-700 text-sm font-semibold"
              >
                {t("invoice.noCancel")}
              </button>
              <button
                type="button"
                onClick={() => void confirmUpiPayment(payConfirm.paymentId, payConfirm.row)}
                className="h-10 rounded-lg bg-emerald-600 text-white text-sm font-semibold"
              >
                {t("invoice.yesPaid")}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
