import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Alert } from "@/components/Alert";
import { Dropdown } from "@/components/Dropdown";
import { PAYMENT_PERIOD_OPTIONS } from "@/lib/payment-periods";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/onboarding/create-center")({
  ssr: false,
  component: CreateCenterScreen,
});

function randomCode(len = 6) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function CreateCenterScreen() {
  const { t } = useTranslation();
  const { userId, profile } = useAuth();
  const { refresh, select } = useCenter();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [code, setCode] = useState(() => randomCode());
  const [village, setVillage] = useState("");
  const [taluka, setTaluka] = useState("");
  const [district, setDistrict] = useState("");
  const [state, setStateVal] = useState("");
  const [pincode, setPincode] = useState("");
  const [contact, setContact] = useState("");
  const [paymentPeriod, setPaymentPeriod] = useState<string>("01-ME");
  const [periodStart, setPeriodStart] = useState("");
  const [referredBy, setReferredBy] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (profile?.phone && !contact) setContact(profile.phone);
  }, [profile?.phone, contact]);

  const isDayCount = useMemo(
    () => PAYMENT_PERIOD_OPTIONS.find((o) => o.value === paymentPeriod)?.isDayCount ?? false,
    [paymentPeriod],
  );

  const canSubmit = name.trim().length >= 2 && code.length === 6 && paymentPeriod;

  const submit = async () => {
    if (!canSubmit || !userId) return;
    setLoading(true);
    setError("");
    try {
      // Ensure profile row exists (handles the rare race with the signup trigger)
      let profileOk = false;
      for (let i = 0; i < 5; i++) {
        const { data: p } = await supabase
          .from("profiles")
          .select("id")
          .eq("id", userId)
          .maybeSingle();
        if (p?.id) {
          profileOk = true;
          break;
        }
        await new Promise((r) => setTimeout(r, 300));
      }
      if (!profileOk) throw new Error(t("auth.account_still_setting_up"));

      const { data: dup } = await supabase
        .from("dairy_centers")
        .select("id")
        .eq("code", code)
        .maybeSingle();
      if (dup) throw new Error(t("auth.code_already_taken"));

      const referralCode = randomCode(8);
      const referrer = referredBy.trim().toUpperCase();
      if (referrer) {
        const { data: ref } = await supabase
          .from("dairy_centers")
          .select("id")
          .eq("referral_code", referrer)
          .maybeSingle();
        if (!ref) throw new Error(t("auth.referral_code_invalid"));
      }
      const { data: inserted, error: insErr } = await supabase
        .from("dairy_centers")
        .insert({
          owner_id: userId,
          name: name.trim(),
          code,
          village: village.trim() || null,
          taluka: taluka.trim() || null,
          district: district.trim() || null,
          state: state.trim() || null,
          pincode: pincode.trim() || null,
          contact_number: contact.trim() || null,
          referral_code: referralCode,
          referred_by_code: referrer || null,
          default_language: profile?.language_preference ?? "en",
        })
        .select("id")
        .single();
      if (insErr) throw new Error(insErr.message);

      await supabase.from("center_collection_settings").insert({
        center_id: inserted.id,
        calculation_mode: "fat_snf",
        payment_period: paymentPeriod,
        payment_period_start_date: periodStart || null,
      });

      await supabase.from("center_subscriptions").insert({
        center_id: inserted.id,
        status: "trial",
      });

      await refresh();
      select(inserted.id);
      navigate({ to: "/dashboard", replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("auth.could_not_create_center"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={t("auth.create_center")} />
      <div className="max-w-md mx-auto px-6 py-6 flex flex-col gap-4 pb-24">
        {error && <Alert message={error} />}

        <Field label={t("auth.center_name")}>
          <TextInput
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("auth.center_name_placeholder")}
          />
        </Field>

        <Field label={t("auth.center_code")} hint={t("auth.center_code_hint")}>
          <TextInput
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase().slice(0, 6))}
            maxLength={6}
            suffix={
              <button
                type="button"
                onClick={() => setCode(randomCode())}
                className="p-2 text-slate-500 hover:text-teal-700"
                aria-label={t("auth.regenerate_code")}
              >
                <RefreshCw className="h-4 w-4" />
              </button>
            }
          />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label={t("auth.village")} className="col-span-2">
            <TextInput value={village} onChange={(e) => setVillage(e.target.value)} />
          </Field>
          <Field label={t("auth.taluka")}>
            <TextInput value={taluka} onChange={(e) => setTaluka(e.target.value)} />
          </Field>
          <Field label={t("auth.district")}>
            <TextInput value={district} onChange={(e) => setDistrict(e.target.value)} />
          </Field>
          <Field label={t("auth.state")}>
            <TextInput value={state} onChange={(e) => setStateVal(e.target.value)} />
          </Field>
          <Field label={t("auth.pincode")}>
            <TextInput
              value={pincode}
              inputMode="numeric"
              maxLength={6}
              onChange={(e) => setPincode(e.target.value.replace(/\D/g, "").slice(0, 6))}
            />
          </Field>
        </div>

        <Field label={t("auth.contact_number")}>
          <TextInput
            prefix="+91"
            inputMode="numeric"
            maxLength={10}
            value={contact}
            onChange={(e) => setContact(e.target.value.replace(/\D/g, "").slice(0, 10))}
          />
        </Field>

        <Field label={t("auth.payment_period")}>
          <Dropdown
            value={paymentPeriod}
            onChange={setPaymentPeriod}
            options={PAYMENT_PERIOD_OPTIONS.map((o) => ({ value: o.value, label: o.label }))}
          />
        </Field>

        <Field label={t("auth.dairy_start_date")} hint={t("auth.dairy_start_date_hint")}>
          <TextInput
            type="date"
            value={periodStart}
            onChange={(e) => setPeriodStart(e.target.value)}
          />
        </Field>

        <Field label={t("auth.referral_code")} hint={t("auth.referral_code_hint")}>
          <TextInput
            value={referredBy}
            maxLength={8}
            autoCapitalize="characters"
            placeholder={t("auth.referral_code_placeholder")}
            onChange={(e) =>
              setReferredBy(
                e.target.value
                  .replace(/[^A-Za-z0-9]/g, "")
                  .toUpperCase()
                  .slice(0, 8),
              )
            }
          />
        </Field>

        <Button onClick={submit} disabled={!canSubmit} loading={loading}>
          {t("auth.create_center")}
        </Button>
      </div>
    </div>
  );
}
