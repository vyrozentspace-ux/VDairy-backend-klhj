import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Field, TextInput } from "@/components/Field";
import { Button } from "@/components/Button";
import { Alert } from "@/components/Alert";
import { Dropdown } from "@/components/Dropdown";
import { LANGUAGES, setAppLanguage } from "@/lib/i18n";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/profile")({
  ssr: false,
  component: ProfileScreen,
});

function ProfileScreen() {
  const { t } = useTranslation();
  const { profile, refreshProfile, session, loading } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [lang, setLang] = useState("en");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/login", replace: true });
  }, [loading, session, navigate]);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name ?? "");
      setLang(profile.language_preference ?? "en");
    }
  }, [profile]);

  const save = async () => {
    if (!profile) return;
    setSaving(true);
    setError("");
    setSaved(false);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: fullName.trim(), language_preference: lang })
      .eq("id", profile.id);
    if (error) setError(error.message);
    else {
      setAppLanguage(lang);
      await refreshProfile();
      setSaved(true);
    }
    setSaving(false);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={t("settings.profile_title")} />
      <div className="max-w-md mx-auto p-4 flex flex-col gap-4 pb-24">
        {error && <Alert message={error} />}
        {saved && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm font-medium text-emerald-700">
            {t("settings.profile_updated")}
          </div>
        )}

        <Field label={t("settings.full_name")}>
          <TextInput value={fullName} onChange={(e) => setFullName(e.target.value)} />
        </Field>

        <Field label={t("settings.phone_number")} hint={t("settings.phone_cannot_change")}>
          <TextInput value={profile?.phone ?? ""} readOnly disabled prefix="+91" />
        </Field>

        <Field label={t("settings.role")} hint={t("settings.role_hint")}>
          <TextInput
            value={profile?.role ? t(`settings.role_${profile.role}`) : ""}
            readOnly
            disabled
          />
        </Field>

        <Field label={t("settings.preferred_language")}>
          <Dropdown
            value={lang}
            onChange={(v) => {
              setLang(v);
              setAppLanguage(v);
            }}
            options={LANGUAGES.map((l) => ({ value: l.code, label: l.label }))}
          />
        </Field>

        <Button onClick={save} disabled={!fullName.trim()} loading={saving}>
          {t("settings.save_changes")}
        </Button>
      </div>
    </div>
  );
}
