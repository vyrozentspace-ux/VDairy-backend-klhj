import { formatDayMonthYear } from "@/lib/date-locale";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Megaphone } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { Spinner } from "@/components/Spinner";
import { supabase } from "@/integrations/supabase/client";
import { useCenter } from "@/contexts/CenterContext";
import { useTranslation } from "react-i18next";

type Notice = {
  id: string;
  title: string;
  message: string;
  language: string;
  is_active: boolean;
  created_at: string;
};

export const Route = createFileRoute("/notices")({
  component: NoticesScreen,
});

function NoticesScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState<Notice[]>([]);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data } = await (supabase as any)
        .from("notices")
        .select("id, title, message, language, is_active, created_at")
        .eq("center_id", selected.id)
        .eq("is_active", true)
        .order("created_at", { ascending: false });
      if (!cancelled) {
        setRows((data ?? []) as Notice[]);
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  return (
    <>
      <AppHeader title={t("auth.notice_board")} onBack={() => navigate({ to: "/dashboard" })} />
      <div className="bg-teal-700 text-white px-4 py-3">
        <div className="flex items-center gap-2">
          <Megaphone className="h-4 w-4" />
          <span className="font-semibold">{t("auth.announcements")}</span>
        </div>
        {selected && <div className="text-xs text-teal-100 mt-0.5">{selected.name}</div>}
      </div>
      <div className="p-4 space-y-3 pb-24">
        {loading ? (
          <div className="py-16 flex justify-center">
            <Spinner />
          </div>
        ) : rows.length === 0 ? (
          <div className="py-16 flex flex-col items-center gap-3">
            <span className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300">
              <Megaphone className="h-7 w-7" />
            </span>
            <p className="text-sm text-slate-500">{t("auth.no_active_notices")}</p>
          </div>
        ) : (
          rows.map((n) => (
            <div key={n.id} className="rounded-lg border border-slate-200 bg-white p-4">
              <div className="flex items-start justify-between gap-2">
                <h2 className="font-semibold text-slate-800">{n.title}</h2>
                <span className="text-[10px] uppercase tracking-wider text-slate-400">
                  {n.language}
                </span>
              </div>
              <p className="mt-1.5 text-sm text-slate-600 whitespace-pre-wrap">{n.message}</p>
              <div className="mt-2 text-xs text-slate-400">
                {formatDayMonthYear(new Date(n.created_at))}
              </div>
            </div>
          ))
        )}
      </div>
    </>
  );
}
