import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { KeyRound } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useServerFn } from "@tanstack/react-start";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Alert } from "@/components/Alert";
import { changePin } from "@/lib/auth.functions";

export const Route = createFileRoute("/change-pin")({
  ssr: false,
  component: ChangePinScreen,
  head: () => ({
    meta: [
      { title: "Change PIN | Dairy Collection Manager" },
      {
        name: "description",
        content: "Update the 4-digit PIN you use to sign in to your dairy collection account.",
      },
      { property: "og:title", content: "Change PIN | Dairy Collection Manager" },
      {
        property: "og:description",
        content: "Update the 4-digit PIN you use to sign in to your dairy collection account.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function ChangePinScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const submitChange = useServerFn(changePin);

  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  const digits = (v: string) => v.replace(/\D/g, "").slice(0, 4);
  const canSubmit = current.length === 4 && next.length === 4 && confirm.length === 4;

  const submit = async () => {
    setError("");
    if (next !== confirm) {
      setError(t("settings.pins_do_not_match"));
      return;
    }
    if (next === current) {
      setError(t("settings.pin_must_be_new"));
      return;
    }
    setLoading(true);
    try {
      await submitChange({ data: { current_pin: current, new_pin: next } });
      setDone(true);
      setCurrent("");
      setNext("");
      setConfirm("");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      setError(
        /incorrect/i.test(msg)
          ? t("settings.pin_incorrect")
          : msg || t("settings.pin_change_failed"),
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={t("settings.change_pin")} onBack={() => navigate({ to: "/more" })} />
      <div className="max-w-md mx-auto px-6 py-6 flex flex-col gap-4">
        <div className="rounded-lg border border-slate-200 bg-white p-4 flex items-start gap-3">
          <KeyRound className="h-5 w-5 text-teal-700 shrink-0 mt-0.5" />
          <p className="text-xs text-slate-500">{t("settings.change_pin_hint")}</p>
        </div>

        {error && <Alert message={error} />}
        {done && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">
            {t("settings.pin_changed")}
          </div>
        )}

        <Field label={t("settings.current_pin")}>
          <TextInput
            type="password"
            inputMode="numeric"
            maxLength={4}
            value={current}
            onChange={(e) => setCurrent(digits(e.target.value))}
          />
        </Field>
        <Field label={t("settings.new_pin")}>
          <TextInput
            type="password"
            inputMode="numeric"
            maxLength={4}
            value={next}
            onChange={(e) => setNext(digits(e.target.value))}
          />
        </Field>
        <Field label={t("settings.confirm_new_pin")}>
          <TextInput
            type="password"
            inputMode="numeric"
            maxLength={4}
            value={confirm}
            onChange={(e) => setConfirm(digits(e.target.value))}
          />
        </Field>

        <Button onClick={submit} disabled={!canSubmit} loading={loading}>
          {t("settings.change_pin")}
        </Button>
      </div>
    </div>
  );
}
