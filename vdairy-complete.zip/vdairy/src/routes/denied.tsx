import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";

import { Button } from "@/components/Button";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/denied")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Access restricted — vDairy" },
      {
        name: "description",
        content: "This module is not available for your operator account in this dairy center.",
      },
      { property: "og:title", content: "Access restricted — vDairy" },
      {
        property: "og:description",
        content: "This module is not available for your operator account in this dairy center.",
      },
    ],
  }),
  component: DeniedScreen,
});

function DeniedScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-6">
      <div className="max-w-sm w-full text-center flex flex-col items-center gap-3">
        <span className="h-14 w-14 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center">
          <ShieldAlert className="h-7 w-7" />
        </span>
        <h1 className="text-lg font-bold text-slate-800">{t("auth.access_restricted")}</h1>
        <p className="text-sm text-slate-500">{t("auth.access_restricted_message")}</p>
        <div className="w-full mt-2">
          <Button onClick={() => navigate({ to: "/dashboard", replace: true })}>
            {t("auth.back_to_dashboard")}
          </Button>
        </div>
      </div>
    </div>
  );
}
