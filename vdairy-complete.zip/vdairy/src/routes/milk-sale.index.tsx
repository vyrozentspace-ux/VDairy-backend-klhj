import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Plus,
  RefreshCw,
  ShoppingCart,
} from "lucide-react";

import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { useCenter } from "@/contexts/CenterContext";
import {
  formatDateLabel,
  formatINR,
  listCustomers,
  listSales,
  todayISO,
  type MilkSale,
  type MilkSaleCustomer,
} from "@/lib/milk-sales";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/milk-sale/")({
  component: MilkSaleList,
});

type Filter = "all" | "paid" | "unpaid";

function shiftISO(iso: string, days: number) {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function MilkSaleList() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();

  const [loading, setLoading] = useState(true);
  const [sales, setSales] = useState<MilkSale[]>([]);
  const [customers, setCustomers] = useState<Record<string, MilkSaleCustomer>>({});
  const [date, setDate] = useState<string>(todayISO());
  const [showAll, setShowAll] = useState(false);
  const [rangeFrom, setRangeFrom] = useState<string>("");
  const [rangeTo, setRangeTo] = useState<string>("");
  const [filter, setFilter] = useState<Filter>("all");
  const dateInputRef = useRef<HTMLInputElement>(null);

  async function reload() {
    if (!selected) return;
    setSales([]);
    setLoading(true);
    try {
      const opts = showAll
        ? { from: rangeFrom || undefined, to: rangeTo || undefined }
        : { from: date, to: date };
      const [ss, cs] = await Promise.all([
        listSales(selected.id, opts),
        listCustomers(selected.id),
      ]);
      setSales(ss);
      setCustomers(Object.fromEntries(cs.map((c) => [c.id, c])));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void reload(); /* eslint-disable-next-line */
  }, [selected?.id, date, showAll, rangeFrom, rangeTo]);

  const counts = useMemo(
    () => ({
      all: sales.length,
      paid: sales.filter((s) => s.payment_status === "paid").length,
      unpaid: sales.filter((s) => s.payment_status === "unpaid").length,
    }),
    [sales],
  );

  const filtered = useMemo(() => {
    if (filter === "all") return sales;
    return sales.filter((s) => s.payment_status === filter);
  }, [sales, filter]);

  const summary = useMemo(() => {
    const liters = filtered.reduce((a, s) => a + Number(s.quantity_liters), 0);
    const total = filtered.reduce((a, s) => a + Number(s.total_amount), 0);
    const unpaid = filtered
      .filter((s) => s.payment_status === "unpaid")
      .reduce((a, s) => a + Number(s.total_amount), 0);
    return { liters, total, unpaid };
  }, [filtered]);

  function customerLabel(s: MilkSale) {
    if (s.customer_id) return customers[s.customer_id]?.name ?? t("sales.customerLabel");
    if (s.walk_in_name) return t("sales.walkInWithName", { name: s.walk_in_name });
    return t("sales.walkIn");
  }

  return (
    <div className="min-h-full bg-slate-50 flex flex-col">
      <AppHeader
        title={t("sales.title")}
        onBack={() => navigate({ to: "/dashboard" })}
        right={
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => navigate({ to: "/milk-sale/customers" })}
              className="h-11 px-3 rounded-lg text-slate-600 text-sm font-medium hover:bg-slate-100"
            >
              {t("sales.customersNav")}
            </button>
            <button
              type="button"
              onClick={reload}
              className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100"
              aria-label={t("invoice.reload")}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate({ to: "/milk-sale/new" })}
              className="w-10 h-10 rounded-full bg-teal-700 text-white flex items-center justify-center hover:bg-teal-800"
              aria-label={t("sales.addSaleTitle")}
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        }
      />
      {selected && (
        <div className="px-4 py-1.5 text-xs text-slate-500 bg-white border-b border-slate-200">
          {selected.name}
        </div>
      )}

      <div className="bg-white border-b border-slate-200 px-4 py-3 grid grid-cols-3 gap-2">
        <div>
          <div className="text-[10px] uppercase text-slate-400">{t("sales.quantity")}</div>
          <div className="text-lg font-bold text-slate-700">{summary.liters.toFixed(1)}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase text-slate-400">{t("sales.total")}</div>
          <div className="text-lg font-bold text-teal-700">{formatINR(summary.total)}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase text-slate-400">{t("sales.unpaid")}</div>
          <div className="text-lg font-bold text-rose-600">{formatINR(summary.unpaid)}</div>
        </div>
      </div>

      <div className="bg-white border-b border-slate-200 px-4 py-2">
        {!showAll ? (
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setDate(shiftISO(date, -1))}
              className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="text-center">
              <div className="text-sm font-semibold text-slate-800">{formatDateLabel(date, t)}</div>
              <button
                type="button"
                onClick={() => {
                  const el = dateInputRef.current;
                  if (!el) return;
                  if (typeof el.showPicker === "function") el.showPicker();
                  else el.click();
                }}
                className="text-xs text-teal-600"
              >
                {t("sales.changeDate")}
              </button>
              <input
                ref={dateInputRef}
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="sr-only"
              />
            </div>
            <button
              type="button"
              onClick={() => setDate(shiftISO(date, 1))}
              className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-800">{t("sales.allRecords")}</span>
              <button
                type="button"
                onClick={() => setShowAll(false)}
                className="text-xs text-teal-600"
              >
                {t("sales.backToToday")}
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="date"
                value={rangeFrom}
                onChange={(e) => setRangeFrom(e.target.value)}
                className="h-10 rounded-lg border border-slate-200 px-2 text-sm"
              />
              <input
                type="date"
                value={rangeTo}
                onChange={(e) => setRangeTo(e.target.value)}
                className="h-10 rounded-lg border border-slate-200 px-2 text-sm"
              />
            </div>
          </div>
        )}
      </div>
      {!showAll && (
        <button
          type="button"
          onClick={() => setShowAll(true)}
          className="bg-white border-b border-slate-200 px-4 py-2 text-xs text-teal-600 flex items-center gap-1"
        >
          <CalendarDays className="w-3.5 h-3.5" /> {t("sales.showAllRecords")}
        </button>
      )}

      <div className="bg-white border-b border-slate-200 px-4 py-2 flex gap-2">
        {(["all", "paid", "unpaid"] as Filter[]).map((f) => {
          const active = filter === f;
          const badgeClass = active
            ? f === "paid"
              ? "bg-emerald-500/30"
              : f === "unpaid"
                ? "bg-rose-500/30"
                : "bg-white/25"
            : "bg-slate-200 text-slate-600";
          return (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={cn(
                "px-3 h-8 rounded-full text-xs font-medium flex items-center gap-1.5 capitalize",
                active ? "bg-teal-700 text-white" : "text-slate-500 hover:bg-slate-100",
              )}
            >
              {f === "all" ? t("sales.all") : f === "paid" ? t("sales.paid") : t("sales.unpaid")}
              <span className={cn("px-1.5 min-w-[20px] rounded-full text-[10px]", badgeClass)}>
                {counts[f]}
              </span>
            </button>
          );
        })}
      </div>

      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-8 flex justify-center">
            <Spinner size={22} color="#0F766E" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-3">
              <ShoppingCart className="w-6 h-6 text-slate-400" />
            </div>
            <div className="font-semibold text-slate-700">{t("sales.noSalesRecorded")}</div>
            <div className="text-xs text-slate-500 mt-1 max-w-[240px]">
              {filter === "all"
                ? t("sales.noSalesForDate")
                : t("sales.noStatusSales", { status: filter })}
            </div>
            <div className="mt-4 w-full max-w-[220px]">
              <Button onClick={() => navigate({ to: "/milk-sale/new" })}>
                {t("sales.addSale")}
              </Button>
            </div>
          </div>
        ) : (
          <ul className="bg-white divide-y">
            {filtered.map((s) => (
              <li key={s.id}>
                <button
                  type="button"
                  onClick={() => navigate({ to: "/milk-sale/$id", params: { id: s.id } })}
                  className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-slate-50"
                >
                  <div className="w-9 h-9 rounded-full bg-teal-50 flex items-center justify-center flex-shrink-0">
                    <ShoppingCart className="w-4 h-4 text-teal-700" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-slate-800 truncate">
                      {customerLabel(s)}
                    </div>
                    <div className="text-xs text-slate-500 truncate">
                      {Number(s.quantity_liters).toFixed(1)}L × ₹
                      {Number(s.rate_per_liter).toFixed(2)} ·{" "}
                      {s.session === "morning" ? t("sales.am") : t("sales.pm")}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-800">
                      {formatINR(Number(s.total_amount))}
                    </div>
                    <span
                      className={cn(
                        "inline-block mt-0.5 px-2 py-0.5 rounded-full text-[10px] font-medium",
                        s.payment_status === "paid"
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-rose-50 text-rose-700",
                      )}
                    >
                      {s.payment_status === "paid" ? t("sales.paid") : t("sales.unpaid")}
                    </span>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
