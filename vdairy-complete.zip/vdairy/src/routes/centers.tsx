import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Building2, LogOut, MapPin, Plus } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/centers")({
  ssr: false,
  component: CentersScreen,
});

function CentersScreen() {
  const { t } = useTranslation();
  const { loading: authLoading, session, profile, logout } = useAuth();
  const { loading, centers, select } = useCenter();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !session) navigate({ to: "/login", replace: true });
  }, [authLoading, session, navigate]);

  const onSelect = (id: string) => {
    select(id);
    navigate({ to: "/dashboard" });
  };

  const onLogout = async () => {
    await logout();
    navigate({ to: "/login", replace: true });
  };

  const isOwner = profile?.role === "owner";

  return (
    <div className="min-h-screen bg-slate-50 safe-bottom">
      <header className="sticky top-0 z-20 bg-white border-b border-slate-200 safe-top">
        <div className="flex items-center justify-between h-14 px-4">
          <Logo size="sm" />
          <button
            onClick={onLogout}
            className="p-2 rounded-lg text-slate-500 hover:bg-slate-100"
            aria-label={t("auth.sign_out")}
          >
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </header>

      <div className="max-w-md mx-auto px-6 py-6">
        <p className="text-sm text-slate-500">{t("auth.signed_in_as")}</p>
        <p className="text-lg font-bold text-slate-800">
          {profile?.full_name ?? t("auth.ellipsis_placeholder")}
        </p>

        <h2 className="mt-6 mb-3 text-xs uppercase tracking-wide text-slate-400 font-semibold">
          {t("auth.select_center")}
        </h2>

        {loading ? (
          <div className="flex justify-center py-12">
            <Spinner size={28} color="#0F766E" />
          </div>
        ) : centers.length === 0 ? (
          <div className="rounded-lg border-2 border-dashed border-slate-300 bg-white p-8 flex flex-col items-center text-center gap-3">
            <Building2 className="h-12 w-12 text-slate-300" />
            <p className="font-semibold text-slate-700">{t("auth.no_centers_yet")}</p>
            <p className="text-sm text-slate-500 max-w-xs">
              {isOwner ? t("auth.create_first_center") : t("auth.ask_owner_to_add")}
            </p>
            {isOwner && (
              <button
                onClick={() => navigate({ to: "/onboarding/create-center" })}
                className="mt-2 inline-flex items-center gap-1.5 px-4 h-10 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800"
              >
                <Plus className="h-4 w-4" /> {t("auth.add_new_center")}
              </button>
            )}
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {isOwner && (
              <button
                onClick={() => navigate({ to: "/onboarding/create-center" })}
                className="w-full flex items-center justify-center gap-1.5 h-12 rounded-lg border-2 border-dashed border-teal-400 bg-teal-50 text-teal-700 font-semibold text-sm hover:bg-teal-100"
              >
                <Plus className="h-4 w-4" /> {t("auth.add_new_center")}
              </button>
            )}
            {centers.map((c) => (
              <button
                key={c.id}
                onClick={() => onSelect(c.id)}
                className="text-left w-full bg-white rounded-lg border border-slate-200 p-4 hover:border-teal-400 hover:shadow-sm transition"
              >
                <p className="font-semibold text-slate-800">{c.name}</p>
                <div className="mt-1 flex items-center gap-1.5 text-sm text-slate-500">
                  <MapPin className="h-3.5 w-3.5" />
                  <span>{[c.village, c.district].filter(Boolean).join(", ") || c.code}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
