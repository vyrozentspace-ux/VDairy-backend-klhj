import { createFileRoute, useNavigate, useSearch, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import {
  BadgeIndianRupee,
  Calendar,
  Check,
  ChevronLeft,
  ChevronRight,
  FileText,
  ListOrdered,
  MoreVertical,
  Package,
  Plus,
  Users,
  Wheat,
  X,
} from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import { fetchFarmers, farmerFullName, type Farmer } from "@/lib/farmers";
import { listFeedSales, listProducts, type FarmerFeedSale, type FeedProduct } from "@/lib/food";
import {
  formatDMY,
  fromISODate,
  periodForDate,
  shiftPeriod as shiftPeriodBy,
  type Period,
} from "@/lib/payment-periods";
import { usePeriodConfig } from "@/hooks/usePeriodConfig";
import { cn } from "@/lib/utils";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

const searchSchema = z.object({ farmer_id: z.string().optional() });

export const Route = createFileRoute("/food/")({
  validateSearch: searchSchema,
  component: FoodListScreen,
});

type SortKey = "farmer_code" | "receipt" | "date";

function FoodListScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const search = useSearch({ from: "/food/" });
  const menuRef = useRef<HTMLDivElement>(null);

  const [loading, setLoading] = useState(true);
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [products, setProducts] = useState<FeedProduct[]>([]);
  const [sales, setSales] = useState<FarmerFeedSale[]>([]);
  const { config, loaded: configLoaded } = usePeriodConfig();
  const [period, setPeriodState] = useState<Period>(() =>
    periodForDate({ paymentPeriod: null, startDate: null }),
  );
  const [periodTouched, setPeriodTouched] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [sortBy, setSortBy] = useState<SortKey>("date");
  const [manualFrom, setManualFrom] = useState<string>("");
  const [manualTo, setManualTo] = useState<string>("");

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
  }, [menuOpen]);

  useEffect(() => {
    if (!configLoaded || periodTouched) return;
    setPeriodState(periodForDate(config));
  }, [configLoaded, config.paymentPeriod, config.startDate, periodTouched]);

  const shift = (dir: number) => {
    setPeriodTouched(true);
    setPeriodState((p) => shiftPeriodBy(config, p, dir));
  };
  const periodStart = useMemo(() => fromISODate(period.start), [period.start]);
  const periodEnd = useMemo(() => fromISODate(period.end), [period.end]);
  const fromISO = useMemo(() => manualFrom || toISO(periodStart), [manualFrom, periodStart]);
  const toISOStr = useMemo(() => manualTo || toISO(periodEnd), [manualTo, periodEnd]);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const [fs, ps, ss] = await Promise.all([
          fetchFarmers(selected.id),
          listProducts(selected.id),
          listFeedSales(
            selected.id,
            showAll
              ? { farmerId: search.farmer_id }
              : { from: fromISO, to: toISOStr, farmerId: search.farmer_id },
          ),
        ]);
        if (cancelled) return;
        setFarmers(fs);
        setProducts(ps);
        setSales(ss);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id, showAll, fromISO, toISOStr, search.farmer_id]);

  const farmerById = useMemo(() => Object.fromEntries(farmers.map((f) => [f.id, f])), [farmers]);
  const productById = useMemo(() => Object.fromEntries(products.map((p) => [p.id, p])), [products]);

  const groups = useMemo(() => {
    const map = new Map<
      string,
      { farmer: Farmer | null; items: FarmerFeedSale[]; total: number }
    >();
    for (const s of sales) {
      const g = map.get(s.farmer_id) ?? {
        farmer: farmerById[s.farmer_id] ?? null,
        items: [],
        total: 0,
      };
      g.items.push(s);
      g.total += Number(s.amount);
      map.set(s.farmer_id, g);
    }
    const arr = Array.from(map.values());
    arr.sort((a, b) => {
      if (sortBy === "farmer_code") {
        const ac = Number(a.farmer?.code ?? 0),
          bc = Number(b.farmer?.code ?? 0);
        if (Number.isFinite(ac) && Number.isFinite(bc)) return ac - bc;
        return String(a.farmer?.code ?? "").localeCompare(String(b.farmer?.code ?? ""));
      }
      if (sortBy === "receipt") {
        return (a.items[0]?.receipt_no ?? "").localeCompare(b.items[0]?.receipt_no ?? "");
      }
      // date: most recent first
      return (b.items[0]?.sale_date ?? "").localeCompare(a.items[0]?.sale_date ?? "");
    });
    return arr;
  }, [sales, farmerById, sortBy]);

  const productSummary = useMemo(() => {
    const m = new Map<string, { name: string; unit: string; qty: number; amount: number }>();
    for (const s of sales) {
      const p = productById[s.feed_product_id];
      const key = s.feed_product_id;
      const row = m.get(key) ?? {
        name: p?.product_name ?? "—",
        unit: p?.unit ?? "",
        qty: 0,
        amount: 0,
      };
      row.qty += Number(s.quantity);
      row.amount += Number(s.amount);
      m.set(key, row);
    }
    return Array.from(m.values());
  }, [sales, productById]);

  const grandTotal = sales.reduce((s, r) => s + Number(r.amount), 0);
  const filteredFarmer = search.farmer_id ? farmerById[search.farmer_id] : null;

  const shiftPeriod = (dir: 1 | -1) => {
    setManualFrom("");
    setManualTo("");
    shift(dir);
  };

  return (
    <>
      <AppHeader
        title={t("food.foods")}
        onBack={() => navigate({ to: "/dashboard" })}
        right={
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => navigate({ to: "/food/new" })}
              aria-label={t("food.add")}
              className="h-10 w-10 rounded-full bg-teal-700 text-white flex items-center justify-center hover:bg-teal-800"
            >
              <Plus className="h-5 w-5" />
            </button>
            <div className="relative" ref={menuRef}>
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                aria-label={t("food.more")}
                className="h-10 w-10 rounded-full text-slate-600 hover:bg-slate-100 flex items-center justify-center"
              >
                <MoreVertical className="h-5 w-5" />
              </button>
              {menuOpen && (
                <div className="absolute right-0 top-11 z-30 w-64 bg-white rounded-lg shadow-lg border border-slate-100 py-1">
                  <MenuItem
                    icon={<Users className="h-4 w-4" />}
                    label={t("food.food_dealers")}
                    onClick={() => {
                      setMenuOpen(false);
                      navigate({ to: "/food/dealers" });
                    }}
                  />
                  <MenuItem
                    icon={<Package className="h-4 w-4" />}
                    label={t("food.food_stock")}
                    onClick={() => {
                      setMenuOpen(false);
                      navigate({ to: "/food/stock" });
                    }}
                  />
                  <MenuItem
                    icon={<FileText className="h-4 w-4" />}
                    label={t("food.register_feed_product")}
                    onClick={() => {
                      setMenuOpen(false);
                      navigate({ to: "/food/register" });
                    }}
                  />
                  <div className="border-t border-slate-100 my-1" />
                  <div className="px-4 pt-2 pb-1 text-xs uppercase tracking-wider text-slate-400">
                    {t("food.sort_by")}
                  </div>
                  <SortItem
                    active={sortBy === "farmer_code"}
                    icon={<ListOrdered className="h-4 w-4" />}
                    label={t("food.sort_by_farmer_code")}
                    onClick={() => setSortBy("farmer_code")}
                  />
                  <SortItem
                    active={sortBy === "receipt"}
                    icon={<BadgeIndianRupee className="h-4 w-4" />}
                    label={t("food.sort_by_receipt")}
                    onClick={() => setSortBy("receipt")}
                  />
                  <SortItem
                    active={sortBy === "date"}
                    icon={<Calendar className="h-4 w-4" />}
                    label={t("food.sort_by_date")}
                    onClick={() => setSortBy("date")}
                  />
                </div>
              )}
            </div>
          </div>
        }
      />

      <div className="p-4 space-y-4 pb-24">
        {!showAll && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => shiftPeriod(-1)}
                className="h-9 w-9 rounded-lg border border-slate-200 text-slate-600 flex items-center justify-center hover:bg-slate-50"
                aria-label={t("food.previous_period")}
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <div className="flex-1 h-9 rounded-lg bg-slate-100 px-3 flex items-center justify-center text-xs font-semibold text-slate-700">
                {formatDMY(periodStart)} {t("invoice.to")} {formatDMY(periodEnd)}
              </div>
              <button
                type="button"
                onClick={() => shiftPeriod(1)}
                className="h-9 w-9 rounded-lg border border-slate-200 text-slate-600 flex items-center justify-center hover:bg-slate-50"
                aria-label={t("food.next_period")}
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="date"
                value={fromISO}
                onChange={(e) => setManualFrom(e.target.value)}
                className="h-10 rounded-lg border border-slate-200 px-3 text-sm"
              />
              <input
                type="date"
                value={toISOStr}
                onChange={(e) => setManualTo(e.target.value)}
                className="h-10 rounded-lg border border-slate-200 px-3 text-sm"
              />
            </div>
            <button
              type="button"
              onClick={() => setShowAll(true)}
              className="w-full h-10 rounded-lg bg-slate-100 text-slate-600 text-sm font-medium hover:bg-slate-200"
            >
              {t("food.show_all_records")}
            </button>
          </div>
        )}
        {showAll && (
          <button
            type="button"
            onClick={() => {
              setShowAll(false);
              setManualFrom("");
              setManualTo("");
            }}
            className="w-full h-10 rounded-lg bg-teal-600 text-white text-sm font-semibold hover:bg-teal-700"
          >
            {t("food.to_current_period")}
          </button>
        )}

        {filteredFarmer && (
          <div className="rounded-lg bg-teal-50 border border-teal-100 px-3 py-2 flex items-center justify-between">
            <span className="text-xs text-teal-700 font-medium">
              {t("food.filtered_by_farmer", { name: farmerFullName(filteredFarmer) })}
            </span>
            <button
              type="button"
              onClick={() => navigate({ to: "/food", search: {} })}
              className="h-7 w-7 rounded-full hover:bg-teal-100 flex items-center justify-center text-teal-700"
              aria-label={t("food.clear_filter")}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        {loading ? (
          <div className="py-16 flex justify-center">
            <Spinner />
          </div>
        ) : groups.length === 0 ? (
          <div className="py-16 flex flex-col items-center gap-3">
            <span className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300">
              <Wheat className="h-7 w-7" />
            </span>
            <p className="text-sm text-slate-500">{t("food.no_records")}</p>
            <Button onClick={() => navigate({ to: "/food/new" })} className="max-w-xs">
              <Plus className="h-4 w-4" /> {t("food.add_entry")}
            </Button>
          </div>
        ) : (
          <>
            <div className="space-y-4">
              {groups.map((g, idx) => (
                <div
                  key={g.farmer?.id ?? idx}
                  className="bg-white border border-slate-200 rounded-lg overflow-hidden"
                >
                  <div className="bg-slate-50 border-b border-slate-100 px-3 py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xs text-slate-400 w-5 shrink-0">{idx + 1}.</span>
                      <span className="font-semibold text-slate-800 truncate">
                        {g.farmer ? `${g.farmer.code} · ${farmerFullName(g.farmer)}` : "—"}
                      </span>
                    </div>
                    <span className="font-bold text-emerald-600 text-sm">
                      ₹{g.total.toFixed(2)}
                    </span>
                  </div>
                  <div className="divide-y divide-slate-50">
                    {g.items.map((s) => {
                      const p = productById[s.feed_product_id];
                      return (
                        <Link
                          key={s.id}
                          to="/food/$id/edit"
                          params={{ id: s.id }}
                          className="block px-3 py-2.5 hover:bg-slate-50"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="font-medium text-slate-800 text-sm truncate">
                                {p?.product_name ?? "—"}
                              </div>
                              {s.receipt_no && (
                                <div className="text-xs text-slate-400 mt-0.5">
                                  {t("food.receipt_no", { receipt: s.receipt_no })}
                                </div>
                              )}
                            </div>
                            <div className="text-xs text-slate-400 shrink-0">
                              {formatDMY(new Date(s.sale_date))}
                            </div>
                          </div>
                          <div className="mt-1 flex items-center justify-between">
                            <div className="text-sm font-medium text-rose-600">
                              {Number(s.quantity)} x {Number(s.rate)} = ₹
                              {Number(s.amount).toFixed(2)}
                            </div>
                            {s.cash_payment && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 text-[10px] font-semibold">
                                {t("food.cash")}
                              </span>
                            )}
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {productSummary.length > 0 && (
              <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
                <div className="bg-slate-50 border-b border-slate-100 px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
                  {t("food.product_summary")}
                </div>
                <div className="divide-y divide-slate-50">
                  {productSummary.map((r, i) => (
                    <div key={i} className="px-3 py-2 flex items-center justify-between text-sm">
                      <span className="text-slate-700">
                        {r.name} ({r.qty} {r.unit})
                      </span>
                      <span className="font-semibold text-slate-800">₹{r.amount.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="border-t-2 border-slate-300 pt-3 flex items-center justify-between font-bold text-slate-800">
              <span>{t("food.total", { count: sales.length })}</span>
              <span>₹{grandTotal.toFixed(2)}</span>
            </div>
          </>
        )}
      </div>
    </>
  );
}

function toISO(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function MenuItem({
  icon,
  label,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 text-left"
    >
      <span className="text-slate-500">{icon}</span>
      <span>{label}</span>
    </button>
  );
}

function SortItem({
  icon,
  label,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left"
    >
      <span className="text-slate-500">{icon}</span>
      <span className="flex-1">{label}</span>
      {active && <Check className={cn("h-4 w-4 text-teal-600")} />}
    </button>
  );
}
