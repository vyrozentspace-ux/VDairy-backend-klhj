import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { z } from "zod";
import { AdvanceForm } from "@/components/AdvanceForm";

const searchSchema = z.object({ farmer_id: z.string().optional() });

export const Route = createFileRoute("/advance/new")({
  validateSearch: searchSchema,
  component: NewAdvanceScreen,
});

function NewAdvanceScreen() {
  const search = useSearch({ from: "/advance/new" });
  const navigate = useNavigate();
  return (
    <AdvanceForm
      mode="create"
      prefillFarmerId={search.farmer_id}
      onBack={() => navigate({ to: "/advance" })}
    />
  );
}
