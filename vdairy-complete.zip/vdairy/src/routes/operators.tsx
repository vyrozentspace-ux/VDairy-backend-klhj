import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Building2, Plus, ShieldCheck, Trash2, UserCog } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Alert } from "@/components/Alert";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Switch } from "@/components/Switch";
import { Spinner } from "@/components/Spinner";
import { BottomSheet } from "@/components/BottomSheet";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import {
  createOperator,
  removeOperator,
  resetOperatorPin,
  setOperatorCenterLink,
} from "@/lib/operators.functions";
import {
  DEFAULT_OPERATOR_PERMISSIONS,
  PERMISSION_KEYS,
  normalizePermissions,
  type PermissionKey,
  type Permissions,
} from "@/lib/permissions";

export const Route = createFileRoute("/operators")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Manage Operators — vDairy" },
      {
        name: "description",
        content:
          "Add dairy center operators, set their module permissions and activate or deactivate their access.",
      },
      { property: "og:title", content: "Manage Operators — vDairy" },
      {
        property: "og:description",
        content: "Add operators and control which dairy modules each one can use.",
      },
    ],
  }),
  component: OperatorsScreen,
});

type OperatorRow = {
  id: string;
  operator_id: string;
  is_active: boolean;
  permissions: Permissions;
  full_name: string;
  phone: string;
  /** Centers of this owner the operator is currently linked to. */
  centerIds: string[];
};

function OperatorsScreen() {
  const { t } = useTranslation();
  const { selected, centers } = useCenter();
  const navigate = useNavigate();
  const [rows, setRows] = useState<OperatorRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [editing, setEditing] = useState<OperatorRow | null>(null);
  const [removing, setRemoving] = useState<OperatorRow | null>(null);
  const [assigning, setAssigning] = useState<OperatorRow | null>(null);

  const load = useCallback(async () => {
    if (!selected) return;
    setLoading(true);
    const { data, error: err } = await supabase
      .from("center_operators")
      .select("id, operator_id, is_active, permissions")
      .eq("center_id", selected.id);
    if (err) {
      setError(err.message);
      setLoading(false);
      return;
    }
    const ids = (data ?? []).map((r) => r.operator_id);
    const { data: profs } = ids.length
      ? await supabase.from("profiles").select("id, full_name, phone").in("id", ids)
      : { data: [] as { id: string; full_name: string; phone: string }[] };
    // Which of the owner's other centers each operator is also linked to.
    const { data: allLinks } = ids.length
      ? await supabase
          .from("center_operators")
          .select("operator_id, center_id")
          .in("operator_id", ids)
      : { data: [] as { operator_id: string; center_id: string }[] };
    const byId = new Map((profs ?? []).map((p) => [p.id, p]));
    setRows(
      (data ?? []).map((r) => ({
        id: r.id,
        operator_id: r.operator_id,
        is_active: r.is_active,
        permissions: normalizePermissions(r.permissions),
        full_name: byId.get(r.operator_id)?.full_name ?? "Operator",
        phone: byId.get(r.operator_id)?.phone ?? "",
        centerIds: (allLinks ?? [])
          .filter((l) => l.operator_id === r.operator_id)
          .map((l) => l.center_id),
      })),
    );
    setLoading(false);
  }, [selected?.id]);

  useEffect(() => {
    void load();
  }, [load]);

  const toggleActive = async (row: OperatorRow) => {
    const { error: err } = await supabase
      .from("center_operators")
      .update({ is_active: !row.is_active })
      .eq("id", row.id);
    if (err) {
      toast.error(err.message);
      return;
    }
    toast.success(
      row.is_active ? t("settings.operator_deactivated") : t("settings.operator_activated"),
    );
    void load();
  };

  const savePermissions = async (row: OperatorRow, perms: Permissions) => {
    const { error: err } = await supabase
      .from("center_operators")
      .update({ permissions: perms })
      .eq("id", row.id);
    if (err) {
      toast.error(err.message);
      return;
    }
    toast.success(t("settings.permissions_updated"));
    setEditing(null);
    void load();
  };

  const toggleCenterLink = async (row: OperatorRow, centerId: string, linked: boolean) => {
    try {
      await setOperatorCenterLink({
        data: {
          center_id: centerId,
          operator_id: row.operator_id,
          linked,
          permissions: row.permissions,
        },
      });
      toast.success(linked ? t("settings.operator_linked") : t("settings.operator_unlinked"));
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("settings.could_not_save"));
    }
  };

  const doRemove = async () => {
    if (!removing || !selected) return;
    try {
      await removeOperator({
        data: { center_id: selected.id, operator_id: removing.operator_id },
      });
      toast.success(t("settings.operator_removed"));
      setRemoving(null);
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("settings.could_not_save"));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader
        title={t("settings.manage_operators_title")}
        onBack={() => navigate({ to: "/more" })}
      />
      <div className="max-w-md mx-auto px-4 py-4 flex flex-col gap-3 pb-28">
        {error && <Alert message={error} />}

        {loading ? (
          <div className="py-10 flex justify-center">
            <Spinner size={22} color="#0F766E" />
          </div>
        ) : rows.length === 0 ? (
          <div className="rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center">
            <UserCog className="h-8 w-8 mx-auto text-slate-300" />
            <p className="mt-2 text-sm text-slate-500">{t("settings.no_operators")}</p>
          </div>
        ) : (
          rows.map((row) => (
            <div key={row.id} className="rounded-lg border border-slate-200 bg-white p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold">
                  {row.full_name.slice(0, 1).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-800 truncate">{row.full_name}</p>
                  <p className="text-xs text-slate-500">+91 {row.phone}</p>
                </div>
                <Switch
                  checked={row.is_active}
                  onChange={() => void toggleActive(row)}
                  label={t("settings.active_label")}
                />
              </div>
              <p className="mt-3 text-xs text-slate-500">
                {PERMISSION_KEYS.filter((k) => row.permissions[k])
                  .map((k) => t(`settings.perm_${k}`))
                  .join(", ") || t("settings.no_modules_enabled")}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setEditing(row)}
                  className="text-xs font-semibold text-teal-700 border border-teal-200 rounded-md px-3 py-1.5"
                >
                  {t("settings.edit_permissions")}
                </button>
                {centers.length > 1 && (
                  <button
                    type="button"
                    onClick={() => setAssigning(row)}
                    className="text-xs font-semibold text-slate-600 border border-slate-200 rounded-md px-3 py-1.5 inline-flex items-center gap-1"
                  >
                    <Building2 className="h-3.5 w-3.5" />
                    {t("settings.assigned_centers_count", { count: row.centerIds.length })}
                  </button>
                )}
                <button
                  type="button"
                  data-testid="remove-operator"
                  onClick={() => setRemoving(row)}
                  className="text-xs font-semibold text-rose-600 border border-rose-200 rounded-md px-3 py-1.5 inline-flex items-center gap-1"
                >
                  <Trash2 className="h-3.5 w-3.5" /> {t("settings.remove_operator")}
                </button>
              </div>
            </div>
          ))
        )}

        <Button onClick={() => setAddOpen(true)}>
          <Plus className="h-4 w-4" /> {t("settings.add_operator")}
        </Button>
      </div>

      <AddOperatorSheet
        open={addOpen}
        centerId={selected?.id ?? null}
        onClose={() => setAddOpen(false)}
        onSaved={() => {
          setAddOpen(false);
          void load();
        }}
      />

      <EditPermissionsSheet
        row={editing}
        onClose={() => setEditing(null)}
        onSave={savePermissions}
      />

      <BottomSheet
        open={!!assigning}
        onClose={() => setAssigning(null)}
        title={t("settings.assign_centers")}
      >
        <div className="flex flex-col gap-2 pb-4">
          <p className="text-xs text-slate-500">{t("settings.assign_centers_hint")}</p>
          {centers.map((c) => {
            const linked = !!assigning?.centerIds.includes(c.id);
            return (
              <div
                key={c.id}
                className="flex items-center justify-between rounded-lg border border-slate-200 p-3"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-800 truncate">{c.name}</p>
                  <p className="text-xs text-slate-500">{c.code}</p>
                </div>
                <Switch
                  checked={linked}
                  label={c.name}
                  onChange={(v) => {
                    if (!assigning) return;
                    void toggleCenterLink(assigning, c.id, v).then(() =>
                      setAssigning((prev) =>
                        prev
                          ? {
                              ...prev,
                              centerIds: v
                                ? [...prev.centerIds, c.id]
                                : prev.centerIds.filter((id) => id !== c.id),
                            }
                          : prev,
                      ),
                    );
                  }}
                />
              </div>
            );
          })}
        </div>
      </BottomSheet>

      <ConfirmDialog
        open={!!removing}
        destructive
        title={t("settings.remove_operator")}
        message={t("settings.remove_operator_confirm", { name: removing?.full_name ?? "" })}
        confirmLabel={t("settings.remove_operator")}
        onConfirm={() => void doRemove()}
        onCancel={() => setRemoving(null)}
      />
    </div>
  );
}

function PermissionToggles({
  value,
  onChange,
}: {
  value: Permissions;
  onChange: (v: Permissions) => void;
}) {
  const { t } = useTranslation();
  return (
    <div className="rounded-lg border border-slate-200 divide-y divide-slate-100">
      {PERMISSION_KEYS.map((key: PermissionKey) => (
        <div key={key} className="flex items-center justify-between p-3">
          <span className="text-sm text-slate-700">{t(`settings.perm_${key}`)}</span>
          <Switch
            checked={value[key]}
            label={t(`settings.perm_${key}`)}
            onChange={(v) => onChange({ ...value, [key]: v })}
          />
        </div>
      ))}
    </div>
  );
}

function AddOperatorSheet({
  open,
  centerId,
  onClose,
  onSaved,
}: {
  open: boolean;
  centerId: string | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [perms, setPerms] = useState<Permissions>(DEFAULT_OPERATOR_PERMISSIONS);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  /** Field-level messages, only shown once the user has tried to submit. */
  const [touched, setTouched] = useState(false);

  // Reset the form every time the sheet is opened.
  useEffect(() => {
    if (!open) return;
    setName("");
    setPhone("");
    setPin("");
    setConfirmPin("");
    setPerms(DEFAULT_OPERATOR_PERMISSIONS);
    setError("");
    setTouched(false);
  }, [open]);

  const nameError = name.trim().length >= 2 ? "" : t("settings.err_name_required");
  const phoneError = /^[6-9][0-9]{9}$/.test(phone) ? "" : t("settings.err_phone_invalid");
  const pinError = /^[0-9]{4}$/.test(pin) ? "" : t("settings.err_pin_invalid");
  const confirmError = confirmPin === pin && pin.length === 4 ? "" : t("settings.err_pin_mismatch");
  const permsError = PERMISSION_KEYS.some((k) => perms[k]) ? "" : t("settings.err_no_permission");

  const firstError = nameError || phoneError || pinError || confirmError || permsError;

  const submit = async () => {
    setTouched(true);
    setError("");
    if (firstError) {
      setError(firstError);
      return;
    }
    if (!centerId) {
      setError(t("settings.err_no_center"));
      return;
    }
    setSaving(true);
    try {
      await createOperator({
        data: { center_id: centerId, full_name: name.trim(), phone, pin, permissions: perms },
      });
      toast.success(t("settings.operator_added"));
      setName("");
      setPhone("");
      setPin("");
      setConfirmPin("");
      setPerms(DEFAULT_OPERATOR_PERMISSIONS);
      setTouched(false);
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("settings.could_not_add_operator"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <BottomSheet open={open} onClose={onClose} title={t("settings.add_operator")}>
      <div className="flex flex-col gap-3 pb-4">
        {error && <Alert message={error} />}
        <Field label={t("settings.full_name")} error={touched ? nameError : undefined}>
          <TextInput
            value={name}
            invalid={touched && !!nameError}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>
        <Field
          label={t("settings.phone_number")}
          hint={t("settings.phone_number_hint")}
          error={touched ? phoneError : undefined}
        >
          <TextInput
            prefix="+91"
            inputMode="numeric"
            maxLength={10}
            value={phone}
            invalid={touched && !!phoneError}
            onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
          />
        </Field>
        <Field label={t("settings.pin_4_digit")} error={touched ? pinError : undefined}>
          <TextInput
            inputMode="numeric"
            maxLength={4}
            value={pin}
            invalid={touched && !!pinError}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
          />
        </Field>
        <Field
          label={t("settings.confirm_pin")}
          error={
            confirmPin.length === 4 && confirmPin !== pin
              ? t("settings.err_pin_mismatch")
              : touched
                ? confirmError
                : undefined
          }
        >
          <TextInput
            inputMode="numeric"
            maxLength={4}
            value={confirmPin}
            invalid={(touched || confirmPin.length === 4) && !!confirmError}
            onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
          />
        </Field>
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2 flex items-center gap-1">
            <ShieldCheck className="h-3.5 w-3.5" /> {t("settings.permissions")}
          </p>
          <PermissionToggles value={perms} onChange={setPerms} />
          {touched && permsError && <p className="mt-1.5 text-xs text-rose-600">{permsError}</p>}
        </div>
        <Button type="button" onClick={() => void submit()} loading={saving} data-testid="create-operator">
          {t("settings.create_operator")}
        </Button>
      </div>
    </BottomSheet>
  );
}

function EditPermissionsSheet({
  row,
  onClose,
  onSave,
}: {
  row: OperatorRow | null;
  onClose: () => void;
  onSave: (row: OperatorRow, perms: Permissions) => Promise<void>;
}) {
  const { t } = useTranslation();
  const [perms, setPerms] = useState<Permissions>(DEFAULT_OPERATOR_PERMISSIONS);
  const [pin, setPin] = useState("");
  const [saving, setSaving] = useState(false);
  const { selected } = useCenter();

  useEffect(() => {
    if (row) setPerms(row.permissions);
    setPin("");
  }, [row?.id]);

  if (!row) return null;

  return (
    <BottomSheet
      open={!!row}
      onClose={onClose}
      title={t("settings.permissions_for", { name: row.full_name })}
    >
      <div className="flex flex-col gap-3 pb-4">
        <PermissionToggles value={perms} onChange={setPerms} />
        <Field label={t("settings.reset_pin_optional")}>
          <TextInput
            inputMode="numeric"
            maxLength={4}
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
          />
        </Field>
        <Button
          loading={saving}
          onClick={async () => {
            setSaving(true);
            try {
              if (/^[0-9]{4}$/.test(pin) && selected) {
                await resetOperatorPin({
                  data: { center_id: selected.id, operator_id: row.operator_id, pin },
                });
                toast.success(t("settings.pin_updated"));
              }
              await onSave(row, perms);
            } catch (err) {
              toast.error(err instanceof Error ? err.message : t("settings.could_not_save"));
            } finally {
              setSaving(false);
            }
          }}
        >
          {t("settings.save_changes")}
        </Button>
      </div>
    </BottomSheet>
  );
}
