import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { Check, Crown, Users } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { cn } from "@/lib/utils";
import {
  countActiveFarmers,
  fetchPlans,
  startPlanCheckout,
  useSubscription,
  type Plan,
} from "@/lib/subscriptions";

export const Route = createFileRoute("/subscription")({
  ssr: false,
  component: SubscriptionScreen,
});

function SubscriptionScreen() {
  const { t } = useTranslation();
  const { userId } = useAuth();
  const { selected } = useCenter();
  const { subscription, reload } = useSubscription(selected?.id ?? null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [members, setMembers] = useState<number | null>(null);
  const [picked, setPicked] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);

  useEffect(() => {
    void fetchPlans().then(setPlans).catch(() => setPlans([]));
  }, []);

  useEffect(() => {
    if (!selected) return;
    void countActiveFarmers(selected.id).then(setMembers).catch(() => setMembers(null));
  }, [selected?.id]);

  const pay = async () => {
    const plan = plans.find((p) => p.code === picked);
    if (!plan || !selected) return;
    setPaying(true);
    try {
      await startPlanCheckout({ centerId: selected.id, plan, userId });
      toast.success(t("sub.payment_placeholder"));
      await reload();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : String(err));
    } finally {
      setPaying(false);
    }
  };

  const status = subscription?.status;

  return (
    <>
      <AppHeader title={t("sub.title")} />
      <div className="p-4 space-y-4 pb-28">
        <section className="rounded-lg bg-white border border-slate-100 shadow-sm p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {t("sub.current_plan")}
          </p>
          <p className="text-base font-bold text-slate-800 mt-1">
            {subscription?.planName ?? t("sub.no_plan")}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">
            {status === "trial" && subscription?.trialDaysLeft != null
              ? t("sub.trial_days_left", { n: subscription.trialDaysLeft })
              : status === "expired"
                ? t("sub.status_expired", { n: subscription?.daysUntilDeactivation ?? 0 })
                : status === "deactivated"
                  ? t("sub.status_deactivated")
                  : t("sub.status_active")}
          </p>
          {members != null && (
            <p className="text-xs text-slate-500 mt-2 flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              {subscription?.maxFarmers
                ? t("sub.members_used", { used: members, limit: subscription.maxFarmers })
                : t("sub.members_count", { used: members })}

            </p>
          )}
        </section>

        <div className="space-y-3">
          {plans.map((p) => {
            const active = picked === p.code;
            const current = subscription?.plan === p.code;
            return (
              <button
                key={p.code}
                type="button"
                data-testid={`plan-${p.code}`}
                onClick={() => setPicked(p.code)}
                className={cn(
                  "w-full text-left rounded-lg border bg-white p-4 shadow-sm transition",
                  active ? "border-teal-600 ring-2 ring-teal-100" : "border-slate-200",
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-bold text-slate-800 flex items-center gap-1.5">
                      {p.code.startsWith("premium") && (
                        <Crown className="h-4 w-4 text-amber-500" />
                      )}
                      {p.name}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {t("sub.member_limit", { n: p.maxFarmers ?? "—" })}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-lg font-extrabold text-teal-700">₹{p.price}</p>
                    <p className="text-[11px] text-slate-500">
                      {p.cycle === "yearly" ? t("sub.per_year") : t("sub.per_month")}
                    </p>
                  </div>
                </div>
                {p.features.length > 0 && (
                  <ul className="mt-3 space-y-1">
                    {p.features.map((f) => (
                      <li key={f} className="text-xs text-slate-600 flex items-center gap-1.5">
                        <Check className="h-3.5 w-3.5 text-teal-600 shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                )}
                {current && (
                  <p className="mt-2 text-[11px] font-semibold text-teal-700">
                    {t("sub.current_badge")}
                  </p>
                )}
              </button>
            );
          })}
        </div>

        <p className="text-xs text-slate-400 text-center">{t("sub.gateway_note")}</p>
      </div>

      <div className="sticky bottom-0 bg-white border-t border-slate-200 p-4 safe-bottom">
        <Button onClick={pay} disabled={!picked} loading={paying} data-testid="plan-pay">
          {t("sub.pay")}
        </Button>
      </div>
    </>
  );
}
