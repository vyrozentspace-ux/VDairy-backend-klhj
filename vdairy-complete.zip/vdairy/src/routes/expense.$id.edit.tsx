import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { ExpenseForm } from "@/components/ExpenseForm";
import { Spinner } from "@/components/Spinner";
import { getExpense, type DairyExpense } from "@/lib/expenses";

export const Route = createFileRoute("/expense/$id/edit")({
  component: EditExp,
});

function EditExp() {
  const { t } = useTranslation();
  const { id } = useParams({ from: "/expense/$id/edit" });
  const navigate = useNavigate();
  const [row, setRow] = useState<DairyExpense | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    void getExpense(id)
      .then(setRow)
      .finally(() => setLoading(false));
  }, [id]);
  if (loading)
    return (
      <div className="p-8 flex justify-center">
        <Spinner size={22} color="#0F766E" />
      </div>
    );
  if (!row) return <div className="p-8 text-center text-slate-500">{t("expense.not_found")}</div>;
  return (
    <ExpenseForm
      mode="edit"
      existing={row}
      onBack={() => navigate({ to: "/expense/$id", params: { id } })}
      onDone={() => navigate({ to: "/expense", replace: true })}
    />
  );
}
