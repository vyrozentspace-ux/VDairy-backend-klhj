import { milkTypeLabel, shiftLabel } from "@/lib/labels";
import { formatDayMonth } from "@/lib/date-locale";
import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { AlertCircle, MessageCircle, MoreVertical, Moon, Sun } from "lucide-react";
import { z } from "zod";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field } from "@/components/Field";
import { Spinner } from "@/components/Spinner";

import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchFarmers,
  farmerFullName,
  formatMobile,
  type Farmer,
  type MilkType,
} from "@/lib/farmers";
import {
  createCollection,
  currentShiftForNow,
  getCollection,
  todayISO,
  updateCollection,
  type Collection,
  type Shift,
} from "@/lib/collections";
import { getRateForFatSnf, type CalculationMode } from "@/lib/rate-charts";
import { collectionSmsText, openSmsApp } from "@/lib/sms-receipt";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  shift: z.enum(["morning", "evening"]).optional(),
  farmer_id: z.string().optional(),
  id: z.string().optional(),
});

export const Route = createFileRoute("/collection/new")({
  validateSearch: searchSchema,
  component: CollectionEntry,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

type RateSource = "chart" | "default" | "manual" | null;

function formatSingleDecimal(rawValue: string): string {
  const cleaned = rawValue.replace(/[^0-9.]/g, "");
  if (cleaned.includes(".")) {
    const [whole, frac] = cleaned.split(".");
    const wholeDigit = whole.slice(-1) || "0";
    const fracDigit = (frac || "").slice(0, 1);
    return fracDigit ? `${wholeDigit}.${fracDigit}` : `${wholeDigit}.`;
  }
  if (cleaned.length === 1) return cleaned;
  if (cleaned.length >= 2) return `${cleaned[0]}.${cleaned[1]}`;
  return cleaned;
}

function maskMobile(m: string | null | undefined, noMobileLabel: string) {
  if (!m) return noMobileLabel;
  const d = m.replace(/\D/g, "");
  if (d.length < 6) return formatMobile(m);
  return `+91 ${d.slice(0, 5)} XXXXX`;
}

function CollectionEntry() {
  const { t } = useTranslation();
  const search = useSearch({ from: "/collection/new" });
  const navigate = useNavigate();
  const { userId } = useAuth();
  const { selected } = useCenter();

  const editingId = search.id;
  const isEditing = !!editingId;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [mode, setMode] = useState<CalculationMode>("fat_snf");

  const [date, setDate] = useState(todayISO());
  const [shift, setShift] = useState<Shift>(search.shift ?? currentShiftForNow());
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [farmerQuery, setFarmerQuery] = useState("");
  const [farmer, setFarmer] = useState<Farmer | null>(null);

  const [milkType, setMilkType] = useState<MilkType>("cow");
  const [qty, setQty] = useState("");
  const [fat, setFat] = useState("");
  const [snf, setSnf] = useState("");

  const [rate, setRate] = useState<number | null>(null);
  const [rateSource, setRateSource] = useState<RateSource>(null);
  const [manualRate, setManualRate] = useState("");

  const [duplicate, setDuplicate] = useState<Collection | null>(null);
  const [shareMessage, setShareMessage] = useState<string | null>(null);
  const [recent, setRecent] = useState<Collection[]>([]);

  const qtyRef = useRef<HTMLInputElement>(null);
  const fatRef = useRef<HTMLInputElement>(null);
  const snfRef = useRef<HTMLInputElement>(null);

  // Initial load
  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [{ data: settings }, fs] = await Promise.all([
          db
            .from("center_collection_settings")
            .select("calculation_mode")
            .eq("center_id", selected.id)
            .maybeSingle(),
          fetchFarmers(selected.id),
        ]);
        if (cancelled) return;
        setMode((settings?.calculation_mode as CalculationMode) ?? "fat_snf");
        setFarmers(fs);

        if (isEditing && editingId) {
          const existing = await getCollection(editingId);
          if (existing && !cancelled) {
            setDate(existing.collection_date);
            setShift(existing.shift);
            setMilkType(existing.milk_type);
            setFat(String(existing.fat));
            setSnf(existing.snf != null ? String(existing.snf) : "");
            setQty(String(existing.quantity_liters));
            setRate(existing.rate_per_liter);
            setRateSource("manual");
            setManualRate(String(existing.rate_per_liter));
            const f = fs.find((x) => x.id === existing.farmer_id) ?? null;
            setFarmer(f);
            if (f) setFarmerQuery(farmerFullName(f));
          }
        } else if (search.farmer_id) {
          const f = fs.find((x) => x.id === search.farmer_id) ?? null;
          if (f) {
            setFarmer(f);
            setFarmerQuery(farmerFullName(f));
            setMilkType((f.milk_type as MilkType) ?? "cow");
          }
        }
      } catch (err) {
        toast.error(err instanceof Error ? err.message : t("collection.failed_to_load"));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.id, editingId]);

  // Farmer live filter
  const matches = useMemo(() => {
    const q = farmerQuery.trim().toLowerCase();
    if (!q || farmer) return [];
    return farmers
      .filter((f) => {
        if (!f.is_active) return false;
        const code = String(f.code).toLowerCase();
        const name = farmerFullName(f).toLowerCase();
        return code.startsWith(q) || name.includes(q);
      })
      .slice(0, 20);
  }, [farmerQuery, farmers, farmer]);

  useEffect(() => {
    if (matches.length === 1 && !farmer) {
      setFarmer(matches[0]);
      setMilkType((matches[0].milk_type as MilkType) ?? milkType);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matches]);

  // Load recent entries + duplicate check
  useEffect(() => {
    if (!selected || !farmer) {
      setRecent([]);
      setDuplicate(null);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data } = await db
        .from("collections")
        .select("*")
        .eq("center_id", selected.id)
        .eq("farmer_id", farmer.id)
        .order("collection_date", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(6);
      if (cancelled) return;
      const list = (data ?? []) as Collection[];
      setRecent(list);
      const dup = list.find(
        (c) => c.collection_date === date && c.shift === shift && c.id !== editingId,
      );
      setDuplicate(dup ?? null);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id, farmer?.id, date, shift, editingId]);

  // Rate lookup (debounced)
  useEffect(() => {
    if (!selected) return;
    const fatN = Number(fat);
    const snfN = Number(snf);
    const fatComplete = /^\d\.\d$/.test(fat);
    const snfComplete = /^\d\.\d$/.test(snf);
    if (!fatComplete) {
      setRate(null);
      setRateSource(null);
      return;
    }
    if (mode === "fat_snf" && !snfComplete) {
      setRate(null);
      setRateSource(null);
      return;
    }
    let cancelled = false;
    const handle = setTimeout(() => {
      void getRateForFatSnf(selected.id, milkType, fatN, mode === "fat_only" ? 0 : snfN)
        .then((res) => {
          if (cancelled) return;
          if (res.rate == null) {
            setRate(null);
            setRateSource(null);
          } else {
            setRate(res.rate);
            // If chart exists we treat it as chart-sourced; else default base
            setRateSource(res.chart ? "chart" : "default");
          }
        })
        .catch(() => {
          if (!cancelled) {
            setRate(null);
            setRateSource(null);
          }
        });
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(handle);
    };
  }, [selected?.id, milkType, fat, snf, mode]);

  // Manual rate override
  useEffect(() => {
    if (!manualRate) return;
    const n = Number(manualRate);
    if (Number.isFinite(n) && n > 0) {
      setRate(n);
      setRateSource("manual");
    }
  }, [manualRate]);

  const qtyN = Number(qty);
  const amount = rate != null && Number.isFinite(qtyN) && qtyN > 0 ? rate * qtyN : null;
  const fatComplete = /^\d\.\d$/.test(fat);
  const snfComplete = mode === "fat_only" ? true : /^\d\.\d$/.test(snf);
  const readyForRate = fatComplete && snfComplete;

  const canSave =
    !!farmer &&
    !!selected &&
    qtyN > 0 &&
    fatComplete &&
    (mode === "fat_only" || snfComplete) &&
    rate != null &&
    rate > 0;

  const resetAll = () => {
    setFat("");
    setSnf("");
    setQty("");
    setRate(null);
    setRateSource(null);
    setManualRate("");
    setFarmer(null);
    setFarmerQuery("");
    setSaveError(null);
    setShareMessage(null);
    setDate(todayISO());
    setShift(currentShiftForNow());
    setMilkType("cow");
  };

  /**
   * Litre → Fat → SNF auto-advance chain.
   * Litre rarely reaches two decimals (people type "12" or "8.5"), so waiting for
   * a `d+.dd` match meant focus never moved. Advance immediately once two decimals
   * are typed, otherwise advance after a short pause in typing.
   */
  const qtyIdleRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const jumpToFat = () => {
    if (qtyIdleRef.current) {
      clearTimeout(qtyIdleRef.current);
      qtyIdleRef.current = null;
    }
    requestAnimationFrame(() => fatRef.current?.focus());
  };

  useEffect(
    () => () => {
      if (qtyIdleRef.current) clearTimeout(qtyIdleRef.current);
    },
    [],
  );

  const onQtyChange = (v: string) => {
    let cleaned = v.replace(/[^0-9.]/g, "");
    const firstDot = cleaned.indexOf(".");
    if (firstDot !== -1) {
      cleaned = cleaned.slice(0, firstDot + 1) + cleaned.slice(firstDot + 1).replace(/\./g, "");
      const [whole, frac] = cleaned.split(".");
      cleaned = `${whole}.${(frac ?? "").slice(0, 2)}`;
    }
    setQty(cleaned);

    if (qtyIdleRef.current) {
      clearTimeout(qtyIdleRef.current);
      qtyIdleRef.current = null;
    }
    if (!(Number(cleaned) > 0)) return;

    if (/^\d+\.\d{2}$/.test(cleaned)) {
      jumpToFat();
      return;
    }
    // Whole number or single decimal: wait briefly in case more digits follow.
    qtyIdleRef.current = setTimeout(() => {
      qtyIdleRef.current = null;
      if (document.activeElement === qtyRef.current) fatRef.current?.focus();
    }, 650);
  };

  const onFatChange = (v: string) => {
    const formatted = formatSingleDecimal(v);
    setFat(formatted);
    if (/^\d\.\d$/.test(formatted)) {
      if (mode === "fat_only") snfRef.current?.blur();
      else requestAnimationFrame(() => snfRef.current?.focus());
    }
  };
  const onSnfChange = (v: string) => {
    const formatted = formatSingleDecimal(v);
    setSnf(formatted);
    if (/^\d\.\d$/.test(formatted)) {
      requestAnimationFrame(() => snfRef.current?.blur());
    }
  };
  const advanceOnEnter = (e: React.KeyboardEvent<HTMLInputElement>, next: "fat" | "snf" | null) => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    if (next === "fat") fatRef.current?.focus();
    else if (next === "snf" && mode !== "fat_only") snfRef.current?.focus();
    else (e.target as HTMLInputElement).blur();
  };

  const doSave = async () => {
    setSaveError(null);
    if (!canSave || !selected || !farmer || rate == null) return;
    setSaving(true);
    try {
      const payload = {
        center_id: selected.id,
        farmer_id: farmer.id,
        collection_date: date,
        shift,
        milk_type: milkType,
        fat: Number(fat),
        snf: mode === "fat_only" ? null : Number(snf),
        quantity_liters: qtyN,
        rate_per_liter: rate,
        total_amount: rate * qtyN,
        created_by: userId ?? null,
      };
      if (isEditing && editingId) {
        const { synced } = await updateCollection(editingId, payload, {
          center_id: selected.id,
          created_by: userId ?? null,
        });
        toast.success(synced ? t("collection.collection_updated") : t("sync.saved_locally"));
        navigate({ to: "/collection" });
        return;
      }
      // Build the receipt text up-front so the SMS app can open the instant the
      // user taps Save — no waiting on the database round-trip or a lazy import.
      const msg = [
        `${selected.name}`,
        `${farmerFullName(farmer)} (${farmer.code})`,
        `${date} · ${shift}`,
        `${qtyN}L · Fat ${fat}${mode !== "fat_only" ? ` · SNF ${snf}` : ""}`,
        `Rate ₹${rate.toFixed(2)}/L`,
        `Total ₹${(rate * qtyN).toFixed(2)}`,
      ].join("\n");
      const smsText = collectionSmsText({
        centerName: selected.name,
        farmerName: farmerFullName(farmer),
        farmerCode: farmer.code,
        date,
        shift,
        fat,
        snf: mode === "fat_only" ? null : snf,
        liters: qtyN,
        rate,
        amount: rate * qtyN,
      });

      const saved = createCollection(payload);
      setShareMessage(msg);
      openSmsApp(farmer.mobile, smsText);
      const { synced } = await saved;
      toast.success(synced ? t("collection.collection_saved") : t("sync.saved_locally"));

    } catch (err) {
      setSaveError(err instanceof Error ? err.message : t("collection.failed_to_save"));
    } finally {
      setSaving(false);
    }
  };

  // Manual, image-based WhatsApp receipt (kept alongside the auto-SMS).
  const shareWA = async () => {
    if (!shareMessage || !selected || !farmer || rate == null) return;
    const { shareReceipt } = await import("@/lib/share");
    await shareReceipt(
      {
        title: t("collection.milk_collection_receipt"),
        centerName: selected.name,
        farmerName: farmerFullName(farmer),
        farmerCode: farmer.code,
        date: `${date} · ${shift}`,
        lines: [
          { label: t("collection.quantity"), value: `${qtyN} L` },
          { label: t("collection.fat"), value: fat },
          ...(mode !== "fat_only" ? [{ label: t("collection.snf"), value: snf }] : []),
          { label: t("collection.rate"), value: `₹${rate.toFixed(2)}/L` },
        ],
        totalLabel: t("collection.total"),
        totalValue: `₹${(rate * qtyN).toFixed(2)}`,
      },
      { text: shareMessage, phone: farmer.mobile },
    );
  };

  return (
    <>
      <AppHeader
        title={isEditing ? t("collection.edit_collection") : t("collection.add_collection")}
        onBack={() => navigate({ to: "/collection" })}
        right={
          <button
            type="button"
            onClick={resetAll}
            aria-label={t("collection.reset_form")}
            className="h-10 w-10 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100"
          >
            <MoreVertical className="h-5 w-5" />
          </button>
        }
      />
      <div className="px-4 pt-1 pb-0 text-xs text-slate-500 truncate">{selected?.name}</div>

      {loading ? (
        <div className="py-16 flex justify-center">
          <Spinner />
        </div>
      ) : (
        <div className="p-4 space-y-3 pb-24">
          {shareMessage && (
            <button
              type="button"
              onClick={shareWA}
              className="w-full h-12 rounded-lg font-semibold text-sm inline-flex items-center justify-center gap-2 text-white transition"
              style={{ backgroundColor: "#25D366" }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#1da851")}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#25D366")}
            >
              <MessageCircle className="h-4 w-4" /> {t("collection.share_on_whatsapp")}
            </button>
          )}

          {duplicate && (
            <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
              <div className="flex-1">
                {t("collection.duplicate_entry_warning")}{" "}
                <Link
                  to="/collection/new"
                  search={{ id: duplicate.id }}
                  className="underline font-semibold"
                >
                  {t("collection.edit_that_entry")}
                </Link>
              </div>
            </div>
          )}

          {/* Compact top row: date · session · milk type */}
          <div className="flex items-center gap-1 overflow-x-auto">
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="shrink-0 h-9 w-28 rounded-lg border border-slate-200 px-2 text-xs text-slate-700 bg-white"
            />
            {(["morning", "evening"] as Shift[]).map((s) => {
              const active = shift === s;
              const Icon = s === "morning" ? Sun : Moon;
              return (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShift(s)}
                  aria-label={shiftLabel(t, s)}
                  title={shiftLabel(t, s)}
                  className={cn(
                    "shrink-0 h-9 w-9 rounded-lg border flex items-center justify-center",
                    active
                      ? "bg-teal-700 border-teal-700 text-white"
                      : "bg-white border-slate-200 text-slate-600",
                  )}
                >
                  <Icon className="h-4 w-4" />
                </button>
              );
            })}
            {(["cow", "buffalo"] as MilkType[]).map((mt) => {
              const active = milkType === mt;
              return (
                <button
                  key={mt}
                  type="button"
                  onClick={() => setMilkType(mt)}
                  className={cn(
                    "shrink-0 h-9 px-3 rounded-lg border text-xs font-semibold",
                    active
                      ? "bg-teal-700 border-teal-700 text-white"
                      : "bg-white border-slate-200 text-slate-600",
                  )}
                >
                  {milkTypeLabel(t, mt)}
                </button>
              );
            })}
          </div>

          {/* Farmer live-filter input */}
          <Field label={t("collection.farmer_code_or_name")}>
            <div className="flex items-stretch h-12 rounded-lg border border-slate-200 bg-white overflow-hidden focus-within:border-teal-500 focus-within:ring-2 focus-within:ring-teal-100">
              <input
                value={farmerQuery}
                disabled={isEditing}
                onChange={(e) => {
                  setFarmerQuery(e.target.value);
                  if (farmer) setFarmer(null);
                }}
                placeholder={t("collection.type_code_or_name")}
                className="flex-1 min-w-0 px-3 bg-transparent outline-none text-sm text-slate-800 placeholder:text-slate-400"
              />
            </div>
            {!farmer && matches.length > 1 && (
              <div className="mt-2 rounded-lg border border-slate-200 bg-white shadow-sm">
                <div className="px-3 py-1.5 text-[11px] uppercase font-semibold text-slate-500 tracking-wider border-b border-slate-100">
                  {t("collection.farmers_match", { count: matches.length })}
                </div>
                <div className="max-h-48 overflow-y-auto">
                  {matches.map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => {
                        setFarmer(f);
                        setFarmerQuery(farmerFullName(f));
                        setMilkType((f.milk_type as MilkType) ?? milkType);
                      }}
                      className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-slate-50 border-b border-slate-100 last:border-0"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-800 truncate">
                          {farmerFullName(f)}
                        </div>
                        <div className="text-xs text-slate-500">
                          {t("collection.code_label", { code: f.code })}
                        </div>
                      </div>
                      <span className="text-xs text-teal-600 shrink-0">
                        {milkTypeLabel(t, f.milk_type)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {!farmer && farmerQuery.trim() && matches.length === 0 && (
              <p className="mt-1 text-xs text-rose-600">
                {t("collection.no_farmer_found", { type: milkTypeLabel(t, milkType) })}
              </p>
            )}
            {farmer && (
              <div className="mt-2 rounded-lg bg-teal-50 border border-teal-200 px-3 py-2 flex items-center justify-between">
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-teal-900 truncate">
                    {farmerFullName(farmer)}
                  </div>
                  <div className="text-xs text-teal-700 truncate">
                    {maskMobile(farmer.mobile, t("collection.no_mobile"))}
                  </div>
                </div>
                <div className="text-sm font-bold text-teal-700 shrink-0">
                  {milkTypeLabel(t, farmer.milk_type)}
                </div>
              </div>
            )}
          </Field>

          {/* Compact 4-col entry grid */}
          <div className="grid grid-cols-4 gap-2">
            <Field label={t("collection.litre")}>
              <input
                ref={qtyRef}
                inputMode="decimal"
                enterKeyHint="next"
                value={qty}
                onChange={(e) => onQtyChange(e.target.value)}
                onKeyDown={(e) => advanceOnEnter(e, "fat")}
                placeholder="0.00"
                className="w-full h-10 rounded-lg border border-slate-200 bg-white text-center text-sm text-slate-800 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
              />
            </Field>
            <Field label={t("collection.fat")}>
              <input
                ref={fatRef}
                inputMode="decimal"
                enterKeyHint="next"
                value={fat}
                onChange={(e) => onFatChange(e.target.value)}
                onKeyDown={(e) => advanceOnEnter(e, "snf")}
                placeholder="0.0"
                className="w-full h-10 rounded-lg border border-slate-200 bg-white text-center text-sm text-slate-800 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
              />
            </Field>
            <Field label={t("collection.snf")}>
              <input
                ref={snfRef}
                inputMode="decimal"
                enterKeyHint="done"
                value={snf}
                disabled={mode === "fat_only"}
                onChange={(e) => onSnfChange(e.target.value)}
                onKeyDown={(e) => advanceOnEnter(e, null)}
                placeholder="0.0"
                className="w-full h-10 rounded-lg border border-slate-200 bg-white text-center text-sm text-slate-800 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100 disabled:bg-slate-50 disabled:text-slate-400"
              />
            </Field>
            <Field label={t("collection.amount")}>
              <div className="w-full h-10 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center text-sm font-bold text-slate-800">
                {amount != null ? `₹${amount.toFixed(2)}` : "—"}
              </div>
            </Field>
          </div>

          {rate != null && rateSource ? (
            <div className="text-xs text-slate-500">
              {t("collection.rate_display", { rate: rate.toFixed(2), source: rateSource })}
            </div>
          ) : readyForRate && rate == null ? (
            <div className="space-y-2">
              <div className="text-xs text-rose-600">
                {t("collection.no_rate_configured", { type: milkTypeLabel(t, milkType) })}{" "}
                <Link to="/settings" className="underline font-semibold">
                  {t("collection.set_default_rate")}
                </Link>{" "}
                {t("collection.or_enter_manually")}
              </div>
              <div className="flex items-center gap-2">
                <label className="text-xs text-slate-500">{t("collection.rate_per_l")}</label>
                <input
                  inputMode="decimal"
                  value={manualRate}
                  onChange={(e) => setManualRate(e.target.value.replace(/[^0-9.]/g, ""))}
                  placeholder="0.00"
                  className="h-8 w-24 rounded-lg border border-slate-200 px-2 text-xs text-slate-800 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
                />
              </div>
            </div>
          ) : null}

          {saveError && (
            <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" /> <span>{saveError}</span>
            </div>
          )}

          {farmer && recent.length > 0 && (
            <div className="space-y-1.5 pt-2">
              <div className="text-[11px] uppercase font-semibold text-slate-400 tracking-wider">
                {t("collection.recent_entries")}
              </div>
              <div className="rounded-lg border border-slate-200 bg-white divide-y divide-slate-100">
                {recent.map((r) => {
                  const Icon = r.shift === "morning" ? Sun : Moon;
                  const d = new Date(r.collection_date + "T00:00:00");
                  const short = formatDayMonth(d);
                  return (
                    <div
                      key={r.id}
                      className="flex items-center gap-2 px-3 py-1.5 text-xs text-slate-700"
                    >
                      <span className="w-14 shrink-0">{short}</span>
                      <Icon className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                      <div className="flex-1 text-right">
                        F{r.fat} {r.snf != null && `S${r.snf}`}{" "}
                        <span className="font-bold text-emerald-600">
                          ₹{Number(r.total_amount).toFixed(0)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 px-4 py-3 safe-bottom flex gap-3">
        <Button variant="secondary" onClick={resetAll} disabled={saving} className="flex-1">
          {t("collection.reset")}
        </Button>
        <Button onClick={doSave} loading={saving} disabled={!canSave || saving} className="flex-1">
          {isEditing ? t("collection.update") : t("collection.save_and_share")}
        </Button>
      </div>
    </>
  );
}
