import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Field, TextInput } from "@/components/Field";
import { Dropdown } from "@/components/Dropdown";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import { farmerFullName, type Farmer } from "@/lib/farmers";
import { usePeriodConfig } from "@/hooks/usePeriodConfig";
import { periodForDate } from "@/lib/payment-periods";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/reports")({
  ssr: false,
  component: ReportsScreen,
});

type Row = {
  collection_date: string;
  shift: string;
  farmer_id: string;
  quantity_liters: number;
  fat: number;
  snf: number | null;
  rate_per_liter: number;
  total_amount: number;
};

function todayISO(d = new Date()) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).toISOString().slice(0, 10);
}

function ReportsScreen() {
  const { t } = useTranslation();
  const { session, loading: authLoading } = useAuth();
  const { selected } = useCenter();
  const { config: periodConfig, loaded: periodConfigLoaded } = usePeriodConfig();
  const navigate = useNavigate();
  const [tab, setTab] = useState<"farmer" | "all">("farmer");
  const [from, setFrom] = useState(todayISO());
  const [to, setTo] = useState(todayISO());
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [farmerId, setFarmerId] = useState<string>("");
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!periodConfigLoaded) return;
    const current = periodForDate(periodConfig, new Date());
    setFrom(current.start);
    setTo(current.end);
  }, [selected?.id, periodConfigLoaded, periodConfig.paymentPeriod, periodConfig.startDate]);

  useEffect(() => {
    if (!authLoading && !session) navigate({ to: "/login", replace: true });
  }, [authLoading, session, navigate]);

  useEffect(() => {
    if (!selected) return;
    void (async () => {
      const { data } = await supabase
        .from("farmers")
        .select("*")
        .eq("center_id", selected.id)
        .order("code");
      setFarmers((data ?? []) as Farmer[]);
      if (data && data.length && !farmerId) setFarmerId(data[0].id);
    })();
  }, [selected?.id]);

  useEffect(() => {
    if (!selected) return;
    setLoading(true);
    let q = supabase
      .from("collections")
      .select(
        "collection_date, shift, farmer_id, quantity_liters, fat, snf, rate_per_liter, total_amount",
      )
      .eq("center_id", selected.id)
      .gte("collection_date", from)
      .lte("collection_date", to)
      .order("collection_date", { ascending: false });
    if (tab === "farmer" && farmerId) q = q.eq("farmer_id", farmerId);
    void q.then(({ data }) => {
      setRows((data ?? []) as Row[]);
      setLoading(false);
    });
  }, [selected?.id, from, to, tab, farmerId]);

  const totals = useMemo(() => {
    const liters = rows.reduce((s, r) => s + Number(r.quantity_liters), 0);
    const amount = rows.reduce((s, r) => s + Number(r.total_amount), 0);
    const avgFat = rows.length ? rows.reduce((s, r) => s + Number(r.fat), 0) / rows.length : 0;
    return { liters, amount, avgFat };
  }, [rows]);

  const byFarmer = useMemo(() => {
    if (tab !== "all") return [];
    const map = new Map<string, { liters: number; amount: number }>();
    for (const r of rows) {
      const cur = map.get(r.farmer_id) ?? { liters: 0, amount: 0 };
      cur.liters += Number(r.quantity_liters);
      cur.amount += Number(r.total_amount);
      map.set(r.farmer_id, cur);
    }
    return Array.from(map.entries())
      .map(([fid, v]) => {
        const f = farmers.find((x) => x.id === fid);
        return { id: fid, name: f ? farmerFullName(f) : "—", code: f?.code ?? "", ...v };
      })
      .sort((a, b) => b.liters - a.liters);
  }, [rows, farmers, tab]);

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={t("dashboard.reports")} />
      <div className="max-w-md mx-auto p-4 flex flex-col gap-4 pb-24">
        <div className="rounded-lg bg-white border border-slate-200 p-1 grid grid-cols-2 gap-1">
          {(["farmer", "all"] as const).map((tabKey) => (
            <button
              key={tabKey}
              onClick={() => setTab(tabKey)}
              className={cn(
                "h-9 rounded-md text-sm font-semibold transition",
                tab === tabKey ? "bg-teal-700 text-white" : "text-slate-600 hover:bg-slate-50",
              )}
            >
              {tabKey === "farmer" ? t("dashboard.farmer_detail") : t("dashboard.all_farmers")}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label={t("dashboard.from")}>
            <TextInput type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </Field>
          <Field label={t("dashboard.to")}>
            <TextInput type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </Field>
        </div>

        {tab === "farmer" && (
          <Field label={t("dashboard.farmer")}>
            <Dropdown
              value={farmerId}
              onChange={setFarmerId}
              options={farmers.map((f) => ({
                value: f.id,
                label: `${f.code} — ${farmerFullName(f)}`,
              }))}
            />
          </Field>
        )}

        <div className="grid grid-cols-3 gap-2 text-center">
          <Stat label={t("dashboard.liters")} value={totals.liters.toFixed(1)} />
          <Stat label={t("dashboard.amount")} value={`₹${totals.amount.toFixed(0)}`} />
          <Stat label={t("dashboard.avg_fat")} value={totals.avgFat.toFixed(1)} />
        </div>

        {loading ? (
          <div className="flex justify-center py-6">
            <Spinner size={24} color="#0F766E" />
          </div>
        ) : tab === "farmer" ? (
          <div className="rounded-lg bg-white border border-slate-200 divide-y divide-slate-100">
            {rows.length === 0 && (
              <p className="p-4 text-sm text-slate-500 text-center">{t("dashboard.no_records")}</p>
            )}
            {rows.map((r, i) => (
              <div key={i} className="p-3 flex items-center justify-between text-sm">
                <div>
                  <div className="font-semibold text-slate-800">{r.collection_date}</div>
                  <div className="text-xs text-slate-500 capitalize">
                    {r.shift} · {Number(r.quantity_liters).toFixed(1)} L · {t("dashboard.fat")}{" "}
                    {Number(r.fat).toFixed(1)}
                  </div>
                </div>
                <div className="font-semibold text-teal-700">
                  ₹{Number(r.total_amount).toFixed(0)}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-lg bg-white border border-slate-200 divide-y divide-slate-100">
            {byFarmer.length === 0 && (
              <p className="p-4 text-sm text-slate-500 text-center">{t("dashboard.no_records")}</p>
            )}
            {byFarmer.map((f) => (
              <div key={f.id} className="p-3 flex items-center justify-between text-sm">
                <div>
                  <div className="font-semibold text-slate-800">
                    {f.code} — {f.name}
                  </div>
                  <div className="text-xs text-slate-500">{f.liters.toFixed(1)} L</div>
                </div>
                <div className="font-semibold text-teal-700">₹{f.amount.toFixed(0)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-white border border-slate-200 p-3">
      <div className="text-[10px] uppercase tracking-wide text-slate-400 font-semibold">
        {label}
      </div>
      <div className="mt-1 font-bold text-slate-800">{value}</div>
    </div>
  );
}
