import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AlertCircle } from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { createDealerPayment, getDealer, type FeedDealer } from "@/lib/food";
import { logActivity } from "@/lib/farmers";

export const Route = createFileRoute("/food/dealers/$dealerId/payment")({
  component: DealerPayment,
});

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function DealerPayment() {
  const { t } = useTranslation();
  const { dealerId } = useParams({ from: "/food/dealers/$dealerId/payment" });
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { userId } = useAuth();
  const [dealer, setDealer] = useState<FeedDealer | null>(null);
  const [date, setDate] = useState(todayISO());
  const [amount, setAmount] = useState("");
  const [comments, setComments] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void getDealer(dealerId).then(setDealer);
  }, [dealerId]);

  const amountN = Number(amount);
  const canSave = !!selected && amountN > 0;

  const submit = async () => {
    setError(null);
    if (!canSave || !selected) return;
    setSaving(true);
    try {
      await createDealerPayment({
        center_id: selected.id,
        dealer_id: dealerId,
        payment_date: date,
        amount: amountN,
        comments: comments.trim() || null,
        entered_by: userId ?? null,
      });
      await logActivity(selected.id, userId ?? "", "dealer_payment_added", {
        dealer_id: dealerId,
        amount: amountN,
      });
      toast.success(t("food.payment_recorded"));
      navigate({ to: "/food/dealers/$dealerId", params: { dealerId } });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("food.failed_to_save"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AppHeader
        title={t("food.dealer_payment")}
        onBack={() => navigate({ to: "/food/dealers/$dealerId", params: { dealerId } })}
      />
      <div className="p-4 space-y-4 pb-28">
        <div className="text-xs text-slate-500 -mt-2">{dealer?.dealer_name ?? ""}</div>
        <Field label={t("food.payment_date")}>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full h-12 rounded-lg border border-slate-200 px-3 text-sm"
          />
        </Field>
        <Field label={t("food.amount")}>
          <TextInput
            type="number"
            inputMode="decimal"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0"
          />
        </Field>
        <Field label={t("food.comments_optional")}>
          <TextInput value={comments} onChange={(e) => setComments(e.target.value)} />
        </Field>
        {error && (
          <div className="rounded-lg bg-rose-50 border border-rose-100 px-3 py-2 flex items-start gap-2 text-sm text-rose-700">
            <AlertCircle className="h-4 w-4 mt-0.5" /> {error}
          </div>
        )}
      </div>
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 p-3 grid grid-cols-2 gap-3 safe-bottom">
        <Button
          variant="secondary"
          onClick={() => navigate({ to: "/food/dealers/$dealerId", params: { dealerId } })}
        >
          {t("food.cancel")}
        </Button>
        <Button onClick={submit} loading={saving} disabled={!canSave}>
          {t("food.save")}
        </Button>
      </div>
    </>
  );
}
