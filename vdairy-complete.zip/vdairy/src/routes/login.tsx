import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Alert } from "@/components/Alert";
import { useAuth } from "@/contexts/AuthContext";
import { APP_NAME } from "@/lib/app-config";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/login")({
  ssr: false,
  component: LoginScreen,
});

function LoginScreen() {
  const { t } = useTranslation();
  const { loginWithPin } = useAuth();
  const navigate = useNavigate();
  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const canSubmit = phone.length === 10 && pin.length === 4;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setLoading(true);
    setError("");
    try {
      await loginWithPin(phone, pin);
      navigate({ to: "/centers", replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("auth.sign_in_failed"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col justify-center px-6 safe-top safe-bottom">
      <div className="w-full max-w-md mx-auto">
        <div className="flex justify-center mb-3">
          <Logo size="lg" />
        </div>
        <p className="text-center text-sm text-slate-500 mb-8">{t("auth.sign_in_subtitle")}</p>

        <form onSubmit={submit} className="flex flex-col gap-4">
          {error && <Alert message={error} />}
          <Field label={t("auth.phone_number")}>
            <TextInput
              prefix="+91"
              inputMode="numeric"
              maxLength={10}
              placeholder={t("auth.phone_placeholder")}
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
            />
          </Field>
          <Field label={t("auth.password")}>
            <TextInput
              type={showPin ? "text" : "password"}
              inputMode="numeric"
              maxLength={4}
              placeholder={t("auth.pin_placeholder")}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
              suffix={
                <button
                  type="button"
                  onClick={() => setShowPin((v) => !v)}
                  className="p-2 text-slate-400 hover:text-slate-600"
                  aria-label={showPin ? t("auth.hide_pin") : t("auth.show_pin")}
                >
                  {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              }
            />
          </Field>
          <Button type="submit" disabled={!canSubmit} loading={loading}>
            {t("auth.sign_in")}
          </Button>
          <div className="text-left">
            <Link to="/forgot-password" className="text-sm text-teal-700 font-medium">
              {t("auth.forgot_password")}
            </Link>
          </div>
          <div className="pt-4 border-t border-slate-200 text-center text-sm text-slate-600">
            {t("auth.new_to_app", { appName: APP_NAME })}{" "}
            <Link to="/register" className="text-teal-700 font-semibold">
              {t("auth.register_as_owner")}
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
