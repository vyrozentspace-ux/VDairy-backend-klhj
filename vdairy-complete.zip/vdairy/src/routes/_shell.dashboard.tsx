import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Bell,
  ChevronDown,
  FileText,
  Gift,
  ListChecks,
  MessageSquare,
  Milk,
  Moon,
  Package,
  Plus,
  Receipt,
  ScrollText,
  Settings,
  Store,
  Sun,
  TrendingUp,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";

import { Logo } from "@/components/Logo";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { NotificationsSheet } from "@/components/NotificationsSheet";
import { TrialBanner } from "@/components/TrialBanner";
import { ContentSlot } from "@/components/ContentSlot";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { cn } from "@/lib/utils";
import { listCollections, todayISO, type Collection } from "@/lib/collections";
import { requiredPermissionsFor } from "@/lib/permissions";
import { PendingSyncBadge } from "@/components/PendingSyncBadge";
import { SocialLinksBar } from "@/components/SocialLinksBar";
import { useSubscription } from "@/lib/subscriptions";


export const Route = createFileRoute("/_shell/dashboard")({
  component: DashboardScreen,
});

type FeatureTo =
  | "/farmers"
  | "/collection"
  | "/invoice"
  | "/reports"
  | "/rate-charts"
  | "/notices"
  | "/bonus"
  | "/store"
  | "/advance"
  | "/food"
  | "/milk-sale"
  | "/expense";

type Feature = { labelKey: string; Icon: LucideIcon; to: FeatureTo };

const FEATURES: Feature[] = [
  { labelKey: "dashboard.collection", Icon: Milk, to: "/collection" },
  { labelKey: "dashboard.farmers", Icon: Users, to: "/farmers" },
  { labelKey: "dashboard.food", Icon: Package, to: "/food" },
  { labelKey: "dashboard.advance", Icon: Wallet, to: "/advance" },
  { labelKey: "dashboard.invoice", Icon: FileText, to: "/invoice" },
  { labelKey: "dashboard.milk_sale", Icon: TrendingUp, to: "/milk-sale" },
  { labelKey: "dashboard.expense", Icon: Receipt, to: "/expense" },
  { labelKey: "dashboard.rate_chart", Icon: ListChecks, to: "/rate-charts" },
  { labelKey: "dashboard.reports", Icon: ScrollText, to: "/reports" },
  { labelKey: "dashboard.notice_board", Icon: MessageSquare, to: "/notices" },
  { labelKey: "dashboard.annual_bonus", Icon: Gift, to: "/bonus" },
  { labelKey: "dashboard.store", Icon: Store, to: "/store" },
];

function DashboardScreen() {
  const { t } = useTranslation();
  const { selected, centers, select, isOwner, ownerName, canAny, can } = useCenter();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [switcher, setSwitcher] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [today, setToday] = useState<Collection[]>([]);
  // Owners can always open the switcher (to add another dairy); operators only
  // when they are assigned to more than one center.
  const canSwitch = centers.length > 1 || isOwner;

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    void listCollections({ centerId: selected.id, date: todayISO(), shift: "all" })
      .then((rows) => {
        if (!cancelled) setToday(rows);
      })
      .catch(() => {
        /* non-fatal */
      });
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  const totalLiters = today.reduce((s, c) => s + Number(c.quantity_liters), 0);
  const totalAmount = today.reduce((s, c) => s + Number(c.total_amount), 0);
  const hasCollections = today.length > 0;

  const features = FEATURES.filter((f) => {
    const required = requiredPermissionsFor(f.to);
    return !required || canAny(required);
  });

  const { subscription } = useSubscription(selected?.id ?? null);

  return (
    <>
      <header className="sticky top-0 z-20 bg-teal-700 text-white safe-top shadow-sm">
        <div className="flex items-center h-14 px-3 gap-2">
          <Logo size="sm" variant="white" />
          <button
            type="button"
            data-testid="dashboard-center-switch"
            onClick={() => canSwitch && setSwitcher(true)}
            className={cn(
              "flex-1 min-w-0 flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg",
              canSwitch ? "hover:bg-teal-800" : "cursor-default",
            )}
          >
            <span className="font-semibold text-sm truncate">
              {selected?.name ?? t("dashboard.select_center")}
            </span>
            {canSwitch && <ChevronDown className="h-4 w-4 shrink-0" />}
          </button>
          <PendingSyncBadge />
          <button

            type="button"
            onClick={() => setNotifOpen(true)}
            aria-label={t("dashboard.notifications")}
            className="relative h-11 w-11 rounded-full flex items-center justify-center hover:bg-teal-800"
          >
            <Bell className="h-5 w-5" />
            {/* Unread dot — stub, hidden until wired */}
          </button>
          <button
            type="button"
            onClick={() => navigate({ to: "/settings" })}
            aria-label={t("dashboard.settings")}
            className="h-11 w-11 rounded-full flex items-center justify-center hover:bg-teal-800"
          >
            <Settings className="h-5 w-5" />
          </button>
        </div>
      </header>

      <div className="p-4 space-y-5">
        {/* Control-Panel-driven banner slot. Renders nothing while inactive/empty. */}
        <ContentSlot slotKey="dashboard_banner" />
        {isOwner && <TrialBanner subscription={subscription} />}
        <section className="rounded-lg bg-white border border-slate-100 shadow-sm p-4">
          <p className="text-base font-bold text-slate-800">
            {t("dashboard.hello_name", { name: profile?.full_name ?? t("dashboard.there") })}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">
            {isOwner
              ? selected
                ? t("dashboard.owner_at", { center: selected.name })
                : t("dashboard.owner")
              : t("dashboard.operator_at", {
                  dairy: ownerName
                    ? t("dashboard.name_s_dairy", { name: ownerName })
                    : (selected?.name ?? t("dashboard.this_dairy")),
                })}
          </p>
        </section>

        <section>
          <div className="grid grid-cols-3 gap-3">
            {features.map(({ labelKey, Icon, to }) => (
              <Link
                key={labelKey}
                to={to}
                className="rounded-lg bg-white border border-slate-100 shadow-sm p-4 flex flex-col items-center gap-2 hover:border-teal-200 transition"
              >
                <span className="h-12 w-12 rounded-full flex items-center justify-center bg-teal-50 text-teal-700">
                  <Icon size={22} />
                </span>
                <span className="text-xs font-semibold text-slate-700 text-center">
                  {t(labelKey)}
                </span>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
            {t("dashboard.todays_collection")}
          </h2>
          <div className="space-y-3">
            {hasCollections && (
              <div className="rounded-lg bg-teal-50 border border-teal-100 p-4 flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wide text-teal-700">
                  {t("dashboard.today")}
                </span>
                <span className="font-bold text-teal-700">
                  {totalLiters.toFixed(1)} L — ₹{totalAmount.toFixed(2)}
                </span>
              </div>
            )}
            {can("collection") && (
              <div className="grid grid-cols-2 gap-3">
                <Link
                  to="/collection/new"
                  search={{ shift: "morning" }}
                  className="rounded-lg bg-white border border-slate-200 p-4 flex flex-col items-start gap-2 hover:border-teal-300 transition"
                >
                  <span className="h-9 w-9 rounded-full flex items-center justify-center bg-amber-50 text-amber-600">
                    <Sun className="h-4 w-4" />
                  </span>
                  <span className="text-sm font-bold text-slate-800">
                    {t("dashboard.add_morning")}
                  </span>
                  <span className="text-xs text-slate-400">{t("dashboard.collection")}</span>
                </Link>
                <Link
                  to="/collection/new"
                  search={{ shift: "evening" }}
                  className="rounded-lg bg-white border border-slate-200 p-4 flex flex-col items-start gap-2 hover:border-teal-300 transition"
                >
                  <span className="h-9 w-9 rounded-full flex items-center justify-center bg-indigo-50 text-indigo-600">
                    <Moon className="h-4 w-4" />
                  </span>
                  <span className="text-sm font-bold text-slate-800">
                    {t("dashboard.add_evening")}
                  </span>
                  <span className="text-xs text-slate-400">{t("dashboard.collection")}</span>
                </Link>
              </div>
            )}
          </div>
        </section>

        <SocialLinksBar />
      </div>

      <BottomSheet
        open={switcher}
        onClose={() => setSwitcher(false)}
        title={t("dashboard.switch_center")}
      >
        <div className="space-y-1 pb-2">
          {centers.map((c) => (
            <SheetItem
              key={c.id}
              icon={<span className="text-xs font-bold">{c.code}</span>}
              label={c.name}
              meta={c.id === selected?.id ? t("dashboard.current") : undefined}
              onClick={() => {
                select(c.id);
                setSwitcher(false);
              }}
            />
          ))}
          {isOwner && (
            <SheetItem
              icon={<Plus className="h-4 w-4" />}
              label={t("settings.add_another_center")}
              onClick={() => {
                setSwitcher(false);
                navigate({ to: "/onboarding/create-center" });
              }}
            />
          )}
        </div>
      </BottomSheet>

      <NotificationsSheet open={notifOpen} onClose={() => setNotifOpen(false)} />
    </>
  );
}
