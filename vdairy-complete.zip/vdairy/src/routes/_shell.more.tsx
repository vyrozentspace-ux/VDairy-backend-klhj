import { formatNumericDate } from "@/lib/date-locale";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Bell,
  Building2,
  Crown,
  FileText,
  Gift,
  Globe,
  KeyRound,
  Languages,
  LogOut,
  Mail,
  MessageSquare,
  Phone,
  Plus,
  ShieldCheck,
  User,
  UserCog,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { Button } from "@/components/Button";
import { Dropdown } from "@/components/Dropdown";
import { LANGUAGES, APP_LANG_KEY, setAppLanguage } from "@/lib/i18n";
import { isAppLockEnabled, setAppLockEnabled } from "@/lib/app-lock";
import { useAppSettings } from "@/lib/app-settings";
import { ContentSlot } from "@/components/ContentSlot";
import { NotificationSettingsSection } from "@/components/NotificationSettingsSection";
import {
  RECEIPT_LANG_KEY,
  clearReceiptLang,
  collectionSmsText,
  type ReceiptLang,
} from "@/lib/sms-receipt";

export const Route = createFileRoute("/_shell/more")({
  component: MoreScreen,
});

function MoreScreen() {
  const { t, i18n } = useTranslation();
  const { profile, logout } = useAuth();
  const { selected, centers, select, isOwner, ownerName, can } = useCenter();
  const navigate = useNavigate();
  const [dairySheet, setDairySheet] = useState(false);
  const settings = useAppSettings();

  const appLang = i18n.resolvedLanguage ?? i18n.language ?? "en";
  // "" means: no explicit choice — receipts follow the App Language.
  const [receiptLang, setReceiptLang] = useState<string>("");
  const [appLock, setAppLock] = useState<boolean>(false);
  const [notifState, setNotifState] = useState<string>("unknown");

  useEffect(() => {
    if (typeof window === "undefined") return;
    setReceiptLang(window.localStorage.getItem(RECEIPT_LANG_KEY) ?? "");
    if (!window.localStorage.getItem(APP_LANG_KEY) && profile?.language_preference) {
      setAppLanguage(profile.language_preference);
    }
    setAppLock(isAppLockEnabled());
    if (typeof Notification !== "undefined") setNotifState(Notification.permission);
    else setNotifState("unsupported");
  }, [profile?.language_preference]);

  const onLogout = async () => {
    await logout();
    navigate({ to: "/login", replace: true });
  };

  const persist = (k: string, v: string) => {
    if (typeof window !== "undefined") window.localStorage.setItem(k, v);
  };

  return (
    <>
      <AppHeader title={t("settings.title")} onBack={() => navigate({ to: "/dashboard" })} />
      <div className="p-4 flex flex-col gap-4 pb-24">
        <div className="rounded-lg border border-slate-200 bg-white p-4 flex items-center gap-3">
          <div className="h-12 w-12 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-lg">
            {(profile?.full_name ?? "?").slice(0, 1).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-slate-800 truncate">{profile?.full_name ?? "—"}</div>
            <div className="text-xs text-slate-500 truncate">+91 {profile?.phone}</div>
            {!isOwner && ownerName && (
              <div className="text-xs text-slate-500 truncate">
                {t("settings.operator_at", { name: ownerName })}
              </div>
            )}
          </div>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-teal-50 text-teal-700 border border-teal-200">
            {profile?.role ?? "owner"}
          </span>
        </div>

        {selected && (
          <div className="rounded-lg border border-slate-200 bg-white p-4">
            <p className="text-xs uppercase tracking-wide text-slate-400 font-semibold">
              {t("settings.active_center")}
            </p>
            <p className="mt-1 font-semibold text-slate-800">{selected.name}</p>
            <p className="text-xs text-slate-500">{t("settings.code", { code: selected.code })}</p>
          </div>
        )}

        <div className="rounded-lg border border-slate-200 bg-white divide-y divide-slate-100">
          <Row
            icon={<User className="h-4 w-4" />}
            label={t("settings.profile")}
            onClick={() => navigate({ to: "/profile" })}
            hint={t("settings.profile_hint")}
          />
          {can("center_settings") && (
            <Row
              icon={<Building2 className="h-4 w-4" />}
              label={t("settings.center_info")}
              onClick={() => navigate({ to: "/center-info" })}
              hint={t("settings.center_info_hint")}
            />
          )}
          {can("manage_operators") && (
            <Row
              icon={<UserCog className="h-4 w-4" />}
              label={t("settings.manage_operators")}
              hint={t("settings.manage_operators_hint")}
              onClick={() => navigate({ to: "/operators" })}
            />
          )}
          {(centers.length > 1 || isOwner) && (
            <Row
              icon={<Globe className="h-4 w-4" />}
              label={t("settings.manage_dairies")}
              hint={t("settings.manage_dairies_hint", { count: centers.length })}
              onClick={() => setDairySheet(true)}
            />
          )}
          {can("rate_chart") && (
            <Row
              icon={<ShieldCheck className="h-4 w-4" />}
              label={t("settings.rate_charts")}
              onClick={() => navigate({ to: "/rate-charts" })}
            />
          )}
          <Row
            icon={<KeyRound className="h-4 w-4" />}
            label={t("settings.change_pin")}
            hint={t("settings.change_pin_hint")}
            onClick={() => navigate({ to: "/change-pin" })}
          />
          {isOwner && (
            <Row
              icon={<Crown className="h-4 w-4" />}
              label={t("sub.manage")}
              onClick={() => navigate({ to: "/subscription" })}
            />
          )}
          {isOwner && (
            <Row
              icon={<Gift className="h-4 w-4" />}
              label={t("settings.referral")}
              hint={t("settings.referral_menu_hint")}
              onClick={() => navigate({ to: "/referral" })}
            />
          )}

          <div className="p-3">
            <div className="flex items-center gap-2 text-slate-700 font-medium text-sm mb-2">
              <Languages className="h-4 w-4" /> {t("settings.app_language")}
            </div>
            <Dropdown
              value={appLang}
              onChange={(v) => setAppLanguage(v)}
              options={LANGUAGES.map((l) => ({ value: l.code, label: l.label }))}
            />
          </div>
          <div className="p-3">
            <div className="flex items-center gap-2 text-slate-700 font-medium text-sm mb-2">
              <MessageSquare className="h-4 w-4" /> {t("settings.receipt_language")}
            </div>
            <p className="text-xs text-slate-500 mb-2">{t("settings.receipt_language_hint")}</p>
            <Dropdown
              value={receiptLang}
              onChange={(v) => {
                setReceiptLang(v);
                if (v === "") clearReceiptLang();
                else persist(RECEIPT_LANG_KEY, v);
              }}
              options={[
                {
                  value: "",
                  label: t("settings.same_as_app_language", {
                    lang: LANGUAGES.find((l) => l.code === appLang)?.label ?? t("settings.english"),
                  }),
                },
                ...LANGUAGES.map((l) => ({ value: l.code, label: l.label })),
              ]}
            />
            <pre className="mt-2 whitespace-pre-wrap rounded-lg border border-slate-200 bg-slate-50 p-3 text-[11px] leading-relaxed text-slate-600 font-sans">
              {collectionSmsText({
                lang: (receiptLang || appLang) as ReceiptLang,
                centerName: selected?.name ?? "Dairy",
                farmerName: profile?.full_name ?? "Farmer",
                farmerCode: "001",
                date: formatNumericDate(new Date(), receiptLang || appLang),
                shift: "morning",
                fat: "4.2",
                snf: "8.5",
                liters: 10,
                rate: 35,
                amount: 350,
              })}
            </pre>
          </div>
          <label className="p-3 flex items-center justify-between cursor-pointer">
            <span className="flex-1 pr-3">
              <span className="flex items-center gap-2 text-slate-700 font-medium text-sm">
                <ShieldCheck className="h-4 w-4" /> {t("settings.app_lock")}
              </span>
              <span className="block text-xs text-slate-500 mt-0.5">
                {t("settings.app_lock_hint")}
              </span>
            </span>
            <input
              type="checkbox"
              role="switch"
              aria-label={t("settings.app_lock")}
              checked={appLock}
              onChange={(e) => {
                setAppLock(e.target.checked);
                setAppLockEnabled(e.target.checked);
              }}
              className="h-5 w-9 accent-teal-700 shrink-0"
            />
          </label>
          <div className="p-3 flex items-center justify-between">
            <span className="flex items-center gap-2 text-slate-700 font-medium text-sm">
              <Bell className="h-4 w-4" /> {t("settings.notifications")}
            </span>
            <span className="text-xs font-semibold capitalize text-slate-500">{notifState}</span>
          </div>
        </div>

        <NotificationSettingsSection />

        {/* Support & legal */}
        <div className="rounded-lg border border-slate-200 bg-white divide-y divide-slate-100">
          <p className="px-3 pt-3 text-xs font-semibold uppercase tracking-wide text-slate-400">
            {t("settings.support_title")}
          </p>
          {/* Support contacts are remotely configured; hide the row when unset. */}
          {settings.support_email && (
            <a
              href={`mailto:${settings.support_email}`}
              className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-50"
            >
              <span className="text-slate-500">
                <Mail className="h-4 w-4" />
              </span>
              <span className="flex-1">
                <span className="block text-sm font-medium text-slate-800">
                  {t("settings.support_email_label")}
                </span>
                <span className="block text-xs text-teal-700">{settings.support_email}</span>
              </span>
            </a>
          )}
          {settings.support_phone && (
            <a
              href={`tel:+91${settings.support_phone}`}
              className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-50"
            >
              <span className="text-slate-500">
                <Phone className="h-4 w-4" />
              </span>
              <span className="flex-1">
                <span className="block text-sm font-medium text-slate-800">
                  {t("settings.support_phone_label")}
                </span>
                <span className="block text-xs text-teal-700">+91 {settings.support_phone}</span>
              </span>
            </a>
          )}

          {/* "How to use VDairy" tutorial video — remotely configured content slot.
              Renders nothing when the slot is cleared or deactivated. */}
          <ContentSlot slotKey="settings_tutorial_video" />

          <Row
            icon={<FileText className="h-4 w-4" />}
            label={t("settings.terms_title")}
            hint={t("settings.terms_hint")}
            onClick={() => navigate({ to: "/terms" })}
          />
        </div>

        <Button variant="danger" onClick={onLogout}>
          <LogOut className="h-4 w-4" />
          {t("settings.sign_out")}
        </Button>
      </div>

      <BottomSheet
        open={dairySheet}
        onClose={() => setDairySheet(false)}
        title={t("settings.manage_dairies_title")}
      >
        <div className="space-y-1 pb-2">
          {centers.map((c, i) => (
            <SheetItem
              key={c.id}
              icon={<span className="text-xs font-bold">{i + 1}</span>}
              label={c.name}
              meta={c.id === selected?.id ? t("settings.active") : undefined}
              onClick={() => {
                select(c.id);
                setDairySheet(false);
              }}
            />
          ))}
          {isOwner && (
            <SheetItem
              icon={<Plus className="h-4 w-4" />}
              label={t("settings.add_another_center")}
              onClick={() => {
                setDairySheet(false);
                navigate({ to: "/onboarding/create-center" });
              }}
            />
          )}
        </div>
      </BottomSheet>
    </>
  );
}

function Row({
  icon,
  label,
  hint,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  hint?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full flex items-center gap-3 p-3 text-left hover:bg-slate-50"
    >
      <span className="text-slate-500">{icon}</span>
      <span className="flex-1">
        <span className="block text-sm font-medium text-slate-800">{label}</span>
        {hint && <span className="block text-xs text-slate-500">{hint}</span>}
      </span>
    </button>
  );
}
