import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { FoodForm } from "@/components/FoodForm";

export const Route = createFileRoute("/food/$id/edit")({
  component: EditFood,
});

function EditFood() {
  const { id } = useParams({ from: "/food/$id/edit" });
  const navigate = useNavigate();
  return <FoodForm mode="edit" saleId={id} onBack={() => navigate({ to: "/food" })} />;
}
