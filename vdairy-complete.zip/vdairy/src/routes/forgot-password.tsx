import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Alert } from "@/components/Alert";
import { resetPinWithAnswers, verifySecurityAnswers } from "@/lib/auth.functions";
import { useTranslation } from "react-i18next";
import { securityQuestionLabel } from "@/lib/security-questions";

export const Route = createFileRoute("/forgot-password")({
  ssr: false,
  component: ForgotPasswordScreen,
});

function ForgotPasswordScreen() {
  const { t } = useTranslation();
  const resetPin = useServerFn(resetPinWithAnswers);
  const verifyAnswersFn = useServerFn(verifySecurityAnswers);
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [phone, setPhone] = useState("");
  const [q1, setQ1] = useState("");
  const [q2, setQ2] = useState("");
  const [a1, setA1] = useState("");
  const [a2, setA2] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const lookup = async () => {
    setError("");
    setLoading(true);
    try {
      const { data, error: rpcErr } = await supabase.rpc("get_security_questions_by_phone", {
        _phone: phone,
      });
      if (rpcErr) throw new Error(rpcErr.message);
      const row = (data as { question_1: string | null; question_2: string | null }[] | null)?.[0];
      if (!row || !row.question_1 || !row.question_2)
        throw new Error(t("auth.no_account_with_phone"));
      setQ1(row.question_1);
      setQ2(row.question_2);
      setStep(2);
    } catch (err) {
      setError(err instanceof Error ? err.message : t("auth.could_not_look_up_account"));
    } finally {
      setLoading(false);
    }
  };

  const verifyAnswers = async () => {
    setError("");
    if (!a1.trim() || !a2.trim()) return;
    setLoading(true);
    try {
      await verifyAnswersFn({ data: { phone, answer_1: a1.trim(), answer_2: a2.trim() } });
      setStep(3);
    } catch {
      // Never advance on a failed check.
      setStep(2);
      setError(t("auth.security_answers_incorrect"));
    } finally {
      setLoading(false);
    }
  };

  const submitNewPin = async () => {
    setError("");
    if (pin.length !== 4 || pin !== confirmPin) {
      setError(t("auth.pin_must_be_4_digits_and_match"));
      return;
    }
    setLoading(true);
    try {
      await resetPin({ data: { phone, answer_1: a1, answer_2: a2, new_pin: pin } });
      navigate({ to: "/login", replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("auth.reset_failed"));
      setStep(2);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white safe-top safe-bottom">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200">
        <Logo size="sm" />
        <Link to="/login" className="text-sm text-teal-700 font-medium">
          {t("auth.back_to_login")}
        </Link>
      </div>

      <div className="px-6 py-6 max-w-md mx-auto">
        <h1 className="text-2xl font-bold text-slate-800">{t("auth.reset_password")}</h1>
        <p className="text-sm text-slate-500 mt-1 mb-6">
          {step === 1 && t("auth.enter_phone_to_begin")}
          {step === 2 && t("auth.answer_security_questions")}
          {step === 3 && t("auth.choose_new_pin")}
        </p>

        <div className="flex flex-col gap-4">
          {error && <Alert message={error} />}

          {step === 1 && (
            <>
              <Field label={t("auth.phone_number")}>
                <TextInput
                  prefix="+91"
                  inputMode="numeric"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                />
              </Field>
              <Button onClick={lookup} disabled={phone.length !== 10} loading={loading}>
                {t("auth.continue")}
              </Button>
            </>
          )}

          {step === 2 && (
            <>
              <Field label={securityQuestionLabel(q1, t)}>
                <TextInput
                  value={a1}
                  onChange={(e) => setA1(e.target.value)}
                  placeholder={t("auth.your_answer")}
                />
              </Field>
              <Field label={securityQuestionLabel(q2, t)}>
                <TextInput
                  value={a2}
                  onChange={(e) => setA2(e.target.value)}
                  placeholder={t("auth.your_answer")}
                />
              </Field>
              <Button onClick={verifyAnswers} disabled={!a1.trim() || !a2.trim()} loading={loading}>
                {t("auth.continue")}
              </Button>
            </>
          )}

          {step === 3 && (
            <>
              <Field label={t("auth.new_pin")} hint={t("auth.choose_4_digit_pin")}>
                <TextInput
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                />
              </Field>
              <Field
                label={t("auth.confirm_new_pin")}
                error={
                  confirmPin.length === 4 && pin !== confirmPin
                    ? t("auth.pins_do_not_match")
                    : undefined
                }
              >
                <TextInput
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  invalid={confirmPin.length === 4 && pin !== confirmPin}
                />
              </Field>
              <Button
                onClick={submitNewPin}
                disabled={pin.length !== 4 || pin !== confirmPin}
                loading={loading}
              >
                {t("auth.reset_pin")}
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
