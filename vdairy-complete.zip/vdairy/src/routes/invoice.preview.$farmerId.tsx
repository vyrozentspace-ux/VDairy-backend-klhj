import { createFileRoute, useParams, useSearch } from "@tanstack/react-router";
import { z } from "zod";
import { InvoiceDetail } from "@/components/InvoiceDetail";
import { usePeriodConfig } from "@/hooks/usePeriodConfig";
import { periodForDate } from "@/lib/payment-periods";

const searchSchema = z.object({ start: z.string().optional(), end: z.string().optional() });

export const Route = createFileRoute("/invoice/preview/$farmerId")({
  validateSearch: searchSchema,
  component: PreviewInvoiceScreen,
});

function PreviewInvoiceScreen() {
  const { farmerId } = useParams({ from: "/invoice/preview/$farmerId" });
  const { start, end } = useSearch({ from: "/invoice/preview/$farmerId" });
  const { config } = usePeriodConfig();
  const fallback = periodForDate(config);
  return (
    <InvoiceDetail
      mode="preview"
      farmerId={farmerId}
      periodStart={start ?? fallback.start}
      periodEnd={end ?? fallback.end}
    />
  );
}
