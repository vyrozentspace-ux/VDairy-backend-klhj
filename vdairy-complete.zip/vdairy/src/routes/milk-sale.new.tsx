import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { MilkSaleForm } from "@/components/MilkSaleForm";

export const Route = createFileRoute("/milk-sale/new")({
  component: NewSale,
});

function NewSale() {
  const navigate = useNavigate();
  return (
    <MilkSaleForm
      mode="create"
      onBack={() => navigate({ to: "/milk-sale" })}
      onDone={() => navigate({ to: "/milk-sale", replace: true })}
    />
  );
}
