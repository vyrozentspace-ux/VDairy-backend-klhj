import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ChevronDown, Package, Plus } from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Spinner } from "@/components/Spinner";
import { useCenter } from "@/contexts/CenterContext";
import {
  listDealers,
  listProducts,
  listStockPurchasesForProduct,
  stockOnHand,
  type FeedDealer,
  type FeedProduct,
  type FeedStockPurchase,
} from "@/lib/food";
import { formatDMY } from "@/lib/payment-periods";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/food/stock/")({
  component: StockScreen,
});

function StockScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<FeedProduct[]>([]);
  const [dealers, setDealers] = useState<FeedDealer[]>([]);
  const [stocks, setStocks] = useState<Record<string, number>>({});
  const [expanded, setExpanded] = useState<string | null>(null);
  const [historyCache, setHistoryCache] = useState<Record<string, FeedStockPurchase[]>>({});

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [ps, ds] = await Promise.all([listProducts(selected.id), listDealers(selected.id)]);
        if (cancelled) return;
        setProducts(ps);
        setDealers(ds);
        const entries = await Promise.all(
          ps.map(async (p) => [p.id, await stockOnHand(p.id)] as const),
        );
        if (!cancelled) setStocks(Object.fromEntries(entries));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  const dealerById = Object.fromEntries(dealers.map((d) => [d.id, d]));

  const toggle = async (pid: string) => {
    setExpanded((cur) => (cur === pid ? null : pid));
    if (!historyCache[pid]) {
      const list = await listStockPurchasesForProduct(pid);
      setHistoryCache((c) => ({ ...c, [pid]: list }));
    }
  };

  return (
    <>
      <AppHeader
        title={t("food.stock")}
        onBack={() => navigate({ to: "/food" })}
        right={
          <button
            type="button"
            onClick={() => navigate({ to: "/food/stock/new" })}
            aria-label={t("food.add_stock")}
            className="h-10 w-10 rounded-full bg-teal-700 text-white flex items-center justify-center hover:bg-teal-800"
          >
            <Plus className="h-5 w-5" />
          </button>
        }
      />
      <div className="p-4 pb-24">
        {loading ? (
          <div className="py-16 flex justify-center">
            <Spinner />
          </div>
        ) : products.length === 0 ? (
          <div className="py-16 flex flex-col items-center gap-3">
            <span className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300">
              <Package className="h-7 w-7" />
            </span>
            <p className="text-sm text-slate-500">{t("food.no_feed_products")}</p>
          </div>
        ) : (
          <div className="space-y-2">
            {products.map((p) => {
              const qty = stocks[p.id] ?? 0;
              const isOpen = expanded === p.id;
              const hist = historyCache[p.id] ?? [];
              return (
                <div
                  key={p.id}
                  className="bg-white border border-slate-200 rounded-lg overflow-hidden"
                >
                  <button
                    type="button"
                    onClick={() => toggle(p.id)}
                    className="w-full px-3 py-3 flex items-center justify-between hover:bg-slate-50"
                  >
                    <div className="min-w-0 text-left">
                      <div className="font-semibold text-slate-800 truncate">{p.product_name}</div>
                      <div className="text-xs text-slate-400 mt-0.5">{p.unit}</div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span
                        className={cn(
                          "font-bold text-sm",
                          qty <= 0 ? "text-rose-600" : "text-slate-700",
                        )}
                      >
                        {Number(qty).toFixed(2)} {p.unit}(s)
                      </span>
                      <ChevronDown
                        className={cn(
                          "h-4 w-4 text-slate-400 transition-transform",
                          isOpen && "rotate-180",
                        )}
                      />
                    </div>
                  </button>
                  {isOpen && (
                    <div className="border-t border-slate-100 divide-y divide-slate-50 bg-slate-50/40">
                      {hist.length === 0 ? (
                        <div className="px-3 py-3 text-center text-xs text-slate-400">
                          {t("food.no_purchases")}
                        </div>
                      ) : (
                        hist.map((h) => (
                          <div
                            key={h.id}
                            className="px-3 py-2 flex items-start justify-between gap-2"
                          >
                            <div className="min-w-0 text-xs">
                              <div className="text-slate-700">
                                {formatDMY(new Date(h.purchase_date))}
                                {h.dealer_id
                                  ? ` · ${dealerById[h.dealer_id]?.dealer_name ?? ""}`
                                  : ""}
                              </div>
                              <div className="text-slate-400">
                                {Number(h.quantity)} x ₹{Number(h.rate)}
                              </div>
                            </div>
                            <div className="font-bold text-slate-800 text-sm shrink-0">
                              ₹{Number(h.amount).toFixed(2)}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
