import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { AppHeader } from "@/components/AppHeader";
import { Field, TextInput } from "@/components/Field";
import { Button } from "@/components/Button";
import { MilkTypePills } from "@/components/MilkTypePills";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { logActivity, type MilkType } from "@/lib/farmers";

export const Route = createFileRoute("/farmer/register")({
  component: FarmerRegister,
});

function FarmerRegister() {
  const { t } = useTranslation();
  const { userId } = useAuth();
  const { selected } = useCenter();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [mobile, setMobile] = useState("");
  const [village, setVillage] = useState("");
  const [milkType, setMilkType] = useState<MilkType | null>("cow");
  const [busy, setBusy] = useState(false);
  const [lastSavedId, setLastSavedId] = useState<string | null>(null);

  const reset = () => {
    setFirstName("");
    setLastName("");
    setMobile("");
    setVillage("");
    setMilkType("cow");
  };

  const submit = async () => {
    if (!selected || !userId || !milkType || !firstName.trim()) return;
    setBusy(true);
    const { data, error } = await supabase
      .from("farmers")
      .insert({
        center_id: selected.id,
        code: "",
        first_name: firstName.trim(),
        last_name: lastName.trim() || null,
        mobile: mobile.trim() || null,
        village: village.trim() || null,
        milk_type: milkType,
        created_by: userId,
      })
      .select()
      .single();
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(t("farmers.registered", { code: data.code, name: data.first_name }));
    void logActivity(selected.id, userId, "farmer_created", {
      farmer_id: data.id,
      via: "register",
    });
    setLastSavedId(data.id);
    reset();
  };

  return (
    <>
      <AppHeader title={t("farmers.farmer_registration")} />
      <div className="p-4 space-y-4">
        <Field label={t("farmers.first_name")}>
          <TextInput
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            placeholder={t("farmers.first_name_placeholder")}
          />
        </Field>
        <Field label={t("farmers.last_name")}>
          <TextInput
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            placeholder={t("farmers.last_name_placeholder")}
          />
        </Field>
        <Field label={t("farmers.mobile")}>
          <TextInput
            value={mobile}
            onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
            prefix="+91"
            inputMode="numeric"
            placeholder={t("farmers.mobile_placeholder")}
          />
        </Field>
        <Field label={t("farmers.village")}>
          <TextInput
            value={village}
            onChange={(e) => setVillage(e.target.value)}
            placeholder={t("farmers.village_placeholder")}
          />
        </Field>
        <Field label={t("farmers.milk_type")}>
          <MilkTypePills value={milkType} onChange={setMilkType} />
        </Field>
        <Button loading={busy} disabled={!firstName.trim() || !milkType} onClick={submit}>
          {t("farmers.register_farmer")}
        </Button>
        {lastSavedId && (
          <Link
            to="/farmers"
            className="block text-center text-sm font-medium text-teal-700 hover:underline"
          >
            {t("farmers.view_all_farmers")}
          </Link>
        )}
      </div>
    </>
  );
}
