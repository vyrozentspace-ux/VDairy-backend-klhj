import { createFileRoute, useParams } from "@tanstack/react-router";
import { InvoiceDetail } from "@/components/InvoiceDetail";

export const Route = createFileRoute("/invoice/view/$invoiceId")({
  component: ViewInvoiceScreen,
});

function ViewInvoiceScreen() {
  const { invoiceId } = useParams({ from: "/invoice/view/$invoiceId" });
  return <InvoiceDetail mode="view" invoiceId={invoiceId} />;
}
