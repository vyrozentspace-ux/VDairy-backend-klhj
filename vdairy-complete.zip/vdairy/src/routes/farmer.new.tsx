import { createFileRoute } from "@tanstack/react-router";
import { FarmerForm } from "@/components/FarmerForm";

export const Route = createFileRoute("/farmer/new")({
  component: () => <FarmerForm />,
});
