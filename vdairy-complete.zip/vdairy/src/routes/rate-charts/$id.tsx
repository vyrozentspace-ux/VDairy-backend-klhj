import { createFileRoute } from "@tanstack/react-router";
import { RateChartForm } from "@/components/RateChartForm";

export const Route = createFileRoute("/rate-charts/$id")({
  component: EditRateChart,
});

function EditRateChart() {
  const { id } = Route.useParams();
  return <RateChartForm chartId={id} />;
}
