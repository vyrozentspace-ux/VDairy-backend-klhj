import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { ListChecks, MoreVertical, Plus, Copy, Trash2 } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { Switch } from "@/components/Switch";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { useCenter } from "@/contexts/CenterContext";
import {
  activateChart,
  deactivateChart,
  deleteChart,
  duplicateChart,
  listRateCharts,
  type MilkType,
  type RateChart,
} from "@/lib/rate-charts";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/rate-charts/")({
  component: RateChartsList,
});

function RateChartsList() {
  const { t } = useTranslation();
  const { selected } = useCenter();
  const navigate = useNavigate();

  const TABS: { value: MilkType; label: string }[] = [
    { value: "cow", label: t("settings.cow") },
    { value: "buffalo", label: t("settings.buffalo") },
    { value: "mixed", label: t("settings.mixed") },
  ];

  const [tab, setTab] = useState<MilkType>("cow");
  const [loading, setLoading] = useState(true);
  const [charts, setCharts] = useState<RateChart[]>([]);
  const [menuFor, setMenuFor] = useState<RateChart | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<RateChart | null>(null);

  const refresh = async () => {
    if (!selected) return;
    setLoading(true);
    try {
      const rows = await listRateCharts(selected.id);
      setCharts(rows);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("settings.load_failed"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void refresh();
  }, [selected?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = charts.filter((c) => c.milk_type === tab);

  const onToggle = async (chart: RateChart, next: boolean) => {
    try {
      if (next) {
        await activateChart(chart);
        toast.success(t("settings.activated_chart", { name: chart.chart_name }));
      } else {
        await deactivateChart(chart);
      }
      await refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("settings.action_failed"));
    }
  };

  const onDuplicate = async (chart: RateChart) => {
    setMenuFor(null);
    try {
      await duplicateChart(chart);
      toast.success(t("settings.chart_duplicated"));
      await refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("settings.action_failed"));
    }
  };

  const onDelete = async () => {
    if (!confirmDelete) return;
    try {
      await deleteChart(confirmDelete);
      toast.success(t("settings.chart_deleted"));
      setConfirmDelete(null);
      await refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("settings.action_failed"));
    }
  };

  return (
    <>
      <AppHeader
        title={t("settings.rate_charts_title")}
        right={
          <Link
            to="/rate-charts/new"
            className="h-11 w-11 rounded-full bg-teal-700 text-white flex items-center justify-center"
            aria-label={t("settings.new_rate_chart")}
          >
            <Plus className="h-5 w-5" />
          </Link>
        }
      />

      <div className="p-4">
        <div className="flex gap-2 mb-4">
          {TABS.map((tItem) => (
            <button
              key={tItem.value}
              onClick={() => setTab(tItem.value)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium",
                tab === tItem.value ? "bg-teal-700 text-white" : "bg-slate-100 text-slate-600",
              )}
            >
              {tItem.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="py-8 flex justify-center">
            <Spinner />
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-12 flex flex-col items-center text-center gap-3">
            <span className="h-14 w-14 rounded-full bg-slate-100 flex items-center justify-center">
              <ListChecks className="h-6 w-6 text-slate-400" />
            </span>
            <p className="text-sm text-slate-600">
              {t("settings.no_charts_yet", {
                type: TABS.find((tItem) => tItem.value === tab)?.label,
              })}
            </p>
            <Button onClick={() => navigate({ to: "/rate-charts/new" })}>
              {t("settings.create_rate_chart")}
            </Button>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map((c) => (
              <div
                key={c.id}
                role="button"
                tabIndex={0}
                onClick={() => navigate({ to: "/rate-charts/$id", params: { id: c.id } })}
                onKeyDown={(e) => {
                  if (e.key === "Enter") navigate({ to: "/rate-charts/$id", params: { id: c.id } });
                }}
                className="rounded-lg border border-slate-200 bg-white p-4 hover:border-teal-300 transition"
              >
                <div className="flex items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-slate-800 truncate">{c.chart_name}</span>
                      {c.is_active && (
                        <span className="inline-flex items-center rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-semibold px-2 py-0.5 uppercase tracking-wide">
                          {t("settings.active_badge")}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-slate-500 mt-1">
                      {t("settings.base_rate_summary", {
                        base: Number(c.base_rate ?? 0).toFixed(2),
                        fatMin: c.fat_min,
                        fatMax: c.fat_max,
                        snfMin: c.snf_min,
                        snfMax: c.snf_max,
                      })}
                    </p>
                  </div>
                  <div
                    className="flex items-center gap-2 shrink-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Switch checked={c.is_active} onChange={(v) => onToggle(c, v)} />
                    <button
                      type="button"
                      onClick={() => setMenuFor(c)}
                      className="h-8 w-8 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100"
                      aria-label={t("settings.more")}
                    >
                      <MoreVertical className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <BottomSheet open={!!menuFor} onClose={() => setMenuFor(null)} title={menuFor?.chart_name}>
        {menuFor && (
          <>
            <SheetItem
              icon={<Copy className="h-4 w-4" />}
              label={t("settings.duplicate_chart")}
              onClick={() => onDuplicate(menuFor)}
            />
            <SheetItem
              icon={<Trash2 className="h-4 w-4" />}
              label={t("settings.delete_chart")}
              danger
              onClick={() => {
                setConfirmDelete(menuFor);
                setMenuFor(null);
              }}
            />
          </>
        )}
      </BottomSheet>

      <BottomSheet
        open={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        title={t("settings.delete_chart_confirm_title")}
      >
        <div className="px-4 pb-4">
          <p className="text-sm text-slate-600 mb-4">
            {t("settings.delete_chart_confirm_body", { name: confirmDelete?.chart_name })}
          </p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setConfirmDelete(null)}>
              {t("settings.cancel")}
            </Button>
            <Button variant="danger" onClick={onDelete}>
              {t("settings.delete")}
            </Button>
          </div>
        </div>
      </BottomSheet>
    </>
  );
}
