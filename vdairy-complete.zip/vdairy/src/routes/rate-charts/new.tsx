import { createFileRoute } from "@tanstack/react-router";
import { RateChartForm } from "@/components/RateChartForm";

export const Route = createFileRoute("/rate-charts/new")({
  component: () => <RateChartForm />,
});
