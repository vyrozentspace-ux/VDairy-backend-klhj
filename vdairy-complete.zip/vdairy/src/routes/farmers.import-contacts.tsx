import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, Loader2, Search, Users } from "lucide-react";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Spinner } from "@/components/Spinner";
import { ContactUnavailableDialog } from "@/components/ContactUnavailableDialog";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import { fetchFarmers, logActivity, nextFarmerCode } from "@/lib/farmers";
import { hasContactPicker, pickAllContacts, type PickedContact } from "@/lib/contacts";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/farmers/import-contacts")({
  component: ImportContactsScreen,
});

type Row = PickedContact & {
  chosenPhone: string;
  alreadyExists: boolean;
  selected: boolean;
};

function ImportContactsScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { userId } = useAuth();

  const [loading, setLoading] = useState(true);
  const [denied, setDenied] = useState(false);
  const [unavailable, setUnavailable] = useState(false);
  const [rows, setRows] = useState<Row[]>([]);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ added: number; skipped: number } | null>(null);

  useEffect(() => {
    if (!selected) return;
    if (!hasContactPicker()) {
      setLoading(false);
      setUnavailable(true);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const [contacts, existing] = await Promise.all([
          pickAllContacts(),
          fetchFarmers(selected.id),
        ]);
        if (cancelled) return;
        const existingPhones = new Set(
          existing
            .map((f) => (f.mobile ?? "").replace(/\D/g, "").slice(-10))
            .filter((p) => p.length === 10),
        );
        const mapped: Row[] = contacts.map((c) => {
          const first = c.phones[0];
          const already = c.phones.some((p) => existingPhones.has(p));
          return {
            ...c,
            chosenPhone: first,
            alreadyExists: already,
            selected: !already,
          };
        });
        setRows(mapped);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "";
        if (/denied|permission/i.test(msg)) setDenied(true);
        else setUnavailable(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter(
      (r) => r.name.toLowerCase().includes(q) || r.phones.some((p) => p.includes(q)),
    );
  }, [rows, query]);

  const selectableFiltered = filtered.filter((r) => !r.alreadyExists);
  const allSelected = selectableFiltered.length > 0 && selectableFiltered.every((r) => r.selected);

  const toggleAll = () => {
    const target = !allSelected;
    setRows((cur) =>
      cur.map((r) => {
        if (r.alreadyExists) return r;
        if (!filtered.includes(r)) return r;
        return { ...r, selected: target };
      }),
    );
  };

  const toggleOne = (idx: number) => {
    setRows((cur) =>
      cur.map((r, i) => (i === idx && !r.alreadyExists ? { ...r, selected: !r.selected } : r)),
    );
  };

  const changePhone = (idx: number, phone: string) => {
    setRows((cur) => cur.map((r, i) => (i === idx ? { ...r, chosenPhone: phone } : r)));
  };

  const selectedCount = rows.filter((r) => r.selected && !r.alreadyExists).length;

  const doImport = async () => {
    if (!selected || !userId || selectedCount === 0) return;
    setBusy(true);
    let added = 0;
    let skipped = 0;
    try {
      let nextCode = parseInt(await nextFarmerCode(selected.id), 10);
      const chosen = rows.filter((r) => r.selected && !r.alreadyExists);
      for (const r of chosen) {
        const [first, ...rest] = r.name.trim().split(/\s+/);
        const payload = {
          center_id: selected.id,
          code: String(nextCode),
          first_name: first || r.name,
          last_name: rest.join(" ") || null,
          mobile: r.chosenPhone,
          milk_type: "cow" as const,
          is_active: true,
          created_by: userId,
        };
        const { error } = await supabase.from("farmers").insert(payload);
        if (error) {
          skipped++;
        } else {
          added++;
          nextCode++;
        }
      }
      void logActivity(selected.id, userId, "farmer_bulk_imported", {
        added,
        skipped,
      });
      setResult({ added, skipped });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("farmers.import_failed"));
    } finally {
      setBusy(false);
    }
  };

  // Result screen
  if (result) {
    return (
      <>
        <AppHeader title={t("farmers.title_sync_from_contacts")} showBack={false} />
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center gap-3">
          <div className="h-16 w-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
            <Check className="h-8 w-8" />
          </div>
          <h2 className="text-lg font-bold text-slate-800">{t("farmers.import_complete")}</h2>
          <p className="text-sm text-slate-500">
            <span className="font-semibold text-emerald-600">{result.added}</span>{" "}
            {t("farmers.added_word")}
            {" · "}
            <span className="font-semibold text-slate-600">{result.skipped}</span>{" "}
            {t("farmers.skipped_word")}
          </p>
          <div className="w-full max-w-xs pt-2">
            <Button onClick={() => navigate({ to: "/farmers" })}>{t("farmers.done")}</Button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <AppHeader
        title={t("farmers.title_sync_from_contacts")}
        onBack={() => navigate({ to: "/farmers" })}
      />

      {loading ? (
        <div className="py-16 flex justify-center">
          <Spinner />
        </div>
      ) : unavailable || denied ? (
        <ContactUnavailableDialog
          open
          reason={denied ? "denied" : "unavailable"}
          onClose={() => navigate({ to: "/farmers" })}
        />
      ) : rows.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-16 text-center gap-3">
          <div className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center">
            <Users className="h-8 w-8 text-slate-400" />
          </div>
          <h2 className="text-lg font-bold text-slate-800">
            {t("farmers.no_contacts_with_phone")}
          </h2>
          <p className="text-sm text-slate-500 max-w-xs">
            {t("farmers.contacts_with_no_valid_phone")}
          </p>
        </div>
      ) : (
        <>
          <div className="sticky top-14 z-10 bg-white border-b border-slate-200 px-4 py-3 space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t("farmers.search_contacts")}
                className="w-full h-10 rounded-lg bg-slate-50 border border-slate-200 pl-9 pr-3 text-sm outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100"
              />
            </div>
            <button
              type="button"
              onClick={toggleAll}
              disabled={selectableFiltered.length === 0}
              className="text-xs font-semibold text-teal-700 hover:underline disabled:text-slate-300"
            >
              {allSelected
                ? t("farmers.deselect_all")
                : t("farmers.select_all", { count: selectableFiltered.length })}
            </button>
          </div>

          <div className="pb-24">
            {filtered.map((r) => {
              const idx = rows.indexOf(r);
              return (
                <div
                  key={idx}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 bg-white border-b border-slate-100",
                    r.alreadyExists && "opacity-60",
                  )}
                >
                  <input
                    type="checkbox"
                    checked={r.selected}
                    disabled={r.alreadyExists}
                    onChange={() => toggleOne(idx)}
                    className="accent-teal-700 h-4 w-4"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm text-slate-800 truncate">{r.name}</div>
                    <div className="text-xs text-slate-500 truncate">
                      {r.alreadyExists ? (
                        <span className="text-slate-400">{t("farmers.already_exists")}</span>
                      ) : r.phones.length > 1 ? (
                        <select
                          value={r.chosenPhone}
                          onChange={(e) => changePhone(idx, e.target.value)}
                          className="text-xs bg-transparent outline-none text-slate-600"
                        >
                          {r.phones.map((p) => (
                            <option key={p} value={p}>
                              +91 {p.slice(0, 5)} {p.slice(5)}
                            </option>
                          ))}
                        </select>
                      ) : (
                        `+91 ${r.chosenPhone.slice(0, 5)} ${r.chosenPhone.slice(5)}`
                      )}
                    </div>
                  </div>
                  {r.phones.length > 1 && (
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200 shrink-0">
                      {t("farmers.nos_suffix", { count: r.phones.length })}
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 px-4 py-3 safe-bottom">
            <Button onClick={doImport} loading={busy} disabled={selectedCount === 0 || busy}>
              {busy ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> {t("farmers.importing")}
                </>
              ) : (
                t("farmers.add_selected_as_farmers", {
                  count: selectedCount,
                  plural: selectedCount === 1 ? "" : "s",
                })
              )}
            </Button>
          </div>
        </>
      )}
    </>
  );
}
