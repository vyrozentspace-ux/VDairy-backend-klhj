import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { AppHeader } from "@/components/AppHeader";
import { Alert } from "@/components/Alert";
import { Button } from "@/components/Button";
import { Dropdown } from "@/components/Dropdown";
import { Field, TextInput } from "@/components/Field";
import { Spinner } from "@/components/Spinner";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import { LANGUAGES } from "@/lib/i18n";
import { PAYMENT_PERIOD_OPTIONS } from "@/lib/payment-periods";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/center-info")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Center Info — Dairy Center Settings" },
      {
        name: "description",
        content:
          "View and edit your dairy center details: address, contact, bank details, language and milk collection settings.",
      },
      { property: "og:title", content: "Center Info — Dairy Center Settings" },
      {
        property: "og:description",
        content: "Manage dairy center address, bank details and collection settings.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CenterInfoScreen,
});

function useCalcModes() {
  const { t } = useTranslation();
  return [
    { value: "fat_snf", label: t("settings.calc_fat_snf") },
    { value: "fat_only", label: t("settings.calc_fat_only") },
    { value: "total_solid", label: t("settings.calc_total_solid") },
  ];
}

type Form = {
  name: string;
  village: string;
  taluka: string;
  district: string;
  state: string;
  pincode: string;
  contact_number: string;
  bank_account_number: string;
  bank_ifsc_code: string;
  bank_branch_name: string;
  default_language: string;
  calculation_mode: string;
  payment_period: string;
  morning_start_time: string;
  morning_end_time: string;
  evening_start_time: string;
  evening_end_time: string;
  default_cow_rate: string;
  default_buffalo_rate: string;
  default_milk_sale_rate: string;
};

const EMPTY: Form = {
  name: "",
  village: "",
  taluka: "",
  district: "",
  state: "",
  pincode: "",
  contact_number: "",
  bank_account_number: "",
  bank_ifsc_code: "",
  bank_branch_name: "",
  default_language: "en",
  calculation_mode: "fat_snf",
  payment_period: "01-ME",
  morning_start_time: "",
  morning_end_time: "",
  evening_start_time: "",
  evening_end_time: "",
  default_cow_rate: "",
  default_buffalo_rate: "",
  default_milk_sale_rate: "",
};

const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
const hhmm = (v: unknown) => (v ? String(v).slice(0, 5) : "");
const numOrNull = (v: string) => (v.trim() === "" ? null : Number(v));
const strOrNull = (v: string) => (v.trim() === "" ? null : v.trim());

function CenterInfoScreen() {
  const { t } = useTranslation();
  const CALC_MODES = useCalcModes();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const { selected, refresh } = useCenter();

  const canEdit = profile?.role === "owner";

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<Form>(EMPTY);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setForm((f) => ({ ...f, [k]: v }));

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      if (!selected) return;
      setLoading(true);
      setError(null);
      const [{ data: center, error: cErr }, { data: settings }] = await Promise.all([
        supabase.from("dairy_centers").select("*").eq("id", selected.id).maybeSingle(),
        supabase
          .from("center_collection_settings")
          .select("*")
          .eq("center_id", selected.id)
          .maybeSingle(),
      ]);
      if (cancelled) return;
      if (cErr || !center) {
        setError(t("settings.could_not_load_center"));
        setLoading(false);
        return;
      }
      const c = center as Record<string, unknown>;
      const st = (settings ?? {}) as Record<string, unknown>;
      setForm({
        name: s(c.name),
        village: s(c.village),
        taluka: s(c.taluka),
        district: s(c.district),
        state: s(c.state),
        pincode: s(c.pincode),
        contact_number: s(c.contact_number),
        bank_account_number: s(c.bank_account_number),
        bank_ifsc_code: s(c.bank_ifsc_code),
        bank_branch_name: s(c.bank_branch_name),
        default_language: s(c.default_language) || "en",
        calculation_mode: s(st.calculation_mode) || "fat_snf",
        payment_period: s(st.payment_period) || "01-ME",
        morning_start_time: hhmm(st.morning_start_time),
        morning_end_time: hhmm(st.morning_end_time),
        evening_start_time: hhmm(st.evening_start_time),
        evening_end_time: hhmm(st.evening_end_time),
        default_cow_rate: s(st.default_cow_rate),
        default_buffalo_rate: s(st.default_buffalo_rate),
        default_milk_sale_rate: s(st.default_milk_sale_rate),
      });
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  async function onSave() {
    if (!selected || !canEdit) return;
    if (!form.name.trim()) {
      setError(t("settings.center_name_required"));
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const { error: cErr } = await supabase
        .from("dairy_centers")
        .update({
          name: form.name.trim(),
          village: strOrNull(form.village),
          taluka: strOrNull(form.taluka),
          district: strOrNull(form.district),
          state: strOrNull(form.state),
          pincode: strOrNull(form.pincode),
          contact_number: strOrNull(form.contact_number),
          bank_account_number: strOrNull(form.bank_account_number),
          bank_ifsc_code: strOrNull(form.bank_ifsc_code),
          bank_branch_name: strOrNull(form.bank_branch_name),
          default_language: form.default_language,
        })
        .eq("id", selected.id);
      if (cErr) throw cErr;

      const { error: sErr } = await supabase.from("center_collection_settings").upsert(
        {
          center_id: selected.id,
          calculation_mode: form.calculation_mode,
          payment_period: form.payment_period,
          morning_start_time: strOrNull(form.morning_start_time),
          morning_end_time: strOrNull(form.morning_end_time),
          evening_start_time: strOrNull(form.evening_start_time),
          evening_end_time: strOrNull(form.evening_end_time),
          default_cow_rate: numOrNull(form.default_cow_rate),
          default_buffalo_rate: numOrNull(form.default_buffalo_rate),
          default_milk_sale_rate: numOrNull(form.default_milk_sale_rate),
        },
        { onConflict: "center_id" },
      );
      if (sErr) throw sErr;

      await refresh();
      toast.success(t("settings.center_info_saved"));
    } catch (e) {
      setError(e instanceof Error ? e.message : t("settings.could_not_save_changes"));
    } finally {
      setSaving(false);
    }
  }

  if (!selected) {
    return (
      <>
        <AppHeader
          title={t("settings.center_info_title")}
          onBack={() => navigate({ to: "/more" })}
        />
        <div className="p-4">
          <Alert message={t("settings.select_center_first")} />
        </div>
      </>
    );
  }

  return (
    <div className="min-h-screen w-full bg-slate-50 flex justify-center">
      <div className="w-full max-w-md min-h-screen bg-white flex flex-col">
        <AppHeader
          title={t("settings.center_info_title")}
          onBack={() => navigate({ to: "/more" })}
        />
        {loading ? (
          <div className="flex-1 flex items-center justify-center py-16">
            <Spinner size={24} color="#0F766E" />
          </div>
        ) : (
          <div className="p-4 flex flex-col gap-5 pb-28">
            {!canEdit && <Alert message={t("settings.read_only_operator")} />}
            {error && <Alert message={error} />}

            <Section title={t("settings.section_center")}>
              <Field label={t("settings.center_name")}>
                <TextInput
                  value={form.name}
                  disabled={!canEdit}
                  onChange={(e) => set("name", e.target.value)}
                  placeholder={t("settings.center_name_placeholder")}
                />
              </Field>
              <Field label={t("settings.center_code")}>
                <TextInput value={selected.code} disabled readOnly />
              </Field>
            </Section>

            <Section title={t("settings.section_address")}>
              <Field label={t("settings.village")}>
                <TextInput
                  value={form.village}
                  disabled={!canEdit}
                  onChange={(e) => set("village", e.target.value)}
                />
              </Field>
              <Field label={t("settings.taluka")}>
                <TextInput
                  value={form.taluka}
                  disabled={!canEdit}
                  onChange={(e) => set("taluka", e.target.value)}
                />
              </Field>
              <Field label={t("settings.district")}>
                <TextInput
                  value={form.district}
                  disabled={!canEdit}
                  onChange={(e) => set("district", e.target.value)}
                />
              </Field>
              <Field label={t("settings.state")}>
                <TextInput
                  value={form.state}
                  disabled={!canEdit}
                  onChange={(e) => set("state", e.target.value)}
                />
              </Field>
              <Field label={t("settings.pincode")}>
                <TextInput
                  value={form.pincode}
                  inputMode="numeric"
                  maxLength={6}
                  disabled={!canEdit}
                  onChange={(e) => set("pincode", e.target.value.replace(/\D/g, ""))}
                />
              </Field>
              <Field label={t("settings.contact_number")}>
                <TextInput
                  value={form.contact_number}
                  inputMode="tel"
                  prefix="+91"
                  maxLength={10}
                  disabled={!canEdit}
                  onChange={(e) => set("contact_number", e.target.value.replace(/\D/g, ""))}
                />
              </Field>
            </Section>

            <Section title={t("settings.section_bank")}>
              <Field label={t("settings.account_number")}>
                <TextInput
                  value={form.bank_account_number}
                  inputMode="numeric"
                  disabled={!canEdit}
                  onChange={(e) => set("bank_account_number", e.target.value)}
                />
              </Field>
              <Field label={t("settings.ifsc_code")}>
                <TextInput
                  value={form.bank_ifsc_code}
                  disabled={!canEdit}
                  onChange={(e) => set("bank_ifsc_code", e.target.value.toUpperCase())}
                />
              </Field>
              <Field label={t("settings.branch_name")}>
                <TextInput
                  value={form.bank_branch_name}
                  disabled={!canEdit}
                  onChange={(e) => set("bank_branch_name", e.target.value)}
                />
              </Field>
            </Section>

            <Section title={t("settings.section_preferences")}>
              <Field label={t("settings.default_language")}>
                <Dropdown
                  value={form.default_language}
                  onChange={(v) => canEdit && set("default_language", v)}
                  options={LANGUAGES.map((l) => ({
                    value: l.code,
                    label: l.label,
                    disabled: !canEdit,
                  }))}
                />
              </Field>
              <Field label={t("settings.payment_period")}>
                <Dropdown
                  value={form.payment_period}
                  onChange={(v) => canEdit && set("payment_period", v)}
                  options={PAYMENT_PERIOD_OPTIONS.map((o) => ({
                    value: o.value,
                    label: o.label,
                    disabled: !canEdit,
                  }))}
                />
              </Field>
            </Section>

            <Section title={t("settings.section_collection")}>
              <Field label={t("settings.rate_calc_mode")}>
                <Dropdown
                  value={form.calculation_mode}
                  onChange={(v) => canEdit && set("calculation_mode", v)}
                  options={CALC_MODES.map((o) => ({ ...o, disabled: !canEdit }))}
                />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label={t("settings.morning_start")}>
                  <TextInput
                    type="time"
                    value={form.morning_start_time}
                    disabled={!canEdit}
                    onChange={(e) => set("morning_start_time", e.target.value)}
                  />
                </Field>
                <Field label={t("settings.morning_end")}>
                  <TextInput
                    type="time"
                    value={form.morning_end_time}
                    disabled={!canEdit}
                    onChange={(e) => set("morning_end_time", e.target.value)}
                  />
                </Field>
                <Field label={t("settings.evening_start")}>
                  <TextInput
                    type="time"
                    value={form.evening_start_time}
                    disabled={!canEdit}
                    onChange={(e) => set("evening_start_time", e.target.value)}
                  />
                </Field>
                <Field label={t("settings.evening_end")}>
                  <TextInput
                    type="time"
                    value={form.evening_end_time}
                    disabled={!canEdit}
                    onChange={(e) => set("evening_end_time", e.target.value)}
                  />
                </Field>
              </div>
              <Field label={t("settings.default_cow_rate")}>
                <TextInput
                  value={form.default_cow_rate}
                  inputMode="decimal"
                  disabled={!canEdit}
                  onChange={(e) => set("default_cow_rate", e.target.value)}
                />
              </Field>
              <Field label={t("settings.default_buffalo_rate")}>
                <TextInput
                  value={form.default_buffalo_rate}
                  inputMode="decimal"
                  disabled={!canEdit}
                  onChange={(e) => set("default_buffalo_rate", e.target.value)}
                />
              </Field>
              <Field label={t("settings.default_milk_sale_rate")}>
                <TextInput
                  value={form.default_milk_sale_rate}
                  inputMode="decimal"
                  disabled={!canEdit}
                  onChange={(e) => set("default_milk_sale_rate", e.target.value)}
                />
              </Field>
            </Section>

            {canEdit && (
              <Button onClick={onSave} loading={saving}>
                {t("settings.save_changes")}
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-4 flex flex-col gap-3">
      <h2 className="text-xs uppercase tracking-wide text-slate-400 font-semibold">{title}</h2>
      {children}
    </section>
  );
}
