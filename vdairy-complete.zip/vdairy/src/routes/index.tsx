import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Logo } from "@/components/Logo";
import { useAuth } from "@/contexts/AuthContext";

export const Route = createFileRoute("/")({
  ssr: false,
  component: SplashScreen,
});

function SplashScreen() {
  const { loading, session } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;
    navigate({ to: session ? "/centers" : "/login", replace: true });
  }, [loading, session, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="animate-scale-fade">
        <Logo size="lg" />
      </div>
    </div>
  );
}
