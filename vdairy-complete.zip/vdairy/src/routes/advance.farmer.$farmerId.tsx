import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, X } from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { Spinner } from "@/components/Spinner";
import { BottomSheet } from "@/components/BottomSheet";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { fetchFarmer, farmerFullName, type Farmer } from "@/lib/farmers";
import {
  listAdvancesForFarmer,
  listDeductionsForFarmer,
  recordRepayment,
  type Advance,
  type AdvanceDeduction,
} from "@/lib/advances";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/advance/farmer/$farmerId")({
  component: FarmerAdvanceDetail,
});

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function fmtDMY(iso: string): string {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

function FarmerAdvanceDetail() {
  const { t } = useTranslation();
  const { farmerId } = useParams({ from: "/advance/farmer/$farmerId" });
  const navigate = useNavigate();
  const { userId } = useAuth();
  const { selected } = useCenter();

  const [loading, setLoading] = useState(true);
  const [farmer, setFarmer] = useState<Farmer | null>(null);
  const [advances, setAdvances] = useState<Advance[]>([]);
  const [deductions, setDeductions] = useState<AdvanceDeduction[]>([]);
  const [sheetOpen, setSheetOpen] = useState(false);

  const [rDate, setRDate] = useState(todayISO());
  const [rAmount, setRAmount] = useState("");
  const [rComments, setRComments] = useState("");
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [f, advs, deds] = await Promise.all([
        fetchFarmer(farmerId),
        listAdvancesForFarmer(farmerId),
        listDeductionsForFarmer(farmerId),
      ]);
      setFarmer(f);
      setAdvances(advs);
      setDeductions(deds);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [farmerId]);

  const totalGiven = advances.reduce((s, a) => s + Number(a.amount), 0);
  const totalRepaid = deductions.reduce((s, d) => s + Number(d.amount), 0);
  const balance = totalGiven - totalRepaid;

  const submitRepayment = async () => {
    if (!selected) return;
    const amt = Number(rAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast.error(t("advance.enter_valid_amount"));
      return;
    }
    setSaving(true);
    try {
      const res = await recordRepayment({
        centerId: selected.id,
        farmerId,
        amount: amt,
        date: rDate,
        comments: rComments.trim() || null,
        enteredBy: userId,
      });
      if (!res.ok) {
        toast.error(res.error ?? t("advance.failed_to_record"));
        return;
      }
      toast.success(t("advance.repayment_recorded"));
      setSheetOpen(false);
      setRAmount("");
      setRComments("");
      setRDate(todayISO());
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("advance.failed_to_record"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AppHeader
        title={farmer ? farmerFullName(farmer) : t("advance.farmer")}
        onBack={() => navigate({ to: "/advance" })}
        right={
          <button
            type="button"
            onClick={() => navigate({ to: "/advance/new", search: { farmer_id: farmerId } })}
            aria-label={t("advance.add_advance_aria")}
            className="h-11 w-11 rounded-full bg-teal-700 text-white flex items-center justify-center hover:bg-teal-800"
          >
            <Plus className="h-5 w-5" />
          </button>
        }
      />

      {loading ? (
        <div className="py-16 flex justify-center">
          <Spinner />
        </div>
      ) : (
        <div className="p-4 space-y-5 pb-8">
          <div className="text-xs text-slate-500 -mt-1">
            {farmer ? t("advance.code_prefix", { code: farmer.code }) : ""}
          </div>

          <div className="rounded-lg border border-slate-200 bg-white p-4 grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-[11px] uppercase text-slate-400 font-semibold">
                {t("advance.total_given")}
              </div>
              <div className="font-bold text-slate-800 mt-0.5">₹{totalGiven.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase text-slate-400 font-semibold">
                {t("advance.total_repaid")}
              </div>
              <div className="font-bold text-slate-800 mt-0.5">₹{totalRepaid.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase text-slate-400 font-semibold">
                {t("advance.balance")}
              </div>
              <div
                className={cn(
                  "font-bold text-lg mt-0.5",
                  balance > 0.001 ? "text-rose-600" : "text-emerald-600",
                )}
              >
                ₹{Math.abs(balance).toFixed(2)}
              </div>
            </div>
          </div>

          <section>
            <h2 className="text-sm font-semibold text-slate-700 mb-2">
              {t("advance.advances_given")}
            </h2>
            {advances.length === 0 ? (
              <div className="rounded-lg border border-slate-200 p-6 text-center text-sm text-slate-500">
                {t("advance.no_advances")}
              </div>
            ) : (
              <div className="rounded-lg border border-slate-200 overflow-hidden">
                <div className="grid grid-cols-[90px_1fr_100px] gap-2 px-3 py-2 bg-slate-50 text-[11px] uppercase font-semibold text-slate-400">
                  <div>{t("advance.date")}</div>
                  <div>{t("advance.comments")}</div>
                  <div className="text-right">{t("advance.amount_column")}</div>
                </div>
                <div className="divide-y divide-slate-100">
                  {advances.map((a) => (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => navigate({ to: "/advance/$id/edit", params: { id: a.id } })}
                      className="w-full grid grid-cols-[90px_1fr_100px] gap-2 px-3 py-2.5 text-left text-sm hover:bg-slate-50"
                    >
                      <div className="text-slate-600 text-xs">{fmtDMY(a.advance_date)}</div>
                      <div className="text-slate-700 truncate">
                        {a.comments ?? "—"}
                        {Number(a.interest_rate) > 0 && (
                          <span className="text-slate-400">
                            {" "}
                            ({a.interest_rate}%
                            {a.advance_type === "Monthly Installment"
                              ? t("advance.per_month_short")
                              : ""}
                            )
                          </span>
                        )}
                      </div>
                      <div className="text-right font-semibold text-slate-800">
                        ₹{Number(a.amount).toFixed(2)}
                      </div>
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-[90px_1fr_100px] gap-2 px-3 py-2.5 border-t-2 border-slate-300 text-sm">
                  <div className="font-bold text-slate-800">{t("advance.total_label")}</div>
                  <div />
                  <div className="text-right font-bold text-slate-800">
                    ₹{totalGiven.toFixed(2)}
                  </div>
                </div>
              </div>
            )}
          </section>

          <section>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-semibold text-slate-700">
                {t("advance.deductions_repayments")}
              </h2>
              <button
                type="button"
                onClick={() => setSheetOpen(true)}
                className="inline-flex items-center gap-1 rounded-md bg-teal-50 text-teal-700 text-xs font-semibold px-2 py-1 hover:bg-teal-100"
              >
                <Plus className="h-3.5 w-3.5" /> {t("advance.record_repayment")}
              </button>
            </div>
            {deductions.length === 0 ? (
              <div className="rounded-lg border border-slate-200 p-6 text-center text-sm text-slate-500">
                {t("advance.no_advances")}
              </div>
            ) : (
              <div className="rounded-lg border border-slate-200 overflow-hidden">
                <div className="grid grid-cols-[90px_1fr_100px] gap-2 px-3 py-2 bg-slate-50 text-[11px] uppercase font-semibold text-slate-400">
                  <div>{t("advance.date")}</div>
                  <div>{t("advance.source")}</div>
                  <div className="text-right">{t("advance.amount_column")}</div>
                </div>
                <div className="divide-y divide-slate-100">
                  {deductions.map((d) => (
                    <div
                      key={d.id}
                      className="grid grid-cols-[90px_1fr_100px] gap-2 px-3 py-2.5 text-sm items-center"
                    >
                      <div className="text-slate-600 text-xs">{fmtDMY(d.deduction_date)}</div>
                      <div>
                        <span
                          className={cn(
                            "inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold",
                            d.source === "Manual"
                              ? "bg-slate-100 text-slate-600"
                              : "bg-teal-50 text-teal-700",
                          )}
                        >
                          {d.source}
                        </span>
                      </div>
                      <div className="text-right font-semibold text-emerald-600">
                        ₹{Number(d.amount).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-[90px_1fr_100px] gap-2 px-3 py-2.5 border-t-2 border-slate-300 text-sm">
                  <div className="font-bold text-slate-800">{t("advance.total_label")}</div>
                  <div />
                  <div className="text-right font-bold text-emerald-600">
                    ₹{totalRepaid.toFixed(2)}
                  </div>
                </div>
              </div>
            )}
          </section>
        </div>
      )}

      <BottomSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title={
          <div className="flex items-center justify-between">
            <span>{t("advance.record_repayment")}</span>
            <button
              onClick={() => setSheetOpen(false)}
              className="p-1 rounded-full hover:bg-slate-100"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        }
      >
        <div className="px-3 pb-4 space-y-3">
          <Field label={t("advance.date")}>
            <TextInput type="date" value={rDate} onChange={(e) => setRDate(e.target.value)} />
          </Field>
          <Field label={t("advance.amount_inr")}>
            <TextInput
              value={rAmount}
              onChange={(e) => setRAmount(e.target.value.replace(/[^0-9.]/g, ""))}
              inputMode="decimal"
              placeholder="0.00"
            />
          </Field>
          <Field label={t("advance.comments")}>
            <TextInput
              value={rComments}
              onChange={(e) => setRComments(e.target.value)}
              placeholder={t("advance.optional_placeholder")}
            />
          </Field>
          <Button onClick={submitRepayment} loading={saving} disabled={saving}>
            {t("advance.record_repayment")}
          </Button>
        </div>
      </BottomSheet>
    </>
  );
}
