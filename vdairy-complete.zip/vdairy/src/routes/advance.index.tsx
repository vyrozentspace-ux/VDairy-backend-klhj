import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Calendar, ChevronLeft, ChevronRight, Loader2, Lock, Plus, Wallet } from "lucide-react";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { supabase } from "@/integrations/supabase/client";
import { fetchFarmers, farmerFullName, type Farmer } from "@/lib/farmers";
import { farmerBalancesForCenter } from "@/lib/advances";
import {
  formatDMY,
  fromISODate,
  periodForDate,
  shiftPeriod,
  type Period,
} from "@/lib/payment-periods";
import { usePeriodConfig } from "@/hooks/usePeriodConfig";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/advance/")({
  component: AdvanceListScreen,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

function AdvanceListScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { profile } = useAuth();

  const [loading, setLoading] = useState(true);
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [balances, setBalances] = useState<
    Record<string, { given: number; repaid: number; balance: number }>
  >({});
  const [includePaid, setIncludePaid] = useState(false);
  const [periodOn, setPeriodOn] = useState(false);
  const { config, loaded: configLoaded } = usePeriodConfig();
  const [period, setPeriodState] = useState<Period>(() =>
    periodForDate({ paymentPeriod: null, startDate: null }),
  );
  const [periodTouched, setPeriodTouched] = useState(false);

  const canView = !!profile; // stub — later gate for operator permissions

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const [fs, bals] = await Promise.all([
          fetchFarmers(selected.id),
          farmerBalancesForCenter(selected.id),
        ]);
        if (cancelled) return;
        setFarmers(fs);
        setBalances(bals);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  useEffect(() => {
    if (!configLoaded || periodTouched) return;
    setPeriodState(periodForDate(config));
  }, [configLoaded, config.paymentPeriod, config.startDate, periodTouched]);

  const shift = (dir: number) => {
    setPeriodTouched(true);
    setPeriodState((p) => shiftPeriod(config, p, dir));
  };
  const periodStart = useMemo(() => fromISODate(period.start), [period.start]);
  const periodEnd = useMemo(() => fromISODate(period.end), [period.end]);

  const rows = useMemo(() => {
    const withAny = farmers
      .map((f) => ({ farmer: f, ...(balances[f.id] ?? { given: 0, repaid: 0, balance: 0 }) }))
      .filter((r) => r.given > 0 || r.repaid > 0);
    const filtered = includePaid ? withAny : withAny.filter((r) => Math.abs(r.balance) > 0.001);
    return filtered.sort((a, b) =>
      farmerFullName(a.farmer).localeCompare(farmerFullName(b.farmer)),
    );
  }, [farmers, balances, includePaid]);

  const totals = useMemo(
    () =>
      rows.reduce((acc, r) => ({ given: acc.given + r.given, balance: acc.balance + r.balance }), {
        given: 0,
        balance: 0,
      }),
    [rows],
  );

  if (!canView) {
    return (
      <>
        <AppHeader title={t("advance.advances")} onBack={() => navigate({ to: "/dashboard" })} />
        <div className="py-16 flex flex-col items-center gap-3">
          <span className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300">
            <Lock className="h-7 w-7" />
          </span>
          <p className="text-sm text-slate-500">{t("advance.no_permission")}</p>
        </div>
      </>
    );
  }

  return (
    <>
      <AppHeader
        title={t("advance.advances")}
        onBack={() => navigate({ to: "/dashboard" })}
        right={
          <button
            type="button"
            onClick={() => navigate({ to: "/advance/new" })}
            aria-label={t("advance.add_advance_aria")}
            className="h-11 w-11 rounded-full bg-teal-700 text-white flex items-center justify-center hover:bg-teal-800"
          >
            <Plus className="h-5 w-5" />
          </button>
        }
      />

      <div className="px-4 py-3">
        <div className="text-xs text-slate-500 -mt-1 mb-3">{selected?.name}</div>

        <div className="flex items-center justify-between mb-3">
          <label className="inline-flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={includePaid}
              onChange={(e) => setIncludePaid(e.target.checked)}
              className="h-4 w-4 rounded accent-teal-600"
            />
            {t("advance.include_paid")}
          </label>
          <button
            type="button"
            onClick={() => setPeriodOn((v) => !v)}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold",
              periodOn ? "bg-teal-100 text-teal-700" : "bg-slate-100 text-slate-600",
            )}
          >
            <Calendar className="h-3.5 w-3.5" /> {t("advance.filter_by_period")}
          </button>
        </div>

        {periodOn && (
          <div className="flex items-center gap-2 mb-3">
            <button
              type="button"
              onClick={() => shift(-1)}
              className="h-9 w-9 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <div className="flex-1 text-center text-xs font-medium rounded-lg bg-slate-100 py-2 text-slate-700">
              {formatDMY(periodStart)} {t("invoice.to")} {formatDMY(periodEnd)}
            </div>
            <button
              type="button"
              onClick={() => shift(1)}
              className="h-9 w-9 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        )}

        {loading ? (
          <div className="py-16 flex justify-center">
            <Loader2 className="h-6 w-6 text-teal-700 animate-spin" />
          </div>
        ) : rows.length === 0 ? (
          <div className="py-14 flex flex-col items-center gap-3">
            <span className="h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300">
              <Wallet className="h-7 w-7" />
            </span>
            <p className="text-sm text-slate-500">{t("advance.no_advances_recorded")}</p>
            <div className="w-40">
              <Button onClick={() => navigate({ to: "/advance/new" })}>
                <Plus className="h-4 w-4" /> {t("advance.add_advance")}
              </Button>
            </div>
          </div>
        ) : (
          <div>
            <div className="grid grid-cols-3 gap-2 pb-2 border-b border-slate-200 text-[11px] uppercase font-semibold text-slate-400 tracking-wide">
              <div>{t("advance.name")}</div>
              <div className="text-center">{t("advance.amount_column")}</div>
              <div className="text-right">{t("advance.balance")}</div>
            </div>
            <div className="divide-y divide-slate-100">
              {rows.map((r) => (
                <button
                  key={r.farmer.id}
                  type="button"
                  onClick={() =>
                    navigate({ to: "/advance/farmer/$farmerId", params: { farmerId: r.farmer.id } })
                  }
                  className="grid grid-cols-3 gap-2 py-3 items-center text-left hover:bg-slate-50"
                >
                  <div className="text-sm font-medium text-slate-800 truncate">
                    {farmerFullName(r.farmer)}
                  </div>
                  <div className="text-sm text-slate-700 text-center">₹{r.given.toFixed(2)}</div>
                  <div
                    className={cn(
                      "text-sm font-semibold text-right",
                      r.balance > 0.001 ? "text-rose-600" : "text-emerald-600",
                    )}
                  >
                    ₹{r.balance.toFixed(2)}
                  </div>
                </button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2 border-t-2 border-slate-300 pt-3 mt-2">
              <div className="text-sm font-bold text-slate-800">
                {t("advance.total", { count: rows.length })}
              </div>
              <div className="text-sm font-bold text-slate-800 text-center">
                ₹{totals.given.toFixed(2)}
              </div>
              <div
                className={cn(
                  "text-sm font-bold text-right",
                  totals.balance > 0.001 ? "text-rose-600" : "text-emerald-600",
                )}
              >
                ₹{totals.balance.toFixed(2)}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
