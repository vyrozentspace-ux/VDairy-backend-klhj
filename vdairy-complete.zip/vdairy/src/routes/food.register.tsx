import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";

import { useTranslation } from "react-i18next";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/Button";
import { Field, TextInput } from "@/components/Field";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import { createProduct, type FeedUnit } from "@/lib/food";
import { logActivity } from "@/lib/farmers";

export const Route = createFileRoute("/food/register")({
  component: RegisterProductScreen,
});

function RegisterProductScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { selected } = useCenter();
  const { userId } = useAuth();

  const [name, setName] = useState("");
  const [unit, setUnit] = useState<FeedUnit>("Bag");
  const [rate, setRate] = useState("");
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    if (!selected || !name.trim()) return;
    setSaving(true);
    try {
      const p = await createProduct({
        center_id: selected.id,
        product_name: name.trim(),
        unit,
        default_rate: rate ? Number(rate) : null,
      });
      await logActivity(selected.id, userId ?? "", "feed_product_added", {
        id: p.id,
        product_name: p.product_name,
      });
      toast.success(t("food.product_registered"));
      setName("");
      setRate("");
      setUnit("Bag");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("food.failed_to_save"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <AppHeader title={t("food.register_feed_product")} onBack={() => navigate({ to: "/food" })} />
      <div className="p-4 space-y-4 pb-24">
        <Field label={t("food.product_name")}>
          <TextInput value={name} onChange={(e) => setName(e.target.value)} autoFocus />
        </Field>
        <Field label={t("food.unit")}>
          <div className="grid grid-cols-3 gap-2">
            {(["Bag", "Kg", "Unit"] as FeedUnit[]).map((u) => (
              <button
                key={u}
                type="button"
                onClick={() => setUnit(u)}
                className={`h-11 rounded-lg border text-sm font-semibold ${unit === u ? "bg-teal-700 text-white border-teal-700" : "bg-white text-slate-700 border-slate-200"}`}
              >
                {u}
              </button>
            ))}
          </div>
        </Field>
        <Field label={t("food.default_rate_optional")}>
          <TextInput
            type="number"
            inputMode="decimal"
            value={rate}
            onChange={(e) => setRate(e.target.value)}
            placeholder="0"
          />
        </Field>
        <Button onClick={submit} loading={saving} disabled={!name.trim()}>
          {t("food.register_product")}
        </Button>
        <Link
          to="/food/stock"
          className="block text-center text-sm text-teal-700 font-medium hover:underline"
        >
          {t("food.go_to_food_stock")}
        </Link>
      </div>
    </>
  );
}
