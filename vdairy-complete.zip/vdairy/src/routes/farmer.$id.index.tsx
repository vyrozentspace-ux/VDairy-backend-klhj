import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Edit, MapPin, MoreVertical, Phone, Plus, Trash2, UserX } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/AppHeader";
import { FarmerAvatar } from "@/components/FarmerAvatar";
import { BottomSheet, SheetItem } from "@/components/BottomSheet";
import { Button } from "@/components/Button";
import { MilkTypePills } from "@/components/MilkTypePills";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCenter } from "@/contexts/CenterContext";
import {
  farmerFullName,
  fetchFarmer,
  formatMobile,
  logActivity,
  MILK_TYPE_BADGE,
  MILK_TYPE_LABEL,
  type Farmer,
  type MilkType,
} from "@/lib/farmers";
import { cn } from "@/lib/utils";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

type OverviewStats = {
  monthLiters: number;
  monthAmount: number;
  outstandingAdvance: number;
  lastCollectionDate: string | null;
};

export const Route = createFileRoute("/farmer/$id/")({
  component: FarmerDetail,
});

function FarmerDetail() {
  const { t } = useTranslation();
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { profile, userId } = useAuth();
  const { selected } = useCenter();
  const isOwner = profile?.role === "owner";

  const [farmer, setFarmer] = useState<Farmer | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"overview" | "collections" | "advances" | "invoices">("overview");
  const [menuOpen, setMenuOpen] = useState(false);
  const [milkSheet, setMilkSheet] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [busy, setBusy] = useState(false);
  const [stats, setStats] = useState<OverviewStats | null>(null);

  const load = async () => {
    setLoading(true);
    const f = await fetchFarmer(id);
    setFarmer(f);
    setLoading(false);
    // Fire-and-forget: load overview stats
    void loadStats(id);
  };

  const loadStats = async (farmerId: string) => {
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth();
    const pad = (n: number) => String(n).padStart(2, "0");
    const from = `${y}-${pad(m + 1)}-01`;
    const lastDay = new Date(y, m + 1, 0).getDate();
    const to = `${y}-${pad(m + 1)}-${pad(lastDay)}`;
    const [monthRes, lastRes, advRes] = await Promise.all([
      db
        .from("collections")
        .select("quantity_liters,total_amount")
        .eq("farmer_id", farmerId)
        .gte("collection_date", from)
        .lte("collection_date", to),
      db
        .from("collections")
        .select("collection_date")
        .eq("farmer_id", farmerId)
        .order("collection_date", { ascending: false })
        .limit(1),
      db.rpc("farmer_advance_balance", { p_farmer_id: farmerId }),
    ]);
    const monthLiters = ((monthRes.data ?? []) as { quantity_liters: number }[]).reduce(
      (s, r) => s + Number(r.quantity_liters),
      0,
    );
    const monthAmount = ((monthRes.data ?? []) as { total_amount: number }[]).reduce(
      (s, r) => s + Number(r.total_amount),
      0,
    );
    const lastCollectionDate =
      ((lastRes.data ?? []) as { collection_date: string }[])[0]?.collection_date ?? null;
    setStats({
      monthLiters,
      monthAmount,
      outstandingAdvance: Number(advRes.data ?? 0),
      lastCollectionDate,
    });
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (loading || !farmer) {
    return (
      <>
        <AppHeader title={t("farmers.title_farmer")} />
        <div className="p-6 text-sm text-slate-500">{t("farmers.loading")}</div>
      </>
    );
  }

  const mt = farmer.milk_type as MilkType;

  const setMilk = async (next: MilkType) => {
    setBusy(true);
    const { error } = await supabase.from("farmers").update({ milk_type: next }).eq("id", id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(t("farmers.milk_type_updated"));
    if (userId && selected)
      void logActivity(selected.id, userId, "farmer_milk_type_changed", {
        farmer_id: id,
        milk_type: next,
      });
    setMilkSheet(false);
    void load();
  };

  const toggleActive = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("farmers")
      .update({ is_active: !farmer.is_active })
      .eq("id", id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(
      farmer.is_active ? t("farmers.farmer_deactivated") : t("farmers.farmer_activated"),
    );
    if (userId && selected)
      void logActivity(
        selected.id,
        userId,
        farmer.is_active ? "farmer_deactivated" : "farmer_activated",
        { farmer_id: id },
      );
    setMenuOpen(false);
    void load();
  };

  const remove = async () => {
    setBusy(true);
    const { error } = await supabase.from("farmers").delete().eq("id", id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(t("farmers.farmer_deleted"));
    if (userId && selected)
      void logActivity(selected.id, userId, "farmer_deleted", { farmer_id: id });
    navigate({ to: "/farmers" });
  };

  return (
    <>
      <AppHeader
        title={farmerFullName(farmer)}
        onBack={() => navigate({ to: "/farmers" })}
        right={
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="h-11 w-11 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100"
            aria-label={t("farmers.more")}
          >
            <MoreVertical className="h-5 w-5" />
          </button>
        }
      />

      <div className="px-4 py-5 border-b border-slate-100 flex items-start gap-4">
        <FarmerAvatar farmer={farmer} size={60} />
        <div className="flex-1 min-w-0">
          <div className="text-lg font-bold text-slate-800 truncate">{farmerFullName(farmer)}</div>
          <div className="flex flex-wrap gap-1.5 mt-1">
            <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-semibold">
              {farmer.code}
            </span>
            <span
              className={cn(
                "px-2 py-0.5 rounded-full border text-[11px] font-semibold",
                MILK_TYPE_BADGE[mt],
              )}
            >
              {MILK_TYPE_LABEL[mt]}
            </span>
            <span
              className={cn(
                "px-2 py-0.5 rounded-full text-[11px] font-semibold",
                farmer.is_active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500",
              )}
            >
              {farmer.is_active ? t("farmers.status_active") : t("farmers.status_inactive")}
            </span>
          </div>
          {(farmer.village || farmer.address) && (
            <div className="mt-2 flex items-start gap-1.5 text-xs text-slate-500">
              <MapPin className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <span>{[farmer.village, farmer.address].filter(Boolean).join(", ")}</span>
            </div>
          )}
          {farmer.mobile && (
            <a
              href={`tel:${farmer.mobile}`}
              className="mt-1.5 flex items-center gap-1.5 text-xs text-teal-700 font-medium"
            >
              <Phone className="h-3.5 w-3.5" /> {formatMobile(farmer.mobile)}
            </a>
          )}
        </div>
      </div>

      <div className="px-4 py-3 grid grid-cols-3 gap-2 border-b border-slate-100">
        {farmer.mobile && (
          <QuickAction
            href={`tel:${farmer.mobile}`}
            icon={<Phone className="h-4 w-4" />}
            tint="bg-emerald-50 text-emerald-600"
            label={t("farmers.call")}
          />
        )}
        <QuickAction
          onClick={() => toast(t("farmers.collection_module_coming"))}
          icon={<Plus className="h-4 w-4" />}
          tint="bg-teal-50 text-teal-700"
          label={t("farmers.collection")}
        />
        <QuickAction
          to="/farmer/$id/edit"
          params={{ id }}
          icon={<Edit className="h-4 w-4" />}
          tint="bg-indigo-50 text-indigo-600"
          label={t("farmers.edit")}
        />
      </div>

      <div className="px-4 py-3 flex gap-2 overflow-x-auto border-b border-slate-100">
        {(["overview", "collections", "advances", "invoices"] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={cn(
              "px-3 py-1.5 rounded-full text-xs font-semibold capitalize",
              tab === t
                ? "bg-teal-700 text-white"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200",
            )}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="p-4">
        {tab === "overview" ? (
          <div className="grid grid-cols-2 gap-3">
            <Stat
              label={t("farmers.this_month_liters")}
              value={stats ? `${stats.monthLiters.toFixed(1)} L` : "…"}
            />
            <Stat
              label={t("farmers.this_month_amount")}
              value={stats ? `₹${stats.monthAmount.toFixed(2)}` : "…"}
            />
            <Stat
              label={t("farmers.outstanding_advance")}
              value={stats ? `₹${stats.outstandingAdvance.toFixed(2)}` : "…"}
            />
            <Stat label={t("farmers.last_collection")} value={stats?.lastCollectionDate ?? "—"} />
          </div>
        ) : (
          <div className="text-center text-sm text-slate-500 py-10">
            {t("farmers.no_tab_yet", { tab })}
          </div>
        )}
      </div>

      <BottomSheet
        open={menuOpen && !confirmDelete}
        onClose={() => setMenuOpen(false)}
        title={farmerFullName(farmer)}
      >
        <div className="space-y-1">
          <SheetItem
            icon={<Edit className="h-4 w-4" />}
            label={t("farmers.edit")}
            onClick={() => {
              setMenuOpen(false);
              navigate({ to: "/farmer/$id/edit", params: { id } });
            }}
          />
          <SheetItem
            icon={<Phone className="h-4 w-4" />}
            label={t("farmers.set_milk_type")}
            meta={farmer.milk_type}
            onClick={() => setMilkSheet(true)}
          />
          {isOwner && (
            <SheetItem
              icon={<UserX className="h-4 w-4" />}
              label={farmer.is_active ? t("farmers.deactivate") : t("farmers.activate")}
              onClick={toggleActive}
            />
          )}
          {isOwner && (
            <SheetItem
              icon={<Trash2 className="h-4 w-4" />}
              label={t("farmers.delete")}
              danger
              onClick={() => setConfirmDelete(true)}
            />
          )}
        </div>
      </BottomSheet>

      <BottomSheet
        open={milkSheet}
        onClose={() => setMilkSheet(false)}
        title={t("farmers.milk_type")}
      >
        <div className="p-2">
          <MilkTypePills value={mt} onChange={setMilk} />
        </div>
      </BottomSheet>

      <BottomSheet
        open={confirmDelete}
        onClose={() => setConfirmDelete(false)}
        title={t("farmers.delete_this_farmer")}
      >
        <div className="px-3 pb-2">
          <p className="text-sm text-slate-500 mb-4">
            {t("farmers.confirm_delete_message", { name: farmerFullName(farmer) })}
          </p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setConfirmDelete(false)}>
              {t("farmers.cancel")}
            </Button>
            <Button variant="danger" loading={busy} onClick={remove}>
              {t("farmers.delete")}
            </Button>
          </div>
        </div>
      </BottomSheet>
    </>
  );
}

function QuickAction({
  icon,
  tint,
  label,
  href,
  to,
  params,
  onClick,
}: {
  icon: React.ReactNode;
  tint: string;
  label: string;
  href?: string;
  to?: "/farmer/$id/edit";
  params?: { id: string };
  onClick?: () => void;
}) {
  const inner = (
    <div className="flex flex-col items-center justify-center gap-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 py-3 transition">
      <span className={cn("h-9 w-9 rounded-full flex items-center justify-center", tint)}>
        {icon}
      </span>
      <span className="text-xs font-medium text-slate-700">{label}</span>
    </div>
  );
  if (href) return <a href={href}>{inner}</a>;
  if (to && params)
    return (
      <Link to={to} params={params}>
        {inner}
      </Link>
    );
  return (
    <button type="button" onClick={onClick} className="text-left">
      {inner}
    </button>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
      <div className="text-xs text-slate-500">{label}</div>
      <div className="text-lg font-bold text-slate-800 mt-0.5">{value}</div>
    </div>
  );
}
