import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/store")({
  component: StoreScreen,
});

function StoreScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  return (
    <>
      <AppHeader title={t("auth.store")} onBack={() => navigate({ to: "/dashboard" })} />
      <div className="p-6 pb-24">
        <div className="rounded-lg border border-slate-200 bg-white p-8 flex flex-col items-center text-center gap-3">
          <span className="h-16 w-16 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center">
            <ShoppingBag className="h-7 w-7" />
          </span>
          <h2 className="text-lg font-semibold text-slate-800">{t("auth.store")}</h2>
          <p className="text-sm text-slate-500 max-w-xs">{t("auth.store_coming_soon")}</p>
        </div>
      </div>
    </>
  );
}
