import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { useTranslation } from "react-i18next";

import { AppHeader } from "@/components/AppHeader";
import { APP_NAME } from "@/lib/app-config";
import { useAppSettings } from "@/lib/app-settings";

export const Route = createFileRoute("/terms")({
  ssr: false,
  component: TermsScreen,
  head: () => ({
    meta: [
      { title: "Terms & Conditions — VDairy" },
      {
        name: "description",
        content:
          "Terms and conditions for using VDairy: accounts, dairy data ownership, subscriptions, referrals and acceptable use.",
      },
      { property: "og:title", content: "Terms & Conditions — VDairy" },
      {
        property: "og:description",
        content: "How VDairy handles your account, your dairy data, subscriptions and referrals.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function TermsScreen() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const router = useRouter();
  const settings = useAppSettings();

  const sections = [
    "terms_s1",
    "terms_s2",
    "terms_s3",
    "terms_s4",
    "terms_s5",
    "terms_s6",
    "terms_s7",
    "terms_s8",
  ] as const;

  const goBack = () => {
    if (typeof window !== "undefined" && window.history.length > 1) router.history.back();
    else navigate({ to: "/more" });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={t("settings.terms_title")} onBack={goBack} />
      <div className="max-w-md mx-auto px-5 py-5 pb-24 flex flex-col gap-4">
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <h1 className="text-lg font-bold text-slate-800">
            {t("settings.terms_heading", { app: APP_NAME })}
          </h1>
          <p className="mt-1 text-xs text-slate-500">{t("settings.terms_intro")}</p>
        </div>

        {sections.map((key) => (
          <section key={key} className="rounded-lg border border-slate-200 bg-white p-5">
            <h2 className="text-sm font-semibold text-slate-800">
              {t(`settings.${key}_title`)}
            </h2>
            <p className="mt-1.5 text-sm leading-relaxed text-slate-600">
              {t(`settings.${key}_body`)}
            </p>
          </section>
        ))}

        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold text-slate-800">{t("settings.terms_s9_title")}</h2>
          <p className="mt-1.5 text-sm leading-relaxed text-slate-600">
            {t("settings.terms_s9_body")}
          </p>
          {(settings.support_email || settings.support_phone) && (
            <div className="mt-3 flex flex-col gap-1 text-sm">
              {settings.support_email && (
                <a
                  className="font-semibold text-teal-700"
                  href={`mailto:${settings.support_email}`}
                >
                  {settings.support_email}
                </a>
              )}
              {settings.support_phone && (
                <a className="font-semibold text-teal-700" href={`tel:+91${settings.support_phone}`}>
                  +91 {settings.support_phone}
                </a>
              )}
            </div>
          )}

        </section>
      </div>
    </div>
  );
}
