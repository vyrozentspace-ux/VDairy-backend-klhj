import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCenter } from "@/contexts/CenterContext";
import type { PeriodConfig } from "@/lib/payment-periods";

/** Loads the selected center's configured payment cycle + anchor start date. */
export function usePeriodConfig(): { config: PeriodConfig; loaded: boolean } {
  const { selected } = useCenter();
  const [config, setConfig] = useState<PeriodConfig>({ paymentPeriod: null, startDate: null });
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setLoaded(false);
    (async () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data } = await (supabase as any)
        .from("center_collection_settings")
        .select("payment_period, payment_period_start_date")
        .eq("center_id", selected.id)
        .maybeSingle();
      if (cancelled) return;
      setConfig({
        paymentPeriod: data?.payment_period ?? null,
        startDate: data?.payment_period_start_date ?? null,
      });
      setLoaded(true);
    })();
    return () => {
      cancelled = true;
    };
  }, [selected?.id]);

  return { config, loaded };
}
