import { useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import {
  planMissedCollectionAlerts,
  planShiftReminders,
  planPaidPlanReminders,
  planSubscriptionReminders,
  selectDue,
  selectSchedulable,
  ymd,
  type CenterShiftTimes,
  type CollectionRow,
  type FarmerRef,
  type PlannedNotification,
} from "@/lib/notification-engine";
import {
  deliverNow,
  getOperatorSubscriptionNotifications,
  loadFiredKeys,
  markFired,
  scheduleNative,
  useNotificationPrefs,
} from "@/lib/notifications";

const TICK_MS = 60_000;

/** Builds the full plan of notifications for a centre at a given moment. */
export async function buildPlan(
  centerId: string,
  now: Date,
): Promise<{ planned: PlannedNotification[]; allowSubscriptionData: boolean }> {
  const day = ymd(now);
  const weekAgo = new Date(now.getTime() - 7 * 86_400_000);

  const [{ data: settings }, { data: farmers }, { data: collections }, { data: sub }] =
    await Promise.all([
      supabase
        .from("center_collection_settings")
        .select("morning_start_time, morning_end_time, evening_start_time, evening_end_time")
        .eq("center_id", centerId)
        .maybeSingle(),
      supabase
        .from("farmers")
        .select("id, code, first_name, last_name")
        .eq("center_id", centerId)
        .eq("is_active", true),
      supabase
        .from("collections")
        .select("farmer_id, collection_date, shift")
        .eq("center_id", centerId)
        .gte("collection_date", ymd(weekAgo)),
      supabase
        .from("center_subscriptions")
        .select("trial_ends_at, status, plan, current_period_end, trial_started_at")
        .eq("center_id", centerId)
        .maybeSingle(),
    ]);

  const times = (settings ?? {
    morning_start_time: null,
    morning_end_time: null,
    evening_start_time: null,
    evening_end_time: null,
  }) as CenterShiftTimes;

  const rows = (collections ?? []) as CollectionRow[];
  const planned: PlannedNotification[] = [
    ...planShiftReminders(now, times),
    ...planMissedCollectionAlerts({
      now,
      times,
      farmers: (farmers ?? []) as FarmerRef[],
      history: rows.filter((r) => r.collection_date !== day),
      today: rows.filter((r) => r.collection_date === day),
    }),
    ...planSubscriptionReminders(now, sub ?? null),
    ...planPaidPlanReminders(
      now,
      sub
        ? {
            status: sub.status,
            plan: sub.plan,
            trial_ends_at: sub.trial_ends_at,
            current_period_end: sub.current_period_end,
            plan_started_at: sub.trial_started_at,
          }
        : null,
    ),
  ];
  return { planned, allowSubscriptionData: true };
}

/**
 * Runs the smart-notification engine while the app is open.
 * On native it also pre-schedules today's upcoming reminders with
 * @capacitor/local-notifications so they fire with the app closed.
 */
export function useNotificationRunner(args: {
  userId: string | null;
  centerId: string | null;
  isOwner: boolean;
}) {
  const { userId, centerId, isOwner } = args;
  const { t } = useTranslation();
  const { prefs, loading } = useNotificationPrefs(userId);
  const prefsRef = useRef(prefs);
  prefsRef.current = prefs;

  useEffect(() => {
    if (!userId || !centerId || loading) return;
    let cancelled = false;
    let scheduled = false;

    const run = async () => {
      const now = new Date();
      const allowSubscription = isOwner
        ? true
        : await getOperatorSubscriptionNotifications(centerId);
      const { planned } = await buildPlan(centerId, now);
      if (cancelled) return;

      const render = (n: PlannedNotification) => ({
        ...n,
        title: t(n.titleKey, n.vars ?? {}),
        body: t(n.bodyKey, n.vars ?? {}),
      });

      const due = selectDue(planned, {
        now,
        prefs: prefsRef.current,
        fired: loadFiredKeys(),
        allowSubscription,
      });
      for (const n of due) {
        await deliverNow(render(n), { userId, centerId });
      }
      markFired(due.map((n) => n.key));

      if (!scheduled) {
        scheduled = true;
        const upcoming = selectSchedulable(planned, {
          now,
          prefs: prefsRef.current,
          allowSubscription,
        });
        await scheduleNative(upcoming.map(render));
      }
    };

    void run();
    const id = window.setInterval(() => void run(), TICK_MS);
    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [userId, centerId, isOwner, loading, t]);
}
