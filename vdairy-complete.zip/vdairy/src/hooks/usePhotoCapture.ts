import { useCallback, useState } from "react";

/**
 * Reusable camera / gallery capture hook.
 *
 * Prepared for the upcoming Rate Chart photo-scan feature but intentionally
 * not wired into any screen yet. Uses @capacitor/camera on a native build and
 * falls back to a hidden `<input type="file">` in the browser, so it is safe
 * to call from anywhere in the app.
 */

export type CapturedPhoto = {
  /** `data:image/...;base64,...` — ready for <img src> or an OCR upload. */
  dataUrl: string;
  /** Raw base64 payload without the data-URL prefix. */
  base64: string;
  format: string;
};

export type PhotoSource = "camera" | "gallery";

function isNative(): boolean {
  if (typeof window === "undefined") return false;
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return !!cap?.isNativePlatform?.();
}

function splitDataUrl(dataUrl: string): CapturedPhoto {
  const match = /^data:image\/([a-zA-Z0-9+.-]+);base64,(.*)$/.exec(dataUrl);
  return {
    dataUrl,
    base64: match?.[2] ?? "",
    format: match?.[1] ?? "jpeg",
  };
}

function pickFromBrowser(source: PhotoSource): Promise<CapturedPhoto | null> {
  return new Promise((resolve, reject) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    if (source === "camera") input.capture = "environment";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) {
        resolve(null);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => resolve(splitDataUrl(String(reader.result)));
      reader.onerror = () => reject(new Error("Could not read the selected image"));
      reader.readAsDataURL(file);
    };
    input.oncancel = () => resolve(null);
    input.click();
  });
}

async function pickFromNative(source: PhotoSource): Promise<CapturedPhoto | null> {
  const { Camera, CameraResultType, CameraSource } = await import("@capacitor/camera");

  const permission = await Camera.checkPermissions();
  const needed = source === "camera" ? permission.camera : permission.photos;
  if (needed !== "granted") {
    const requested = await Camera.requestPermissions({
      permissions: source === "camera" ? ["camera"] : ["photos"],
    });
    const granted = source === "camera" ? requested.camera : requested.photos;
    if (granted !== "granted" && granted !== "limited") {
      throw new Error("Permission denied");
    }
  }

  const photo = await Camera.getPhoto({
    quality: 85,
    allowEditing: false,
    correctOrientation: true,
    resultType: CameraResultType.DataUrl,
    source: source === "camera" ? CameraSource.Camera : CameraSource.Photos,
  });

  if (!photo.dataUrl) return null;
  return splitDataUrl(photo.dataUrl);
}

/** Open the camera or the gallery and return the picked image, or null if cancelled. */
export async function capturePhoto(source: PhotoSource = "camera"): Promise<CapturedPhoto | null> {
  return isNative() ? pickFromNative(source) : pickFromBrowser(source);
}

export function usePhotoCapture() {
  const [photo, setPhoto] = useState<CapturedPhoto | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const capture = useCallback(async (source: PhotoSource = "camera") => {
    setLoading(true);
    setError(null);
    try {
      const result = await capturePhoto(source);
      if (result) setPhoto(result);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not open the camera");
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setPhoto(null);
    setError(null);
  }, []);

  return { photo, loading, error, capture, reset };
}
