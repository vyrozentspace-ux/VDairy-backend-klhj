import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./AuthContext";
import {
  ALL_PERMISSIONS,
  normalizePermissions,
  type PermissionKey,
  type Permissions,
} from "@/lib/permissions";

export type Center = {
  id: string;
  name: string;
  code: string;
  village: string | null;
  district: string | null;
  owner_id: string;
};

interface CenterContextValue {
  loading: boolean;
  centers: Center[];
  selectedId: string | null;
  selected: Center | null;
  select: (id: string) => void;
  refresh: () => Promise<void>;
  /** True when the signed-in user owns the selected center. */
  isOwner: boolean;
  /** Effective permissions for the selected center (owners get everything). */
  permissions: Permissions;
  can: (perm: PermissionKey) => boolean;
  canAny: (perms: PermissionKey[]) => boolean;
  /** Owner's display name, when the signed-in user is an operator. */
  ownerName: string | null;
}

const STORAGE_KEY = "vdairy.selectedCenterId";
const CenterContext = createContext<CenterContextValue | null>(null);

export function CenterProvider({ children }: { children: ReactNode }) {
  const { userId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [centers, setCenters] = useState<Center[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [permsByCenter, setPermsByCenter] = useState<Record<string, Permissions>>({});
  const [ownerNames, setOwnerNames] = useState<Record<string, string>>({});

  const refresh = useCallback(async () => {
    if (!userId) {
      setCenters([]);
      setSelectedId(null);
      setPermsByCenter({});
      setOwnerNames({});
      return;
    }
    setLoading(true);
    const { data: owned } = await supabase
      .from("dairy_centers")
      .select("id, name, code, village, district, owner_id")
      .eq("owner_id", userId);
    const { data: opRows } = await supabase
      .from("center_operators")
      .select(
        "center_id, is_active, permissions, dairy_centers ( id, name, code, village, district, owner_id )",
      )
      .eq("operator_id", userId)
      .eq("is_active", true);
    const opCenters = (opRows ?? [])
      .map((r) => (r as unknown as { dairy_centers: Center | null }).dairy_centers)
      .filter((x): x is Center => !!x);
    const merged = [...(owned ?? []), ...opCenters].reduce<Record<string, Center>>((acc, c) => {
      acc[c.id] = c as Center;
      return acc;
    }, {});
    const list = Object.values(merged);
    setCenters(list);

    const perms: Record<string, Permissions> = {};
    for (const c of owned ?? []) perms[c.id] = ALL_PERMISSIONS;
    for (const row of opRows ?? []) {
      const r = row as unknown as { center_id: string; permissions: unknown };
      if (!perms[r.center_id]) perms[r.center_id] = normalizePermissions(r.permissions);
    }
    setPermsByCenter(perms);

    const ownerIds = Array.from(
      new Set(opCenters.filter((c) => c.owner_id !== userId).map((c) => c.owner_id)),
    );
    if (ownerIds.length) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", ownerIds);
      const map: Record<string, string> = {};
      for (const p of profs ?? []) map[p.id] = p.full_name;
      setOwnerNames(map);
    } else {
      setOwnerNames({});
    }

    const stored = typeof window !== "undefined" ? window.localStorage.getItem(STORAGE_KEY) : null;
    if (stored && list.some((c) => c.id === stored)) {
      setSelectedId(stored);
    } else if (list.length === 1) {
      setSelectedId(list[0].id);
      if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, list[0].id);
    } else {
      setSelectedId(null);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const select = useCallback((id: string) => {
    setSelectedId(id);
    if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, id);
  }, []);

  const value = useMemo<CenterContextValue>(() => {
    const selected = centers.find((c) => c.id === selectedId) ?? null;
    const isOwner = !!selected && selected.owner_id === userId;
    const permissions =
      selected && permsByCenter[selected.id]
        ? permsByCenter[selected.id]
        : isOwner
          ? ALL_PERMISSIONS
          : normalizePermissions(null);
    return {
      loading,
      centers,
      selectedId,
      selected,
      select,
      refresh,
      isOwner,
      permissions,
      can: (perm: PermissionKey) => permissions[perm] === true,
      canAny: (perms: PermissionKey[]) => perms.some((p) => permissions[p] === true),
      ownerName: selected && !isOwner ? (ownerNames[selected.owner_id] ?? null) : null,
    };
  }, [loading, centers, selectedId, select, refresh, permsByCenter, ownerNames, userId]);

  return <CenterContext.Provider value={value}>{children}</CenterContext.Provider>;
}

export function useCenter() {
  const ctx = useContext(CenterContext);
  if (!ctx) throw new Error("useCenter must be used inside CenterProvider");
  return ctx;
}
