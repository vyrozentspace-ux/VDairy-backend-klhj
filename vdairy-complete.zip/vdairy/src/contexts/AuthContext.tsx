import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import { phoneToEmail, pinToPassword } from "@/lib/pin-auth";

type Profile = {
  id: string;
  full_name: string;
  phone: string;
  role: "owner" | "operator";
  language_preference: string;
  is_blocked_by_admin: boolean;
};

interface AuthContextValue {
  loading: boolean;
  session: boolean;
  userId: string | null;
  profile: Profile | null;
  loginWithPin: (phone: string, pin: string) => Promise<void>;
  refreshProfile: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);

  const loadProfile = useCallback(async (uid: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("id, full_name, phone, role, language_preference, is_blocked_by_admin")
      .eq("id", uid)
      .maybeSingle();
    setProfile((data as Profile | null) ?? null);
  }, []);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, session) => {
      const uid = session?.user?.id ?? null;
      setUserId(uid);
      if (uid) void loadProfile(uid);
      else setProfile(null);
    });

    void (async () => {
      const { data } = await supabase.auth.getSession();
      const uid = data.session?.user?.id ?? null;
      setUserId(uid);
      if (uid) await loadProfile(uid);
      setLoading(false);
    })();

    return () => sub.subscription.unsubscribe();
  }, [loadProfile]);

  const loginWithPin = useCallback(async (phone: string, pin: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email: phoneToEmail(phone),
      password: pinToPassword(pin),
    });
    if (error) throw new Error("Invalid phone number or PIN");
  }, []);

  const refreshProfile = useCallback(async () => {
    if (userId) await loadProfile(userId);
  }, [userId, loadProfile]);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setUserId(null);
    setProfile(null);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      loading,
      session: !!userId,
      userId,
      profile,
      loginWithPin,
      refreshProfile,
      logout,
    }),
    [loading, userId, profile, loginWithPin, refreshProfile, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
