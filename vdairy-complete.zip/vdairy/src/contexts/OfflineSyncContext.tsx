import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { loadQueue, queueSnapshot, subscribeQueue, type PendingRecord } from "@/lib/offline/queue";
import { flushQueue, isOnline, retryRecord, startSyncEngine } from "@/lib/offline/sync";

interface OfflineSyncValue {
  records: PendingRecord[];
  pendingCount: number;
  failedCount: number;
  online: boolean;
  flush: () => Promise<void>;
  retry: (id: string) => Promise<void>;
}

const OfflineSyncContext = createContext<OfflineSyncValue | null>(null);

export function OfflineSyncProvider({ children }: { children: ReactNode }) {
  const [records, setRecords] = useState<PendingRecord[]>(queueSnapshot);
  const [online, setOnline] = useState(true);

  useEffect(() => {
    const unsub = subscribeQueue(() => setRecords(queueSnapshot()));
    void loadQueue().then(setRecords);
    const stop = startSyncEngine();

    const refreshOnline = () => void isOnline().then(setOnline);
    refreshOnline();
    const timer = window.setInterval(refreshOnline, 5000);
    window.addEventListener("online", refreshOnline);
    window.addEventListener("offline", refreshOnline);

    return () => {
      unsub();
      stop();
      window.clearInterval(timer);
      window.removeEventListener("online", refreshOnline);
      window.removeEventListener("offline", refreshOnline);
    };
  }, []);

  const flush = useCallback(async () => {
    await flushQueue();
  }, []);
  const retry = useCallback(async (id: string) => {
    await retryRecord(id);
  }, []);

  const value = useMemo<OfflineSyncValue>(
    () => ({
      records,
      pendingCount: records.filter((r) => r.status === "pending").length,
      failedCount: records.filter((r) => r.status === "failed").length,
      online,
      flush,
      retry,
    }),
    [records, online, flush, retry],
  );

  return <OfflineSyncContext.Provider value={value}>{children}</OfflineSyncContext.Provider>;
}

export function useOfflineSync() {
  const ctx = useContext(OfflineSyncContext);
  if (!ctx) throw new Error("useOfflineSync must be used inside OfflineSyncProvider");
  return ctx;
}
