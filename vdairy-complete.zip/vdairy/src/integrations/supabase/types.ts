export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          action: string
          center_id: string
          created_at: string
          details: Json
          id: string
          user_id: string | null
        }
        Insert: {
          action: string
          center_id: string
          created_at?: string
          details?: Json
          id?: string
          user_id?: string | null
        }
        Update: {
          action?: string
          center_id?: string
          created_at?: string
          details?: Json
          id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "activity_logs_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_users: {
        Row: {
          created_at: string
          id: string
          note: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          note?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          note?: string | null
          user_id?: string
        }
        Relationships: []
      }
      advance_deductions: {
        Row: {
          advance_id: string
          amount: number
          center_id: string
          comments: string | null
          created_at: string
          deduction_date: string
          entered_by: string | null
          farmer_id: string
          id: string
          source: string
        }
        Insert: {
          advance_id: string
          amount: number
          center_id: string
          comments?: string | null
          created_at?: string
          deduction_date: string
          entered_by?: string | null
          farmer_id: string
          id?: string
          source?: string
        }
        Update: {
          advance_id?: string
          amount?: number
          center_id?: string
          comments?: string | null
          created_at?: string
          deduction_date?: string
          entered_by?: string | null
          farmer_id?: string
          id?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "advance_deductions_advance_id_fkey"
            columns: ["advance_id"]
            isOneToOne: false
            referencedRelation: "advances"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "advance_deductions_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "advance_deductions_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "farmers"
            referencedColumns: ["id"]
          },
        ]
      }
      advances: {
        Row: {
          advance_date: string
          advance_type: string
          amount: number
          center_id: string
          comments: string | null
          created_at: string
          entered_by: string | null
          farmer_id: string
          id: string
          interest_rate: number
          is_paid: boolean
          monthly_installment_amount: number | null
          term_months: number | null
          updated_at: string
        }
        Insert: {
          advance_date: string
          advance_type: string
          amount: number
          center_id: string
          comments?: string | null
          created_at?: string
          entered_by?: string | null
          farmer_id: string
          id?: string
          interest_rate?: number
          is_paid?: boolean
          monthly_installment_amount?: number | null
          term_months?: number | null
          updated_at?: string
        }
        Update: {
          advance_date?: string
          advance_type?: string
          amount?: number
          center_id?: string
          comments?: string | null
          created_at?: string
          entered_by?: string | null
          farmer_id?: string
          id?: string
          interest_rate?: number
          is_paid?: boolean
          monthly_installment_amount?: number | null
          term_months?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "advances_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "advances_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "farmers"
            referencedColumns: ["id"]
          },
        ]
      }
      app_notifications: {
        Row: {
          body: string
          center_id: string | null
          created_at: string
          dedupe_key: string | null
          id: string
          kind: string
          read_at: string | null
          title: string
          user_id: string
        }
        Insert: {
          body: string
          center_id?: string | null
          created_at?: string
          dedupe_key?: string | null
          id?: string
          kind?: string
          read_at?: string | null
          title: string
          user_id: string
        }
        Update: {
          body?: string
          center_id?: string | null
          created_at?: string
          dedupe_key?: string | null
          id?: string
          kind?: string
          read_at?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "app_notifications_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      app_settings: {
        Row: {
          created_at: string
          description: string | null
          key: string
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          key: string
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          description?: string | null
          key?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      center_collection_settings: {
        Row: {
          calculation_mode: string
          center_id: string
          created_at: string
          default_buffalo_rate: number | null
          default_cow_rate: number | null
          default_milk_sale_rate: number | null
          evening_end_time: string | null
          evening_start_time: string | null
          id: string
          morning_end_time: string | null
          morning_start_time: string | null
          payment_period: string
          payment_period_start_date: string | null
          updated_at: string
        }
        Insert: {
          calculation_mode?: string
          center_id: string
          created_at?: string
          default_buffalo_rate?: number | null
          default_cow_rate?: number | null
          default_milk_sale_rate?: number | null
          evening_end_time?: string | null
          evening_start_time?: string | null
          id?: string
          morning_end_time?: string | null
          morning_start_time?: string | null
          payment_period?: string
          payment_period_start_date?: string | null
          updated_at?: string
        }
        Update: {
          calculation_mode?: string
          center_id?: string
          created_at?: string
          default_buffalo_rate?: number | null
          default_cow_rate?: number | null
          default_milk_sale_rate?: number | null
          evening_end_time?: string | null
          evening_start_time?: string | null
          id?: string
          morning_end_time?: string | null
          morning_start_time?: string | null
          payment_period?: string
          payment_period_start_date?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "center_collection_settings_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: true
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      center_operators: {
        Row: {
          center_id: string
          created_at: string
          id: string
          is_active: boolean
          operator_id: string
          permissions: Json
        }
        Insert: {
          center_id: string
          created_at?: string
          id?: string
          is_active?: boolean
          operator_id: string
          permissions?: Json
        }
        Update: {
          center_id?: string
          created_at?: string
          id?: string
          is_active?: boolean
          operator_id?: string
          permissions?: Json
        }
        Relationships: [
          {
            foreignKeyName: "center_operators_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      center_subscriptions: {
        Row: {
          billing_cycle: string | null
          center_id: string
          created_at: string
          current_period_end: string | null
          deactivated_at: string | null
          id: string
          last_upgrade_reminder_at: string | null
          plan: string | null
          referral_bonus_days: number
          status: string
          trial_ends_at: string
          trial_started_at: string
          updated_at: string
        }
        Insert: {
          billing_cycle?: string | null
          center_id: string
          created_at?: string
          current_period_end?: string | null
          deactivated_at?: string | null
          id?: string
          last_upgrade_reminder_at?: string | null
          plan?: string | null
          referral_bonus_days?: number
          status?: string
          trial_ends_at?: string
          trial_started_at?: string
          updated_at?: string
        }
        Update: {
          billing_cycle?: string | null
          center_id?: string
          created_at?: string
          current_period_end?: string | null
          deactivated_at?: string | null
          id?: string
          last_upgrade_reminder_at?: string | null
          plan?: string | null
          referral_bonus_days?: number
          status?: string
          trial_ends_at?: string
          trial_started_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "center_subscriptions_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: true
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      collections: {
        Row: {
          center_id: string
          collection_date: string
          created_at: string
          created_by: string | null
          farmer_id: string
          fat: number
          id: string
          milk_type: string
          quantity_liters: number
          rate_per_liter: number
          shift: string
          snf: number | null
          total_amount: number
          updated_at: string
        }
        Insert: {
          center_id: string
          collection_date: string
          created_at?: string
          created_by?: string | null
          farmer_id: string
          fat: number
          id?: string
          milk_type: string
          quantity_liters: number
          rate_per_liter: number
          shift: string
          snf?: number | null
          total_amount: number
          updated_at?: string
        }
        Update: {
          center_id?: string
          collection_date?: string
          created_at?: string
          created_by?: string | null
          farmer_id?: string
          fat?: number
          id?: string
          milk_type?: string
          quantity_liters?: number
          rate_per_liter?: number
          shift?: string
          snf?: number | null
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "collections_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "collections_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "farmers"
            referencedColumns: ["id"]
          },
        ]
      }
      content_slots: {
        Row: {
          body: string | null
          content_type: string
          created_at: string
          display_order: number
          icon: string | null
          id: string
          is_active: boolean
          slot_key: string
          title: string | null
          updated_at: string
          url: string | null
        }
        Insert: {
          body?: string | null
          content_type?: string
          created_at?: string
          display_order?: number
          icon?: string | null
          id?: string
          is_active?: boolean
          slot_key: string
          title?: string | null
          updated_at?: string
          url?: string | null
        }
        Update: {
          body?: string | null
          content_type?: string
          created_at?: string
          display_order?: number
          icon?: string | null
          id?: string
          is_active?: boolean
          slot_key?: string
          title?: string | null
          updated_at?: string
          url?: string | null
        }
        Relationships: []
      }
      dairy_centers: {
        Row: {
          bank_account_number: string | null
          bank_branch_name: string | null
          bank_ifsc_code: string | null
          code: string
          contact_number: string | null
          created_at: string
          default_language: string
          district: string | null
          id: string
          name: string
          operator_subscription_notifications: boolean
          owner_id: string
          pincode: string | null
          referral_code: string | null
          referred_by_code: string | null
          state: string | null
          taluka: string | null
          updated_at: string
          village: string | null
        }
        Insert: {
          bank_account_number?: string | null
          bank_branch_name?: string | null
          bank_ifsc_code?: string | null
          code: string
          contact_number?: string | null
          created_at?: string
          default_language?: string
          district?: string | null
          id?: string
          name: string
          operator_subscription_notifications?: boolean
          owner_id: string
          pincode?: string | null
          referral_code?: string | null
          referred_by_code?: string | null
          state?: string | null
          taluka?: string | null
          updated_at?: string
          village?: string | null
        }
        Update: {
          bank_account_number?: string | null
          bank_branch_name?: string | null
          bank_ifsc_code?: string | null
          code?: string
          contact_number?: string | null
          created_at?: string
          default_language?: string
          district?: string | null
          id?: string
          name?: string
          operator_subscription_notifications?: boolean
          owner_id?: string
          pincode?: string | null
          referral_code?: string | null
          referred_by_code?: string | null
          state?: string | null
          taluka?: string | null
          updated_at?: string
          village?: string | null
        }
        Relationships: []
      }
      dairy_expenses: {
        Row: {
          amount: number
          category_id: string
          center_id: string
          created_at: string
          created_by: string | null
          custom_category_label: string | null
          expense_date: string
          id: string
          note: string | null
          payment_mode: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          category_id: string
          center_id: string
          created_at?: string
          created_by?: string | null
          custom_category_label?: string | null
          expense_date: string
          id?: string
          note?: string | null
          payment_mode?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          category_id?: string
          center_id?: string
          created_at?: string
          created_by?: string | null
          custom_category_label?: string | null
          expense_date?: string
          id?: string
          note?: string | null
          payment_mode?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "dairy_expenses_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "expense_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dairy_expenses_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      expense_categories: {
        Row: {
          center_id: string | null
          created_at: string
          id: string
          is_default: boolean
          name: string
        }
        Insert: {
          center_id?: string | null
          created_at?: string
          id?: string
          is_default?: boolean
          name: string
        }
        Update: {
          center_id?: string | null
          created_at?: string
          id?: string
          is_default?: boolean
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "expense_categories_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      farmer_feed_sales: {
        Row: {
          amount: number
          cash_payment: boolean
          center_id: string
          created_at: string
          entered_by: string | null
          farmer_id: string
          feed_product_id: string
          id: string
          invoice_id: string | null
          is_settled: boolean
          quantity: number
          rate: number
          receipt_no: string | null
          sale_date: string
        }
        Insert: {
          amount: number
          cash_payment?: boolean
          center_id: string
          created_at?: string
          entered_by?: string | null
          farmer_id: string
          feed_product_id: string
          id?: string
          invoice_id?: string | null
          is_settled?: boolean
          quantity: number
          rate: number
          receipt_no?: string | null
          sale_date: string
        }
        Update: {
          amount?: number
          cash_payment?: boolean
          center_id?: string
          created_at?: string
          entered_by?: string | null
          farmer_id?: string
          feed_product_id?: string
          id?: string
          invoice_id?: string | null
          is_settled?: boolean
          quantity?: number
          rate?: number
          receipt_no?: string | null
          sale_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "farmer_feed_sales_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "farmer_feed_sales_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "farmers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "farmer_feed_sales_feed_product_id_fkey"
            columns: ["feed_product_id"]
            isOneToOne: false
            referencedRelation: "feed_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "farmer_feed_sales_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
        ]
      }
      farmers: {
        Row: {
          address: string | null
          center_id: string
          code: string
          created_at: string
          created_by: string | null
          email: string | null
          first_name: string
          id: string
          is_active: boolean
          last_name: string | null
          milk_type: string
          mobile: string | null
          name_english: string | null
          payment_mobile: string | null
          updated_at: string
          village: string | null
        }
        Insert: {
          address?: string | null
          center_id: string
          code: string
          created_at?: string
          created_by?: string | null
          email?: string | null
          first_name: string
          id?: string
          is_active?: boolean
          last_name?: string | null
          milk_type?: string
          mobile?: string | null
          name_english?: string | null
          payment_mobile?: string | null
          updated_at?: string
          village?: string | null
        }
        Update: {
          address?: string | null
          center_id?: string
          code?: string
          created_at?: string
          created_by?: string | null
          email?: string | null
          first_name?: string
          id?: string
          is_active?: boolean
          last_name?: string | null
          milk_type?: string
          mobile?: string | null
          name_english?: string | null
          payment_mobile?: string | null
          updated_at?: string
          village?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "farmers_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      feed_dealer_payments: {
        Row: {
          amount: number
          center_id: string
          comments: string | null
          created_at: string
          dealer_id: string
          entered_by: string | null
          id: string
          payment_date: string
        }
        Insert: {
          amount: number
          center_id: string
          comments?: string | null
          created_at?: string
          dealer_id: string
          entered_by?: string | null
          id?: string
          payment_date: string
        }
        Update: {
          amount?: number
          center_id?: string
          comments?: string | null
          created_at?: string
          dealer_id?: string
          entered_by?: string | null
          id?: string
          payment_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "feed_dealer_payments_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "feed_dealer_payments_dealer_id_fkey"
            columns: ["dealer_id"]
            isOneToOne: false
            referencedRelation: "feed_dealers"
            referencedColumns: ["id"]
          },
        ]
      }
      feed_dealers: {
        Row: {
          address: string | null
          center_id: string
          created_at: string
          dealer_name: string
          id: string
          is_active: boolean
          mobile: string | null
        }
        Insert: {
          address?: string | null
          center_id: string
          created_at?: string
          dealer_name: string
          id?: string
          is_active?: boolean
          mobile?: string | null
        }
        Update: {
          address?: string | null
          center_id?: string
          created_at?: string
          dealer_name?: string
          id?: string
          is_active?: boolean
          mobile?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "feed_dealers_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      feed_products: {
        Row: {
          center_id: string
          created_at: string
          default_rate: number | null
          id: string
          is_active: boolean
          product_name: string
          unit: string
        }
        Insert: {
          center_id: string
          created_at?: string
          default_rate?: number | null
          id?: string
          is_active?: boolean
          product_name: string
          unit: string
        }
        Update: {
          center_id?: string
          created_at?: string
          default_rate?: number | null
          id?: string
          is_active?: boolean
          product_name?: string
          unit?: string
        }
        Relationships: [
          {
            foreignKeyName: "feed_products_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      feed_stock_purchases: {
        Row: {
          amount: number
          center_id: string
          created_at: string
          dealer_id: string | null
          entered_by: string | null
          feed_product_id: string
          id: string
          invoice_id: string | null
          is_settled: boolean
          purchase_date: string
          quantity: number
          rate: number
          receipt_no: string | null
        }
        Insert: {
          amount: number
          center_id: string
          created_at?: string
          dealer_id?: string | null
          entered_by?: string | null
          feed_product_id: string
          id?: string
          invoice_id?: string | null
          is_settled?: boolean
          purchase_date: string
          quantity: number
          rate: number
          receipt_no?: string | null
        }
        Update: {
          amount?: number
          center_id?: string
          created_at?: string
          dealer_id?: string | null
          entered_by?: string | null
          feed_product_id?: string
          id?: string
          invoice_id?: string | null
          is_settled?: boolean
          purchase_date?: string
          quantity?: number
          rate?: number
          receipt_no?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "feed_stock_purchases_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "feed_stock_purchases_dealer_id_fkey"
            columns: ["dealer_id"]
            isOneToOne: false
            referencedRelation: "feed_dealers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "feed_stock_purchases_feed_product_id_fkey"
            columns: ["feed_product_id"]
            isOneToOne: false
            referencedRelation: "feed_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "feed_stock_purchases_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_deductions: {
        Row: {
          balance_after: number
          created_at: string
          deduction_amount: number
          deduction_type: string
          deposit: number
          id: string
          invoice_id: string
        }
        Insert: {
          balance_after?: number
          created_at?: string
          deduction_amount?: number
          deduction_type: string
          deposit?: number
          id?: string
          invoice_id: string
        }
        Update: {
          balance_after?: number
          created_at?: string
          deduction_amount?: number
          deduction_type?: string
          deposit?: number
          id?: string
          invoice_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoice_deductions_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_payments: {
        Row: {
          amount: number
          created_at: string
          farmer_id: string
          id: string
          initiated_by: string | null
          invoice_id: string
          payment_number_used: string | null
          status: string
          upi_uri: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          farmer_id: string
          id?: string
          initiated_by?: string | null
          invoice_id: string
          payment_number_used?: string | null
          status?: string
          upi_uri?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          farmer_id?: string
          id?: string
          initiated_by?: string | null
          invoice_id?: string
          payment_number_used?: string | null
          status?: string
          upi_uri?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoice_payments_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "farmers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_payments_initiated_by_fkey"
            columns: ["initiated_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_payments_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          amount_due: number
          center_id: string
          created_at: string
          created_by: string | null
          farmer_id: string
          id: string
          invoice_number: number
          new_balance: number
          paid_at: string | null
          period_end: string
          period_start: string
          previous_balance: number
          status: string
          total_advance_given: number
          total_deduction: number
          total_feed_amount: number
          total_liter: number
          total_milk_amount: number
          updated_at: string
        }
        Insert: {
          amount_due?: number
          center_id: string
          created_at?: string
          created_by?: string | null
          farmer_id: string
          id?: string
          invoice_number: number
          new_balance?: number
          paid_at?: string | null
          period_end: string
          period_start: string
          previous_balance?: number
          status?: string
          total_advance_given?: number
          total_deduction?: number
          total_feed_amount?: number
          total_liter?: number
          total_milk_amount?: number
          updated_at?: string
        }
        Update: {
          amount_due?: number
          center_id?: string
          created_at?: string
          created_by?: string | null
          farmer_id?: string
          id?: string
          invoice_number?: number
          new_balance?: number
          paid_at?: string | null
          period_end?: string
          period_start?: string
          previous_balance?: number
          status?: string
          total_advance_given?: number
          total_deduction?: number
          total_feed_amount?: number
          total_liter?: number
          total_milk_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "farmers"
            referencedColumns: ["id"]
          },
        ]
      }
      milk_sale_customers: {
        Row: {
          address: string | null
          center_id: string
          created_at: string
          id: string
          mobile: string | null
          name: string
          updated_at: string
        }
        Insert: {
          address?: string | null
          center_id: string
          created_at?: string
          id?: string
          mobile?: string | null
          name: string
          updated_at?: string
        }
        Update: {
          address?: string | null
          center_id?: string
          created_at?: string
          id?: string
          mobile?: string | null
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "milk_sale_customers_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      milk_sales: {
        Row: {
          center_id: string
          created_at: string
          created_by: string | null
          customer_id: string | null
          id: string
          payment_mode: string | null
          payment_status: string
          quantity_liters: number
          rate_per_liter: number
          sale_date: string
          session: string
          total_amount: number
          updated_at: string
          walk_in_mobile: string | null
          walk_in_name: string | null
        }
        Insert: {
          center_id: string
          created_at?: string
          created_by?: string | null
          customer_id?: string | null
          id?: string
          payment_mode?: string | null
          payment_status?: string
          quantity_liters: number
          rate_per_liter: number
          sale_date: string
          session: string
          total_amount: number
          updated_at?: string
          walk_in_mobile?: string | null
          walk_in_name?: string | null
        }
        Update: {
          center_id?: string
          created_at?: string
          created_by?: string | null
          customer_id?: string | null
          id?: string
          payment_mode?: string | null
          payment_status?: string
          quantity_liters?: number
          rate_per_liter?: number
          sale_date?: string
          session?: string
          total_amount?: number
          updated_at?: string
          walk_in_mobile?: string | null
          walk_in_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "milk_sales_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "milk_sales_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "milk_sale_customers"
            referencedColumns: ["id"]
          },
        ]
      }
      notices: {
        Row: {
          center_id: string
          created_at: string
          id: string
          is_active: boolean
          language: string
          message: string
          posted_by: string | null
          title: string
          updated_at: string
        }
        Insert: {
          center_id: string
          created_at?: string
          id?: string
          is_active?: boolean
          language?: string
          message: string
          posted_by?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          center_id?: string
          created_at?: string
          id?: string
          is_active?: boolean
          language?: string
          message?: string
          posted_by?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "notices_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          full_name: string
          id: string
          is_blocked_by_admin: boolean
          language_preference: string
          phone: string
          referral_code: string | null
          referred_by_code: string | null
          role: string
          security_answer_1_hash: string | null
          security_answer_2_hash: string | null
          security_question_1: string | null
          security_question_2: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          full_name: string
          id: string
          is_blocked_by_admin?: boolean
          language_preference?: string
          phone: string
          referral_code?: string | null
          referred_by_code?: string | null
          role?: string
          security_answer_1_hash?: string | null
          security_answer_2_hash?: string | null
          security_question_1?: string | null
          security_question_2?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          is_blocked_by_admin?: boolean
          language_preference?: string
          phone?: string
          referral_code?: string | null
          referred_by_code?: string | null
          role?: string
          security_answer_1_hash?: string | null
          security_answer_2_hash?: string | null
          security_question_1?: string | null
          security_question_2?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      rate_chart_rows: {
        Row: {
          created_at: string
          fat_value: number
          id: string
          rate: number
          rate_chart_id: string
          snf_value: number
        }
        Insert: {
          created_at?: string
          fat_value: number
          id?: string
          rate: number
          rate_chart_id: string
          snf_value: number
        }
        Update: {
          created_at?: string
          fat_value?: number
          id?: string
          rate?: number
          rate_chart_id?: string
          snf_value?: number
        }
        Relationships: [
          {
            foreignKeyName: "rate_chart_rows_rate_chart_id_fkey"
            columns: ["rate_chart_id"]
            isOneToOne: false
            referencedRelation: "rate_charts"
            referencedColumns: ["id"]
          },
        ]
      }
      rate_charts: {
        Row: {
          base_rate: number | null
          center_id: string
          chart_name: string
          created_at: string
          fat_max: number
          fat_min: number
          fat_step: number
          id: string
          is_active: boolean
          milk_type: string
          snf_max: number
          snf_min: number
          snf_step: number
          updated_at: string
        }
        Insert: {
          base_rate?: number | null
          center_id: string
          chart_name: string
          created_at?: string
          fat_max?: number
          fat_min?: number
          fat_step?: number
          id?: string
          is_active?: boolean
          milk_type: string
          snf_max?: number
          snf_min?: number
          snf_step?: number
          updated_at?: string
        }
        Update: {
          base_rate?: number | null
          center_id?: string
          chart_name?: string
          created_at?: string
          fat_max?: number
          fat_min?: number
          fat_step?: number
          id?: string
          is_active?: boolean
          milk_type?: string
          snf_max?: number
          snf_min?: number
          snf_step?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "rate_charts_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      referral_credits: {
        Row: {
          bonus_days: number
          created_at: string
          id: string
          payment_id: string
          referred_center_id: string
          referrer_center_id: string
        }
        Insert: {
          bonus_days: number
          created_at?: string
          id?: string
          payment_id: string
          referred_center_id: string
          referrer_center_id: string
        }
        Update: {
          bonus_days?: number
          created_at?: string
          id?: string
          payment_id?: string
          referred_center_id?: string
          referrer_center_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "referral_credits_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: true
            referencedRelation: "subscription_payments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referral_credits_referred_center_id_fkey"
            columns: ["referred_center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referral_credits_referrer_center_id_fkey"
            columns: ["referrer_center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      social_links: {
        Row: {
          created_at: string
          display_order: number
          id: string
          is_active: boolean
          label: string | null
          platform: string
          updated_at: string
          url: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          label?: string | null
          platform: string
          updated_at?: string
          url?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          label?: string | null
          platform?: string
          updated_at?: string
          url?: string
        }
        Relationships: []
      }
      subscription_payments: {
        Row: {
          amount: number
          billing_cycle: string
          center_id: string
          created_at: string
          created_by: string | null
          id: string
          paid_at: string | null
          plan_code: string
          reference: string | null
          status: string
          updated_at: string
          upi_uri: string | null
        }
        Insert: {
          amount: number
          billing_cycle?: string
          center_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          paid_at?: string | null
          plan_code: string
          reference?: string | null
          status?: string
          updated_at?: string
          upi_uri?: string | null
        }
        Update: {
          amount?: number
          billing_cycle?: string
          center_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          paid_at?: string | null
          plan_code?: string
          reference?: string | null
          status?: string
          updated_at?: string
          upi_uri?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscription_payments_center_id_fkey"
            columns: ["center_id"]
            isOneToOne: false
            referencedRelation: "dairy_centers"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          code: string
          created_at: string
          features: Json
          id: string
          is_active: boolean
          max_farmers: number | null
          name: string
          price_monthly: number
          price_yearly: number
          sort_order: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          features?: Json
          id?: string
          is_active?: boolean
          max_farmers?: number | null
          name: string
          price_monthly?: number
          price_yearly?: number
          sort_order?: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          features?: Json
          id?: string
          is_active?: boolean
          max_farmers?: number | null
          name?: string
          price_monthly?: number
          price_yearly?: number
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      user_notification_prefs: {
        Row: {
          app_updates: boolean
          collection_reminders: boolean
          created_at: string
          customer_alerts: boolean
          marketing: boolean
          payment_reminders: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          app_updates?: boolean
          collection_reminders?: boolean
          created_at?: string
          customer_alerts?: boolean
          marketing?: boolean
          payment_reminders?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          app_updates?: boolean
          collection_reminders?: boolean
          created_at?: string
          customer_alerts?: boolean
          marketing?: boolean
          payment_reminders?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_set_profile_blocked: {
        Args: { _blocked: boolean; _user_id: string }
        Returns: undefined
      }
      admin_set_profile_role: {
        Args: { _role: string; _user_id: string }
        Returns: undefined
      }
      advance_total_repayable: {
        Args: { p_advance_id: string }
        Returns: number
      }
      apply_installment_deductions:
        | {
            Args: { p_center_id: string; p_deduction_date: string }
            Returns: number
          }
        | {
            Args: {
              p_center_id: string
              p_created_by: string
              p_farmer_id: string
              p_period_end: string
              p_period_start: string
            }
            Returns: undefined
          }
      auth_user_id_by_email: { Args: { _email: string }; Returns: string }
      can_access_center: {
        Args: { _center_id: string; _user_id: string }
        Returns: boolean
      }
      center_periods_per_month: {
        Args: { p_center_id: string }
        Returns: number
      }
      confirm_invoice_payment: {
        Args: { p_invoice_payment_id: string }
        Returns: undefined
      }
      confirm_subscription_payment: {
        Args: { p_payment_id: string }
        Returns: undefined
      }
      create_profile_for_user: {
        Args: {
          _a1: string
          _a2: string
          _full_name: string
          _language: string
          _phone: string
          _q1: string
          _q2: string
          _referred_by_code: string
          _role: string
          _user_id: string
        }
        Returns: undefined
      }
      dealer_balance: { Args: { p_dealer_id: string }; Returns: number }
      farmer_advance_balance: { Args: { p_farmer_id: string }; Returns: number }
      farmer_last_invoice_balance: {
        Args: { p_farmer_id: string }
        Returns: number
      }
      feed_stock_on_hand: {
        Args: { p_feed_product_id: string }
        Returns: number
      }
      generate_invoice: {
        Args: {
          p_center_id: string
          p_created_by: string
          p_farmer_id: string
          p_period_end: string
          p_period_start: string
        }
        Returns: string
      }
      get_security_questions_by_phone: {
        Args: { _phone: string }
        Returns: {
          question_1: string
          question_2: string
        }[]
      }
      has_any_center_permission: {
        Args: { _center_id: string; _perms: string[]; _user_id: string }
        Returns: boolean
      }
      has_center_permission: {
        Args: { _center_id: string; _perm: string; _user_id: string }
        Returns: boolean
      }
      is_platform_admin: { Args: { _user_id?: string }; Returns: boolean }
      mark_invoice_paid: { Args: { p_invoice_id: string }; Returns: undefined }
      mark_invoice_unpaid: {
        Args: { p_invoice_id: string }
        Returns: undefined
      }
      pending_installment_for_period: {
        Args: {
          p_center_id: string
          p_farmer_id: string
          p_period_end: string
          p_period_start: string
        }
        Returns: number
      }
      profile_privileged_unchanged: {
        Args: { _blocked: boolean; _id: string; _role: string }
        Returns: boolean
      }
      referral_stats: {
        Args: { p_center_id: string }
        Returns: {
          bonus_days: number
          referral_code: string
          referred_count: number
          trial_ends_at: string
        }[]
      }
      refresh_advance_settlement: {
        Args: { p_advance_id: string }
        Returns: undefined
      }
      refresh_center_subscription_status: {
        Args: { p_center_id: string }
        Returns: {
          deactivate_at: string
          period_end: string
          plan_code: string
          sub_status: string
          trial_ends: string
        }[]
      }
      shares_center_with: { Args: { _a: string; _b: string }; Returns: boolean }
      verify_security_answers: {
        Args: { _a1: string; _a2: string; _phone: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
