import type { CapacitorConfig } from "@capacitor/cli";

/**
 * VDairy Android wrapper configuration.
 *
 * The web app is a TanStack Start (SSR) build, so `dist/client` holds the
 * static assets only. For a Play Store build the shell loads the hosted
 * deployment; point `server.url` at the published site before running
 * `npx cap sync android`.
 */
const config: CapacitorConfig = {
  appId: "app.vdairy.mobile",
  appName: "VDairy",
  webDir: "capacitor-shell",
  android: {
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
    // url: "https://<your-published-domain>",
    cleartext: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      backgroundColor: "#0F766E",
      androidScaleType: "CENTER_CROP",
      showSpinner: false,
    },
    LocalNotifications: {
      smallIcon: "ic_stat_icon_config_sample",
      iconColor: "#0F766E",
    },
  },
};

export default config;
