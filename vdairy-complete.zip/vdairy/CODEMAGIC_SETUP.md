# Codemagic से APK Build करने के लिए गाइड

## Step 1: GitHub में Project Push करें

```bash
# अगर पहले से git initialize नहीं है
git init
git add .
git commit -m "Add Codemagic configuration"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vdairy.git
git push -u origin main
```

## Step 2: Codemagic Account Setup

1. [Codemagic.io](https://codemagic.io) पर जाएं
2. GitHub account से sign up करें
3. अपने GitHub account को authorize करें

## Step 3: Project को Codemagic में Connect करें

1. Codemagic dashboard में "Add application" करें
2. अपना GitHub repository select करें (`vdairy`)
3. Configure करने के लिए कहेगा - आप यह files already add कर चुके हैं

## Step 4: Android Signing Setup (महत्वपूर्ण!)

### Release Keystore बनाएं:

```bash
keytool -genkey -v -keystore ~/vdairy.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias vdairy_key
```

### Keystore को Base64 में convert करें:
```bash
base64 ~/vdairy.keystore
```

### Codemagic में Add करें:
1. Project Settings → Code signing → Android
2. "Upload keystore" पर क्लिक करें
3. Keystore file upload करें
4. Keystore password और key alias दोनों भरें

## Step 5: Environment Variables सेट करें (अगर जरूरत हो)

Project Settings → Environment Variables में add करें:
- `KEYSTORE_PASSWORD`: आपका keystore password
- `KEY_ALIAS`: keystore का alias (example: vdairy_key)
- `KEY_PASSWORD`: key का password

## Step 6: APK Build शुरू करें

1. Codemagic dashboard में अपना project खोलें
2. "Start new build" करें
3. Build complete होने के बाद artifacts download करें

---

## अगर Manual Build करना चाहें:

```bash
# Local machine पर
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleRelease

# APK यहाँ मिलेगा:
# android/app/build/outputs/apk/release/app-release-unsigned.apk
```

## Troubleshooting:

### "Could not find gradle wrapper"
```bash
cd android
./gradlew wrapper --gradle-version 7.5
```

### Dependencies issue
```bash
npm install
cd android
./gradlew clean
./gradlew assembleRelease
```

### Capacitor sync issue
```bash
npm install -g @capacitor/cli
npx cap sync android
```

---

## Advanced: Signed APK के लिए

अगर keystore properly setup हो, तो `codemagic.yaml` में यह add करें:

```yaml
scripts:
  - name: Sign APK
    script: |
      jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
        -keystore $CODEMAGIC_BUILD_DIR/vdairy.keystore \
        -storepass $KEYSTORE_PASSWORD \
        -keypass $KEY_PASSWORD \
        android/app/build/outputs/apk/release/app-release-unsigned.apk \
        $KEY_ALIAS
```

## Success! 🎉

APK successfully build हो जाएगा! Download करके अपने Android device पर install कर सकते हो।
