# VDairy

A mobile-first dairy collection management app: farmer records, milk collection,
rate charts, advances, feed sales, invoices and SMS receipts.

Supported languages: English, Hindi, Marathi, Tamil and Telugu — across the app UI,
the Settings language picker and the Receipt Language picker.

This project was built with [Lovable](https://lovable.dev).


## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/10eb72cb-9bfe-4bfe-ab30-92e792faa148).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Demo data (for ad / screenshot recording)

There's a ready-made script that fills one dairy center with realistic-looking
data: 10 farmers, ~20 days of morning + evening milk collection, rate charts,
advances with deductions, a feed dealer with stock + payments + farmer feed
sales, walk-in milk-sale customers, and — importantly — generated **bills
(invoices)** with a realistic mix of Paid and Unpaid status, so the bill
collection screens look populated.

1. Get your Supabase project's URL and **service role key** (Project Settings → API in the Supabase dashboard).
2. Run:

   ```sh
   SUPABASE_URL="https://xxxx.supabase.co" \
   SUPABASE_SERVICE_ROLE_KEY="your-service-role-key" \
   bun scripts/seed-demo.ts
   ```

   (Needs [Bun](https://bun.sh) installed — `npm i -g bun` if you don't have it. `npx tsx scripts/seed-demo.ts` also works if you'd rather not install Bun, as long as the same env vars are set.)

3. Log in to the app with:
   - **Owner:** phone `9820000001`, PIN `1234`
   - **Operator:** phone `9820000002`, PIN `1234`

The script is safe to re-run — farmers, settings, and rate charts won't be
duplicated. If you want a completely fresh look, delete the "Shivpur Dairy
Collection Center" (code `SHIVPUR01`) from Supabase first, then re-run.

There's also the original `scripts/seed-qa.ts`, which seeds two smaller
centers with minimal QA data (no bills) — useful for functional testing
rather than demos.
