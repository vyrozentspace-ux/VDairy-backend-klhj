/**
 * QA seed script (dev only). Run with:  bun scripts/seed-qa.ts
 * Idempotent: re-running refreshes the same QA owner/operator/centres.
 */
import { createClient } from "@supabase/supabase-js";

const url = process.env.SUPABASE_URL!;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const admin = createClient(url, key, {
  auth: { persistSession: false, autoRefreshToken: false },
  global: {
    fetch: (input: any, init: any = {}) => {
      const headers = new Headers(init.headers);
      if (headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
      headers.set("apikey", key);
      return fetch(input, { ...init, headers });
    },
  },
});

const email = (phone: string) => `${phone}@vdairy.app`;
const pw = (pin: string) => `${pin}-vdairy`;

async function ensureUser(opts: {
  phone: string;
  pin: string;
  full_name: string;
  role: string;
  a1: string;
  a2: string;
}) {
  const meta = {
    full_name: opts.full_name,
    phone: opts.phone,
    role: opts.role,
    language_preference: "en",
    security_question_1: "What is your favourite colour?",
    security_answer_1: opts.a1,
    security_question_2: "Which city were you born in?",
    security_answer_2: opts.a2,
  };
  const { data: list } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
  const existing = list?.users.find((u) => u.email === email(opts.phone));
  let id: string;
  if (existing) {
    id = existing.id;
    await admin.auth.admin.updateUserById(id, {
      password: pw(opts.pin),
      email_confirm: true,
      user_metadata: meta,
    });
  } else {
    const { data, error } = await admin.auth.admin.createUser({
      email: email(opts.phone),
      password: pw(opts.pin),
      email_confirm: true,
      user_metadata: meta,
    });
    if (error) throw error;
    id = data.user!.id;
  }
  const { error: pErr } = await admin.rpc("create_profile_for_user", {
    _user_id: id,
    _full_name: opts.full_name,
    _phone: opts.phone,
    _role: opts.role,
    _language: "en",
    _q1: meta.security_question_1,
    _a1: opts.a1,
    _q2: meta.security_question_2,
    _a2: opts.a2,
    _referred_by_code: "",
  });
  if (pErr) throw pErr;
  return id;
}

async function upsertCenter(ownerId: string, name: string, code: string) {
  const { data: found } = await admin
    .from("dairy_centers")
    .select("id")
    .eq("code", code)
    .maybeSingle();
  if (found) return found.id as string;
  const { data, error } = await admin
    .from("dairy_centers")
    .insert({
      owner_id: ownerId,
      name,
      code,
      village: "Testwadi",
      taluka: "Test Taluka",
      district: "Pune",
      state: "Maharashtra",
      pincode: "411001",
      contact_number: "9000000001",
      referral_code: code.slice(0, 8).toUpperCase(),
      default_language: "en",
    })
    .select("id")
    .single();
  if (error) throw error;
  return data.id as string;
}

const ALL_PERMS = {
  collection: true,
  collection_history: true,
  farmer: true,
  food: true,
  advance: true,
  invoice: true,
  invoice_view_only: true,
  milk_sale: true,
  dairy_expense: true,
  rate_chart: true,
  reports: true,
  center_settings: false,
  manage_operators: false,
  send_messages: true,
};

const iso = (d: Date) => d.toISOString().slice(0, 10);
const daysAgo = (n: number) => iso(new Date(Date.now() - n * 86_400_000));

async function seedCenterData(centerId: string, ownerId: string, tag: string) {
  // settings + subscription
  const { data: cs } = await admin
    .from("center_collection_settings")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  if (!cs) {
    await admin.from("center_collection_settings").insert({
      center_id: centerId,
      calculation_mode: "rate_chart",
      payment_period: "01-10, 11-20, 21-ME",
      payment_period_start_date: daysAgo(30),
      morning_start_time: "05:00",
      morning_end_time: "10:00",
      evening_start_time: "16:00",
      evening_end_time: "20:00",
      default_cow_rate: 34,
      default_buffalo_rate: 58,
      default_milk_sale_rate: 60,
    });
  }
  const { data: sub } = await admin
    .from("center_subscriptions")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  if (!sub) await admin.from("center_subscriptions").insert({ center_id: centerId });

  // rate chart (active)
  const { data: rc0 } = await admin
    .from("rate_charts")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  let chartId = rc0?.id as string | undefined;
  if (!chartId) {
    const { data: rc, error } = await admin
      .from("rate_charts")
      .insert({
        center_id: centerId,
        milk_type: "cow",
        chart_name: `${tag} Cow Chart`,
        is_active: true,
        base_rate: 34,
        fat_min: 3,
        fat_max: 5,
        fat_step: 0.5,
        snf_min: 8,
        snf_max: 9,
        snf_step: 0.5,
      })
      .select("id")
      .single();
    if (error) throw error;
    chartId = rc.id as string;
    const rows: any[] = [];
    for (let fat = 3; fat <= 5.001; fat += 0.5) {
      for (let snf = 8; snf <= 9.001; snf += 0.5) {
        rows.push({
          rate_chart_id: chartId,
          fat_value: Number(fat.toFixed(1)),
          snf_value: Number(snf.toFixed(1)),
          rate: Number((fat * 6 + snf * 1.5).toFixed(2)),
        });
      }
    }
    await admin.from("rate_chart_rows").insert(rows);
  }

  // farmers
  const farmerDefs = [
    { code: "1", first_name: "Ramesh", last_name: "Patil", milk_type: "cow" },
    { code: "2", first_name: "Sunita", last_name: "Jadhav", milk_type: "buffalo" },
    { code: "3", first_name: "Anil", last_name: "Deshmukh", milk_type: "cow" },
  ];
  const farmerIds: string[] = [];
  for (const f of farmerDefs) {
    const { data: ex } = await admin
      .from("farmers")
      .select("id")
      .eq("center_id", centerId)
      .eq("code", f.code)
      .maybeSingle();
    if (ex) {
      farmerIds.push(ex.id as string);
      continue;
    }
    const { data, error } = await admin
      .from("farmers")
      .insert({
        center_id: centerId,
        code: f.code,
        first_name: f.first_name,
        last_name: f.last_name,
        name_english: `${f.first_name} ${f.last_name}`,
        mobile: `90000100${f.code}`,
        milk_type: f.milk_type,
        village: "Testwadi",
        is_active: true,
        created_by: ownerId,
      })
      .select("id")
      .single();
    if (error) throw error;
    farmerIds.push(data.id as string);
  }

  // collections (last 6 days, both shifts)
  const { count: colCount } = await admin
    .from("collections")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (!colCount) {
    const rows: any[] = [];
    for (let d = 6; d >= 1; d--) {
      for (const [i, fid] of farmerIds.entries()) {
        for (const shift of ["morning", "evening"]) {
          const milk_type = farmerDefs[i].milk_type;
          const fat = milk_type === "cow" ? 3.5 + i * 0.2 : 6 + i * 0.1;
          const snf = 8.5;
          const qty = 8 + i * 2 + (shift === "evening" ? 1 : 0);
          const rate = milk_type === "cow" ? Number((fat * 6 + snf * 1.5).toFixed(2)) : 58;
          rows.push({
            center_id: centerId,
            farmer_id: fid,
            collection_date: daysAgo(d),
            shift,
            milk_type,
            fat: Number(fat.toFixed(1)),
            snf,
            quantity_liters: qty,
            rate_per_liter: rate,
            total_amount: Number((qty * rate).toFixed(2)),
            created_by: ownerId,
          });
        }
      }
    }
    const { error } = await admin.from("collections").insert(rows);
    if (error) throw error;
  }

  // advances (+ one deduction)
  const { count: advCount } = await admin
    .from("advances")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (!advCount) {
    const { data: adv, error } = await admin
      .from("advances")
      .insert([
        {
          center_id: centerId,
          farmer_id: farmerIds[0],
          advance_date: daysAgo(20),
          amount: 5000,
          advance_type: "Monthly Installment",
          monthly_installment_amount: 1000,
          term_months: 5,
          interest_rate: 0,
          comments: "QA installment advance",
          entered_by: ownerId,
        },
        {
          center_id: centerId,
          farmer_id: farmerIds[1],
          advance_date: daysAgo(10),
          amount: 2000,
          advance_type: "One Time",
          interest_rate: 0,
          comments: "QA one-time advance",
          entered_by: ownerId,
        },
      ])
      .select("id, farmer_id");
    if (error) throw error;
    await admin.from("advance_deductions").insert({
      center_id: centerId,
      advance_id: adv![0].id,
      farmer_id: adv![0].farmer_id,
      deduction_date: daysAgo(5),
      amount: 1000,
      source: "Manual",
      comments: "QA deduction",
      entered_by: ownerId,
    });
  }

  // feed dealer / product / stock / sale
  const { data: dealer0 } = await admin
    .from("feed_dealers")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  let dealerId = dealer0?.id as string | undefined;
  if (!dealerId) {
    const { data, error } = await admin
      .from("feed_dealers")
      .insert({
        center_id: centerId,
        dealer_name: "QA Feed Supplies",
        mobile: "9000002001",
        address: "Market Road",
        is_active: true,
      })
      .select("id")
      .single();
    if (error) throw error;
    dealerId = data.id as string;
  }
  const { data: prod0 } = await admin
    .from("feed_products")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  let productId = prod0?.id as string | undefined;
  if (!productId) {
    const { data, error } = await admin
      .from("feed_products")
      .insert({
        center_id: centerId,
        product_name: "Cattle Feed 50kg",
        unit: "bag",
        default_rate: 1250,
        is_active: true,
      })
      .select("id")
      .single();
    if (error) throw error;
    productId = data.id as string;
  }
  const { count: stockCount } = await admin
    .from("feed_stock_purchases")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (!stockCount) {
    await admin.from("feed_stock_purchases").insert({
      center_id: centerId,
      dealer_id: dealerId,
      feed_product_id: productId,
      purchase_date: daysAgo(15),
      quantity: 20,
      rate: 1200,
      amount: 24000,
      receipt_no: "QA-STK-1",
      entered_by: ownerId,
      is_settled: false,
    });
    await admin.from("feed_dealer_payments").insert({
      center_id: centerId,
      dealer_id: dealerId,
      payment_date: daysAgo(7),
      amount: 10000,
      comments: "QA part payment",
      entered_by: ownerId,
    });
    await admin.from("farmer_feed_sales").insert({
      center_id: centerId,
      farmer_id: farmerIds[0],
      feed_product_id: productId,
      sale_date: daysAgo(4),
      quantity: 2,
      rate: 1250,
      amount: 2500,
      receipt_no: "QA-SALE-1",
      cash_payment: false,
      entered_by: ownerId,
      is_settled: false,
    });
  }
}

async function main() {
  const ownerId = await ensureUser({
    phone: "9000000001",
    pin: "1234",
    full_name: "QA Owner",
    role: "owner",
    a1: "blue",
    a2: "mumbai",
  });
  const operatorId = await ensureUser({
    phone: "9000000002",
    pin: "1234",
    full_name: "Test Operator",
    role: "operator",
    a1: "blue",
    a2: "mumbai",
  });

  const c1 = await upsertCenter(ownerId, "QA Dairy One", "QADAIRY1");
  const c2 = await upsertCenter(ownerId, "QA Dairy Two", "QADAIRY2");
  await seedCenterData(c1, ownerId, "QA1");
  await seedCenterData(c2, ownerId, "QA2");

  for (const cid of [c1, c2]) {
    const { data: ex } = await admin
      .from("center_operators")
      .select("id")
      .eq("center_id", cid)
      .eq("operator_id", operatorId)
      .maybeSingle();
    if (ex) {
      await admin
        .from("center_operators")
        .update({ is_active: true, permissions: ALL_PERMS })
        .eq("id", ex.id);
    } else {
      const { error } = await admin
        .from("center_operators")
        .insert({
          center_id: cid,
          operator_id: operatorId,
          is_active: true,
          permissions: ALL_PERMS,
        });
      if (error) throw error;
    }
  }

  console.log(JSON.stringify({ ownerId, operatorId, centers: [c1, c2] }, null, 2));
}

await main();
