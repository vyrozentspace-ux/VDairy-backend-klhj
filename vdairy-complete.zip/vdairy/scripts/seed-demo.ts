/**
 * DEMO seed script (for ad/screenshot recording). Run with:  bun scripts/seed-demo.ts
 *
 * Builds a rich, realistic-looking dataset in ONE center so the app looks
 * "alive" for a demo video: many farmers, a few weeks of collections
 * (morning + evening), rate charts, advances + deductions, feed dealer +
 * stock + farmer feed sales, milk-sale walk-in customers, and — importantly —
 * generated INVOICES/BILLS with a realistic mix of Paid and Unpaid status so
 * the "bill collection" screens have something to show.
 *
 * Idempotent-ish: safe to re-run, but if you want a totally fresh look,
 * delete the demo center from Supabase first (or bump DEMO_CENTER_CODE).
 *
 * Needs env vars:
 *   SUPABASE_URL
 *   SUPABASE_SERVICE_ROLE_KEY
 */
import { createClient } from "@supabase/supabase-js";

const url = process.env.SUPABASE_URL!;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
if (!url || !key) {
  console.error("Missing SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY env vars.");
  process.exit(1);
}

const admin = createClient(url, key, {
  auth: { persistSession: false, autoRefreshToken: false },
  global: {
    fetch: (input: any, init: any = {}) => {
      const headers = new Headers(init.headers);
      if (headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
      headers.set("apikey", key);
      return fetch(input, { ...init, headers });
    },
  },
});

const email = (phone: string) => `${phone}@vdairy.app`;
const pw = (pin: string) => `${pin}-vdairy`;
const iso = (d: Date) => d.toISOString().slice(0, 10);
const daysAgo = (n: number) => iso(new Date(Date.now() - n * 86_400_000));

// ---------------------------------------------------------------------------
// Owner / operator
// ---------------------------------------------------------------------------
async function ensureUser(opts: {
  phone: string;
  pin: string;
  full_name: string;
  role: string;
  a1: string;
  a2: string;
}) {
  const meta = {
    full_name: opts.full_name,
    phone: opts.phone,
    role: opts.role,
    language_preference: "en",
    security_question_1: "What is your favourite colour?",
    security_answer_1: opts.a1,
    security_question_2: "Which city were you born in?",
    security_answer_2: opts.a2,
  };
  const { data: list } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
  const existing = list?.users.find((u) => u.email === email(opts.phone));
  let id: string;
  if (existing) {
    id = existing.id;
    await admin.auth.admin.updateUserById(id, {
      password: pw(opts.pin),
      email_confirm: true,
      user_metadata: meta,
    });
  } else {
    const { data, error } = await admin.auth.admin.createUser({
      email: email(opts.phone),
      password: pw(opts.pin),
      email_confirm: true,
      user_metadata: meta,
    });
    if (error) throw error;
    id = data.user!.id;
  }
  const { error: pErr } = await admin.rpc("create_profile_for_user", {
    _user_id: id,
    _full_name: opts.full_name,
    _phone: opts.phone,
    _role: opts.role,
    _language: "en",
    _q1: meta.security_question_1,
    _a1: opts.a1,
    _q2: meta.security_question_2,
    _a2: opts.a2,
    _referred_by_code: "",
  });
  if (pErr) throw pErr;
  return id;
}

async function upsertCenter(ownerId: string, name: string, code: string) {
  const { data: found } = await admin
    .from("dairy_centers")
    .select("id")
    .eq("code", code)
    .maybeSingle();
  if (found) return found.id as string;
  const { data, error } = await admin
    .from("dairy_centers")
    .insert({
      owner_id: ownerId,
      name,
      code,
      village: "Shivpur",
      taluka: "Baramati",
      district: "Pune",
      state: "Maharashtra",
      pincode: "413102",
      contact_number: "9820012345",
      referral_code: code.slice(0, 8).toUpperCase(),
      default_language: "en",
    })
    .select("id")
    .single();
  if (error) throw error;
  return data.id as string;
}

const ALL_PERMS = {
  collection: true,
  collection_history: true,
  farmer: true,
  food: true,
  advance: true,
  invoice: true,
  invoice_view_only: true,
  milk_sale: true,
  dairy_expense: true,
  rate_chart: true,
  reports: true,
  center_settings: false,
  manage_operators: false,
  send_messages: true,
};

// ---------------------------------------------------------------------------
// Realistic farmer roster (10 farmers, mixed cow/buffalo)
// ---------------------------------------------------------------------------
const FARMERS = [
  { code: "101", first_name: "Ramesh", last_name: "Patil", milk_type: "cow", village: "Shivpur" },
  { code: "102", first_name: "Sunita", last_name: "Jadhav", milk_type: "buffalo", village: "Shivpur" },
  { code: "103", first_name: "Anil", last_name: "Deshmukh", milk_type: "cow", village: "Malegaon" },
  { code: "104", first_name: "Kavita", last_name: "More", milk_type: "buffalo", village: "Shivpur" },
  { code: "105", first_name: "Sanjay", last_name: "Shinde", milk_type: "cow", village: "Kadegaon" },
  { code: "106", first_name: "Meena", last_name: "Kale", milk_type: "cow", village: "Malegaon" },
  { code: "107", first_name: "Vitthal", last_name: "Gaikwad", milk_type: "buffalo", village: "Kadegaon" },
  { code: "108", first_name: "Pooja", last_name: "Bhosale", milk_type: "cow", village: "Shivpur" },
  { code: "109", first_name: "Dattatray", last_name: "Pawar", milk_type: "buffalo", village: "Malegaon" },
  { code: "110", first_name: "Rekha", last_name: "Chavan", milk_type: "cow", village: "Kadegaon" },
];

async function seedFarmers(centerId: string, ownerId: string) {
  const ids: string[] = [];
  for (const f of FARMERS) {
    const { data: ex } = await admin
      .from("farmers")
      .select("id")
      .eq("center_id", centerId)
      .eq("code", f.code)
      .maybeSingle();
    if (ex) {
      ids.push(ex.id as string);
      continue;
    }
    const { data, error } = await admin
      .from("farmers")
      .insert({
        center_id: centerId,
        code: f.code,
        first_name: f.first_name,
        last_name: f.last_name,
        name_english: `${f.first_name} ${f.last_name}`,
        mobile: `98${f.code}100${f.code.slice(-2)}45`.slice(0, 10),
        milk_type: f.milk_type,
        village: f.village,
        is_active: true,
        created_by: ownerId,
      })
      .select("id")
      .single();
    if (error) throw error;
    ids.push(data.id as string);
  }
  return ids;
}

// ---------------------------------------------------------------------------
// Settings, subscription, rate chart
// ---------------------------------------------------------------------------
async function seedSettings(centerId: string) {
  const { data: cs } = await admin
    .from("center_collection_settings")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  if (!cs) {
    await admin.from("center_collection_settings").insert({
      center_id: centerId,
      calculation_mode: "rate_chart",
      payment_period: "01-10, 11-20, 21-ME",
      payment_period_start_date: daysAgo(45),
      morning_start_time: "05:00",
      morning_end_time: "10:00",
      evening_start_time: "16:00",
      evening_end_time: "20:00",
      default_cow_rate: 34,
      default_buffalo_rate: 58,
      default_milk_sale_rate: 60,
    });
  }
  const { data: sub } = await admin
    .from("center_subscriptions")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  if (!sub) await admin.from("center_subscriptions").insert({ center_id: centerId });
}

async function seedRateChart(centerId: string, milkType: "cow" | "buffalo", baseRate: number) {
  const { data: rc0 } = await admin
    .from("rate_charts")
    .select("id")
    .eq("center_id", centerId)
    .eq("milk_type", milkType)
    .maybeSingle();
  if (rc0) return rc0.id as string;
  const { data: rc, error } = await admin
    .from("rate_charts")
    .insert({
      center_id: centerId,
      milk_type: milkType,
      chart_name: `${milkType === "cow" ? "Cow" : "Buffalo"} Standard Chart`,
      is_active: true,
      base_rate: baseRate,
      fat_min: milkType === "cow" ? 3 : 5,
      fat_max: milkType === "cow" ? 5 : 8,
      fat_step: 0.5,
      snf_min: 8,
      snf_max: 9.5,
      snf_step: 0.5,
    })
    .select("id")
    .single();
  if (error) throw error;
  const chartId = rc.id as string;
  const rows: any[] = [];
  const fatMin = milkType === "cow" ? 3 : 5;
  const fatMax = milkType === "cow" ? 5 : 8;
  for (let fat = fatMin; fat <= fatMax + 0.001; fat += 0.5) {
    for (let snf = 8; snf <= 9.5001; snf += 0.5) {
      rows.push({
        rate_chart_id: chartId,
        fat_value: Number(fat.toFixed(1)),
        snf_value: Number(snf.toFixed(1)),
        rate: Number((fat * 6 + snf * 1.5).toFixed(2)),
      });
    }
  }
  await admin.from("rate_chart_rows").insert(rows);
  return chartId;
}

// ---------------------------------------------------------------------------
// Collections — 20 days, morning + evening, every farmer
// ---------------------------------------------------------------------------
async function seedCollections(centerId: string, ownerId: string, farmerIds: string[]) {
  const { count } = await admin
    .from("collections")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (count) return;

  const rows: any[] = [];
  for (let d = 20; d >= 1; d--) {
    for (const [i, fid] of farmerIds.entries()) {
      const milk_type = FARMERS[i].milk_type as "cow" | "buffalo";
      for (const shift of ["morning", "evening"] as const) {
        // small day-to-day variance so charts/reports look real
        const wobble = Math.sin(d + i) * 0.3;
        const fat =
          milk_type === "cow" ? 3.4 + (i % 4) * 0.3 + wobble : 6.0 + (i % 4) * 0.25 + wobble;
        const snf = 8.4 + ((i + d) % 3) * 0.3;
        const baseQty = 6 + (i % 5) * 1.5;
        const qty = Number((baseQty + (shift === "evening" ? 1.2 : 0) + Math.abs(wobble)).toFixed(1));
        const rate = Number((fat * 6 + snf * 1.5).toFixed(2));
        rows.push({
          center_id: centerId,
          farmer_id: fid,
          collection_date: daysAgo(d),
          shift,
          milk_type,
          fat: Number(fat.toFixed(1)),
          snf: Number(snf.toFixed(1)),
          quantity_liters: qty,
          rate_per_liter: rate,
          total_amount: Number((qty * rate).toFixed(2)),
          created_by: ownerId,
        });
      }
    }
  }
  // insert in chunks to avoid payload limits
  for (let i = 0; i < rows.length; i += 200) {
    const { error } = await admin.from("collections").insert(rows.slice(i, i + 200));
    if (error) throw error;
  }
}

// ---------------------------------------------------------------------------
// Advances + deductions across several farmers
// ---------------------------------------------------------------------------
async function seedAdvances(centerId: string, ownerId: string, farmerIds: string[]) {
  const { count } = await admin
    .from("advances")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (count) return;

  const plans = [
    { idx: 0, amount: 10000, type: "Monthly Installment", monthly: 2000, term: 5, daysAgoAdv: 40 },
    { idx: 1, amount: 3000, type: "One Time", monthly: null, term: null, daysAgoAdv: 15 },
    { idx: 3, amount: 8000, type: "Monthly Installment", monthly: 1500, term: 6, daysAgoAdv: 25 },
    { idx: 5, amount: 4000, type: "One Time", monthly: null, term: null, daysAgoAdv: 10 },
    { idx: 7, amount: 6000, type: "Monthly Installment", monthly: 1000, term: 6, daysAgoAdv: 35 },
  ];

  const inserted: { id: string; farmer_id: string }[] = [];
  for (const p of plans) {
    const { data, error } = await admin
      .from("advances")
      .insert({
        center_id: centerId,
        farmer_id: farmerIds[p.idx],
        advance_date: daysAgo(p.daysAgoAdv),
        amount: p.amount,
        advance_type: p.type,
        monthly_installment_amount: p.monthly,
        term_months: p.term,
        interest_rate: 0,
        comments: p.type === "One Time" ? "Cattle feed emergency" : "Cattle purchase support",
        entered_by: ownerId,
      })
      .select("id, farmer_id")
      .single();
    if (error) throw error;
    inserted.push(data as any);
  }

  // deductions against a couple of the installment advances
  const deductions = [
    { advIdx: 0, amount: 2000, daysAgoDed: 15 },
    { advIdx: 0, amount: 2000, daysAgoDed: 3 },
    { advIdx: 2, amount: 1500, daysAgoDed: 8 },
  ];
  for (const d of deductions) {
    const adv = inserted[d.advIdx];
    await admin.from("advance_deductions").insert({
      center_id: centerId,
      advance_id: adv.id,
      farmer_id: adv.farmer_id,
      deduction_date: daysAgo(d.daysAgoDed),
      amount: d.amount,
      source: "Manual",
      comments: "Installment deduction",
      entered_by: ownerId,
    });
  }
}

// ---------------------------------------------------------------------------
// Feed dealer, products, stock purchases, dealer payments, farmer feed sales
// ---------------------------------------------------------------------------
async function seedFeed(centerId: string, ownerId: string, farmerIds: string[]) {
  const { data: dealer0 } = await admin
    .from("feed_dealers")
    .select("id")
    .eq("center_id", centerId)
    .maybeSingle();
  let dealerId = dealer0?.id as string | undefined;
  if (!dealerId) {
    const { data, error } = await admin
      .from("feed_dealers")
      .insert({
        center_id: centerId,
        dealer_name: "Shivpur Krishi Kendra",
        mobile: "9822011223",
        address: "Main Market Road, Shivpur",
        is_active: true,
      })
      .select("id")
      .single();
    if (error) throw error;
    dealerId = data.id as string;
  }

  const productDefs = [
    { name: "Cattle Feed 50kg", unit: "bag", rate: 1250 },
    { name: "Mineral Mixture 5kg", unit: "packet", rate: 320 },
  ];
  const productIds: string[] = [];
  for (const p of productDefs) {
    const { data: ex } = await admin
      .from("feed_products")
      .select("id")
      .eq("center_id", centerId)
      .eq("product_name", p.name)
      .maybeSingle();
    if (ex) {
      productIds.push(ex.id as string);
      continue;
    }
    const { data, error } = await admin
      .from("feed_products")
      .insert({
        center_id: centerId,
        product_name: p.name,
        unit: p.unit,
        default_rate: p.rate,
        is_active: true,
      })
      .select("id")
      .single();
    if (error) throw error;
    productIds.push(data.id as string);
  }

  const { count: stockCount } = await admin
    .from("feed_stock_purchases")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (!stockCount) {
    await admin.from("feed_stock_purchases").insert([
      {
        center_id: centerId,
        dealer_id: dealerId,
        feed_product_id: productIds[0],
        purchase_date: daysAgo(30),
        quantity: 40,
        rate: 1200,
        amount: 48000,
        receipt_no: "STK-1001",
        entered_by: ownerId,
        is_settled: false,
      },
      {
        center_id: centerId,
        dealer_id: dealerId,
        feed_product_id: productIds[1],
        purchase_date: daysAgo(20),
        quantity: 25,
        rate: 300,
        amount: 7500,
        receipt_no: "STK-1002",
        entered_by: ownerId,
        is_settled: false,
      },
    ]);
    await admin.from("feed_dealer_payments").insert([
      {
        center_id: centerId,
        dealer_id: dealerId,
        payment_date: daysAgo(18),
        amount: 25000,
        comments: "Part payment - cash",
        entered_by: ownerId,
      },
      {
        center_id: centerId,
        dealer_id: dealerId,
        payment_date: daysAgo(5),
        amount: 15000,
        comments: "Part payment - UPI",
        entered_by: ownerId,
      },
    ]);
  }

  const { count: saleCount } = await admin
    .from("farmer_feed_sales")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (!saleCount) {
    const saleDefs = [
      { idx: 0, prod: 0, qty: 2, daysAgoSale: 18, cash: false, receipt: "SALE-2001" },
      { idx: 1, prod: 0, qty: 1, daysAgoSale: 12, cash: true, receipt: "SALE-2002" },
      { idx: 2, prod: 1, qty: 3, daysAgoSale: 9, cash: false, receipt: "SALE-2003" },
      { idx: 4, prod: 0, qty: 2, daysAgoSale: 6, cash: false, receipt: "SALE-2004" },
      { idx: 6, prod: 1, qty: 2, daysAgoSale: 3, cash: true, receipt: "SALE-2005" },
    ];
    const rows = saleDefs.map((s) => {
      const rate = productDefs[s.prod].rate;
      return {
        center_id: centerId,
        farmer_id: farmerIds[s.idx],
        feed_product_id: productIds[s.prod],
        sale_date: daysAgo(s.daysAgoSale),
        quantity: s.qty,
        rate,
        amount: s.qty * rate,
        receipt_no: s.receipt,
        cash_payment: s.cash,
        entered_by: ownerId,
        is_settled: s.cash,
      };
    });
    await admin.from("farmer_feed_sales").insert(rows);
  }
}

// ---------------------------------------------------------------------------
// Milk-sale walk-in customers (retail milk sales, separate from farmer collection)
// ---------------------------------------------------------------------------
async function seedMilkSales(centerId: string, ownerId: string) {
  const { data: existingCustomers } = await admin
    .from("milk_sale_customers")
    .select("id, name")
    .eq("center_id", centerId);
  let customers = existingCustomers ?? [];
  if (customers.length === 0) {
    const defs = [
      { name: "Ganesh Hotel", mobile: "9765432101", address: "Station Road" },
      { name: "Shraddha Sweets", mobile: "9765432102", address: "Main Bazar" },
      { name: "Om Sai Milk Booth", mobile: "9765432103", address: "Bus Stand" },
    ];
    const { data, error } = await admin
      .from("milk_sale_customers")
      .insert(defs.map((d) => ({ center_id: centerId, ...d })))
      .select("id, name");
    if (error) throw error;
    customers = data ?? [];
  }

  const { count: salesCount } = await admin
    .from("milk_sales")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (salesCount) return;

  const rows: any[] = [];
  for (let d = 10; d >= 1; d--) {
    for (const [i, c] of customers.entries()) {
      const qty = 5 + i * 2;
      const rate = 60;
      const paid = d % 3 !== 0; // most paid, some pending -> good for "collection" demo
      rows.push({
        center_id: centerId,
        customer_id: c.id,
        walk_in_name: null,
        walk_in_mobile: null,
        sale_date: daysAgo(d),
        session: d % 2 === 0 ? "morning" : "evening",
        quantity_liters: qty,
        rate_per_liter: rate,
        total_amount: qty * rate,
        payment_status: paid ? "paid" : "unpaid",
        payment_mode: paid ? (i % 2 === 0 ? "cash" : "upi") : null,
        created_by: ownerId,
      });
    }
  }
  // a couple of walk-in (non-registered) buyers too
  rows.push({
    center_id: centerId,
    customer_id: null,
    walk_in_name: "Walk-in Customer",
    walk_in_mobile: "9765400000",
    sale_date: daysAgo(2),
    session: "evening",
    quantity_liters: 3,
    rate_per_liter: 60,
    total_amount: 180,
    payment_status: "paid",
    payment_mode: "cash",
    created_by: ownerId,
  });
  const { error } = await admin.from("milk_sales").insert(rows);
  if (error) throw error;
}

// ---------------------------------------------------------------------------
// Invoices / BILLS — generate for last 2 terciles, mark some paid, some unpaid
// This is the key part for a "bill collection" demo.
// ---------------------------------------------------------------------------
function terciles(): { start: string; end: string }[] {
  // Build the last 4 ten-day billing periods ending today, going backwards.
  const out: { start: string; end: string }[] = [];
  const today = new Date();
  for (let block = 3; block >= 0; block--) {
    const end = new Date(today.getTime() - block * 10 * 86_400_000);
    const start = new Date(end.getTime() - 9 * 86_400_000);
    out.push({ start: iso(start), end: iso(end) });
  }
  return out;
}

async function seedInvoices(centerId: string, ownerId: string, farmerIds: string[]) {
  const { count } = await admin
    .from("invoices")
    .select("id", { count: "exact", head: true })
    .eq("center_id", centerId);
  if (count) {
    console.log("Invoices already present, skipping bill generation.");
    return;
  }

  const periods = terciles();
  let generated = 0;
  let paidCount = 0;

  for (const period of periods) {
    for (const farmerId of farmerIds) {
      try {
        const { data: invoiceId, error } = await admin.rpc("generate_invoice", {
          p_center_id: centerId,
          p_farmer_id: farmerId,
          p_period_start: period.start,
          p_period_end: period.end,
          p_created_by: ownerId,
        });
        if (error) {
          // no activity in this period for this farmer, or already exists — skip quietly
          continue;
        }
        generated++;
        // Mark ~60% of bills as paid to give a realistic mix for the
        // "bill collection" / dues screens, biasing older periods more paid.
        const shouldPay = Math.random() < 0.6;
        if (shouldPay && invoiceId) {
          const { error: payErr } = await admin.rpc("mark_invoice_paid", {
            p_invoice_id: invoiceId,
          });
          if (!payErr) paidCount++;
        }
      } catch {
        continue;
      }
    }
  }
  console.log(`Generated ${generated} invoices, marked ${paidCount} as paid.`);
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main() {
  const ownerId = await ensureUser({
    phone: "9820000001",
    pin: "1234",
    full_name: "Demo Dairy Owner",
    role: "owner",
    a1: "blue",
    a2: "pune",
  });
  const operatorId = await ensureUser({
    phone: "9820000002",
    pin: "1234",
    full_name: "Demo Operator",
    role: "operator",
    a1: "blue",
    a2: "pune",
  });

  const centerId = await upsertCenter(ownerId, "Shivpur Dairy Collection Center", "SHIVPUR01");

  await seedSettings(centerId);
  await seedRateChart(centerId, "cow", 34);
  await seedRateChart(centerId, "buffalo", 58);

  const farmerIds = await seedFarmers(centerId, ownerId);
  await seedCollections(centerId, ownerId, farmerIds);
  await seedAdvances(centerId, ownerId, farmerIds);
  await seedFeed(centerId, ownerId, farmerIds);
  await seedMilkSales(centerId, ownerId);
  await seedInvoices(centerId, ownerId, farmerIds);

  const { data: ex } = await admin
    .from("center_operators")
    .select("id")
    .eq("center_id", centerId)
    .eq("operator_id", operatorId)
    .maybeSingle();
  if (ex) {
    await admin
      .from("center_operators")
      .update({ is_active: true, permissions: ALL_PERMS })
      .eq("id", ex.id);
  } else {
    const { error } = await admin.from("center_operators").insert({
      center_id: centerId,
      operator_id: operatorId,
      is_active: true,
      permissions: ALL_PERMS,
    });
    if (error) throw error;
  }

  console.log(
    JSON.stringify(
      {
        ownerLogin: { phone: "9820000001", pin: "1234" },
        operatorLogin: { phone: "9820000002", pin: "1234" },
        centerId,
        farmerCount: farmerIds.length,
      },
      null,
      2,
    ),
  );
}

await main();
