package app.vdairy.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
